�i
:
rules_varlinkvarlink/privaterust_varlink_library.bzl�frust_varlink_library�	Generate a Rust library from a varlink_library target.

Builds a Rust library crate.

Example:

Suppose you have the following directory structure for a simple Rust library crate:

```output
[workspace]/
    WORKSPACE
    hello_lib/
        BUILD
        src/
            greeter.rs
            lib.rs
```

`hello_lib/src/greeter.rs`:
```rust
pub struct Greeter {
    greeting: String,
}

impl Greeter {
    pub fn new(greeting: &str) -> Greeter {
        Greeter { greeting: greeting.to_string(), }
    }

    pub fn greet(&self, thing: &str) {
        println!("{} {}", &self.greeting, thing);
    }
}
```

`hello_lib/src/lib.rs`:

```rust
pub mod greeter;
```

`hello_lib/BUILD`:
```python
package(default_visibility = ["//visibility:public"])

load("@rules_rust//rust:defs.bzl", "rust_library")

rust_library(
    name = "hello_lib",
    srcs = [
        "src/greeter.rs",
        "src/lib.rs",
    ],
)
```

Build the library:
```output
$ bazel build //hello_lib
INFO: Found 1 target...
Target //examples/rust/hello_lib:hello_lib up-to-date:
bazel-bin/examples/rust/hello_lib/libhello_lib.rlib
INFO: Elapsed time: 1.245s, Critical Path: 1.01s
```
"�]
�2
rust_varlink_library�	Generate a Rust library from a varlink_library target.

Builds a Rust library crate.

Example:

Suppose you have the following directory structure for a simple Rust library crate:

```output
[workspace]/
    WORKSPACE
    hello_lib/
        BUILD
        src/
            greeter.rs
            lib.rs
```

`hello_lib/src/greeter.rs`:
```rust
pub struct Greeter {
    greeting: String,
}

impl Greeter {
    pub fn new(greeting: &str) -> Greeter {
        Greeter { greeting: greeting.to_string(), }
    }

    pub fn greet(&self, thing: &str) {
        println!("{} {}", &self.greeting, thing);
    }
}
```

`hello_lib/src/lib.rs`:

```rust
pub mod greeter;
```

`hello_lib/BUILD`:
```python
package(default_visibility = ["//visibility:public"])

load("@rules_rust//rust:defs.bzl", "rust_library")

rust_library(
    name = "hello_lib",
    srcs = [
        "src/greeter.rs",
        "src/lib.rs",
    ],
)
```

Build the library:
```output
$ bazel build //hello_lib
INFO: Found 1 target...
Target //examples/rust/hello_lib:hello_lib up-to-date:
bazel-bin/examples/rust/hello_lib/libhello_lib.rlib
INFO: Elapsed time: 1.245s, Critical Path: 1.01s
```
*
nameA unique name for this target. �
aliases�Remap crates to a new name or moniker for linkage to this target

These are other `rust_library` targets and will be presented as the new name given.
	2{}�

alwayslink�If 1, any binary that depends (directly or indirectly) on this library
will link in all the object files even if some contain no symbols referenced by the binary.

This attribute is used by the C++ Starlark API when passing CcInfo providers.
2False�
compile_data�List of files used by this rule at compile time.

This attribute can be used to specify any data files that are embedded into
the library, such as via the
[`include_str!`](https://doc.rust-lang.org/std/macro.include_str!.html)
macro.
2[]�
crate_features�List of features to enable for this crate.

Features are defined in the code using the `#[cfg(feature = "foo")]`
configuration option. The features listed here will be passed to `rustc`
with `--cfg feature="${feature_name}"` flags.
2[]�

crate_name�Crate name to use for this target.

This must be a valid Rust identifier, i.e. it may contain only alphanumeric characters and underscores.
Defaults to the target name, with any hyphens replaced by underscores.
2""�

crate_root�The file that will be passed to `rustc` to be used for building this crate.

If `crate_root` is not set, then this rule will look for a `lib.rs` file (or `main.rs` for rust_binary)
or the single file in `srcs` if `srcs` contains only one file.
2None�
data�List of files used by this rule at compile time and runtime.

If including data at compile time with include_str!() and similar,
prefer `compile_data` over `data`, to prevent the data also being included
in the runfiles.
2[]�
deps�List of other libraries to be linked to this library target.

These can be either other `rust_library` targets or `cc_library` targets if
linking a native library.
2[]�
disable_pipelining�Disables pipelining for this rule if it is globally enabled.
This will cause this rule to not produce a `.rmeta` file and all the dependent
crates will instead use the `.rlib` file.
2Falseq
edition`The rust edition to use for this crate. Defaults to the edition specified in the rust_toolchain.2""p
proc_macro_depsJList of `rust_proc_macro` targets used to help build this library target.
*
	CrateInfo2[]�
	rustc_env�Dictionary of additional `"key": "value"` environment variables to set for rustc.

rust_test()/rust_binary() rules can use $(rootpath //package:target) to pass in the
location of a generated file or external tool. Cargo build scripts that wish to
expand locations should use cargo_build_script()'s build_script_env argument instead,
as build scripts are run in a different environment - see cargo_build_script()'s
documentation for more.

2{}�
rustc_env_files�Files containing additional environment variables to set for rustc.

These files should  contain a single variable per line, of format
`NAME=value`, and newlines may be included in a value by ending a
line with a trailing back-slash (`\\`).

The order that these files will be processed is unspecified, so
multiple definitions of a particular variable are discouraged.

Note that the variables here are subject to
[workspace status](https://docs.bazel.build/versions/main/user-manual.html#workspace_status)
stamping should the `stamp` attribute be enabled. Stamp variables
should be wrapped in brackets in order to be resolved. E.g.
`NAME={WORKSPACE_STATUS_VARIABLE}`.
2[]�
rustc_flags�List of compiler flags passed to `rustc`.

These strings are subject to Make variable expansion for predefined
source/output path variables like `$location`, `$execpath`, and
`$rootpath`. This expansion is useful if you wish to pass a generated
file of arguments to rustc: `@$(location //package:target)`.
2[]�
srcs�List of Rust `.rs` source files used to build the library.

If `srcs` contains more than one file, then there must be a file either
named `lib.rs`. Otherwise, `crate_root` must be set to the source file that
is the root of the crate to be passed to rustc to build this crate.
2[]�
stamp�Whether to encode build information into the `Rustc` action. Possible values:

- `stamp = 1`: Always stamp the build information into the `Rustc` action, even in             [--nostamp](https://docs.bazel.build/versions/main/user-manual.html#flag--stamp) builds.             This setting should be avoided, since it potentially kills remote caching for the target and             any downstream actions that depend on it.

- `stamp = 0`: Always replace build information by constant values. This gives good build result caching.

- `stamp = -1`: Embedding of build information is controlled by the             [--[no]stamp](https://docs.bazel.build/versions/main/user-manual.html#flag--stamp) flag.

Stamped targets are not rebuilt unless their dependencies change.

For example if a `rust_library` is stamped, and a `rust_binary` depends on that library, the stamped
library won't be rebuilt when we change sources of the `rust_binary`. This is different from how
[`cc_library.linkstamps`](https://docs.bazel.build/versions/main/be/c-cpp.html#cc_library.linkstamp)
behaves.
20L
version6A version to inject in the cargo environment variable.2"0.0.0"
66,
*
nameA unique name for this target. �
�
aliases�Remap crates to a new name or moniker for linkage to this target

These are other `rust_library` targets and will be presented as the new name given.
	2{}�
�

alwayslink�If 1, any binary that depends (directly or indirectly) on this library
will link in all the object files even if some contain no symbols referenced by the binary.

This attribute is used by the C++ Starlark API when passing CcInfo providers.
2False�
�
compile_data�List of files used by this rule at compile time.

This attribute can be used to specify any data files that are embedded into
the library, such as via the
[`include_str!`](https://doc.rust-lang.org/std/macro.include_str!.html)
macro.
2[]�
�
crate_features�List of features to enable for this crate.

Features are defined in the code using the `#[cfg(feature = "foo")]`
configuration option. The features listed here will be passed to `rustc`
with `--cfg feature="${feature_name}"` flags.
2[]�
�

crate_name�Crate name to use for this target.

This must be a valid Rust identifier, i.e. it may contain only alphanumeric characters and underscores.
Defaults to the target name, with any hyphens replaced by underscores.
2""�
�

crate_root�The file that will be passed to `rustc` to be used for building this crate.

If `crate_root` is not set, then this rule will look for a `lib.rs` file (or `main.rs` for rust_binary)
or the single file in `srcs` if `srcs` contains only one file.
2None�
�
data�List of files used by this rule at compile time and runtime.

If including data at compile time with include_str!() and similar,
prefer `compile_data` over `data`, to prevent the data also being included
in the runfiles.
2[]�
�
deps�List of other libraries to be linked to this library target.

These can be either other `rust_library` targets or `cc_library` targets if
linking a native library.
2[]�
�
disable_pipelining�Disables pipelining for this rule if it is globally enabled.
This will cause this rule to not produce a `.rmeta` file and all the dependent
crates will instead use the `.rlib` file.
2Falses
q
edition`The rust edition to use for this crate. Defaults to the edition specified in the rust_toolchain.2""r
p
proc_macro_depsJList of `rust_proc_macro` targets used to help build this library target.
*
	CrateInfo2[]�
�
	rustc_env�Dictionary of additional `"key": "value"` environment variables to set for rustc.

rust_test()/rust_binary() rules can use $(rootpath //package:target) to pass in the
location of a generated file or external tool. Cargo build scripts that wish to
expand locations should use cargo_build_script()'s build_script_env argument instead,
as build scripts are run in a different environment - see cargo_build_script()'s
documentation for more.

2{}�
�
rustc_env_files�Files containing additional environment variables to set for rustc.

These files should  contain a single variable per line, of format
`NAME=value`, and newlines may be included in a value by ending a
line with a trailing back-slash (`\\`).

The order that these files will be processed is unspecified, so
multiple definitions of a particular variable are discouraged.

Note that the variables here are subject to
[workspace status](https://docs.bazel.build/versions/main/user-manual.html#workspace_status)
stamping should the `stamp` attribute be enabled. Stamp variables
should be wrapped in brackets in order to be resolved. E.g.
`NAME={WORKSPACE_STATUS_VARIABLE}`.
2[]�
�
rustc_flags�List of compiler flags passed to `rustc`.

These strings are subject to Make variable expansion for predefined
source/output path variables like `$location`, `$execpath`, and
`$rootpath`. This expansion is useful if you wish to pass a generated
file of arguments to rustc: `@$(location //package:target)`.
2[]�
�
srcs�List of Rust `.rs` source files used to build the library.

If `srcs` contains more than one file, then there must be a file either
named `lib.rs`. Otherwise, `crate_root` must be set to the source file that
is the root of the crate to be passed to rustc to build this crate.
2[]�
�
stamp�Whether to encode build information into the `Rustc` action. Possible values:

- `stamp = 1`: Always stamp the build information into the `Rustc` action, even in             [--nostamp](https://docs.bazel.build/versions/main/user-manual.html#flag--stamp) builds.             This setting should be avoided, since it potentially kills remote caching for the target and             any downstream actions that depend on it.

- `stamp = 0`: Always replace build information by constant values. This gives good build result caching.

- `stamp = -1`: Embedding of build information is controlled by the             [--[no]stamp](https://docs.bazel.build/versions/main/user-manual.html#flag--stamp) flag.

Stamped targets are not rebuilt unless their dependencies change.

For example if a `rust_library` is stamped, and a `rust_binary` depends on that library, the stamped
library won't be rebuilt when we change sources of the `rust_binary`. This is different from how
[`cc_library.linkstamps`](https://docs.bazel.build/versions/main/be/c-cpp.html#cc_library.linkstamp)
behaves.
20N
L
version6A version to inject in the cargo environment variable.2"0.0.0"w
//rs:rust_library.bzlr\
 
rules_rsrsrust_library.bzl*
rust_libraryrust_library
)5
7~
//varlink:providers.bzlra
'
rules_varlinkvarlinkproviders.bzl(
VarlinkInfoVarlinkInfo
0;
=Srust_varlink_library macro: generates a rust_library from a varlink_library target.�
5
rules_varlinkvarlink/privatevarlink_library.bzl�varlink_library-Declares a Varlink interface definition file."�
�
varlink_library-Declares a Varlink interface definition file.*
nameA unique name for this target. V
deps9Other varlink_library targets imported by this interface.*
VarlinkInfo2[]2
src'The .varlink interface definition file. "G
varlink_library4@@rules_varlink//varlink/private:varlink_library.bzl
,
*
nameA unique name for this target. X
V
deps9Other varlink_library targets imported by this interface.*
VarlinkInfo2[]4
2
src'The .varlink interface definition file. ~
//varlink:providers.bzlra
'
rules_varlinkvarlinkproviders.bzl(
VarlinkInfoVarlinkInfo
0;
=Dvarlink_library rule: carries .varlink source files via VarlinkInfo.�
2
rules_varlinkvarlink/privatevarlink_lint.bzl�varlink_lint�Validate a varlink_library interface file at build time.

Runs the varlink-rust-generator with --nosource and discards output,
producing a sentinel file on success.  Build errors surface before any
Rust compilation starts.
*�
�
varlink_lint<
name0target name; the sentinel output is <name>.lint. (?
	interface.label of a varlink_library target to validate. (4

visibilitypassed through to the genrule.None(%
kwargsforwarded to the genrule.(�Validate a varlink_library interface file at build time.

Runs the varlink-rust-generator with --nosource and discards output,
producing a sentinel file on success.  Build errors surface before any
Rust compilation starts.
2A
varlink_lint1@@rules_varlink//varlink/private:varlink_lint.bzl
*native.genrule2native.genruleOvarlink_lint rule: validates a .varlink interface file without generating code.�
3
rules_varlinkvarlink/toolchainmusl_binary.bzl�musl_binary@Wraps an executable, building it (and all deps) for static musl."�
�
musl_binary@Wraps an executable, building it (and all deps) for static musl.*
nameA unique name for this target. 
binary "A
musl_binary2@@rules_varlink//varlink/toolchain:musl_binary.bzl
,
*
nameA unique name for this target. 

binary �musl_binary: wraps a rust_binary and builds it for x86_64-unknown-linux-musl.

Using the musl platform for exec tools avoids the glibc/libcxx runtime on NixOS
hosts where the LLVM CC toolchain's libcxx.static link-order differs from
what rustc generates.
�u
"
rules_varlinkvarlinkdefs.bzl�varlink_library-Declares a Varlink interface definition file."�
�
varlink_library-Declares a Varlink interface definition file.*
nameA unique name for this target. V
deps9Other varlink_library targets imported by this interface.*
VarlinkInfo2[]2
src'The .varlink interface definition file. "4
varlink_library!@@rules_varlink//varlink:defs.bzl
,
*
nameA unique name for this target. X
V
deps9Other varlink_library targets imported by this interface.*
VarlinkInfo2[]4
2
src'The .varlink interface definition file. �frust_varlink_library�	Generate a Rust library from a varlink_library target.

Builds a Rust library crate.

Example:

Suppose you have the following directory structure for a simple Rust library crate:

```output
[workspace]/
    WORKSPACE
    hello_lib/
        BUILD
        src/
            greeter.rs
            lib.rs
```

`hello_lib/src/greeter.rs`:
```rust
pub struct Greeter {
    greeting: String,
}

impl Greeter {
    pub fn new(greeting: &str) -> Greeter {
        Greeter { greeting: greeting.to_string(), }
    }

    pub fn greet(&self, thing: &str) {
        println!("{} {}", &self.greeting, thing);
    }
}
```

`hello_lib/src/lib.rs`:

```rust
pub mod greeter;
```

`hello_lib/BUILD`:
```python
package(default_visibility = ["//visibility:public"])

load("@rules_rust//rust:defs.bzl", "rust_library")

rust_library(
    name = "hello_lib",
    srcs = [
        "src/greeter.rs",
        "src/lib.rs",
    ],
)
```

Build the library:
```output
$ bazel build //hello_lib
INFO: Found 1 target...
Target //examples/rust/hello_lib:hello_lib up-to-date:
bazel-bin/examples/rust/hello_lib/libhello_lib.rlib
INFO: Elapsed time: 1.245s, Critical Path: 1.01s
```
"�]
�2
rust_varlink_library�	Generate a Rust library from a varlink_library target.

Builds a Rust library crate.

Example:

Suppose you have the following directory structure for a simple Rust library crate:

```output
[workspace]/
    WORKSPACE
    hello_lib/
        BUILD
        src/
            greeter.rs
            lib.rs
```

`hello_lib/src/greeter.rs`:
```rust
pub struct Greeter {
    greeting: String,
}

impl Greeter {
    pub fn new(greeting: &str) -> Greeter {
        Greeter { greeting: greeting.to_string(), }
    }

    pub fn greet(&self, thing: &str) {
        println!("{} {}", &self.greeting, thing);
    }
}
```

`hello_lib/src/lib.rs`:

```rust
pub mod greeter;
```

`hello_lib/BUILD`:
```python
package(default_visibility = ["//visibility:public"])

load("@rules_rust//rust:defs.bzl", "rust_library")

rust_library(
    name = "hello_lib",
    srcs = [
        "src/greeter.rs",
        "src/lib.rs",
    ],
)
```

Build the library:
```output
$ bazel build //hello_lib
INFO: Found 1 target...
Target //examples/rust/hello_lib:hello_lib up-to-date:
bazel-bin/examples/rust/hello_lib/libhello_lib.rlib
INFO: Elapsed time: 1.245s, Critical Path: 1.01s
```
*
nameA unique name for this target. �
aliases�Remap crates to a new name or moniker for linkage to this target

These are other `rust_library` targets and will be presented as the new name given.
	2{}�

alwayslink�If 1, any binary that depends (directly or indirectly) on this library
will link in all the object files even if some contain no symbols referenced by the binary.

This attribute is used by the C++ Starlark API when passing CcInfo providers.
2False�
compile_data�List of files used by this rule at compile time.

This attribute can be used to specify any data files that are embedded into
the library, such as via the
[`include_str!`](https://doc.rust-lang.org/std/macro.include_str!.html)
macro.
2[]�
crate_features�List of features to enable for this crate.

Features are defined in the code using the `#[cfg(feature = "foo")]`
configuration option. The features listed here will be passed to `rustc`
with `--cfg feature="${feature_name}"` flags.
2[]�

crate_name�Crate name to use for this target.

This must be a valid Rust identifier, i.e. it may contain only alphanumeric characters and underscores.
Defaults to the target name, with any hyphens replaced by underscores.
2""�

crate_root�The file that will be passed to `rustc` to be used for building this crate.

If `crate_root` is not set, then this rule will look for a `lib.rs` file (or `main.rs` for rust_binary)
or the single file in `srcs` if `srcs` contains only one file.
2None�
data�List of files used by this rule at compile time and runtime.

If including data at compile time with include_str!() and similar,
prefer `compile_data` over `data`, to prevent the data also being included
in the runfiles.
2[]�
deps�List of other libraries to be linked to this library target.

These can be either other `rust_library` targets or `cc_library` targets if
linking a native library.
2[]�
disable_pipelining�Disables pipelining for this rule if it is globally enabled.
This will cause this rule to not produce a `.rmeta` file and all the dependent
crates will instead use the `.rlib` file.
2Falseq
edition`The rust edition to use for this crate. Defaults to the edition specified in the rust_toolchain.2""p
proc_macro_depsJList of `rust_proc_macro` targets used to help build this library target.
*
	CrateInfo2[]�
	rustc_env�Dictionary of additional `"key": "value"` environment variables to set for rustc.

rust_test()/rust_binary() rules can use $(rootpath //package:target) to pass in the
location of a generated file or external tool. Cargo build scripts that wish to
expand locations should use cargo_build_script()'s build_script_env argument instead,
as build scripts are run in a different environment - see cargo_build_script()'s
documentation for more.

2{}�
rustc_env_files�Files containing additional environment variables to set for rustc.

These files should  contain a single variable per line, of format
`NAME=value`, and newlines may be included in a value by ending a
line with a trailing back-slash (`\\`).

The order that these files will be processed is unspecified, so
multiple definitions of a particular variable are discouraged.

Note that the variables here are subject to
[workspace status](https://docs.bazel.build/versions/main/user-manual.html#workspace_status)
stamping should the `stamp` attribute be enabled. Stamp variables
should be wrapped in brackets in order to be resolved. E.g.
`NAME={WORKSPACE_STATUS_VARIABLE}`.
2[]�
rustc_flags�List of compiler flags passed to `rustc`.

These strings are subject to Make variable expansion for predefined
source/output path variables like `$location`, `$execpath`, and
`$rootpath`. This expansion is useful if you wish to pass a generated
file of arguments to rustc: `@$(location //package:target)`.
2[]�
srcs�List of Rust `.rs` source files used to build the library.

If `srcs` contains more than one file, then there must be a file either
named `lib.rs`. Otherwise, `crate_root` must be set to the source file that
is the root of the crate to be passed to rustc to build this crate.
2[]�
stamp�Whether to encode build information into the `Rustc` action. Possible values:

- `stamp = 1`: Always stamp the build information into the `Rustc` action, even in             [--nostamp](https://docs.bazel.build/versions/main/user-manual.html#flag--stamp) builds.             This setting should be avoided, since it potentially kills remote caching for the target and             any downstream actions that depend on it.

- `stamp = 0`: Always replace build information by constant values. This gives good build result caching.

- `stamp = -1`: Embedding of build information is controlled by the             [--[no]stamp](https://docs.bazel.build/versions/main/user-manual.html#flag--stamp) flag.

Stamped targets are not rebuilt unless their dependencies change.

For example if a `rust_library` is stamped, and a `rust_binary` depends on that library, the stamped
library won't be rebuilt when we change sources of the `rust_binary`. This is different from how
[`cc_library.linkstamps`](https://docs.bazel.build/versions/main/be/c-cpp.html#cc_library.linkstamp)
behaves.
20L
version6A version to inject in the cargo environment variable.2"0.0.0"
66,
*
nameA unique name for this target. �
�
aliases�Remap crates to a new name or moniker for linkage to this target

These are other `rust_library` targets and will be presented as the new name given.
	2{}�
�

alwayslink�If 1, any binary that depends (directly or indirectly) on this library
will link in all the object files even if some contain no symbols referenced by the binary.

This attribute is used by the C++ Starlark API when passing CcInfo providers.
2False�
�
compile_data�List of files used by this rule at compile time.

This attribute can be used to specify any data files that are embedded into
the library, such as via the
[`include_str!`](https://doc.rust-lang.org/std/macro.include_str!.html)
macro.
2[]�
�
crate_features�List of features to enable for this crate.

Features are defined in the code using the `#[cfg(feature = "foo")]`
configuration option. The features listed here will be passed to `rustc`
with `--cfg feature="${feature_name}"` flags.
2[]�
�

crate_name�Crate name to use for this target.

This must be a valid Rust identifier, i.e. it may contain only alphanumeric characters and underscores.
Defaults to the target name, with any hyphens replaced by underscores.
2""�
�

crate_root�The file that will be passed to `rustc` to be used for building this crate.

If `crate_root` is not set, then this rule will look for a `lib.rs` file (or `main.rs` for rust_binary)
or the single file in `srcs` if `srcs` contains only one file.
2None�
�
data�List of files used by this rule at compile time and runtime.

If including data at compile time with include_str!() and similar,
prefer `compile_data` over `data`, to prevent the data also being included
in the runfiles.
2[]�
�
deps�List of other libraries to be linked to this library target.

These can be either other `rust_library` targets or `cc_library` targets if
linking a native library.
2[]�
�
disable_pipelining�Disables pipelining for this rule if it is globally enabled.
This will cause this rule to not produce a `.rmeta` file and all the dependent
crates will instead use the `.rlib` file.
2Falses
q
edition`The rust edition to use for this crate. Defaults to the edition specified in the rust_toolchain.2""r
p
proc_macro_depsJList of `rust_proc_macro` targets used to help build this library target.
*
	CrateInfo2[]�
�
	rustc_env�Dictionary of additional `"key": "value"` environment variables to set for rustc.

rust_test()/rust_binary() rules can use $(rootpath //package:target) to pass in the
location of a generated file or external tool. Cargo build scripts that wish to
expand locations should use cargo_build_script()'s build_script_env argument instead,
as build scripts are run in a different environment - see cargo_build_script()'s
documentation for more.

2{}�
�
rustc_env_files�Files containing additional environment variables to set for rustc.

These files should  contain a single variable per line, of format
`NAME=value`, and newlines may be included in a value by ending a
line with a trailing back-slash (`\\`).

The order that these files will be processed is unspecified, so
multiple definitions of a particular variable are discouraged.

Note that the variables here are subject to
[workspace status](https://docs.bazel.build/versions/main/user-manual.html#workspace_status)
stamping should the `stamp` attribute be enabled. Stamp variables
should be wrapped in brackets in order to be resolved. E.g.
`NAME={WORKSPACE_STATUS_VARIABLE}`.
2[]�
�
rustc_flags�List of compiler flags passed to `rustc`.

These strings are subject to Make variable expansion for predefined
source/output path variables like `$location`, `$execpath`, and
`$rootpath`. This expansion is useful if you wish to pass a generated
file of arguments to rustc: `@$(location //package:target)`.
2[]�
�
srcs�List of Rust `.rs` source files used to build the library.

If `srcs` contains more than one file, then there must be a file either
named `lib.rs`. Otherwise, `crate_root` must be set to the source file that
is the root of the crate to be passed to rustc to build this crate.
2[]�
�
stamp�Whether to encode build information into the `Rustc` action. Possible values:

- `stamp = 1`: Always stamp the build information into the `Rustc` action, even in             [--nostamp](https://docs.bazel.build/versions/main/user-manual.html#flag--stamp) builds.             This setting should be avoided, since it potentially kills remote caching for the target and             any downstream actions that depend on it.

- `stamp = 0`: Always replace build information by constant values. This gives good build result caching.

- `stamp = -1`: Embedding of build information is controlled by the             [--[no]stamp](https://docs.bazel.build/versions/main/user-manual.html#flag--stamp) flag.

Stamped targets are not rebuilt unless their dependencies change.

For example if a `rust_library` is stamped, and a `rust_binary` depends on that library, the stamped
library won't be rebuilt when we change sources of the `rust_binary`. This is different from how
[`cc_library.linkstamps`](https://docs.bazel.build/versions/main/be/c-cpp.html#cc_library.linkstamp)
behaves.
20N
L
version6A version to inject in the cargo environment variable.2"0.0.0"�varlink_lint�Validate a varlink_library interface file at build time.

Runs the varlink-rust-generator with --nosource and discards output,
producing a sentinel file on success.  Build errors surface before any
Rust compilation starts.
*�
�
varlink_lint<
name0target name; the sentinel output is <name>.lint. (?
	interface.label of a varlink_library target to validate. (4

visibilitypassed through to the genrule.None(%
kwargsforwarded to the genrule.(�Validate a varlink_library interface file at build time.

Runs the varlink-rust-generator with --nosource and discards output,
producing a sentinel file on success.  Build errors surface before any
Rust compilation starts.
2A
varlink_lint1@@rules_varlink//varlink/private:varlink_lint.bzl
*native.genrule2native.genrule�
*//varlink/private:rust_varlink_library.bzlr�
:
rules_varlinkvarlink/privaterust_varlink_library.bzl;
rust_varlink_library_rust_varlink_library
BW
q�
%//varlink/private:varlink_library.bzlrx
5
rules_varlinkvarlink/privatevarlink_library.bzl1
varlink_library_varlink_library
=M
b�
"//varlink/private:varlink_lint.bzlro
2
rules_varlinkvarlink/privatevarlink_lint.bzl+
varlink_lint_varlink_lint
:G
YPublic API for rules_varlink.�
'
rules_varlinkvarlinkproviders.bzl�VarlinkInfo6Varlink interface sources and transitive dependencies.2�
�
VarlinkInfo6Varlink interface sources and transitive dependencies.7
srcs/depset of .varlink files (direct + transitive).C
direct_srcs4list of .varlink files declared by this target only."5
VarlinkInfo&@@rules_varlink//varlink:providers.bzl
9
7
srcs/depset of .varlink files (direct + transitive).E
C
direct_srcs4list of .varlink files declared by this target only. 