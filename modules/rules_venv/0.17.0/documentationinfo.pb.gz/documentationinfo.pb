�
-

rules_venvpython/black/private	black.bzl�py_black_test,A rule for running black on a Python target."�
�
py_black_test,A rule for running black on a Python target.*
nameA unique name for this target. `
config=The config file (`pyproject.toml`) containing black settings.2//python/black:config5
targetThe target to run `black` on. *
PyInfo"=
py_black_test,@@rules_venv//python/black/private:black.bzl
FF,
*
nameA unique name for this target. b
`
config=The config file (`pyproject.toml`) containing black settings.2//python/black:config7
5
targetThe target to run `black` on. *
PyInfo�py_black_aspect;An aspect for running black on targets with Python sources.:�
�
py_black_aspect;An aspect for running black on targets with Python sources."*
nameA unique name for this target. *?
py_black_aspect,@@rules_venv//python/black/private:black.bzl
��,
*
nameA unique name for this target. k
//python:py_info.bzlrQ
!

rules_venvpythonpy_info.bzl
PyInfoPyInfo
*0
2�
 //python/private:target_srcs.bzlr�
-

rules_venvpython/privatetarget_srcs.bzl$
	find_srcs	find_srcs
6?<
target_sources_aspecttarget_sources_aspect
CX
Z
//python/venv:defs.bzlrc
#

rules_venvpython/venvdefs.bzl.
py_venv_commonpy_venv_common
,:
<Bazel rules for black�	
7

rules_venvpython/black/privateblack_toolchain.bzl�current_py_black_toolchain@A rule for exposing the current registered `py_black_toolchain`."�
�
current_py_black_toolchain@A rule for exposing the current registered `py_black_toolchain`.*
nameA unique name for this target. "T
current_py_black_toolchain6@@rules_venv//python/black/private:black_toolchain.bzl
="=",
*
nameA unique name for this target. �py_black_toolchainUA toolchain for the [black](https://black.readthedocs.io/en/stable/) formatter rules."�
�
py_black_toolchainUA toolchain for the [black](https://black.readthedocs.io/en/stable/) formatter rules.*
nameA unique name for this target. D
black-The black `py_library` to use with the rules. *
PyInfo"L
py_black_toolchain6@@rules_venv//python/black/private:black_toolchain.bzl
,
*
nameA unique name for this target. F
D
black-The black `py_library` to use with the rules. *
PyInfok
//python:py_info.bzlrQ
!

rules_venvpythonpy_info.bzl
PyInfoPyInfo
*0
2V	TOOLCHAIN_TYPE@@//python/black:toolchain_typej!@@//python/black:toolchain_typeblack toolchain rules.�
$

rules_venvpython/blackdefs.bzl�py_black_toolchainUA toolchain for the [black](https://black.readthedocs.io/en/stable/) formatter rules."�
�
py_black_toolchainUA toolchain for the [black](https://black.readthedocs.io/en/stable/) formatter rules.*
nameA unique name for this target. D
black-The black `py_library` to use with the rules. *
PyInfo"9
py_black_toolchain#@@rules_venv//python/black:defs.bzl
,
*
nameA unique name for this target. F
D
black-The black `py_library` to use with the rules. *
PyInfo�py_black_aspect;An aspect for running black on targets with Python sources.:�
�
py_black_aspect;An aspect for running black on targets with Python sources."*
nameA unique name for this target. *6
py_black_aspect#@@rules_venv//python/black:defs.bzl
��,
*
nameA unique name for this target. �
"//python/black:py_black_aspect.bzlrr
/

rules_venvpython/blackpy_black_aspect.bzl1
py_black_aspect_py_black_aspect
<<
:=�
 //python/black:py_black_test.bzlrl
-

rules_venvpython/blackpy_black_test.bzl-
py_black_test_py_black_test
@@
>A�
%//python/black:py_black_toolchain.bzlr{
2

rules_venvpython/blackpy_black_toolchain.bzl7
py_black_toolchain_py_black_toolchain
DD
BE�# Black

Bazel rules for the Python formatter [black][blk].

### Setup

First ensure `rules_venv` is setup by referring to [rules_venv setup](../index.md#setup).

Next, the `black` rules work mostly off of toolchains which are used to provide the necessary python targets (aka `black`)
for the process wrappers. Users will want to make sure they have a way to get the necessary python dependencies. Tools such as
[req-compile](https://github.com/periareon/req-compile) can provide these.

With the appropriate dependencies available, a [py_black_toolchain](#py_black_toolchain) will need to be configured:

```python
load("@rules_venv//python/black:defs.bzl", "py_black_toolchain")

py_black_toolchain(
    name = "toolchain_impl",
    black = "@pip_deps//black",
    visibility = ["//visibility:public"]
)

toolchain(
    name = "toolchain",
    toolchain = ":toolchain_impl",
    toolchain_type = "@rules_venv//python/black:toolchain_type",
    visibility = ["//visibility:public"]
)
```

This toolchain then needs to be registered in the `MODULE.bazel` file.

```python
register_toolchains("//tools/python/black:toolchain")
```


### Usage

Python code can be formatted using the following command:

```bash
bazel run @rules_venv//python/black
```

In addition to this formatter, a check can be added to `bazel build` invocations using the [py_black_aspect](#py_black_aspect)
aspect. Simply add the following to a `.bazelrc` file to enable this check.

```text
build --aspects=@rules_venv//python/black:py_black_aspect.bzl%py_black_aspect
build --output_groups=+py_black_checks
```

[blk]: https://black.readthedocs.io/en/stable/index.html
�
/

rules_venvpython/blackpy_black_aspect.bzl�py_black_aspect;An aspect for running black on targets with Python sources.:�
�
py_black_aspect;An aspect for running black on targets with Python sources."*
nameA unique name for this target. *A
py_black_aspect.@@rules_venv//python/black:py_black_aspect.bzl
��,
*
nameA unique name for this target. �
 //python/black/private:black.bzlrp
-

rules_venvpython/black/private	black.bzl1
py_black_aspect_py_black_aspect

# py_black_aspect�
2

rules_venvpython/blackpy_black_toolchain.bzl�py_black_toolchainUA toolchain for the [black](https://black.readthedocs.io/en/stable/) formatter rules."�
�
py_black_toolchainUA toolchain for the [black](https://black.readthedocs.io/en/stable/) formatter rules.*
nameA unique name for this target. D
black-The black `py_library` to use with the rules. *
PyInfo"G
py_black_toolchain1@@rules_venv//python/black:py_black_toolchain.bzl
,
*
nameA unique name for this target. F
D
black-The black `py_library` to use with the rules. *
PyInfo�
*//python/black/private:black_toolchain.bzlr�
7

rules_venvpython/black/privateblack_toolchain.bzl7
py_black_toolchain_py_black_toolchain

# py_black_toolchain��
+

rules_venvpython/extensions
python.bzlՇpython=Bzlmod extension that is used to register Python toolchains.
J��
�`
python=Bzlmod extension that is used to register Python toolchains.
�
defaults0Tag class to specify the default Python version.�
python_version�String saying what the default Python version should be. If the string
matches the {attr}`python_version` attribute of a toolchain, this
toolchain is the default version. If this attribute is set, the
{attr}`is_default` attribute of the toolchain is ignored.

:::{versionadded} 1.4.0
:::
2""�
python_version_env�Environment variable saying what the default Python version should be.
If the string matches the {attr}`python_version` attribute of a
toolchain, this toolchain is the default version. If this attribute is
set, the {attr}`is_default` attribute of the toolchain is ignored.

:::{versionadded} 1.4.0
:::
2""�
python_version_file�File saying what the default Python version should be. If the contents
of the file match the {attr}`python_version` attribute of a toolchain,
this toolchain is the default version. If this attribute is set, the
{attr}`is_default` attribute of the toolchain is ignored.

:::{versionadded} 1.4.0
:::
2None�
overrideiTag class used to override defaults and behaviour of the module extension.

:::{versionadded} 0.36.0
:::
�
auth_patterns�An optional dict mapping host names to custom authorization patterns.

If a URL's host name is present in this dict the value will be used as a pattern when
generating the authorization header for the http request. This enables the use of custom
authorization schemes used in a lot of common cloud storage providers.

The pattern currently supports 2 tokens: <code>&lt;login&gt;</code> and
<code>&lt;password&gt;</code>, which are replaced with their equivalent value
in the netrc file for the same host name. After formatting, the result is set
as the value for the <code>Authorization</code> field of the HTTP request.

Example attribute and netrc for a http download to an oauth2 enabled API using a bearer token:

<pre>
auth_patterns = {
    "storage.cloudprovider.com": "Bearer &lt;password&gt;"
}
</pre>

netrc:

<pre>
machine storage.cloudprovider.com
        password RANDOM-TOKEN
</pre>

The final HTTP request would have the following header:

<pre>
Authorization: Bearer RANDOM-TOKEN
</pre>

2{}�
available_python_versions�The list of available python tool versions to use. Must be in `X.Y.Z` format.
If the unknown version given the processing of the extension will fail - all of
the versions in the list have to be defined with
{obj}`python.single_version_override` or
{obj}`python.single_version_platform_override` before they are used in this
list.

This attribute is usually used in order to ensure that no unexpected transitive
dependencies are introduced.
2[]�
base_url4The base URL to be used when downloading toolchains.2H"https://github.com/astral-sh/python-build-standalone/releases/download"W
ignore_root_user_error5Deprecated; do not use. This attribute has no effect.2True�
minor_mapping�The mapping between `X.Y` to `X.Y.Z` versions to be used when setting up
toolchains. It defaults to the interpreter with the highest available patch
version for each minor version. For example if one registers `3.10.3`, `3.10.4`
and `3.11.4` then the default for the `minor_mapping` dict will be:
```starlark
{
"3.10": "3.10.4",
"3.11": "3.11.4",
}
```

:::{versionchanged} 0.37.0
The values in this mapping override the default values and do not replace them.
:::

2{}D
netrc5Location of the .netrc file to use for authentication2""2
register_all_versionsAdd all versions2False�
single_version_override�Override single python version URLs and patches for all platforms.

:::{note}
This will replace any existing configuration for the given python version.
:::

:::{tip}
If you would like to modify the configuration for a specific `(version,
platform)`, please use the {obj}`single_version_platform_override` tag
class.
:::

:::{versionadded} 0.36.0
:::
�
	distutils�A distutils.cfg file to be included in the Python installation. Either {attr}`distutils` or {attr}`distutils_content` can be specified, but not both.2None�
distutils_content�A distutils.cfg file content to be included in the Python installation. Either {attr}`distutils` or {attr}`distutils_content` can be specified, but not both.2""?
patch_strip+Same as the --strip argument of Unix patch.20�
patches�A list of labels pointing to patch files to apply for the interpreter repository. They are applied in the list order and are applied before any platform-specific patches are applied.2[]Y
python_versionCThe python version to override URLs for. Must be in `X.Y.Z` format. �
sha256xThe python platform to sha256 dict. See {attr}`python.single_version_platform_override.platform` for allowed key values.
2{}U
strip_prefix9The 'strip_prefix' for the archive, defaults to 'python'.2"python"�
urls�The URL template to fetch releases for this Python version. See {attr}`python.single_version_platform_override.urls` for documentation.2[]�
 single_version_platform_override�Override single python version for a single existing platform.

If the `(version, platform)` is new, we will add it to the existing versions and will
use the same `url` template.

:::{tip}
If you would like to add or remove platforms to a single python version toolchain
configuration, please use {obj}`single_version_override`.
:::

:::{versionadded} 0.36.0
:::
�
arch�
The arch (cpu) the runtime is compatible with.

If not set, then the runtime cannot be used as a `python_X_Y_host` runtime.

If set, the `os_name`, `target_compatible_with` and `target_settings` attributes
should also be set.

The values should be one of the values in `@platforms//cpu`

:::{seealso}
Docs for [Registering custom runtimes]
:::

:::{{versionadded}} 1.5.0
:::
2""�
coverage_toolmThe coverage tool to be used for a particular Python interpreter. This can override
`rules_python` defaults.
2None�
os_name�
The host OS the runtime is compatible with.

If not set, then the runtime cannot be used as a `python_X_Y_host` runtime.

If set, the `os_name`, `target_compatible_with` and `target_settings` attributes
should also be set.

The values should be one of the values in `@platforms//os`

:::{seealso}
Docs for [Registering custom runtimes]
:::

:::{{versionadded}} 1.5.0
:::
2""?
patch_strip+Same as the --strip argument of Unix patch.20�
patches�A list of labels pointing to patch files to apply for the interpreter repository. They are applied in the list order and are applied after the common patches are applied.2[]�
platform�
The platform to override the values for, typically one of:

* `aarch64-apple-darwin-freethreaded`
* `aarch64-apple-darwin`
* `aarch64-pc-windows-msvc-freethreaded`
* `aarch64-pc-windows-msvc`
* `aarch64-unknown-linux-gnu-freethreaded`
* `aarch64-unknown-linux-gnu`
* `armv7-unknown-linux-gnu-freethreaded`
* `armv7-unknown-linux-gnu`
* `i386-unknown-linux-gnu-freethreaded`
* `i386-unknown-linux-gnu`
* `ppc64le-unknown-linux-gnu-freethreaded`
* `ppc64le-unknown-linux-gnu`
* `riscv64-unknown-linux-gnu-freethreaded`
* `riscv64-unknown-linux-gnu`
* `s390x-unknown-linux-gnu-freethreaded`
* `s390x-unknown-linux-gnu`
* `x86_64-apple-darwin-freethreaded`
* `x86_64-apple-darwin`
* `x86_64-pc-windows-msvc-freethreaded`
* `x86_64-pc-windows-msvc`
* `x86_64-unknown-linux-gnu-freethreaded`
* `x86_64-unknown-linux-gnu`
* `x86_64-unknown-linux-musl-freethreaded`
* `x86_64-unknown-linux-musl`

Other values are allowed, in which case, `target_compatible_with`,
`target_settings`, `os_name`, and `arch` should be specified so the toolchain is
only used when appropriate.

:::{versionchanged} 1.5.0
Arbitrary platform strings allowed.
:::
 Y
python_versionCThe python version to override URLs for. Must be in `X.Y.Z` format. *
sha256The sha256 for the archive2""U
strip_prefix9The 'strip_prefix' for the archive, defaults to 'python'.2"python"�
target_compatible_with�
The `target_compatible_with` values to use for the toolchain definition.

If not set, then `os_name` and `arch` will be used to populate it.

If set, `target_settings`, `os_name`, and `arch` should also be set.

:::{seealso}
Docs for [Registering custom runtimes]
:::

:::{{versionadded}} 1.5.0
:::
2[]�
target_settings�
The `target_setings` values to use for the toolchain definition.

If set, `target_compatible_with`, `os_name`, and `arch` should also be set.

:::{seealso}
Docs for [Registering custom runtimes]
:::

:::{{versionadded}} 1.5.0
:::
2[]�
urls�The URL template to fetch releases for this Python version. If the URL template results in a relative fragment, default base URL is going to be used. Occurrences of `{python_version}`, `{platform}` and `{build}` will be interpolated based on the contents in the override and the known {attr}`platform` values.2[]�
	toolchain�Tag class used to register Python toolchains.
Use this tag class to register one or more Python toolchains. This class
is also potentially called by sub modules. The following covers different
business rules and use cases.

:::{topic} Toolchains in the Root Module

This class registers all toolchains in the root module.
:::

:::{topic} Toolchains in Sub Modules

It will create a toolchain that is in a sub module, if the toolchain
of the same name does not exist in the root module.  The extension stops name
clashing between toolchains in the root module and toolchains in sub modules.
You cannot configure more than one toolchain as the default toolchain.
:::

:::{topic} Toolchain set as the default version

This extension will not create a toolchain that exists in a sub module,
if the sub module toolchain is marked as the default version. If you have
more than one toolchain in your root module, you need to set one of the
toolchains as the default version.  If there is only one toolchain it
is set as the default toolchain.
:::

:::{topic} Toolchain repository name

A toolchain's repository name uses the format `python_{major}_{minor}`, e.g.
`python_3_10`. The `major` and `minor` components are
`major` and `minor` are the Python version from the `python_version` attribute.

If a toolchain is registered in `X.Y.Z`, then similarly the toolchain name will
be `python_{major}_{minor}_{patch}`, e.g. `python_3_10_19`.
:::

:::{topic} Toolchain detection
The definition of the first toolchain wins, which means that the root module
can override settings for any python toolchain available. This relies on the
documented module traversal from the {obj}`module_ctx.modules`.
:::

:::{tip}
In order to use a different name than the above, you can use the following `MODULE.bazel`
syntax:
```starlark
python = use_extension("@rules_python//python/extensions:python.bzl", "python")
python.defaults(python_version = "3.11")
python.toolchain(python_version = "3.11")

use_repo(python, my_python_name = "python_3_11")
```

Then the python interpreter will be available as `my_python_name`.
:::
�
configure_coverage_tooloWhether or not to configure the default coverage tool provided by `rules_python` for the compatible toolchains.2False�
ignore_root_user_error�The Python runtime installation is made read only. This improves the ability for
Bazel to cache it by preventing the interpreter from creating `.pyc` files for
the standard library dynamically at runtime as they are loaded (this often leads
to spurious cache misses or build failures).

However, if the user is running Bazel as root, this read-onlyness is not
respected. Bazel will print a warning message when it detects that the runtime
installation is writable despite being made read only (i.e. it's running with
root access) while this attribute is set `False`, however this messaging can be ignored by setting
this to `False`.
2True�

is_default�Whether the toolchain is the default version.

:::{versionchanged} 1.4.0
This setting is ignored if the default version is set using the `defaults`
tag class (encouraged).
:::
2False�
python_versionyThe Python version, in `major.minor` or `major.minor.patch` format, e.g
`3.12` (or `3.12.3`), to create a toolchain for.
 "4
python*@@rules_venv//python/extensions:python.bzl
�
�
�
�
defaults0Tag class to specify the default Python version.�
python_version�String saying what the default Python version should be. If the string
matches the {attr}`python_version` attribute of a toolchain, this
toolchain is the default version. If this attribute is set, the
{attr}`is_default` attribute of the toolchain is ignored.

:::{versionadded} 1.4.0
:::
2""�
python_version_env�Environment variable saying what the default Python version should be.
If the string matches the {attr}`python_version` attribute of a
toolchain, this toolchain is the default version. If this attribute is
set, the {attr}`is_default` attribute of the toolchain is ignored.

:::{versionadded} 1.4.0
:::
2""�
python_version_file�File saying what the default Python version should be. If the contents
of the file match the {attr}`python_version` attribute of a toolchain,
this toolchain is the default version. If this attribute is set, the
{attr}`is_default` attribute of the toolchain is ignored.

:::{versionadded} 1.4.0
:::
2None�
�
python_version�String saying what the default Python version should be. If the string
matches the {attr}`python_version` attribute of a toolchain, this
toolchain is the default version. If this attribute is set, the
{attr}`is_default` attribute of the toolchain is ignored.

:::{versionadded} 1.4.0
:::
2""�
�
python_version_env�Environment variable saying what the default Python version should be.
If the string matches the {attr}`python_version` attribute of a
toolchain, this toolchain is the default version. If this attribute is
set, the {attr}`is_default` attribute of the toolchain is ignored.

:::{versionadded} 1.4.0
:::
2""�
�
python_version_file�File saying what the default Python version should be. If the contents
of the file match the {attr}`python_version` attribute of a toolchain,
this toolchain is the default version. If this attribute is set, the
{attr}`is_default` attribute of the toolchain is ignored.

:::{versionadded} 1.4.0
:::
2None�%
�
overrideiTag class used to override defaults and behaviour of the module extension.

:::{versionadded} 0.36.0
:::
�
auth_patterns�An optional dict mapping host names to custom authorization patterns.

If a URL's host name is present in this dict the value will be used as a pattern when
generating the authorization header for the http request. This enables the use of custom
authorization schemes used in a lot of common cloud storage providers.

The pattern currently supports 2 tokens: <code>&lt;login&gt;</code> and
<code>&lt;password&gt;</code>, which are replaced with their equivalent value
in the netrc file for the same host name. After formatting, the result is set
as the value for the <code>Authorization</code> field of the HTTP request.

Example attribute and netrc for a http download to an oauth2 enabled API using a bearer token:

<pre>
auth_patterns = {
    "storage.cloudprovider.com": "Bearer &lt;password&gt;"
}
</pre>

netrc:

<pre>
machine storage.cloudprovider.com
        password RANDOM-TOKEN
</pre>

The final HTTP request would have the following header:

<pre>
Authorization: Bearer RANDOM-TOKEN
</pre>

2{}�
available_python_versions�The list of available python tool versions to use. Must be in `X.Y.Z` format.
If the unknown version given the processing of the extension will fail - all of
the versions in the list have to be defined with
{obj}`python.single_version_override` or
{obj}`python.single_version_platform_override` before they are used in this
list.

This attribute is usually used in order to ensure that no unexpected transitive
dependencies are introduced.
2[]�
base_url4The base URL to be used when downloading toolchains.2H"https://github.com/astral-sh/python-build-standalone/releases/download"W
ignore_root_user_error5Deprecated; do not use. This attribute has no effect.2True�
minor_mapping�The mapping between `X.Y` to `X.Y.Z` versions to be used when setting up
toolchains. It defaults to the interpreter with the highest available patch
version for each minor version. For example if one registers `3.10.3`, `3.10.4`
and `3.11.4` then the default for the `minor_mapping` dict will be:
```starlark
{
"3.10": "3.10.4",
"3.11": "3.11.4",
}
```

:::{versionchanged} 0.37.0
The values in this mapping override the default values and do not replace them.
:::

2{}D
netrc5Location of the .netrc file to use for authentication2""2
register_all_versionsAdd all versions2False�
�
auth_patterns�An optional dict mapping host names to custom authorization patterns.

If a URL's host name is present in this dict the value will be used as a pattern when
generating the authorization header for the http request. This enables the use of custom
authorization schemes used in a lot of common cloud storage providers.

The pattern currently supports 2 tokens: <code>&lt;login&gt;</code> and
<code>&lt;password&gt;</code>, which are replaced with their equivalent value
in the netrc file for the same host name. After formatting, the result is set
as the value for the <code>Authorization</code> field of the HTTP request.

Example attribute and netrc for a http download to an oauth2 enabled API using a bearer token:

<pre>
auth_patterns = {
    "storage.cloudprovider.com": "Bearer &lt;password&gt;"
}
</pre>

netrc:

<pre>
machine storage.cloudprovider.com
        password RANDOM-TOKEN
</pre>

The final HTTP request would have the following header:

<pre>
Authorization: Bearer RANDOM-TOKEN
</pre>

2{}�
�
available_python_versions�The list of available python tool versions to use. Must be in `X.Y.Z` format.
If the unknown version given the processing of the extension will fail - all of
the versions in the list have to be defined with
{obj}`python.single_version_override` or
{obj}`python.single_version_platform_override` before they are used in this
list.

This attribute is usually used in order to ensure that no unexpected transitive
dependencies are introduced.
2[]�
�
base_url4The base URL to be used when downloading toolchains.2H"https://github.com/astral-sh/python-build-standalone/releases/download"Y
W
ignore_root_user_error5Deprecated; do not use. This attribute has no effect.2True�
�
minor_mapping�The mapping between `X.Y` to `X.Y.Z` versions to be used when setting up
toolchains. It defaults to the interpreter with the highest available patch
version for each minor version. For example if one registers `3.10.3`, `3.10.4`
and `3.11.4` then the default for the `minor_mapping` dict will be:
```starlark
{
"3.10": "3.10.4",
"3.11": "3.11.4",
}
```

:::{versionchanged} 0.37.0
The values in this mapping override the default values and do not replace them.
:::

2{}F
D
netrc5Location of the .netrc file to use for authentication2""4
2
register_all_versionsAdd all versions2False�
�
single_version_override�Override single python version URLs and patches for all platforms.

:::{note}
This will replace any existing configuration for the given python version.
:::

:::{tip}
If you would like to modify the configuration for a specific `(version,
platform)`, please use the {obj}`single_version_platform_override` tag
class.
:::

:::{versionadded} 0.36.0
:::
�
	distutils�A distutils.cfg file to be included in the Python installation. Either {attr}`distutils` or {attr}`distutils_content` can be specified, but not both.2None�
distutils_content�A distutils.cfg file content to be included in the Python installation. Either {attr}`distutils` or {attr}`distutils_content` can be specified, but not both.2""?
patch_strip+Same as the --strip argument of Unix patch.20�
patches�A list of labels pointing to patch files to apply for the interpreter repository. They are applied in the list order and are applied before any platform-specific patches are applied.2[]Y
python_versionCThe python version to override URLs for. Must be in `X.Y.Z` format. �
sha256xThe python platform to sha256 dict. See {attr}`python.single_version_platform_override.platform` for allowed key values.
2{}U
strip_prefix9The 'strip_prefix' for the archive, defaults to 'python'.2"python"�
urls�The URL template to fetch releases for this Python version. See {attr}`python.single_version_platform_override.urls` for documentation.2[]�
�
	distutils�A distutils.cfg file to be included in the Python installation. Either {attr}`distutils` or {attr}`distutils_content` can be specified, but not both.2None�
�
distutils_content�A distutils.cfg file content to be included in the Python installation. Either {attr}`distutils` or {attr}`distutils_content` can be specified, but not both.2""A
?
patch_strip+Same as the --strip argument of Unix patch.20�
�
patches�A list of labels pointing to patch files to apply for the interpreter repository. They are applied in the list order and are applied before any platform-specific patches are applied.2[][
Y
python_versionCThe python version to override URLs for. Must be in `X.Y.Z` format. �
�
sha256xThe python platform to sha256 dict. See {attr}`python.single_version_platform_override.platform` for allowed key values.
2{}W
U
strip_prefix9The 'strip_prefix' for the archive, defaults to 'python'.2"python"�
�
urls�The URL template to fetch releases for this Python version. See {attr}`python.single_version_platform_override.urls` for documentation.2[]�9
�
 single_version_platform_override�Override single python version for a single existing platform.

If the `(version, platform)` is new, we will add it to the existing versions and will
use the same `url` template.

:::{tip}
If you would like to add or remove platforms to a single python version toolchain
configuration, please use {obj}`single_version_override`.
:::

:::{versionadded} 0.36.0
:::
�
arch�
The arch (cpu) the runtime is compatible with.

If not set, then the runtime cannot be used as a `python_X_Y_host` runtime.

If set, the `os_name`, `target_compatible_with` and `target_settings` attributes
should also be set.

The values should be one of the values in `@platforms//cpu`

:::{seealso}
Docs for [Registering custom runtimes]
:::

:::{{versionadded}} 1.5.0
:::
2""�
coverage_toolmThe coverage tool to be used for a particular Python interpreter. This can override
`rules_python` defaults.
2None�
os_name�
The host OS the runtime is compatible with.

If not set, then the runtime cannot be used as a `python_X_Y_host` runtime.

If set, the `os_name`, `target_compatible_with` and `target_settings` attributes
should also be set.

The values should be one of the values in `@platforms//os`

:::{seealso}
Docs for [Registering custom runtimes]
:::

:::{{versionadded}} 1.5.0
:::
2""?
patch_strip+Same as the --strip argument of Unix patch.20�
patches�A list of labels pointing to patch files to apply for the interpreter repository. They are applied in the list order and are applied after the common patches are applied.2[]�
platform�
The platform to override the values for, typically one of:

* `aarch64-apple-darwin-freethreaded`
* `aarch64-apple-darwin`
* `aarch64-pc-windows-msvc-freethreaded`
* `aarch64-pc-windows-msvc`
* `aarch64-unknown-linux-gnu-freethreaded`
* `aarch64-unknown-linux-gnu`
* `armv7-unknown-linux-gnu-freethreaded`
* `armv7-unknown-linux-gnu`
* `i386-unknown-linux-gnu-freethreaded`
* `i386-unknown-linux-gnu`
* `ppc64le-unknown-linux-gnu-freethreaded`
* `ppc64le-unknown-linux-gnu`
* `riscv64-unknown-linux-gnu-freethreaded`
* `riscv64-unknown-linux-gnu`
* `s390x-unknown-linux-gnu-freethreaded`
* `s390x-unknown-linux-gnu`
* `x86_64-apple-darwin-freethreaded`
* `x86_64-apple-darwin`
* `x86_64-pc-windows-msvc-freethreaded`
* `x86_64-pc-windows-msvc`
* `x86_64-unknown-linux-gnu-freethreaded`
* `x86_64-unknown-linux-gnu`
* `x86_64-unknown-linux-musl-freethreaded`
* `x86_64-unknown-linux-musl`

Other values are allowed, in which case, `target_compatible_with`,
`target_settings`, `os_name`, and `arch` should be specified so the toolchain is
only used when appropriate.

:::{versionchanged} 1.5.0
Arbitrary platform strings allowed.
:::
 Y
python_versionCThe python version to override URLs for. Must be in `X.Y.Z` format. *
sha256The sha256 for the archive2""U
strip_prefix9The 'strip_prefix' for the archive, defaults to 'python'.2"python"�
target_compatible_with�
The `target_compatible_with` values to use for the toolchain definition.

If not set, then `os_name` and `arch` will be used to populate it.

If set, `target_settings`, `os_name`, and `arch` should also be set.

:::{seealso}
Docs for [Registering custom runtimes]
:::

:::{{versionadded}} 1.5.0
:::
2[]�
target_settings�
The `target_setings` values to use for the toolchain definition.

If set, `target_compatible_with`, `os_name`, and `arch` should also be set.

:::{seealso}
Docs for [Registering custom runtimes]
:::

:::{{versionadded}} 1.5.0
:::
2[]�
urls�The URL template to fetch releases for this Python version. If the URL template results in a relative fragment, default base URL is going to be used. Occurrences of `{python_version}`, `{platform}` and `{build}` will be interpolated based on the contents in the override and the known {attr}`platform` values.2[]�
�
arch�
The arch (cpu) the runtime is compatible with.

If not set, then the runtime cannot be used as a `python_X_Y_host` runtime.

If set, the `os_name`, `target_compatible_with` and `target_settings` attributes
should also be set.

The values should be one of the values in `@platforms//cpu`

:::{seealso}
Docs for [Registering custom runtimes]
:::

:::{{versionadded}} 1.5.0
:::
2""�
�
coverage_toolmThe coverage tool to be used for a particular Python interpreter. This can override
`rules_python` defaults.
2None�
�
os_name�
The host OS the runtime is compatible with.

If not set, then the runtime cannot be used as a `python_X_Y_host` runtime.

If set, the `os_name`, `target_compatible_with` and `target_settings` attributes
should also be set.

The values should be one of the values in `@platforms//os`

:::{seealso}
Docs for [Registering custom runtimes]
:::

:::{{versionadded}} 1.5.0
:::
2""A
?
patch_strip+Same as the --strip argument of Unix patch.20�
�
patches�A list of labels pointing to patch files to apply for the interpreter repository. They are applied in the list order and are applied after the common patches are applied.2[]�	
�
platform�
The platform to override the values for, typically one of:

* `aarch64-apple-darwin-freethreaded`
* `aarch64-apple-darwin`
* `aarch64-pc-windows-msvc-freethreaded`
* `aarch64-pc-windows-msvc`
* `aarch64-unknown-linux-gnu-freethreaded`
* `aarch64-unknown-linux-gnu`
* `armv7-unknown-linux-gnu-freethreaded`
* `armv7-unknown-linux-gnu`
* `i386-unknown-linux-gnu-freethreaded`
* `i386-unknown-linux-gnu`
* `ppc64le-unknown-linux-gnu-freethreaded`
* `ppc64le-unknown-linux-gnu`
* `riscv64-unknown-linux-gnu-freethreaded`
* `riscv64-unknown-linux-gnu`
* `s390x-unknown-linux-gnu-freethreaded`
* `s390x-unknown-linux-gnu`
* `x86_64-apple-darwin-freethreaded`
* `x86_64-apple-darwin`
* `x86_64-pc-windows-msvc-freethreaded`
* `x86_64-pc-windows-msvc`
* `x86_64-unknown-linux-gnu-freethreaded`
* `x86_64-unknown-linux-gnu`
* `x86_64-unknown-linux-musl-freethreaded`
* `x86_64-unknown-linux-musl`

Other values are allowed, in which case, `target_compatible_with`,
`target_settings`, `os_name`, and `arch` should be specified so the toolchain is
only used when appropriate.

:::{versionchanged} 1.5.0
Arbitrary platform strings allowed.
:::
 [
Y
python_versionCThe python version to override URLs for. Must be in `X.Y.Z` format. ,
*
sha256The sha256 for the archive2""W
U
strip_prefix9The 'strip_prefix' for the archive, defaults to 'python'.2"python"�
�
target_compatible_with�
The `target_compatible_with` values to use for the toolchain definition.

If not set, then `os_name` and `arch` will be used to populate it.

If set, `target_settings`, `os_name`, and `arch` should also be set.

:::{seealso}
Docs for [Registering custom runtimes]
:::

:::{{versionadded}} 1.5.0
:::
2[]�
�
target_settings�
The `target_setings` values to use for the toolchain definition.

If set, `target_compatible_with`, `os_name`, and `arch` should also be set.

:::{seealso}
Docs for [Registering custom runtimes]
:::

:::{{versionadded}} 1.5.0
:::
2[]�
�
urls�The URL template to fetch releases for this Python version. If the URL template results in a relative fragment, default base URL is going to be used. Occurrences of `{python_version}`, `{platform}` and `{build}` will be interpolated based on the contents in the override and the known {attr}`platform` values.2[]�"
�
	toolchain�Tag class used to register Python toolchains.
Use this tag class to register one or more Python toolchains. This class
is also potentially called by sub modules. The following covers different
business rules and use cases.

:::{topic} Toolchains in the Root Module

This class registers all toolchains in the root module.
:::

:::{topic} Toolchains in Sub Modules

It will create a toolchain that is in a sub module, if the toolchain
of the same name does not exist in the root module.  The extension stops name
clashing between toolchains in the root module and toolchains in sub modules.
You cannot configure more than one toolchain as the default toolchain.
:::

:::{topic} Toolchain set as the default version

This extension will not create a toolchain that exists in a sub module,
if the sub module toolchain is marked as the default version. If you have
more than one toolchain in your root module, you need to set one of the
toolchains as the default version.  If there is only one toolchain it
is set as the default toolchain.
:::

:::{topic} Toolchain repository name

A toolchain's repository name uses the format `python_{major}_{minor}`, e.g.
`python_3_10`. The `major` and `minor` components are
`major` and `minor` are the Python version from the `python_version` attribute.

If a toolchain is registered in `X.Y.Z`, then similarly the toolchain name will
be `python_{major}_{minor}_{patch}`, e.g. `python_3_10_19`.
:::

:::{topic} Toolchain detection
The definition of the first toolchain wins, which means that the root module
can override settings for any python toolchain available. This relies on the
documented module traversal from the {obj}`module_ctx.modules`.
:::

:::{tip}
In order to use a different name than the above, you can use the following `MODULE.bazel`
syntax:
```starlark
python = use_extension("@rules_python//python/extensions:python.bzl", "python")
python.defaults(python_version = "3.11")
python.toolchain(python_version = "3.11")

use_repo(python, my_python_name = "python_3_11")
```

Then the python interpreter will be available as `my_python_name`.
:::
�
configure_coverage_tooloWhether or not to configure the default coverage tool provided by `rules_python` for the compatible toolchains.2False�
ignore_root_user_error�The Python runtime installation is made read only. This improves the ability for
Bazel to cache it by preventing the interpreter from creating `.pyc` files for
the standard library dynamically at runtime as they are loaded (this often leads
to spurious cache misses or build failures).

However, if the user is running Bazel as root, this read-onlyness is not
respected. Bazel will print a warning message when it detects that the runtime
installation is writable despite being made read only (i.e. it's running with
root access) while this attribute is set `False`, however this messaging can be ignored by setting
this to `False`.
2True�

is_default�Whether the toolchain is the default version.

:::{versionchanged} 1.4.0
This setting is ignored if the default version is set using the `defaults`
tag class (encouraged).
:::
2False�
python_versionyThe Python version, in `major.minor` or `major.minor.patch` format, e.g
`3.12` (or `3.12.3`), to create a toolchain for.
 �
�
configure_coverage_tooloWhether or not to configure the default coverage tool provided by `rules_python` for the compatible toolchains.2False�
�
ignore_root_user_error�The Python runtime installation is made read only. This improves the ability for
Bazel to cache it by preventing the interpreter from creating `.pyc` files for
the standard library dynamically at runtime as they are loaded (this often leads
to spurious cache misses or build failures).

However, if the user is running Bazel as root, this read-onlyness is not
respected. Bazel will print a warning message when it detects that the runtime
installation is writable despite being made read only (i.e. it's running with
root access) while this attribute is set `False`, however this messaging can be ignored by setting
this to `False`.
2True�
�

is_default�Whether the toolchain is the default version.

:::{versionchanged} 1.4.0
This setting is ignored if the default version is set using the `defaults`
tag class (encouraged).
:::
2False�
�
python_versionyThe Python version, in `major.minor` or `major.minor.patch` format, e.g
`3.12` (or `3.12.3`), to create a toolchain for.
 �
//python/extensions:python.bzlr^
-
rules_pythonpython/extensions
python.bzl
python_python
5<
HRe-exports from rules_python�@
9

rules_venvpython/global_venv/privateglobal_venv.bzl�5py_global_venv�Define a "global venv" executable.

When ``gen_pyrightconfig`` is enabled (the default), running this target
writes a ``bazel-pyrightconfig.json`` at the workspace root containing
``extraPaths`` that point into ``bazel-bin``. This lets Pyright/Pylance
resolve generated Python sources that live outside the source tree.

To use it, add an ``extends`` field to your ``pyrightconfig.json``::

```json
{
    "extends": "bazel-pyrightconfig.json",
    ...
}
```

**Important:** Do not define ``extraPaths`` in your own ``pyrightconfig.json``
when using ``extends``. Pyright's ``extends`` replaces array fields rather
than merging them, so any ``extraPaths`` in the child config will override
the generated values from ``bazel-pyrightconfig.json``.

When targets use configuration transitions (e.g. ``py_cc_extension`` building
with ``compilation_mode = "opt"``), generated files may live in directories
like ``bazel-out/k8-opt/bin`` instead of ``bazel-out/k8-fastbuild/bin``. The
generated ``bazel-pyrightconfig.json`` includes all observed output directories
automatically.

For **ruff** or **isort** to correctly classify first-party imports that
include generated sources, add the Bazel output directories to the ``src``
setting::

```toml
# .ruff.toml
src = [".", "bazel-out/k8-*/bin"]
```

For standalone **isort**::

```ini
# .isort.cfg
[isort]
src_paths = .,bazel-out/k8-*/bin
```

This allows ruff/isort to find generated ``.pyi`` stubs and ``.so`` extensions
when determining whether an import is first-party or third-party.

When ``gen_entrypoints`` is enabled (the default), running this target will
auto-discover ``console_scripts`` entrypoints from pip packages via
``importlib.metadata`` and generate executable scripts in the venv's ``bin/``
directory. Pre-built binaries shipped via wheel data scripts (e.g. ``ruff``)
are also symlinked into the venv. This allows IDEs to find tools like
``black``, ``ruff``, or ``mypy`` inside the venv. Additional entrypoints can
be specified manually via ``entrypoints``.


A `py_venv_binary` is an executable Python program consisting of a collection of
`.py` source files (possibly belonging to other `py_library` rules), a `*.runfiles`
directory tree containing all the code and data needed by the program at run-time,
and a stub script that starts up the program with the correct initial environment
and data.

```python
load("@rules_venv//python/venv:defs.bzl", "py_venv_binary")

py_venv_binary(
    name = "foo",
    srcs = ["foo.py"],
    data = [":transform"],  # a cc_binary which we invoke at run time
    deps = [
        ":bar",  # a py_library
    ],
)
```
"� 
�
py_global_venv�Define a "global venv" executable.

When ``gen_pyrightconfig`` is enabled (the default), running this target
writes a ``bazel-pyrightconfig.json`` at the workspace root containing
``extraPaths`` that point into ``bazel-bin``. This lets Pyright/Pylance
resolve generated Python sources that live outside the source tree.

To use it, add an ``extends`` field to your ``pyrightconfig.json``::

```json
{
    "extends": "bazel-pyrightconfig.json",
    ...
}
```

**Important:** Do not define ``extraPaths`` in your own ``pyrightconfig.json``
when using ``extends``. Pyright's ``extends`` replaces array fields rather
than merging them, so any ``extraPaths`` in the child config will override
the generated values from ``bazel-pyrightconfig.json``.

When targets use configuration transitions (e.g. ``py_cc_extension`` building
with ``compilation_mode = "opt"``), generated files may live in directories
like ``bazel-out/k8-opt/bin`` instead of ``bazel-out/k8-fastbuild/bin``. The
generated ``bazel-pyrightconfig.json`` includes all observed output directories
automatically.

For **ruff** or **isort** to correctly classify first-party imports that
include generated sources, add the Bazel output directories to the ``src``
setting::

```toml
# .ruff.toml
src = [".", "bazel-out/k8-*/bin"]
```

For standalone **isort**::

```ini
# .isort.cfg
[isort]
src_paths = .,bazel-out/k8-*/bin
```

This allows ruff/isort to find generated ``.pyi`` stubs and ``.so`` extensions
when determining whether an import is first-party or third-party.

When ``gen_entrypoints`` is enabled (the default), running this target will
auto-discover ``console_scripts`` entrypoints from pip packages via
``importlib.metadata`` and generate executable scripts in the venv's ``bin/``
directory. Pre-built binaries shipped via wheel data scripts (e.g. ``ruff``)
are also symlinked into the venv. This allows IDEs to find tools like
``black``, ``ruff``, or ``mypy`` inside the venv. Additional entrypoints can
be specified manually via ``entrypoints``.


A `py_venv_binary` is an executable Python program consisting of a collection of
`.py` source files (possibly belonging to other `py_library` rules), a `*.runfiles`
directory tree containing all the code and data needed by the program at run-time,
and a stub script that starts up the program with the correct initial environment
and data.

```python
load("@rules_venv//python/venv:defs.bzl", "py_venv_binary")

py_venv_binary(
    name = "foo",
    srcs = ["foo.py"],
    data = [":transform"],  # a cc_binary which we invoke at run time
    deps = [
        ":bar",  # a py_library
    ],
)
```
*
nameA unique name for this target. o
dataaFiles needed by this rule at runtime. May list file or rule targets. Generally allows any target.2[]K
deps3Other python targets to link to the current target.*
PyInfo2[]i
env\Dictionary of strings; values are subject to `$(location)` and "Make variable" substitution.
2{}L
imports;List of import directories to be added to the `PYTHONPATH`.2[]�
main�The name of the source file that is the main entry point of the application. This file must also be listed in `srcs`. If left unspecified, `name` is used instead. If `name` does not match any filename in `srcs`, `main` must be specified. 2NoneU
srcsGThe list of source (.py) files that are processed to create the target.2[]
,
*
nameA unique name for this target. q
o
dataaFiles needed by this rule at runtime. May list file or rule targets. Generally allows any target.2[]M
K
deps3Other python targets to link to the current target.*
PyInfo2[]k
i
env\Dictionary of strings; values are subject to `$(location)` and "Make variable" substitution.
2{}N
L
imports;List of import directories to be added to the `PYTHONPATH`.2[]�
�
main�The name of the source file that is the main entry point of the application. This file must also be listed in `srcs`. If left unspecified, `name` is used instead. If `name` does not match any filename in `srcs`, `main` must be specified. 2NoneW
U
srcsGThe list of source (.py) files that are processed to create the target.2[]�PyGlobalVenvInfoDInfo about a python package required to include it in a global venv.2�
�
PyGlobalVenvInfoDInfo about a python package required to include it in a global venv.R
bin_dirsFList[String]: The paths to the bin dirs for each unique configuration.%
importsFile: A json encoded file."L
PyGlobalVenvInfo8@@rules_venv//python/global_venv/private:global_venv.bzl
iiT
R
bin_dirsFList[String]: The paths to the bin dirs for each unique configuration.'
%
importsFile: A json encoded file.�py_global_venv_aspectVAn aspect for generating metadata required to include Python targets in a global venv.:�
�
py_global_venv_aspectVAn aspect for generating metadata required to include Python targets in a global venv."*
nameA unique name for this target. *Q
py_global_venv_aspect8@@rules_venv//python/global_venv/private:global_venv.bzl
��,
*
nameA unique name for this target. k
//python:py_info.bzlrQ
!

rules_venvpythonpy_info.bzl
PyInfoPyInfo
*0
2
//python/venv:defs.bzlrc
#

rules_venvpython/venvdefs.bzl.
py_venv_binarypy_venv_binary
,:
<L	SPEC_FILE_SUFFIX.py_global_venv_info.jsonj.py_global_venv_info.json@Utilities for setting up a venv with all available Bazel targets�K
*

rules_venvpython/global_venvdefs.bzl�5py_global_venv�Define a "global venv" executable.

When ``gen_pyrightconfig`` is enabled (the default), running this target
writes a ``bazel-pyrightconfig.json`` at the workspace root containing
``extraPaths`` that point into ``bazel-bin``. This lets Pyright/Pylance
resolve generated Python sources that live outside the source tree.

To use it, add an ``extends`` field to your ``pyrightconfig.json``::

```json
{
    "extends": "bazel-pyrightconfig.json",
    ...
}
```

**Important:** Do not define ``extraPaths`` in your own ``pyrightconfig.json``
when using ``extends``. Pyright's ``extends`` replaces array fields rather
than merging them, so any ``extraPaths`` in the child config will override
the generated values from ``bazel-pyrightconfig.json``.

When targets use configuration transitions (e.g. ``py_cc_extension`` building
with ``compilation_mode = "opt"``), generated files may live in directories
like ``bazel-out/k8-opt/bin`` instead of ``bazel-out/k8-fastbuild/bin``. The
generated ``bazel-pyrightconfig.json`` includes all observed output directories
automatically.

For **ruff** or **isort** to correctly classify first-party imports that
include generated sources, add the Bazel output directories to the ``src``
setting::

```toml
# .ruff.toml
src = [".", "bazel-out/k8-*/bin"]
```

For standalone **isort**::

```ini
# .isort.cfg
[isort]
src_paths = .,bazel-out/k8-*/bin
```

This allows ruff/isort to find generated ``.pyi`` stubs and ``.so`` extensions
when determining whether an import is first-party or third-party.

When ``gen_entrypoints`` is enabled (the default), running this target will
auto-discover ``console_scripts`` entrypoints from pip packages via
``importlib.metadata`` and generate executable scripts in the venv's ``bin/``
directory. Pre-built binaries shipped via wheel data scripts (e.g. ``ruff``)
are also symlinked into the venv. This allows IDEs to find tools like
``black``, ``ruff``, or ``mypy`` inside the venv. Additional entrypoints can
be specified manually via ``entrypoints``.


A `py_venv_binary` is an executable Python program consisting of a collection of
`.py` source files (possibly belonging to other `py_library` rules), a `*.runfiles`
directory tree containing all the code and data needed by the program at run-time,
and a stub script that starts up the program with the correct initial environment
and data.

```python
load("@rules_venv//python/venv:defs.bzl", "py_venv_binary")

py_venv_binary(
    name = "foo",
    srcs = ["foo.py"],
    data = [":transform"],  # a cc_binary which we invoke at run time
    deps = [
        ":bar",  # a py_library
    ],
)
```
"� 
�
py_global_venv�Define a "global venv" executable.

When ``gen_pyrightconfig`` is enabled (the default), running this target
writes a ``bazel-pyrightconfig.json`` at the workspace root containing
``extraPaths`` that point into ``bazel-bin``. This lets Pyright/Pylance
resolve generated Python sources that live outside the source tree.

To use it, add an ``extends`` field to your ``pyrightconfig.json``::

```json
{
    "extends": "bazel-pyrightconfig.json",
    ...
}
```

**Important:** Do not define ``extraPaths`` in your own ``pyrightconfig.json``
when using ``extends``. Pyright's ``extends`` replaces array fields rather
than merging them, so any ``extraPaths`` in the child config will override
the generated values from ``bazel-pyrightconfig.json``.

When targets use configuration transitions (e.g. ``py_cc_extension`` building
with ``compilation_mode = "opt"``), generated files may live in directories
like ``bazel-out/k8-opt/bin`` instead of ``bazel-out/k8-fastbuild/bin``. The
generated ``bazel-pyrightconfig.json`` includes all observed output directories
automatically.

For **ruff** or **isort** to correctly classify first-party imports that
include generated sources, add the Bazel output directories to the ``src``
setting::

```toml
# .ruff.toml
src = [".", "bazel-out/k8-*/bin"]
```

For standalone **isort**::

```ini
# .isort.cfg
[isort]
src_paths = .,bazel-out/k8-*/bin
```

This allows ruff/isort to find generated ``.pyi`` stubs and ``.so`` extensions
when determining whether an import is first-party or third-party.

When ``gen_entrypoints`` is enabled (the default), running this target will
auto-discover ``console_scripts`` entrypoints from pip packages via
``importlib.metadata`` and generate executable scripts in the venv's ``bin/``
directory. Pre-built binaries shipped via wheel data scripts (e.g. ``ruff``)
are also symlinked into the venv. This allows IDEs to find tools like
``black``, ``ruff``, or ``mypy`` inside the venv. Additional entrypoints can
be specified manually via ``entrypoints``.


A `py_venv_binary` is an executable Python program consisting of a collection of
`.py` source files (possibly belonging to other `py_library` rules), a `*.runfiles`
directory tree containing all the code and data needed by the program at run-time,
and a stub script that starts up the program with the correct initial environment
and data.

```python
load("@rules_venv//python/venv:defs.bzl", "py_venv_binary")

py_venv_binary(
    name = "foo",
    srcs = ["foo.py"],
    data = [":transform"],  # a cc_binary which we invoke at run time
    deps = [
        ":bar",  # a py_library
    ],
)
```
*
nameA unique name for this target. o
dataaFiles needed by this rule at runtime. May list file or rule targets. Generally allows any target.2[]K
deps3Other python targets to link to the current target.*
PyInfo2[]i
env\Dictionary of strings; values are subject to `$(location)` and "Make variable" substitution.
2{}L
imports;List of import directories to be added to the `PYTHONPATH`.2[]�
main�The name of the source file that is the main entry point of the application. This file must also be listed in `srcs`. If left unspecified, `name` is used instead. If `name` does not match any filename in `srcs`, `main` must be specified. 2NoneU
srcsGThe list of source (.py) files that are processed to create the target.2[]
,
*
nameA unique name for this target. q
o
dataaFiles needed by this rule at runtime. May list file or rule targets. Generally allows any target.2[]M
K
deps3Other python targets to link to the current target.*
PyInfo2[]k
i
env\Dictionary of strings; values are subject to `$(location)` and "Make variable" substitution.
2{}N
L
imports;List of import directories to be added to the `PYTHONPATH`.2[]�
�
main�The name of the source file that is the main entry point of the application. This file must also be listed in `srcs`. If left unspecified, `name` is used instead. If `name` does not match any filename in `srcs`, `main` must be specified. 2NoneW
U
srcsGThe list of source (.py) files that are processed to create the target.2[]�py_global_venv_aspectVAn aspect for generating metadata required to include Python targets in a global venv.:�
�
py_global_venv_aspectVAn aspect for generating metadata required to include Python targets in a global venv."*
nameA unique name for this target. *B
py_global_venv_aspect)@@rules_venv//python/global_venv:defs.bzl
��,
*
nameA unique name for this target. �
'//python/global_venv:py_global_venv.bzlru
4

rules_venvpython/global_venvpy_global_venv.bzl/
py_global_venv_py_global_venv
PP
NQ�
.//python/global_venv:py_global_venv_aspect.bzlr�
;

rules_venvpython/global_venvpy_global_venv_aspect.bzl=
py_global_venv_aspect_py_global_venv_aspect
TT
RU�# Global Venv

Bazel rules for generating usable [virtualenv][venv] from Bazel targets.

## Usage

A venv can be created by invoking the following command

```bash
bazel run @rules_venv//python/global_venv
```

From here a [venv][venv] will likely be available at `.venv` within your workspace that
can be activated for improved IDE support.

## Pyright / Pylance

By default, a `bazel-pyrightconfig.json` is generated with `extraPaths` pointing to
each Bazel output directory that contains generated Python sources. To use it, add
an `extends` field to your `pyrightconfig.json`:

```json
{
    "extends": "bazel-pyrightconfig.json"
}
```

**Important:** Do not define `extraPaths` in your own `pyrightconfig.json`. Pyright's
`extends` replaces array fields rather than merging them, so any `extraPaths` in the
child config will override the generated values.

## Ruff / isort

Ruff classifies imports as first-party by checking whether the imported module can be
resolved under its `src` directories. Generated sources (`.pyi` stubs, `.so` extensions)
only exist under `bazel-out`, so ruff needs those directories in `src`:

```toml
# .ruff.toml
src = [".", "bazel-out/k8-*/bin"]
```

For standalone isort:

```ini
# .isort.cfg
[isort]
src_paths = .,bazel-out/k8-*/bin
```

The glob `k8-*` covers all Bazel configurations (`k8-fastbuild`, `k8-opt`, `k8-dbg`).

## Entrypoints

By default, `py_global_venv` auto-discovers `console_scripts` entrypoints from pip
packages (via `importlib.metadata`) and generates executable scripts in the venv's
`bin/` directory. Pre-built binaries shipped via wheel data scripts (e.g. `ruff`) are
also symlinked into the venv. This allows IDEs to find tools like `black`, `ruff`, or
`mypy` inside the venv.

Additional entrypoints can be specified manually:

```python
py_global_venv(
    name = "global_venv",
    entrypoints = {
        "my_tool": "my.module:cli",
    },
)
```

Auto-discovery can be disabled with `gen_entrypoints = False`.

[venv]: https://docs.python.org/3/library/venv.html

�7
4

rules_venvpython/global_venvpy_global_venv.bzl�5py_global_venv�Define a "global venv" executable.

When ``gen_pyrightconfig`` is enabled (the default), running this target
writes a ``bazel-pyrightconfig.json`` at the workspace root containing
``extraPaths`` that point into ``bazel-bin``. This lets Pyright/Pylance
resolve generated Python sources that live outside the source tree.

To use it, add an ``extends`` field to your ``pyrightconfig.json``::

```json
{
    "extends": "bazel-pyrightconfig.json",
    ...
}
```

**Important:** Do not define ``extraPaths`` in your own ``pyrightconfig.json``
when using ``extends``. Pyright's ``extends`` replaces array fields rather
than merging them, so any ``extraPaths`` in the child config will override
the generated values from ``bazel-pyrightconfig.json``.

When targets use configuration transitions (e.g. ``py_cc_extension`` building
with ``compilation_mode = "opt"``), generated files may live in directories
like ``bazel-out/k8-opt/bin`` instead of ``bazel-out/k8-fastbuild/bin``. The
generated ``bazel-pyrightconfig.json`` includes all observed output directories
automatically.

For **ruff** or **isort** to correctly classify first-party imports that
include generated sources, add the Bazel output directories to the ``src``
setting::

```toml
# .ruff.toml
src = [".", "bazel-out/k8-*/bin"]
```

For standalone **isort**::

```ini
# .isort.cfg
[isort]
src_paths = .,bazel-out/k8-*/bin
```

This allows ruff/isort to find generated ``.pyi`` stubs and ``.so`` extensions
when determining whether an import is first-party or third-party.

When ``gen_entrypoints`` is enabled (the default), running this target will
auto-discover ``console_scripts`` entrypoints from pip packages via
``importlib.metadata`` and generate executable scripts in the venv's ``bin/``
directory. Pre-built binaries shipped via wheel data scripts (e.g. ``ruff``)
are also symlinked into the venv. This allows IDEs to find tools like
``black``, ``ruff``, or ``mypy`` inside the venv. Additional entrypoints can
be specified manually via ``entrypoints``.


A `py_venv_binary` is an executable Python program consisting of a collection of
`.py` source files (possibly belonging to other `py_library` rules), a `*.runfiles`
directory tree containing all the code and data needed by the program at run-time,
and a stub script that starts up the program with the correct initial environment
and data.

```python
load("@rules_venv//python/venv:defs.bzl", "py_venv_binary")

py_venv_binary(
    name = "foo",
    srcs = ["foo.py"],
    data = [":transform"],  # a cc_binary which we invoke at run time
    deps = [
        ":bar",  # a py_library
    ],
)
```
"� 
�
py_global_venv�Define a "global venv" executable.

When ``gen_pyrightconfig`` is enabled (the default), running this target
writes a ``bazel-pyrightconfig.json`` at the workspace root containing
``extraPaths`` that point into ``bazel-bin``. This lets Pyright/Pylance
resolve generated Python sources that live outside the source tree.

To use it, add an ``extends`` field to your ``pyrightconfig.json``::

```json
{
    "extends": "bazel-pyrightconfig.json",
    ...
}
```

**Important:** Do not define ``extraPaths`` in your own ``pyrightconfig.json``
when using ``extends``. Pyright's ``extends`` replaces array fields rather
than merging them, so any ``extraPaths`` in the child config will override
the generated values from ``bazel-pyrightconfig.json``.

When targets use configuration transitions (e.g. ``py_cc_extension`` building
with ``compilation_mode = "opt"``), generated files may live in directories
like ``bazel-out/k8-opt/bin`` instead of ``bazel-out/k8-fastbuild/bin``. The
generated ``bazel-pyrightconfig.json`` includes all observed output directories
automatically.

For **ruff** or **isort** to correctly classify first-party imports that
include generated sources, add the Bazel output directories to the ``src``
setting::

```toml
# .ruff.toml
src = [".", "bazel-out/k8-*/bin"]
```

For standalone **isort**::

```ini
# .isort.cfg
[isort]
src_paths = .,bazel-out/k8-*/bin
```

This allows ruff/isort to find generated ``.pyi`` stubs and ``.so`` extensions
when determining whether an import is first-party or third-party.

When ``gen_entrypoints`` is enabled (the default), running this target will
auto-discover ``console_scripts`` entrypoints from pip packages via
``importlib.metadata`` and generate executable scripts in the venv's ``bin/``
directory. Pre-built binaries shipped via wheel data scripts (e.g. ``ruff``)
are also symlinked into the venv. This allows IDEs to find tools like
``black``, ``ruff``, or ``mypy`` inside the venv. Additional entrypoints can
be specified manually via ``entrypoints``.


A `py_venv_binary` is an executable Python program consisting of a collection of
`.py` source files (possibly belonging to other `py_library` rules), a `*.runfiles`
directory tree containing all the code and data needed by the program at run-time,
and a stub script that starts up the program with the correct initial environment
and data.

```python
load("@rules_venv//python/venv:defs.bzl", "py_venv_binary")

py_venv_binary(
    name = "foo",
    srcs = ["foo.py"],
    data = [":transform"],  # a cc_binary which we invoke at run time
    deps = [
        ":bar",  # a py_library
    ],
)
```
*
nameA unique name for this target. o
dataaFiles needed by this rule at runtime. May list file or rule targets. Generally allows any target.2[]K
deps3Other python targets to link to the current target.*
PyInfo2[]i
env\Dictionary of strings; values are subject to `$(location)` and "Make variable" substitution.
2{}L
imports;List of import directories to be added to the `PYTHONPATH`.2[]�
main�The name of the source file that is the main entry point of the application. This file must also be listed in `srcs`. If left unspecified, `name` is used instead. If `name` does not match any filename in `srcs`, `main` must be specified. 2NoneU
srcsGThe list of source (.py) files that are processed to create the target.2[]
,
*
nameA unique name for this target. q
o
dataaFiles needed by this rule at runtime. May list file or rule targets. Generally allows any target.2[]M
K
deps3Other python targets to link to the current target.*
PyInfo2[]k
i
env\Dictionary of strings; values are subject to `$(location)` and "Make variable" substitution.
2{}N
L
imports;List of import directories to be added to the `PYTHONPATH`.2[]�
�
main�The name of the source file that is the main entry point of the application. This file must also be listed in `srcs`. If left unspecified, `name` is used instead. If `name` does not match any filename in `srcs`, `main` must be specified. 2NoneW
U
srcsGThe list of source (.py) files that are processed to create the target.2[]�
,//python/global_venv/private:global_venv.bzlrz
9

rules_venvpython/global_venv/privateglobal_venv.bzl/
py_global_venv_py_global_venv

# py_global_venv�;
;

rules_venvpython/global_venvpy_global_venv_aspect.bzl�5py_global_venv�Define a "global venv" executable.

When ``gen_pyrightconfig`` is enabled (the default), running this target
writes a ``bazel-pyrightconfig.json`` at the workspace root containing
``extraPaths`` that point into ``bazel-bin``. This lets Pyright/Pylance
resolve generated Python sources that live outside the source tree.

To use it, add an ``extends`` field to your ``pyrightconfig.json``::

```json
{
    "extends": "bazel-pyrightconfig.json",
    ...
}
```

**Important:** Do not define ``extraPaths`` in your own ``pyrightconfig.json``
when using ``extends``. Pyright's ``extends`` replaces array fields rather
than merging them, so any ``extraPaths`` in the child config will override
the generated values from ``bazel-pyrightconfig.json``.

When targets use configuration transitions (e.g. ``py_cc_extension`` building
with ``compilation_mode = "opt"``), generated files may live in directories
like ``bazel-out/k8-opt/bin`` instead of ``bazel-out/k8-fastbuild/bin``. The
generated ``bazel-pyrightconfig.json`` includes all observed output directories
automatically.

For **ruff** or **isort** to correctly classify first-party imports that
include generated sources, add the Bazel output directories to the ``src``
setting::

```toml
# .ruff.toml
src = [".", "bazel-out/k8-*/bin"]
```

For standalone **isort**::

```ini
# .isort.cfg
[isort]
src_paths = .,bazel-out/k8-*/bin
```

This allows ruff/isort to find generated ``.pyi`` stubs and ``.so`` extensions
when determining whether an import is first-party or third-party.

When ``gen_entrypoints`` is enabled (the default), running this target will
auto-discover ``console_scripts`` entrypoints from pip packages via
``importlib.metadata`` and generate executable scripts in the venv's ``bin/``
directory. Pre-built binaries shipped via wheel data scripts (e.g. ``ruff``)
are also symlinked into the venv. This allows IDEs to find tools like
``black``, ``ruff``, or ``mypy`` inside the venv. Additional entrypoints can
be specified manually via ``entrypoints``.


A `py_venv_binary` is an executable Python program consisting of a collection of
`.py` source files (possibly belonging to other `py_library` rules), a `*.runfiles`
directory tree containing all the code and data needed by the program at run-time,
and a stub script that starts up the program with the correct initial environment
and data.

```python
load("@rules_venv//python/venv:defs.bzl", "py_venv_binary")

py_venv_binary(
    name = "foo",
    srcs = ["foo.py"],
    data = [":transform"],  # a cc_binary which we invoke at run time
    deps = [
        ":bar",  # a py_library
    ],
)
```
"� 
�
py_global_venv�Define a "global venv" executable.

When ``gen_pyrightconfig`` is enabled (the default), running this target
writes a ``bazel-pyrightconfig.json`` at the workspace root containing
``extraPaths`` that point into ``bazel-bin``. This lets Pyright/Pylance
resolve generated Python sources that live outside the source tree.

To use it, add an ``extends`` field to your ``pyrightconfig.json``::

```json
{
    "extends": "bazel-pyrightconfig.json",
    ...
}
```

**Important:** Do not define ``extraPaths`` in your own ``pyrightconfig.json``
when using ``extends``. Pyright's ``extends`` replaces array fields rather
than merging them, so any ``extraPaths`` in the child config will override
the generated values from ``bazel-pyrightconfig.json``.

When targets use configuration transitions (e.g. ``py_cc_extension`` building
with ``compilation_mode = "opt"``), generated files may live in directories
like ``bazel-out/k8-opt/bin`` instead of ``bazel-out/k8-fastbuild/bin``. The
generated ``bazel-pyrightconfig.json`` includes all observed output directories
automatically.

For **ruff** or **isort** to correctly classify first-party imports that
include generated sources, add the Bazel output directories to the ``src``
setting::

```toml
# .ruff.toml
src = [".", "bazel-out/k8-*/bin"]
```

For standalone **isort**::

```ini
# .isort.cfg
[isort]
src_paths = .,bazel-out/k8-*/bin
```

This allows ruff/isort to find generated ``.pyi`` stubs and ``.so`` extensions
when determining whether an import is first-party or third-party.

When ``gen_entrypoints`` is enabled (the default), running this target will
auto-discover ``console_scripts`` entrypoints from pip packages via
``importlib.metadata`` and generate executable scripts in the venv's ``bin/``
directory. Pre-built binaries shipped via wheel data scripts (e.g. ``ruff``)
are also symlinked into the venv. This allows IDEs to find tools like
``black``, ``ruff``, or ``mypy`` inside the venv. Additional entrypoints can
be specified manually via ``entrypoints``.


A `py_venv_binary` is an executable Python program consisting of a collection of
`.py` source files (possibly belonging to other `py_library` rules), a `*.runfiles`
directory tree containing all the code and data needed by the program at run-time,
and a stub script that starts up the program with the correct initial environment
and data.

```python
load("@rules_venv//python/venv:defs.bzl", "py_venv_binary")

py_venv_binary(
    name = "foo",
    srcs = ["foo.py"],
    data = [":transform"],  # a cc_binary which we invoke at run time
    deps = [
        ":bar",  # a py_library
    ],
)
```
*
nameA unique name for this target. o
dataaFiles needed by this rule at runtime. May list file or rule targets. Generally allows any target.2[]K
deps3Other python targets to link to the current target.*
PyInfo2[]i
env\Dictionary of strings; values are subject to `$(location)` and "Make variable" substitution.
2{}L
imports;List of import directories to be added to the `PYTHONPATH`.2[]�
main�The name of the source file that is the main entry point of the application. This file must also be listed in `srcs`. If left unspecified, `name` is used instead. If `name` does not match any filename in `srcs`, `main` must be specified. 2NoneU
srcsGThe list of source (.py) files that are processed to create the target.2[]
,
*
nameA unique name for this target. q
o
dataaFiles needed by this rule at runtime. May list file or rule targets. Generally allows any target.2[]M
K
deps3Other python targets to link to the current target.*
PyInfo2[]k
i
env\Dictionary of strings; values are subject to `$(location)` and "Make variable" substitution.
2{}N
L
imports;List of import directories to be added to the `PYTHONPATH`.2[]�
�
main�The name of the source file that is the main entry point of the application. This file must also be listed in `srcs`. If left unspecified, `name` is used instead. If `name` does not match any filename in `srcs`, `main` must be specified. 2NoneW
U
srcsGThe list of source (.py) files that are processed to create the target.2[]�py_global_venv_aspectVAn aspect for generating metadata required to include Python targets in a global venv.:�
�
py_global_venv_aspectVAn aspect for generating metadata required to include Python targets in a global venv."*
nameA unique name for this target. *S
py_global_venv_aspect:@@rules_venv//python/global_venv:py_global_venv_aspect.bzl
��,
*
nameA unique name for this target. �
,//python/global_venv/private:global_venv.bzlr�
9

rules_venvpython/global_venv/privateglobal_venv.bzl/
py_global_venv_py_global_venv
=
py_global_venv_aspect_py_global_venv_aspect

# py_global_venv_aspect�
-

rules_venvpython/isort/private	isort.bzl�py_isort_test,A rule for running isort on a Python target."�
�
py_isort_test,A rule for running isort on a Python target.*
nameA unique name for this target. Y
config6The config file (isort.cfg) containing isort settings.2//python/isort:config5
targetThe target to run `isort` on. *
PyInfo"=
py_isort_test,@@rules_venv//python/isort/private:isort.bzl
FF,
*
nameA unique name for this target. [
Y
config6The config file (isort.cfg) containing isort settings.2//python/isort:config7
5
targetThe target to run `isort` on. *
PyInfo�py_isort_aspect;An aspect for running isort on targets with Python sources.:�
�
py_isort_aspect;An aspect for running isort on targets with Python sources."*
nameA unique name for this target. *?
py_isort_aspect,@@rules_venv//python/isort/private:isort.bzl
��,
*
nameA unique name for this target. k
//python:py_info.bzlrQ
!

rules_venvpythonpy_info.bzl
PyInfoPyInfo
*0
2�
 //python/private:target_srcs.bzlr�
-

rules_venvpython/privatetarget_srcs.bzl,
PySourcesInfoPySourcesInfo
6C<
target_sources_aspecttarget_sources_aspect
G\
^
//python/venv:defs.bzlrc
#

rules_venvpython/venvdefs.bzl.
py_venv_commonpy_venv_common
,:
<Bazel rules for isort�	
7

rules_venvpython/isort/privateisort_toolchain.bzl�current_py_isort_toolchain@A rule for exposing the current registered `py_isort_toolchain`."�
�
current_py_isort_toolchain@A rule for exposing the current registered `py_isort_toolchain`.*
nameA unique name for this target. "T
current_py_isort_toolchain6@@rules_venv//python/isort/private:isort_toolchain.bzl
="=",
*
nameA unique name for this target. �py_isort_toolchainVA toolchain for the [isort](https://pycqa.github.io/isort/index.html) formatter rules."�
�
py_isort_toolchainVA toolchain for the [isort](https://pycqa.github.io/isort/index.html) formatter rules.*
nameA unique name for this target. D
isort-The isort `py_library` to use with the rules. *
PyInfo"L
py_isort_toolchain6@@rules_venv//python/isort/private:isort_toolchain.bzl
,
*
nameA unique name for this target. F
D
isort-The isort `py_library` to use with the rules. *
PyInfok
//python:py_info.bzlrQ
!

rules_venvpythonpy_info.bzl
PyInfoPyInfo
*0
2V	TOOLCHAIN_TYPE@@//python/isort:toolchain_typej!@@//python/isort:toolchain_typeisort toolchain rules.�
$

rules_venvpython/isortdefs.bzl�py_isort_toolchainVA toolchain for the [isort](https://pycqa.github.io/isort/index.html) formatter rules."�
�
py_isort_toolchainVA toolchain for the [isort](https://pycqa.github.io/isort/index.html) formatter rules.*
nameA unique name for this target. D
isort-The isort `py_library` to use with the rules. *
PyInfo"9
py_isort_toolchain#@@rules_venv//python/isort:defs.bzl
,
*
nameA unique name for this target. F
D
isort-The isort `py_library` to use with the rules. *
PyInfo�py_isort_aspect;An aspect for running isort on targets with Python sources.:�
�
py_isort_aspect;An aspect for running isort on targets with Python sources."*
nameA unique name for this target. *6
py_isort_aspect#@@rules_venv//python/isort:defs.bzl
��,
*
nameA unique name for this target. �
"//python/isort:py_isort_aspect.bzlrr
/

rules_venvpython/isortpy_isort_aspect.bzl1
py_isort_aspect_py_isort_aspect
TT
RU�
 //python/isort:py_isort_test.bzlrl
-

rules_venvpython/isortpy_isort_test.bzl-
py_isort_test_py_isort_test
XX
VY�
%//python/isort:py_isort_toolchain.bzlr{
2

rules_venvpython/isortpy_isort_toolchain.bzl7
py_isort_toolchain_py_isort_toolchain
\\
Z]�# isort

Bazel rules for the Python formatter [isort][is].

### Setup

First ensure `rules_venv` is setup by referring to [rules_venv setup](../index.md#setup).

Next, the `rules_venv` rules work mostly off of toolchains which are used to provide the necessary python targets (aka `isort`)
for the process wrappers. Users will want to make sure they have a way to get the necessary python dependencies. Tools such as
[req-compile](https://github.com/periareon/req-compile) can provide these.

With the appropriate dependencies available, a [py_isort_toolchain](#py_isort_toolchain) will need to be configured:

```python
load("@rules_venv//python/isort:defs.bzl", "py_isort_toolchain")

py_isort_toolchain(
    name = "toolchain_impl",
    isort = "@pip_deps//isort",
    visibility = ["//visibility:public"]
)

toolchain(
    name = "toolchain",
    toolchain = ":toolchain_impl",
    toolchain_type = "@rules_venv//python/isort:toolchain_type",
    visibility = ["//visibility:public"]
)
```

This toolchain then needs to be registered in the `MODULE.bazel` file.

```python
register_toolchains("//tools/python/isort:toolchain")
```


### Usage

Python code can be formatted using the following command:

```bash
bazel run @rules_venv//python/isort
```

In addition to this formatter, a check can be added to `bazel build` invocations using the [py_isort_aspect](#py_isort_aspect)
aspect. Simply add the following to a `.bazelrc` file to enable this check.

```text
build --aspects=@rules_venv//python/isort:py_isort_aspect.bzl%py_isort_aspect
build --output_groups=+py_isort_checks
```

## Sections and Ordering

Of all isort [sections](https://pycqa.github.io/isort/reference/isort/sections.html), `FIRSTPARTY` and
`THIRDPARTY` follow unique rules to ensure ordering makes sense on a per-target basis.

### First party

- Direct source dependencies passed to the `srcs` attribute.
- Repository relative packages.

### Third party

- Other `py_*` targets (the `deps` attribute). Note that `deps` which use repo absolute import paths
will be considered first party.

## Tips

Isort is sensitive to the [`legacy_create_init`][legacy_init] attribute on python rules. For more correct
and consistent behavior, this value should always be `0` or if the default of `-1` is set, the
[`--incompatible_default_to_explicit_init_py`][incompat_init] flag should be added to the workspace's
`.bazelrc` file to ensure the behavior is disabled.

[legacy_init]: https://bazel.build/reference/be/python#py_binary.legacy_create_init
[incompat_init]: https://github.com/bazelbuild/bazel/issues/10076
[is]: https://pycqa.github.io/isort/
�
/

rules_venvpython/isortpy_isort_aspect.bzl�py_isort_aspect;An aspect for running isort on targets with Python sources.:�
�
py_isort_aspect;An aspect for running isort on targets with Python sources."*
nameA unique name for this target. *A
py_isort_aspect.@@rules_venv//python/isort:py_isort_aspect.bzl
��,
*
nameA unique name for this target. �
 //python/isort/private:isort.bzlrp
-

rules_venvpython/isort/private	isort.bzl1
py_isort_aspect_py_isort_aspect

# py_isort_aspect�
2

rules_venvpython/isortpy_isort_toolchain.bzl�py_isort_toolchainVA toolchain for the [isort](https://pycqa.github.io/isort/index.html) formatter rules."�
�
py_isort_toolchainVA toolchain for the [isort](https://pycqa.github.io/isort/index.html) formatter rules.*
nameA unique name for this target. D
isort-The isort `py_library` to use with the rules. *
PyInfo"G
py_isort_toolchain1@@rules_venv//python/isort:py_isort_toolchain.bzl
,
*
nameA unique name for this target. F
D
isort-The isort `py_library` to use with the rules. *
PyInfo�
*//python/isort/private:isort_toolchain.bzlr�
7

rules_venvpython/isort/privateisort_toolchain.bzl7
py_isort_toolchain_py_isort_toolchain

# py_isort_toolchain��
?

rules_venvpython/module_extension/privatecc_extension.bzl�
py_cc_extension_library/Define a Python library for a module extension."�	
�
py_cc_extension_library/Define a Python library for a module extension.*
nameA unique name for this target. ?
abi2An optional abi value for the output library name.2""�
compilation_mode�Specify the mode `extension` will be built in. For details see  [`--compilation_mode`](https://bazel.build/reference/command-line-reference#flag--compilation_mode)2"opt"8
	extensionThe module extension library. *
CcInfoL
imports;List of import directories to be added to the `PYTHONPATH`.2[]>
stripped)Use the stripped output from `extension`.2False"Y
py_cc_extension_library>@@rules_venv//python/module_extension/private:cc_extension.bzl
��,
*
nameA unique name for this target. A
?
abi2An optional abi value for the output library name.2""�
�
compilation_mode�Specify the mode `extension` will be built in. For details see  [`--compilation_mode`](https://bazel.build/reference/command-line-reference#flag--compilation_mode)2"opt":
8
	extensionThe module extension library. *
CcInfoN
L
imports;List of import directories to be added to the `PYTHONPATH`.2[]@
>
stripped)Use the stripped output from `extension`.2False��py_cc_extension�Define a Python C extension module.

This target is consumed just as a `py_library` would be.



<p>It produces an executable binary.</p>

<br/>The <code>name</code> of the target should be the same as the name of the
source file that is the main entry point of the application (minus the extension).
For example, if your entry point is in <code>main.cc</code>, then your name should
be <code>main</code>.

<h4>Implicit output targets</h4>
<ul>
<li><code><var>name</var>.stripped</code> (only built if explicitly requested): A stripped
  version of the binary. <code>strip -g</code> is run on the binary to remove debug
  symbols.  Additional strip options can be provided on the command line using
  <code>--stripopt=-foo</code>.</li>
<li><code><var>name</var>.dwp</code> (only built if explicitly requested): If
  <a href="https://gcc.gnu.org/wiki/DebugFission">Fission</a> is enabled: a debug
  information package file suitable for debugging remotely deployed binaries. Else: an
  empty file.</li>
</ul>
"��
��
py_cc_extension�Define a Python C extension module.

This target is consumed just as a `py_library` would be.



<p>It produces an executable binary.</p>

<br/>The <code>name</code> of the target should be the same as the name of the
source file that is the main entry point of the application (minus the extension).
For example, if your entry point is in <code>main.cc</code>, then your name should
be <code>main</code>.

<h4>Implicit output targets</h4>
<ul>
<li><code><var>name</var>.stripped</code> (only built if explicitly requested): A stripped
  version of the binary. <code>strip -g</code> is run on the binary to remove debug
  symbols.  Additional strip options can be provided on the command line using
  <code>--stripopt=-foo</code>.</li>
<li><code><var>name</var>.dwp</code> (only built if explicitly requested): If
  <a href="https://gcc.gnu.org/wiki/DebugFission">Fission</a> is enabled: a debug
  information package file suitable for debugging remotely deployed binaries. Else: an
  empty file.</li>
</ul>
*
nameA unique name for this target. �
additional_compiler_inputs�
Any additional files you might want to pass to the compiler command line, such as sanitizer
ignorelists, for example. Files specified here can then be used in copts with the
$(location) function.
2[]�
additional_linker_inputs�
Dependencies that are only made available to the C++ linker command.
<p>
  Unlike <code>deps</code>, which is conceptually made for both compilation and
  linking dependencies, <code>additional_linker_inputs</code> is specifically
  made for only the latter, and signals a dependency that is required only for
  linking (for example, files that are referenced in <code>linkopts</code>).
</p>
<p>
  For example, compiled Windows .res files can be provided here to be embedded in
  the binary target.
</p>
2[]�
	conlyopts�
Add these options to the C compilation command.
Subject to <a href="${link make-variables}">"Make variable"</a> substitution and
<a href="${link common-definitions#sh-tokenization}">Bourne shell tokenization</a>.
2[]�
copts�
Add these options to the C/C++ compilation command.
Subject to <a href="${link make-variables}">"Make variable"</a> substitution and
<a href="${link common-definitions#sh-tokenization}">Bourne shell tokenization</a>.
<p>
  Each string in this attribute is added in the given order to <code>COPTS</code> before
  compiling the binary target. The flags take effect only for compiling this target, not
  its dependencies, so be careful about header files included elsewhere.
  All paths should be relative to the workspace, not to the current package.
  This attribute should not be needed outside of <code>third_party</code>.
</p>
<p>
  If the package declares the <a href="${link package.features}">feature</a>
  <code>no_copts_tokenization</code>, Bourne shell tokenization applies only to strings
  that consist of a single "Make" variable.
</p>
2[]�
cxxopts�
Add these options to the C++ compilation command.
Subject to <a href="${link make-variables}">"Make variable"</a> substitution and
<a href="${link common-definitions#sh-tokenization}">Bourne shell tokenization</a>.
2[]�
data�
The list of files needed by this library at runtime.

See general comments about <code>data</code>
at <a href="${link common-definitions#typical-attributes}">Typical attributes defined by
most build rules</a>.
<p>If a <code>data</code> is the name of a generated file, then this
   <code>cc_library</code> rule automatically depends on the generating
   rule.
</p>
<p>If a <code>data</code> is a rule name, then this
   <code>cc_library</code> rule automatically depends on that rule,
   and that rule's <code>outs</code> are automatically added to
   this <code>cc_library</code>'s data files.
</p>
<p>Your C++ code can access these data files like so:</p>
<pre><code class="lang-starlark">
  const std::string path = devtools_build::GetDataDependencyFilepath(
      "my/test/data/file");
</code></pre>
2[]�
defines�
List of defines to add to the compile line of this and all dependent targets.
Subject to <a href="${link make-variables}">"Make" variable</a> substitution and
<a href="${link common-definitions#sh-tokenization}">Bourne shell tokenization</a>.
Each string, which must consist of a single Bourne shell token,
is prepended with <code>-D</code> and added to the compile command line to this target,
as well as to every rule that depends on it. Be very careful, since this may have
far-reaching effects -- the defines are added to every target that depends on
this target.  When in doubt, add define values to
<a href="#cc_binary.local_defines"><code>local_defines</code></a> instead.
2[]�
deps�
The list of other libraries to be linked in to the binary target.
<p>These can be <code>cc_library</code> or <code>objc_library</code>
targets.</p>

It is also allowed to
put linker scripts (.lds) into deps, and reference them in
<a href="#cc_binary.linkopts"><code>linkopts</code></a>,
but please consider
<a href="#cc_binary.additional_linker_inputs"><code>additional_linker_inputs</code></a>
for that use case.
*
CcInfo2[]�
dynamic_deps�
These are other <code>cc_shared_library</code> dependencies the current target depends on.

<p>
The <code>cc_shared_library</code> implementation will use the list of
<code>dynamic_deps</code> (transitively, i.e. also the <code>dynamic_deps</code> of the
current target's <code>dynamic_deps</code>) to decide which <code>cc_libraries</code> in
the transitive <code>deps</code> should not be linked in because they are already provided
by a different <code>cc_shared_library</code>.
*
CcSharedLibraryInfo2[]
env
2{}&

hdrs_checkDeprecated, no-op.2""�
includes�
List of include dirs to be added to the compile line.
Subject to <a href="${link make-variables}">"Make variable"</a> substitution.
Each string is prepended with the package path and passed to the C++ toolchain for
expansion via the "include_paths" CROSSTOOL feature. A toolchain running on a POSIX system
with typical feature definitions will produce
<code>-isystem path_to_package/include_entry</code>.
This should only be used for third-party libraries that
do not conform to the Google style of writing #include statements.
Unlike <a href="#cc_binary.copts">COPTS</a>, these flags are added for this rule
and every rule that depends on it. (Note: not the rules it depends upon!) Be
very careful, since this may have far-reaching effects.  When in doubt, add
"-I" flags to <a href="#cc_binary.copts">COPTS</a> instead.
<p>
The added <code>include</code> paths will include generated files as well as
files in the source tree.
</p>
2[]
licenses2[]�
link_extra_lib�
Control linking of extra libraries.
<p>
    By default, C++ binaries are linked against <code>@bazel_tools//tools/cpp:link_extra_lib</code>,
    which by default depends on the label flag <code>@bazel_tools//tools/cpp:link_extra_libs</code>.
    Without setting the flag, this library is empty by default. Setting the label flag
    allows linking optional dependencies, such as overrides for weak symbols, interceptors
    for shared library functions, or special runtime libraries (for malloc replacements,
    prefer <code>malloc</code> or <code>--custom_malloc</code>). Setting this attribute to
    <code>None</code> disables this behaviour.
</p>
*
CcInfo2&@bazel_tools//tools/cpp:link_extra_lib�
linkopts�
Add these flags to the C++ linker command.
Subject to <a href="make-variables.html">"Make" variable</a> substitution,
<a href="common-definitions.html#sh-tokenization">
Bourne shell tokenization</a> and
<a href="common-definitions.html#label-expansion">label expansion</a>.
Each string in this attribute is added to <code>LINKOPTS</code> before
linking the binary target.
<p>
    Each element of this list that does not start with <code>$</code> or <code>-</code> is
    assumed to be the label of a target in <code>deps</code>. The
    list of files generated by that target is appended to the linker
    options.  An error is reported if the label is invalid, or is
    not declared in <code>deps</code>.
</p>
2[]�

linkshared�
Create a shared library.
To enable this attribute, include <code>linkshared=True</code> in your rule. By default
this option is off.
<p>
  The presence of this flag means that linking occurs with the <code>-shared</code> flag
  to <code>gcc</code>, and the resulting shared library is suitable for loading into for
  example a Java program. However, for build purposes it will never be linked into the
  dependent binary, as it is assumed that shared libraries built with a
  <a href="#cc_binary">cc_binary</a> rule are only loaded manually by other programs, so
  it should not be considered a substitute for the <a href="#cc_library">cc_library</a>
  rule. For sake of scalability we recommend avoiding this approach altogether and
  simply letting <code>java_library</code> depend on <code>cc_library</code> rules
  instead.
</p>
<p>
  If you specify both <code>linkopts=['-static']</code> and <code>linkshared=True</code>,
  you get a single completely self-contained unit. If you specify both
  <code>linkstatic=True</code> and <code>linkshared=True</code>, you get a single, mostly
  self-contained unit.
</p>
2False�

linkstatic�
For <a href="${link cc_binary}"><code>cc_binary</code></a> and
<a href="${link cc_test}"><code>cc_test</code></a>: link the binary in static
mode. For <code>cc_library.link_static</code>: see below.
<p>By default this option is on for <code>cc_binary</code> and off for the rest.</p>
<p>
  If enabled and this is a binary or test, this option tells the build tool to link in
  <code>.a</code>'s instead of <code>.so</code>'s for user libraries whenever possible.
  System libraries such as libc (but <i>not</i> the C/C++ runtime libraries,
  see below) are still linked dynamically, as are libraries for which
  there is no static library. So the resulting executable will still be dynamically
  linked, hence only <i>mostly</i> static.
</p>
<p>
There are really three different ways to link an executable:
</p>
<ul>
<li> STATIC with fully_static_link feature, in which everything is linked statically;
  e.g. "<code>gcc -static foo.o libbar.a libbaz.a -lm</code>".<br/>
  This mode is enabled by specifying <code>fully_static_link</code> in the
  <a href="${link common-definitions#features}"><code>features</code></a> attribute.</li>
<li> STATIC, in which all user libraries are linked statically (if a static
  version is available), but where system libraries (excluding C/C++ runtime libraries)
  are linked dynamically, e.g. "<code>gcc foo.o libfoo.a libbaz.a -lm</code>".<br/>
  This mode is enabled by specifying <code>linkstatic=True</code>.</li>
<li> DYNAMIC, in which all libraries are linked dynamically (if a dynamic version is
  available), e.g. "<code>gcc foo.o libfoo.so libbaz.so -lm</code>".<br/>
  This mode is enabled by specifying <code>linkstatic=False</code>.</li>
</ul>
<p>
If the <code>linkstatic</code> attribute or <code>fully_static_link</code> in
<code>features</code> is used outside of <code>//third_party</code>
please include a comment near the rule to explain why.
</p>
<p>
The <code>linkstatic</code> attribute has a different meaning if used on a
<a href="${link cc_library}"><code>cc_library()</code></a> rule.
For a C++ library, <code>linkstatic=True</code> indicates that only
static linking is allowed, so no <code>.so</code> will be produced. linkstatic=False does
not prevent static libraries from being created. The attribute is meant to control the
creation of dynamic libraries.
</p>
<p>
There should be very little code built with <code>linkstatic=False</code> in production.
If <code>linkstatic=False</code>, then the build tool will create symlinks to
depended-upon shared libraries in the <code>*.runfiles</code> area.
</p>
2True�
local_defines�
List of defines to add to the compile line.
Subject to <a href="${link make-variables}">"Make" variable</a> substitution and
<a href="${link common-definitions#sh-tokenization}">Bourne shell tokenization</a>.
Each string, which must consist of a single Bourne shell token,
is prepended with <code>-D</code> and added to the compile command line for this target,
but not to its dependents. Unlike <code>defines</code>, the defines are only added to the
compile command line for this target.
2[]�
malloc�
Override the default dependency on malloc.
<p>
  By default, C++ binaries are linked against <code>//tools/cpp:malloc</code>,
  which is an empty library so the binary ends up using libc malloc.
  This label must refer to a <code>cc_library</code>. If compilation is for a non-C++
  rule, this option has no effect. The value of this attribute is ignored if
  <code>linkshared=True</code> is specified.
</p>
*
CcInfo2@bazel_tools//tools/cpp:malloc�
module_interfaces�
The list of files are regarded as C++20 Modules Interface.

<p>
C++ Standard has no restriction about module interface file extension
<ul>
<li>Clang use cppm </li>
<li>GCC can use any source file extension </li>
<li>MSVC use ixx </li>
</ul>
</p>
<p>The use is guarded by the flag
<code>--experimental_cpp_modules</code>.</p>
2[]�
nocopts�
Remove matching options from the C++ compilation command.
Subject to <a href="${link make-variables}">"Make" variable</a> substitution.
The value of this attribute is interpreted as a regular expression.
Any preexisting <code>COPTS</code> that match this regular expression
(including values explicitly specified in the rule's <a
href="#cc_binary.copts">copts</a> attribute)
will be removed from <code>COPTS</code> for purposes of compiling this rule.
This attribute should not be needed or used
outside of <code>third_party</code>.  The values are not preprocessed
in any way other than the "Make" variable substitution.
2""
reexport_deps2[]�
srcs�
The list of C and C++ files that are processed to create the library target.
These are C/C++ source and header files, either non-generated (normal source
code) or generated.
<p>All <code>.cc</code>, <code>.c</code>, and <code>.cpp</code> files will
   be compiled. These might be generated files: if a named file is in
   the <code>outs</code> of some other rule, this <code>cc_library</code>
   will automatically depend on that other rule.
</p>
<p>Pure assembler files (.s, .asm) are not preprocessed and are typically built using
the assembler. Preprocessed assembly files (.S) are preprocessed and are typically built
using the C/C++ compiler.
</p>
<p>A <code>.h</code> file will not be compiled, but will be available for
   inclusion by sources in this rule. Both <code>.cc</code> and
   <code>.h</code> files can directly include headers listed in
   these <code>srcs</code> or in the <code>hdrs</code> of this rule or any
   rule listed in the <code>deps</code> argument.
</p>
<p>All <code>#include</code>d files must be mentioned in the
   <code>hdrs</code> attribute of this or referenced <code>cc_library</code>
   rules, or they should be listed in <code>srcs</code> if they are private
   to this library. See <a href="#hdrs">"Header inclusion checking"</a> for
   a more detailed description.
</p>
<p><code>.so</code>, <code>.lo</code>, and <code>.a</code> files are
   pre-compiled files. Your library might have these as
   <code>srcs</code> if it uses third-party code for which we don't
   have source code.
</p>
<p>If the <code>srcs</code> attribute includes the label of another rule,
   <code>cc_library</code> will use the output files of that rule as source files to
   compile. This is useful for one-off generation of source code (for more than occasional
   use, it's better to implement a Starlark rule class and use the <code>cc_common</code>
   API)
</p>
<p>
  Permitted <code>srcs</code> file types:
</p>
<ul>
<li>C and C++ source files: <code>.c</code>, <code>.cc</code>, <code>.cpp</code>,
  <code>.cxx</code>, <code>.c++</code>, <code>.C</code></li>
<li>C and C++ header files: <code>.h</code>, <code>.hh</code>, <code>.hpp</code>,
  <code>.hxx</code>, <code>.inc</code>, <code>.inl</code>, <code>.H</code></li>
<li>Assembler with C preprocessor: <code>.S</code></li>
<li>Archive: <code>.a</code>, <code>.pic.a</code></li>
<li>"Always link" library: <code>.lo</code>, <code>.pic.lo</code></li>
<li>Shared library, versioned or unversioned: <code>.so</code>,
  <code>.so.<i>version</i></code></li>
<li>Object file: <code>.o</code>, <code>.pic.o</code></li>
</ul>

<p>
  ... and any rules that produce those files (e.g. <code>cc_embed_data</code>).
  Different extensions denote different programming languages in
  accordance with gcc convention.
</p>
2[]�
stamp�
Whether to encode build information into the binary. Possible values:
<ul>
<li>
  <code>stamp = 1</code>: Always stamp the build information into the binary, even in
  <a href="${link user-manual#flag--stamp}"><code>--nostamp</code></a> builds. <b>This
  setting should be avoided</b>, since it potentially kills remote caching for the
  binary and any downstream actions that depend on it.
</li>
<li>
  <code>stamp = 0</code>: Always replace build information by constant values. This
  gives good build result caching.
</li>
<li>
  <code>stamp = -1</code>: Embedding of build information is controlled by the
  <a href="${link user-manual#flag--stamp}"><code>--[no]stamp</code></a> flag.
</li>
</ul>
<p>Stamped binaries are <em>not</em> rebuilt unless their dependencies change.</p>
2-1�
win_def_file�
The Windows DEF file to be passed to linker.
<p>This attribute should only be used when Windows is the target platform.
It can be used to <a href="https://msdn.microsoft.com/en-us/library/d91k01sh.aspx">
export symbols</a> during linking a shared library.</p>
2None
��,
*
nameA unique name for this target. �
�
additional_compiler_inputs�
Any additional files you might want to pass to the compiler command line, such as sanitizer
ignorelists, for example. Files specified here can then be used in copts with the
$(location) function.
2[]�
�
additional_linker_inputs�
Dependencies that are only made available to the C++ linker command.
<p>
  Unlike <code>deps</code>, which is conceptually made for both compilation and
  linking dependencies, <code>additional_linker_inputs</code> is specifically
  made for only the latter, and signals a dependency that is required only for
  linking (for example, files that are referenced in <code>linkopts</code>).
</p>
<p>
  For example, compiled Windows .res files can be provided here to be embedded in
  the binary target.
</p>
2[]�
�
	conlyopts�
Add these options to the C compilation command.
Subject to <a href="${link make-variables}">"Make variable"</a> substitution and
<a href="${link common-definitions#sh-tokenization}">Bourne shell tokenization</a>.
2[]�
�
copts�
Add these options to the C/C++ compilation command.
Subject to <a href="${link make-variables}">"Make variable"</a> substitution and
<a href="${link common-definitions#sh-tokenization}">Bourne shell tokenization</a>.
<p>
  Each string in this attribute is added in the given order to <code>COPTS</code> before
  compiling the binary target. The flags take effect only for compiling this target, not
  its dependencies, so be careful about header files included elsewhere.
  All paths should be relative to the workspace, not to the current package.
  This attribute should not be needed outside of <code>third_party</code>.
</p>
<p>
  If the package declares the <a href="${link package.features}">feature</a>
  <code>no_copts_tokenization</code>, Bourne shell tokenization applies only to strings
  that consist of a single "Make" variable.
</p>
2[]�
�
cxxopts�
Add these options to the C++ compilation command.
Subject to <a href="${link make-variables}">"Make variable"</a> substitution and
<a href="${link common-definitions#sh-tokenization}">Bourne shell tokenization</a>.
2[]�
�
data�
The list of files needed by this library at runtime.

See general comments about <code>data</code>
at <a href="${link common-definitions#typical-attributes}">Typical attributes defined by
most build rules</a>.
<p>If a <code>data</code> is the name of a generated file, then this
   <code>cc_library</code> rule automatically depends on the generating
   rule.
</p>
<p>If a <code>data</code> is a rule name, then this
   <code>cc_library</code> rule automatically depends on that rule,
   and that rule's <code>outs</code> are automatically added to
   this <code>cc_library</code>'s data files.
</p>
<p>Your C++ code can access these data files like so:</p>
<pre><code class="lang-starlark">
  const std::string path = devtools_build::GetDataDependencyFilepath(
      "my/test/data/file");
</code></pre>
2[]�
�
defines�
List of defines to add to the compile line of this and all dependent targets.
Subject to <a href="${link make-variables}">"Make" variable</a> substitution and
<a href="${link common-definitions#sh-tokenization}">Bourne shell tokenization</a>.
Each string, which must consist of a single Bourne shell token,
is prepended with <code>-D</code> and added to the compile command line to this target,
as well as to every rule that depends on it. Be very careful, since this may have
far-reaching effects -- the defines are added to every target that depends on
this target.  When in doubt, add define values to
<a href="#cc_binary.local_defines"><code>local_defines</code></a> instead.
2[]�
�
deps�
The list of other libraries to be linked in to the binary target.
<p>These can be <code>cc_library</code> or <code>objc_library</code>
targets.</p>

It is also allowed to
put linker scripts (.lds) into deps, and reference them in
<a href="#cc_binary.linkopts"><code>linkopts</code></a>,
but please consider
<a href="#cc_binary.additional_linker_inputs"><code>additional_linker_inputs</code></a>
for that use case.
*
CcInfo2[]�
�
dynamic_deps�
These are other <code>cc_shared_library</code> dependencies the current target depends on.

<p>
The <code>cc_shared_library</code> implementation will use the list of
<code>dynamic_deps</code> (transitively, i.e. also the <code>dynamic_deps</code> of the
current target's <code>dynamic_deps</code>) to decide which <code>cc_libraries</code> in
the transitive <code>deps</code> should not be linked in because they are already provided
by a different <code>cc_shared_library</code>.
*
CcSharedLibraryInfo2[]

env
2{}(
&

hdrs_checkDeprecated, no-op.2""�
�
includes�
List of include dirs to be added to the compile line.
Subject to <a href="${link make-variables}">"Make variable"</a> substitution.
Each string is prepended with the package path and passed to the C++ toolchain for
expansion via the "include_paths" CROSSTOOL feature. A toolchain running on a POSIX system
with typical feature definitions will produce
<code>-isystem path_to_package/include_entry</code>.
This should only be used for third-party libraries that
do not conform to the Google style of writing #include statements.
Unlike <a href="#cc_binary.copts">COPTS</a>, these flags are added for this rule
and every rule that depends on it. (Note: not the rules it depends upon!) Be
very careful, since this may have far-reaching effects.  When in doubt, add
"-I" flags to <a href="#cc_binary.copts">COPTS</a> instead.
<p>
The added <code>include</code> paths will include generated files as well as
files in the source tree.
</p>
2[]

licenses2[]�
�
link_extra_lib�
Control linking of extra libraries.
<p>
    By default, C++ binaries are linked against <code>@bazel_tools//tools/cpp:link_extra_lib</code>,
    which by default depends on the label flag <code>@bazel_tools//tools/cpp:link_extra_libs</code>.
    Without setting the flag, this library is empty by default. Setting the label flag
    allows linking optional dependencies, such as overrides for weak symbols, interceptors
    for shared library functions, or special runtime libraries (for malloc replacements,
    prefer <code>malloc</code> or <code>--custom_malloc</code>). Setting this attribute to
    <code>None</code> disables this behaviour.
</p>
*
CcInfo2&@bazel_tools//tools/cpp:link_extra_lib�
�
linkopts�
Add these flags to the C++ linker command.
Subject to <a href="make-variables.html">"Make" variable</a> substitution,
<a href="common-definitions.html#sh-tokenization">
Bourne shell tokenization</a> and
<a href="common-definitions.html#label-expansion">label expansion</a>.
Each string in this attribute is added to <code>LINKOPTS</code> before
linking the binary target.
<p>
    Each element of this list that does not start with <code>$</code> or <code>-</code> is
    assumed to be the label of a target in <code>deps</code>. The
    list of files generated by that target is appended to the linker
    options.  An error is reported if the label is invalid, or is
    not declared in <code>deps</code>.
</p>
2[]�
�

linkshared�
Create a shared library.
To enable this attribute, include <code>linkshared=True</code> in your rule. By default
this option is off.
<p>
  The presence of this flag means that linking occurs with the <code>-shared</code> flag
  to <code>gcc</code>, and the resulting shared library is suitable for loading into for
  example a Java program. However, for build purposes it will never be linked into the
  dependent binary, as it is assumed that shared libraries built with a
  <a href="#cc_binary">cc_binary</a> rule are only loaded manually by other programs, so
  it should not be considered a substitute for the <a href="#cc_library">cc_library</a>
  rule. For sake of scalability we recommend avoiding this approach altogether and
  simply letting <code>java_library</code> depend on <code>cc_library</code> rules
  instead.
</p>
<p>
  If you specify both <code>linkopts=['-static']</code> and <code>linkshared=True</code>,
  you get a single completely self-contained unit. If you specify both
  <code>linkstatic=True</code> and <code>linkshared=True</code>, you get a single, mostly
  self-contained unit.
</p>
2False�
�

linkstatic�
For <a href="${link cc_binary}"><code>cc_binary</code></a> and
<a href="${link cc_test}"><code>cc_test</code></a>: link the binary in static
mode. For <code>cc_library.link_static</code>: see below.
<p>By default this option is on for <code>cc_binary</code> and off for the rest.</p>
<p>
  If enabled and this is a binary or test, this option tells the build tool to link in
  <code>.a</code>'s instead of <code>.so</code>'s for user libraries whenever possible.
  System libraries such as libc (but <i>not</i> the C/C++ runtime libraries,
  see below) are still linked dynamically, as are libraries for which
  there is no static library. So the resulting executable will still be dynamically
  linked, hence only <i>mostly</i> static.
</p>
<p>
There are really three different ways to link an executable:
</p>
<ul>
<li> STATIC with fully_static_link feature, in which everything is linked statically;
  e.g. "<code>gcc -static foo.o libbar.a libbaz.a -lm</code>".<br/>
  This mode is enabled by specifying <code>fully_static_link</code> in the
  <a href="${link common-definitions#features}"><code>features</code></a> attribute.</li>
<li> STATIC, in which all user libraries are linked statically (if a static
  version is available), but where system libraries (excluding C/C++ runtime libraries)
  are linked dynamically, e.g. "<code>gcc foo.o libfoo.a libbaz.a -lm</code>".<br/>
  This mode is enabled by specifying <code>linkstatic=True</code>.</li>
<li> DYNAMIC, in which all libraries are linked dynamically (if a dynamic version is
  available), e.g. "<code>gcc foo.o libfoo.so libbaz.so -lm</code>".<br/>
  This mode is enabled by specifying <code>linkstatic=False</code>.</li>
</ul>
<p>
If the <code>linkstatic</code> attribute or <code>fully_static_link</code> in
<code>features</code> is used outside of <code>//third_party</code>
please include a comment near the rule to explain why.
</p>
<p>
The <code>linkstatic</code> attribute has a different meaning if used on a
<a href="${link cc_library}"><code>cc_library()</code></a> rule.
For a C++ library, <code>linkstatic=True</code> indicates that only
static linking is allowed, so no <code>.so</code> will be produced. linkstatic=False does
not prevent static libraries from being created. The attribute is meant to control the
creation of dynamic libraries.
</p>
<p>
There should be very little code built with <code>linkstatic=False</code> in production.
If <code>linkstatic=False</code>, then the build tool will create symlinks to
depended-upon shared libraries in the <code>*.runfiles</code> area.
</p>
2True�
�
local_defines�
List of defines to add to the compile line.
Subject to <a href="${link make-variables}">"Make" variable</a> substitution and
<a href="${link common-definitions#sh-tokenization}">Bourne shell tokenization</a>.
Each string, which must consist of a single Bourne shell token,
is prepended with <code>-D</code> and added to the compile command line for this target,
but not to its dependents. Unlike <code>defines</code>, the defines are only added to the
compile command line for this target.
2[]�
�
malloc�
Override the default dependency on malloc.
<p>
  By default, C++ binaries are linked against <code>//tools/cpp:malloc</code>,
  which is an empty library so the binary ends up using libc malloc.
  This label must refer to a <code>cc_library</code>. If compilation is for a non-C++
  rule, this option has no effect. The value of this attribute is ignored if
  <code>linkshared=True</code> is specified.
</p>
*
CcInfo2@bazel_tools//tools/cpp:malloc�
�
module_interfaces�
The list of files are regarded as C++20 Modules Interface.

<p>
C++ Standard has no restriction about module interface file extension
<ul>
<li>Clang use cppm </li>
<li>GCC can use any source file extension </li>
<li>MSVC use ixx </li>
</ul>
</p>
<p>The use is guarded by the flag
<code>--experimental_cpp_modules</code>.</p>
2[]�
�
nocopts�
Remove matching options from the C++ compilation command.
Subject to <a href="${link make-variables}">"Make" variable</a> substitution.
The value of this attribute is interpreted as a regular expression.
Any preexisting <code>COPTS</code> that match this regular expression
(including values explicitly specified in the rule's <a
href="#cc_binary.copts">copts</a> attribute)
will be removed from <code>COPTS</code> for purposes of compiling this rule.
This attribute should not be needed or used
outside of <code>third_party</code>.  The values are not preprocessed
in any way other than the "Make" variable substitution.
2""

reexport_deps2[]�
�
srcs�
The list of C and C++ files that are processed to create the library target.
These are C/C++ source and header files, either non-generated (normal source
code) or generated.
<p>All <code>.cc</code>, <code>.c</code>, and <code>.cpp</code> files will
   be compiled. These might be generated files: if a named file is in
   the <code>outs</code> of some other rule, this <code>cc_library</code>
   will automatically depend on that other rule.
</p>
<p>Pure assembler files (.s, .asm) are not preprocessed and are typically built using
the assembler. Preprocessed assembly files (.S) are preprocessed and are typically built
using the C/C++ compiler.
</p>
<p>A <code>.h</code> file will not be compiled, but will be available for
   inclusion by sources in this rule. Both <code>.cc</code> and
   <code>.h</code> files can directly include headers listed in
   these <code>srcs</code> or in the <code>hdrs</code> of this rule or any
   rule listed in the <code>deps</code> argument.
</p>
<p>All <code>#include</code>d files must be mentioned in the
   <code>hdrs</code> attribute of this or referenced <code>cc_library</code>
   rules, or they should be listed in <code>srcs</code> if they are private
   to this library. See <a href="#hdrs">"Header inclusion checking"</a> for
   a more detailed description.
</p>
<p><code>.so</code>, <code>.lo</code>, and <code>.a</code> files are
   pre-compiled files. Your library might have these as
   <code>srcs</code> if it uses third-party code for which we don't
   have source code.
</p>
<p>If the <code>srcs</code> attribute includes the label of another rule,
   <code>cc_library</code> will use the output files of that rule as source files to
   compile. This is useful for one-off generation of source code (for more than occasional
   use, it's better to implement a Starlark rule class and use the <code>cc_common</code>
   API)
</p>
<p>
  Permitted <code>srcs</code> file types:
</p>
<ul>
<li>C and C++ source files: <code>.c</code>, <code>.cc</code>, <code>.cpp</code>,
  <code>.cxx</code>, <code>.c++</code>, <code>.C</code></li>
<li>C and C++ header files: <code>.h</code>, <code>.hh</code>, <code>.hpp</code>,
  <code>.hxx</code>, <code>.inc</code>, <code>.inl</code>, <code>.H</code></li>
<li>Assembler with C preprocessor: <code>.S</code></li>
<li>Archive: <code>.a</code>, <code>.pic.a</code></li>
<li>"Always link" library: <code>.lo</code>, <code>.pic.lo</code></li>
<li>Shared library, versioned or unversioned: <code>.so</code>,
  <code>.so.<i>version</i></code></li>
<li>Object file: <code>.o</code>, <code>.pic.o</code></li>
</ul>

<p>
  ... and any rules that produce those files (e.g. <code>cc_embed_data</code>).
  Different extensions denote different programming languages in
  accordance with gcc convention.
</p>
2[]�
�
stamp�
Whether to encode build information into the binary. Possible values:
<ul>
<li>
  <code>stamp = 1</code>: Always stamp the build information into the binary, even in
  <a href="${link user-manual#flag--stamp}"><code>--nostamp</code></a> builds. <b>This
  setting should be avoided</b>, since it potentially kills remote caching for the
  binary and any downstream actions that depend on it.
</li>
<li>
  <code>stamp = 0</code>: Always replace build information by constant values. This
  gives good build result caching.
</li>
<li>
  <code>stamp = -1</code>: Embedding of build information is controlled by the
  <a href="${link user-manual#flag--stamp}"><code>--[no]stamp</code></a> flag.
</li>
</ul>
<p>Stamped binaries are <em>not</em> rebuilt unless their dependencies change.</p>
2-1�
�
win_def_file�
The Windows DEF file to be passed to linker.
<p>This attribute should only be used when Windows is the target platform.
It can be used to <a href="https://msdn.microsoft.com/en-us/library/d91k01sh.aspx">
export symbols</a> during linking a shared library.</p>
2None�"target_platform_has_any_constraint:Check if target platform has any of a list of constraints.*�
�
"target_platform_has_any_constraint
ctxrule context. (-
constraintslabel_list of constraints. (:Check if target platform has any of a list of constraints.">
<True if target platform has at least one of the constraints.2d
"target_platform_has_any_constraint>@@rules_venv//python/module_extension/private:cc_extension.bzl
66a
//lib:paths.bzlrL

bazel_skyliblib	paths.bzl
pathspaths
',
.k
//cc:cc_binary.bzlrS

rules_cccccc_binary.bzl$
	cc_binary	cc_binary
&/
1o
//cc/common:cc_info.bzlrR
"
rules_cc	cc/commoncc_info.bzl
CcInfoCcInfo
+1
3�
"//cc/common:debug_package_info.bzlrq
-
rules_cc	cc/commondebug_package_info.bzl2
DebugPackageInfoDebugPackageInfo
6F
Hk
//python:py_info.bzlrQ
!

rules_venvpythonpy_info.bzl
PyInfoPyInfo
*0
2&Bazel rules for building c extensions.��
/

rules_venvpython/module_extensiondefs.bzl��py_cc_extension�Define a Python C extension module.

This target is consumed just as a `py_library` would be.



<p>It produces an executable binary.</p>

<br/>The <code>name</code> of the target should be the same as the name of the
source file that is the main entry point of the application (minus the extension).
For example, if your entry point is in <code>main.cc</code>, then your name should
be <code>main</code>.

<h4>Implicit output targets</h4>
<ul>
<li><code><var>name</var>.stripped</code> (only built if explicitly requested): A stripped
  version of the binary. <code>strip -g</code> is run on the binary to remove debug
  symbols.  Additional strip options can be provided on the command line using
  <code>--stripopt=-foo</code>.</li>
<li><code><var>name</var>.dwp</code> (only built if explicitly requested): If
  <a href="https://gcc.gnu.org/wiki/DebugFission">Fission</a> is enabled: a debug
  information package file suitable for debugging remotely deployed binaries. Else: an
  empty file.</li>
</ul>
"��
��
py_cc_extension�Define a Python C extension module.

This target is consumed just as a `py_library` would be.



<p>It produces an executable binary.</p>

<br/>The <code>name</code> of the target should be the same as the name of the
source file that is the main entry point of the application (minus the extension).
For example, if your entry point is in <code>main.cc</code>, then your name should
be <code>main</code>.

<h4>Implicit output targets</h4>
<ul>
<li><code><var>name</var>.stripped</code> (only built if explicitly requested): A stripped
  version of the binary. <code>strip -g</code> is run on the binary to remove debug
  symbols.  Additional strip options can be provided on the command line using
  <code>--stripopt=-foo</code>.</li>
<li><code><var>name</var>.dwp</code> (only built if explicitly requested): If
  <a href="https://gcc.gnu.org/wiki/DebugFission">Fission</a> is enabled: a debug
  information package file suitable for debugging remotely deployed binaries. Else: an
  empty file.</li>
</ul>
*
nameA unique name for this target. �
additional_compiler_inputs�
Any additional files you might want to pass to the compiler command line, such as sanitizer
ignorelists, for example. Files specified here can then be used in copts with the
$(location) function.
2[]�
additional_linker_inputs�
Dependencies that are only made available to the C++ linker command.
<p>
  Unlike <code>deps</code>, which is conceptually made for both compilation and
  linking dependencies, <code>additional_linker_inputs</code> is specifically
  made for only the latter, and signals a dependency that is required only for
  linking (for example, files that are referenced in <code>linkopts</code>).
</p>
<p>
  For example, compiled Windows .res files can be provided here to be embedded in
  the binary target.
</p>
2[]�
	conlyopts�
Add these options to the C compilation command.
Subject to <a href="${link make-variables}">"Make variable"</a> substitution and
<a href="${link common-definitions#sh-tokenization}">Bourne shell tokenization</a>.
2[]�
copts�
Add these options to the C/C++ compilation command.
Subject to <a href="${link make-variables}">"Make variable"</a> substitution and
<a href="${link common-definitions#sh-tokenization}">Bourne shell tokenization</a>.
<p>
  Each string in this attribute is added in the given order to <code>COPTS</code> before
  compiling the binary target. The flags take effect only for compiling this target, not
  its dependencies, so be careful about header files included elsewhere.
  All paths should be relative to the workspace, not to the current package.
  This attribute should not be needed outside of <code>third_party</code>.
</p>
<p>
  If the package declares the <a href="${link package.features}">feature</a>
  <code>no_copts_tokenization</code>, Bourne shell tokenization applies only to strings
  that consist of a single "Make" variable.
</p>
2[]�
cxxopts�
Add these options to the C++ compilation command.
Subject to <a href="${link make-variables}">"Make variable"</a> substitution and
<a href="${link common-definitions#sh-tokenization}">Bourne shell tokenization</a>.
2[]�
data�
The list of files needed by this library at runtime.

See general comments about <code>data</code>
at <a href="${link common-definitions#typical-attributes}">Typical attributes defined by
most build rules</a>.
<p>If a <code>data</code> is the name of a generated file, then this
   <code>cc_library</code> rule automatically depends on the generating
   rule.
</p>
<p>If a <code>data</code> is a rule name, then this
   <code>cc_library</code> rule automatically depends on that rule,
   and that rule's <code>outs</code> are automatically added to
   this <code>cc_library</code>'s data files.
</p>
<p>Your C++ code can access these data files like so:</p>
<pre><code class="lang-starlark">
  const std::string path = devtools_build::GetDataDependencyFilepath(
      "my/test/data/file");
</code></pre>
2[]�
defines�
List of defines to add to the compile line of this and all dependent targets.
Subject to <a href="${link make-variables}">"Make" variable</a> substitution and
<a href="${link common-definitions#sh-tokenization}">Bourne shell tokenization</a>.
Each string, which must consist of a single Bourne shell token,
is prepended with <code>-D</code> and added to the compile command line to this target,
as well as to every rule that depends on it. Be very careful, since this may have
far-reaching effects -- the defines are added to every target that depends on
this target.  When in doubt, add define values to
<a href="#cc_binary.local_defines"><code>local_defines</code></a> instead.
2[]�
deps�
The list of other libraries to be linked in to the binary target.
<p>These can be <code>cc_library</code> or <code>objc_library</code>
targets.</p>

It is also allowed to
put linker scripts (.lds) into deps, and reference them in
<a href="#cc_binary.linkopts"><code>linkopts</code></a>,
but please consider
<a href="#cc_binary.additional_linker_inputs"><code>additional_linker_inputs</code></a>
for that use case.
*
CcInfo2[]�
dynamic_deps�
These are other <code>cc_shared_library</code> dependencies the current target depends on.

<p>
The <code>cc_shared_library</code> implementation will use the list of
<code>dynamic_deps</code> (transitively, i.e. also the <code>dynamic_deps</code> of the
current target's <code>dynamic_deps</code>) to decide which <code>cc_libraries</code> in
the transitive <code>deps</code> should not be linked in because they are already provided
by a different <code>cc_shared_library</code>.
*
CcSharedLibraryInfo2[]
env
2{}&

hdrs_checkDeprecated, no-op.2""�
includes�
List of include dirs to be added to the compile line.
Subject to <a href="${link make-variables}">"Make variable"</a> substitution.
Each string is prepended with the package path and passed to the C++ toolchain for
expansion via the "include_paths" CROSSTOOL feature. A toolchain running on a POSIX system
with typical feature definitions will produce
<code>-isystem path_to_package/include_entry</code>.
This should only be used for third-party libraries that
do not conform to the Google style of writing #include statements.
Unlike <a href="#cc_binary.copts">COPTS</a>, these flags are added for this rule
and every rule that depends on it. (Note: not the rules it depends upon!) Be
very careful, since this may have far-reaching effects.  When in doubt, add
"-I" flags to <a href="#cc_binary.copts">COPTS</a> instead.
<p>
The added <code>include</code> paths will include generated files as well as
files in the source tree.
</p>
2[]
licenses2[]�
link_extra_lib�
Control linking of extra libraries.
<p>
    By default, C++ binaries are linked against <code>@bazel_tools//tools/cpp:link_extra_lib</code>,
    which by default depends on the label flag <code>@bazel_tools//tools/cpp:link_extra_libs</code>.
    Without setting the flag, this library is empty by default. Setting the label flag
    allows linking optional dependencies, such as overrides for weak symbols, interceptors
    for shared library functions, or special runtime libraries (for malloc replacements,
    prefer <code>malloc</code> or <code>--custom_malloc</code>). Setting this attribute to
    <code>None</code> disables this behaviour.
</p>
*
CcInfo2&@bazel_tools//tools/cpp:link_extra_lib�
linkopts�
Add these flags to the C++ linker command.
Subject to <a href="make-variables.html">"Make" variable</a> substitution,
<a href="common-definitions.html#sh-tokenization">
Bourne shell tokenization</a> and
<a href="common-definitions.html#label-expansion">label expansion</a>.
Each string in this attribute is added to <code>LINKOPTS</code> before
linking the binary target.
<p>
    Each element of this list that does not start with <code>$</code> or <code>-</code> is
    assumed to be the label of a target in <code>deps</code>. The
    list of files generated by that target is appended to the linker
    options.  An error is reported if the label is invalid, or is
    not declared in <code>deps</code>.
</p>
2[]�

linkshared�
Create a shared library.
To enable this attribute, include <code>linkshared=True</code> in your rule. By default
this option is off.
<p>
  The presence of this flag means that linking occurs with the <code>-shared</code> flag
  to <code>gcc</code>, and the resulting shared library is suitable for loading into for
  example a Java program. However, for build purposes it will never be linked into the
  dependent binary, as it is assumed that shared libraries built with a
  <a href="#cc_binary">cc_binary</a> rule are only loaded manually by other programs, so
  it should not be considered a substitute for the <a href="#cc_library">cc_library</a>
  rule. For sake of scalability we recommend avoiding this approach altogether and
  simply letting <code>java_library</code> depend on <code>cc_library</code> rules
  instead.
</p>
<p>
  If you specify both <code>linkopts=['-static']</code> and <code>linkshared=True</code>,
  you get a single completely self-contained unit. If you specify both
  <code>linkstatic=True</code> and <code>linkshared=True</code>, you get a single, mostly
  self-contained unit.
</p>
2False�

linkstatic�
For <a href="${link cc_binary}"><code>cc_binary</code></a> and
<a href="${link cc_test}"><code>cc_test</code></a>: link the binary in static
mode. For <code>cc_library.link_static</code>: see below.
<p>By default this option is on for <code>cc_binary</code> and off for the rest.</p>
<p>
  If enabled and this is a binary or test, this option tells the build tool to link in
  <code>.a</code>'s instead of <code>.so</code>'s for user libraries whenever possible.
  System libraries such as libc (but <i>not</i> the C/C++ runtime libraries,
  see below) are still linked dynamically, as are libraries for which
  there is no static library. So the resulting executable will still be dynamically
  linked, hence only <i>mostly</i> static.
</p>
<p>
There are really three different ways to link an executable:
</p>
<ul>
<li> STATIC with fully_static_link feature, in which everything is linked statically;
  e.g. "<code>gcc -static foo.o libbar.a libbaz.a -lm</code>".<br/>
  This mode is enabled by specifying <code>fully_static_link</code> in the
  <a href="${link common-definitions#features}"><code>features</code></a> attribute.</li>
<li> STATIC, in which all user libraries are linked statically (if a static
  version is available), but where system libraries (excluding C/C++ runtime libraries)
  are linked dynamically, e.g. "<code>gcc foo.o libfoo.a libbaz.a -lm</code>".<br/>
  This mode is enabled by specifying <code>linkstatic=True</code>.</li>
<li> DYNAMIC, in which all libraries are linked dynamically (if a dynamic version is
  available), e.g. "<code>gcc foo.o libfoo.so libbaz.so -lm</code>".<br/>
  This mode is enabled by specifying <code>linkstatic=False</code>.</li>
</ul>
<p>
If the <code>linkstatic</code> attribute or <code>fully_static_link</code> in
<code>features</code> is used outside of <code>//third_party</code>
please include a comment near the rule to explain why.
</p>
<p>
The <code>linkstatic</code> attribute has a different meaning if used on a
<a href="${link cc_library}"><code>cc_library()</code></a> rule.
For a C++ library, <code>linkstatic=True</code> indicates that only
static linking is allowed, so no <code>.so</code> will be produced. linkstatic=False does
not prevent static libraries from being created. The attribute is meant to control the
creation of dynamic libraries.
</p>
<p>
There should be very little code built with <code>linkstatic=False</code> in production.
If <code>linkstatic=False</code>, then the build tool will create symlinks to
depended-upon shared libraries in the <code>*.runfiles</code> area.
</p>
2True�
local_defines�
List of defines to add to the compile line.
Subject to <a href="${link make-variables}">"Make" variable</a> substitution and
<a href="${link common-definitions#sh-tokenization}">Bourne shell tokenization</a>.
Each string, which must consist of a single Bourne shell token,
is prepended with <code>-D</code> and added to the compile command line for this target,
but not to its dependents. Unlike <code>defines</code>, the defines are only added to the
compile command line for this target.
2[]�
malloc�
Override the default dependency on malloc.
<p>
  By default, C++ binaries are linked against <code>//tools/cpp:malloc</code>,
  which is an empty library so the binary ends up using libc malloc.
  This label must refer to a <code>cc_library</code>. If compilation is for a non-C++
  rule, this option has no effect. The value of this attribute is ignored if
  <code>linkshared=True</code> is specified.
</p>
*
CcInfo2@bazel_tools//tools/cpp:malloc�
module_interfaces�
The list of files are regarded as C++20 Modules Interface.

<p>
C++ Standard has no restriction about module interface file extension
<ul>
<li>Clang use cppm </li>
<li>GCC can use any source file extension </li>
<li>MSVC use ixx </li>
</ul>
</p>
<p>The use is guarded by the flag
<code>--experimental_cpp_modules</code>.</p>
2[]�
nocopts�
Remove matching options from the C++ compilation command.
Subject to <a href="${link make-variables}">"Make" variable</a> substitution.
The value of this attribute is interpreted as a regular expression.
Any preexisting <code>COPTS</code> that match this regular expression
(including values explicitly specified in the rule's <a
href="#cc_binary.copts">copts</a> attribute)
will be removed from <code>COPTS</code> for purposes of compiling this rule.
This attribute should not be needed or used
outside of <code>third_party</code>.  The values are not preprocessed
in any way other than the "Make" variable substitution.
2""
reexport_deps2[]�
srcs�
The list of C and C++ files that are processed to create the library target.
These are C/C++ source and header files, either non-generated (normal source
code) or generated.
<p>All <code>.cc</code>, <code>.c</code>, and <code>.cpp</code> files will
   be compiled. These might be generated files: if a named file is in
   the <code>outs</code> of some other rule, this <code>cc_library</code>
   will automatically depend on that other rule.
</p>
<p>Pure assembler files (.s, .asm) are not preprocessed and are typically built using
the assembler. Preprocessed assembly files (.S) are preprocessed and are typically built
using the C/C++ compiler.
</p>
<p>A <code>.h</code> file will not be compiled, but will be available for
   inclusion by sources in this rule. Both <code>.cc</code> and
   <code>.h</code> files can directly include headers listed in
   these <code>srcs</code> or in the <code>hdrs</code> of this rule or any
   rule listed in the <code>deps</code> argument.
</p>
<p>All <code>#include</code>d files must be mentioned in the
   <code>hdrs</code> attribute of this or referenced <code>cc_library</code>
   rules, or they should be listed in <code>srcs</code> if they are private
   to this library. See <a href="#hdrs">"Header inclusion checking"</a> for
   a more detailed description.
</p>
<p><code>.so</code>, <code>.lo</code>, and <code>.a</code> files are
   pre-compiled files. Your library might have these as
   <code>srcs</code> if it uses third-party code for which we don't
   have source code.
</p>
<p>If the <code>srcs</code> attribute includes the label of another rule,
   <code>cc_library</code> will use the output files of that rule as source files to
   compile. This is useful for one-off generation of source code (for more than occasional
   use, it's better to implement a Starlark rule class and use the <code>cc_common</code>
   API)
</p>
<p>
  Permitted <code>srcs</code> file types:
</p>
<ul>
<li>C and C++ source files: <code>.c</code>, <code>.cc</code>, <code>.cpp</code>,
  <code>.cxx</code>, <code>.c++</code>, <code>.C</code></li>
<li>C and C++ header files: <code>.h</code>, <code>.hh</code>, <code>.hpp</code>,
  <code>.hxx</code>, <code>.inc</code>, <code>.inl</code>, <code>.H</code></li>
<li>Assembler with C preprocessor: <code>.S</code></li>
<li>Archive: <code>.a</code>, <code>.pic.a</code></li>
<li>"Always link" library: <code>.lo</code>, <code>.pic.lo</code></li>
<li>Shared library, versioned or unversioned: <code>.so</code>,
  <code>.so.<i>version</i></code></li>
<li>Object file: <code>.o</code>, <code>.pic.o</code></li>
</ul>

<p>
  ... and any rules that produce those files (e.g. <code>cc_embed_data</code>).
  Different extensions denote different programming languages in
  accordance with gcc convention.
</p>
2[]�
stamp�
Whether to encode build information into the binary. Possible values:
<ul>
<li>
  <code>stamp = 1</code>: Always stamp the build information into the binary, even in
  <a href="${link user-manual#flag--stamp}"><code>--nostamp</code></a> builds. <b>This
  setting should be avoided</b>, since it potentially kills remote caching for the
  binary and any downstream actions that depend on it.
</li>
<li>
  <code>stamp = 0</code>: Always replace build information by constant values. This
  gives good build result caching.
</li>
<li>
  <code>stamp = -1</code>: Embedding of build information is controlled by the
  <a href="${link user-manual#flag--stamp}"><code>--[no]stamp</code></a> flag.
</li>
</ul>
<p>Stamped binaries are <em>not</em> rebuilt unless their dependencies change.</p>
2-1�
win_def_file�
The Windows DEF file to be passed to linker.
<p>This attribute should only be used when Windows is the target platform.
It can be used to <a href="https://msdn.microsoft.com/en-us/library/d91k01sh.aspx">
export symbols</a> during linking a shared library.</p>
2None
��,
*
nameA unique name for this target. �
�
additional_compiler_inputs�
Any additional files you might want to pass to the compiler command line, such as sanitizer
ignorelists, for example. Files specified here can then be used in copts with the
$(location) function.
2[]�
�
additional_linker_inputs�
Dependencies that are only made available to the C++ linker command.
<p>
  Unlike <code>deps</code>, which is conceptually made for both compilation and
  linking dependencies, <code>additional_linker_inputs</code> is specifically
  made for only the latter, and signals a dependency that is required only for
  linking (for example, files that are referenced in <code>linkopts</code>).
</p>
<p>
  For example, compiled Windows .res files can be provided here to be embedded in
  the binary target.
</p>
2[]�
�
	conlyopts�
Add these options to the C compilation command.
Subject to <a href="${link make-variables}">"Make variable"</a> substitution and
<a href="${link common-definitions#sh-tokenization}">Bourne shell tokenization</a>.
2[]�
�
copts�
Add these options to the C/C++ compilation command.
Subject to <a href="${link make-variables}">"Make variable"</a> substitution and
<a href="${link common-definitions#sh-tokenization}">Bourne shell tokenization</a>.
<p>
  Each string in this attribute is added in the given order to <code>COPTS</code> before
  compiling the binary target. The flags take effect only for compiling this target, not
  its dependencies, so be careful about header files included elsewhere.
  All paths should be relative to the workspace, not to the current package.
  This attribute should not be needed outside of <code>third_party</code>.
</p>
<p>
  If the package declares the <a href="${link package.features}">feature</a>
  <code>no_copts_tokenization</code>, Bourne shell tokenization applies only to strings
  that consist of a single "Make" variable.
</p>
2[]�
�
cxxopts�
Add these options to the C++ compilation command.
Subject to <a href="${link make-variables}">"Make variable"</a> substitution and
<a href="${link common-definitions#sh-tokenization}">Bourne shell tokenization</a>.
2[]�
�
data�
The list of files needed by this library at runtime.

See general comments about <code>data</code>
at <a href="${link common-definitions#typical-attributes}">Typical attributes defined by
most build rules</a>.
<p>If a <code>data</code> is the name of a generated file, then this
   <code>cc_library</code> rule automatically depends on the generating
   rule.
</p>
<p>If a <code>data</code> is a rule name, then this
   <code>cc_library</code> rule automatically depends on that rule,
   and that rule's <code>outs</code> are automatically added to
   this <code>cc_library</code>'s data files.
</p>
<p>Your C++ code can access these data files like so:</p>
<pre><code class="lang-starlark">
  const std::string path = devtools_build::GetDataDependencyFilepath(
      "my/test/data/file");
</code></pre>
2[]�
�
defines�
List of defines to add to the compile line of this and all dependent targets.
Subject to <a href="${link make-variables}">"Make" variable</a> substitution and
<a href="${link common-definitions#sh-tokenization}">Bourne shell tokenization</a>.
Each string, which must consist of a single Bourne shell token,
is prepended with <code>-D</code> and added to the compile command line to this target,
as well as to every rule that depends on it. Be very careful, since this may have
far-reaching effects -- the defines are added to every target that depends on
this target.  When in doubt, add define values to
<a href="#cc_binary.local_defines"><code>local_defines</code></a> instead.
2[]�
�
deps�
The list of other libraries to be linked in to the binary target.
<p>These can be <code>cc_library</code> or <code>objc_library</code>
targets.</p>

It is also allowed to
put linker scripts (.lds) into deps, and reference them in
<a href="#cc_binary.linkopts"><code>linkopts</code></a>,
but please consider
<a href="#cc_binary.additional_linker_inputs"><code>additional_linker_inputs</code></a>
for that use case.
*
CcInfo2[]�
�
dynamic_deps�
These are other <code>cc_shared_library</code> dependencies the current target depends on.

<p>
The <code>cc_shared_library</code> implementation will use the list of
<code>dynamic_deps</code> (transitively, i.e. also the <code>dynamic_deps</code> of the
current target's <code>dynamic_deps</code>) to decide which <code>cc_libraries</code> in
the transitive <code>deps</code> should not be linked in because they are already provided
by a different <code>cc_shared_library</code>.
*
CcSharedLibraryInfo2[]

env
2{}(
&

hdrs_checkDeprecated, no-op.2""�
�
includes�
List of include dirs to be added to the compile line.
Subject to <a href="${link make-variables}">"Make variable"</a> substitution.
Each string is prepended with the package path and passed to the C++ toolchain for
expansion via the "include_paths" CROSSTOOL feature. A toolchain running on a POSIX system
with typical feature definitions will produce
<code>-isystem path_to_package/include_entry</code>.
This should only be used for third-party libraries that
do not conform to the Google style of writing #include statements.
Unlike <a href="#cc_binary.copts">COPTS</a>, these flags are added for this rule
and every rule that depends on it. (Note: not the rules it depends upon!) Be
very careful, since this may have far-reaching effects.  When in doubt, add
"-I" flags to <a href="#cc_binary.copts">COPTS</a> instead.
<p>
The added <code>include</code> paths will include generated files as well as
files in the source tree.
</p>
2[]

licenses2[]�
�
link_extra_lib�
Control linking of extra libraries.
<p>
    By default, C++ binaries are linked against <code>@bazel_tools//tools/cpp:link_extra_lib</code>,
    which by default depends on the label flag <code>@bazel_tools//tools/cpp:link_extra_libs</code>.
    Without setting the flag, this library is empty by default. Setting the label flag
    allows linking optional dependencies, such as overrides for weak symbols, interceptors
    for shared library functions, or special runtime libraries (for malloc replacements,
    prefer <code>malloc</code> or <code>--custom_malloc</code>). Setting this attribute to
    <code>None</code> disables this behaviour.
</p>
*
CcInfo2&@bazel_tools//tools/cpp:link_extra_lib�
�
linkopts�
Add these flags to the C++ linker command.
Subject to <a href="make-variables.html">"Make" variable</a> substitution,
<a href="common-definitions.html#sh-tokenization">
Bourne shell tokenization</a> and
<a href="common-definitions.html#label-expansion">label expansion</a>.
Each string in this attribute is added to <code>LINKOPTS</code> before
linking the binary target.
<p>
    Each element of this list that does not start with <code>$</code> or <code>-</code> is
    assumed to be the label of a target in <code>deps</code>. The
    list of files generated by that target is appended to the linker
    options.  An error is reported if the label is invalid, or is
    not declared in <code>deps</code>.
</p>
2[]�
�

linkshared�
Create a shared library.
To enable this attribute, include <code>linkshared=True</code> in your rule. By default
this option is off.
<p>
  The presence of this flag means that linking occurs with the <code>-shared</code> flag
  to <code>gcc</code>, and the resulting shared library is suitable for loading into for
  example a Java program. However, for build purposes it will never be linked into the
  dependent binary, as it is assumed that shared libraries built with a
  <a href="#cc_binary">cc_binary</a> rule are only loaded manually by other programs, so
  it should not be considered a substitute for the <a href="#cc_library">cc_library</a>
  rule. For sake of scalability we recommend avoiding this approach altogether and
  simply letting <code>java_library</code> depend on <code>cc_library</code> rules
  instead.
</p>
<p>
  If you specify both <code>linkopts=['-static']</code> and <code>linkshared=True</code>,
  you get a single completely self-contained unit. If you specify both
  <code>linkstatic=True</code> and <code>linkshared=True</code>, you get a single, mostly
  self-contained unit.
</p>
2False�
�

linkstatic�
For <a href="${link cc_binary}"><code>cc_binary</code></a> and
<a href="${link cc_test}"><code>cc_test</code></a>: link the binary in static
mode. For <code>cc_library.link_static</code>: see below.
<p>By default this option is on for <code>cc_binary</code> and off for the rest.</p>
<p>
  If enabled and this is a binary or test, this option tells the build tool to link in
  <code>.a</code>'s instead of <code>.so</code>'s for user libraries whenever possible.
  System libraries such as libc (but <i>not</i> the C/C++ runtime libraries,
  see below) are still linked dynamically, as are libraries for which
  there is no static library. So the resulting executable will still be dynamically
  linked, hence only <i>mostly</i> static.
</p>
<p>
There are really three different ways to link an executable:
</p>
<ul>
<li> STATIC with fully_static_link feature, in which everything is linked statically;
  e.g. "<code>gcc -static foo.o libbar.a libbaz.a -lm</code>".<br/>
  This mode is enabled by specifying <code>fully_static_link</code> in the
  <a href="${link common-definitions#features}"><code>features</code></a> attribute.</li>
<li> STATIC, in which all user libraries are linked statically (if a static
  version is available), but where system libraries (excluding C/C++ runtime libraries)
  are linked dynamically, e.g. "<code>gcc foo.o libfoo.a libbaz.a -lm</code>".<br/>
  This mode is enabled by specifying <code>linkstatic=True</code>.</li>
<li> DYNAMIC, in which all libraries are linked dynamically (if a dynamic version is
  available), e.g. "<code>gcc foo.o libfoo.so libbaz.so -lm</code>".<br/>
  This mode is enabled by specifying <code>linkstatic=False</code>.</li>
</ul>
<p>
If the <code>linkstatic</code> attribute or <code>fully_static_link</code> in
<code>features</code> is used outside of <code>//third_party</code>
please include a comment near the rule to explain why.
</p>
<p>
The <code>linkstatic</code> attribute has a different meaning if used on a
<a href="${link cc_library}"><code>cc_library()</code></a> rule.
For a C++ library, <code>linkstatic=True</code> indicates that only
static linking is allowed, so no <code>.so</code> will be produced. linkstatic=False does
not prevent static libraries from being created. The attribute is meant to control the
creation of dynamic libraries.
</p>
<p>
There should be very little code built with <code>linkstatic=False</code> in production.
If <code>linkstatic=False</code>, then the build tool will create symlinks to
depended-upon shared libraries in the <code>*.runfiles</code> area.
</p>
2True�
�
local_defines�
List of defines to add to the compile line.
Subject to <a href="${link make-variables}">"Make" variable</a> substitution and
<a href="${link common-definitions#sh-tokenization}">Bourne shell tokenization</a>.
Each string, which must consist of a single Bourne shell token,
is prepended with <code>-D</code> and added to the compile command line for this target,
but not to its dependents. Unlike <code>defines</code>, the defines are only added to the
compile command line for this target.
2[]�
�
malloc�
Override the default dependency on malloc.
<p>
  By default, C++ binaries are linked against <code>//tools/cpp:malloc</code>,
  which is an empty library so the binary ends up using libc malloc.
  This label must refer to a <code>cc_library</code>. If compilation is for a non-C++
  rule, this option has no effect. The value of this attribute is ignored if
  <code>linkshared=True</code> is specified.
</p>
*
CcInfo2@bazel_tools//tools/cpp:malloc�
�
module_interfaces�
The list of files are regarded as C++20 Modules Interface.

<p>
C++ Standard has no restriction about module interface file extension
<ul>
<li>Clang use cppm </li>
<li>GCC can use any source file extension </li>
<li>MSVC use ixx </li>
</ul>
</p>
<p>The use is guarded by the flag
<code>--experimental_cpp_modules</code>.</p>
2[]�
�
nocopts�
Remove matching options from the C++ compilation command.
Subject to <a href="${link make-variables}">"Make" variable</a> substitution.
The value of this attribute is interpreted as a regular expression.
Any preexisting <code>COPTS</code> that match this regular expression
(including values explicitly specified in the rule's <a
href="#cc_binary.copts">copts</a> attribute)
will be removed from <code>COPTS</code> for purposes of compiling this rule.
This attribute should not be needed or used
outside of <code>third_party</code>.  The values are not preprocessed
in any way other than the "Make" variable substitution.
2""

reexport_deps2[]�
�
srcs�
The list of C and C++ files that are processed to create the library target.
These are C/C++ source and header files, either non-generated (normal source
code) or generated.
<p>All <code>.cc</code>, <code>.c</code>, and <code>.cpp</code> files will
   be compiled. These might be generated files: if a named file is in
   the <code>outs</code> of some other rule, this <code>cc_library</code>
   will automatically depend on that other rule.
</p>
<p>Pure assembler files (.s, .asm) are not preprocessed and are typically built using
the assembler. Preprocessed assembly files (.S) are preprocessed and are typically built
using the C/C++ compiler.
</p>
<p>A <code>.h</code> file will not be compiled, but will be available for
   inclusion by sources in this rule. Both <code>.cc</code> and
   <code>.h</code> files can directly include headers listed in
   these <code>srcs</code> or in the <code>hdrs</code> of this rule or any
   rule listed in the <code>deps</code> argument.
</p>
<p>All <code>#include</code>d files must be mentioned in the
   <code>hdrs</code> attribute of this or referenced <code>cc_library</code>
   rules, or they should be listed in <code>srcs</code> if they are private
   to this library. See <a href="#hdrs">"Header inclusion checking"</a> for
   a more detailed description.
</p>
<p><code>.so</code>, <code>.lo</code>, and <code>.a</code> files are
   pre-compiled files. Your library might have these as
   <code>srcs</code> if it uses third-party code for which we don't
   have source code.
</p>
<p>If the <code>srcs</code> attribute includes the label of another rule,
   <code>cc_library</code> will use the output files of that rule as source files to
   compile. This is useful for one-off generation of source code (for more than occasional
   use, it's better to implement a Starlark rule class and use the <code>cc_common</code>
   API)
</p>
<p>
  Permitted <code>srcs</code> file types:
</p>
<ul>
<li>C and C++ source files: <code>.c</code>, <code>.cc</code>, <code>.cpp</code>,
  <code>.cxx</code>, <code>.c++</code>, <code>.C</code></li>
<li>C and C++ header files: <code>.h</code>, <code>.hh</code>, <code>.hpp</code>,
  <code>.hxx</code>, <code>.inc</code>, <code>.inl</code>, <code>.H</code></li>
<li>Assembler with C preprocessor: <code>.S</code></li>
<li>Archive: <code>.a</code>, <code>.pic.a</code></li>
<li>"Always link" library: <code>.lo</code>, <code>.pic.lo</code></li>
<li>Shared library, versioned or unversioned: <code>.so</code>,
  <code>.so.<i>version</i></code></li>
<li>Object file: <code>.o</code>, <code>.pic.o</code></li>
</ul>

<p>
  ... and any rules that produce those files (e.g. <code>cc_embed_data</code>).
  Different extensions denote different programming languages in
  accordance with gcc convention.
</p>
2[]�
�
stamp�
Whether to encode build information into the binary. Possible values:
<ul>
<li>
  <code>stamp = 1</code>: Always stamp the build information into the binary, even in
  <a href="${link user-manual#flag--stamp}"><code>--nostamp</code></a> builds. <b>This
  setting should be avoided</b>, since it potentially kills remote caching for the
  binary and any downstream actions that depend on it.
</li>
<li>
  <code>stamp = 0</code>: Always replace build information by constant values. This
  gives good build result caching.
</li>
<li>
  <code>stamp = -1</code>: Embedding of build information is controlled by the
  <a href="${link user-manual#flag--stamp}"><code>--[no]stamp</code></a> flag.
</li>
</ul>
<p>Stamped binaries are <em>not</em> rebuilt unless their dependencies change.</p>
2-1�
�
win_def_file�
The Windows DEF file to be passed to linker.
<p>This attribute should only be used when Windows is the target platform.
It can be used to <a href="https://msdn.microsoft.com/en-us/library/d91k01sh.aspx">
export symbols</a> during linking a shared library.</p>
2None�
-//python/module_extension:py_cc_extension.bzlr}
:

rules_venvpython/module_extensionpy_cc_extension.bzl1
py_cc_extension_py_cc_extension

	p# Module Extensions

Rules for building [Module Extensions](https://docs.python.org/3/extending/extending.html)
ƙ
:

rules_venvpython/module_extensionpy_cc_extension.bzl��py_cc_extension�Define a Python C extension module.

This target is consumed just as a `py_library` would be.



<p>It produces an executable binary.</p>

<br/>The <code>name</code> of the target should be the same as the name of the
source file that is the main entry point of the application (minus the extension).
For example, if your entry point is in <code>main.cc</code>, then your name should
be <code>main</code>.

<h4>Implicit output targets</h4>
<ul>
<li><code><var>name</var>.stripped</code> (only built if explicitly requested): A stripped
  version of the binary. <code>strip -g</code> is run on the binary to remove debug
  symbols.  Additional strip options can be provided on the command line using
  <code>--stripopt=-foo</code>.</li>
<li><code><var>name</var>.dwp</code> (only built if explicitly requested): If
  <a href="https://gcc.gnu.org/wiki/DebugFission">Fission</a> is enabled: a debug
  information package file suitable for debugging remotely deployed binaries. Else: an
  empty file.</li>
</ul>
"��
��
py_cc_extension�Define a Python C extension module.

This target is consumed just as a `py_library` would be.



<p>It produces an executable binary.</p>

<br/>The <code>name</code> of the target should be the same as the name of the
source file that is the main entry point of the application (minus the extension).
For example, if your entry point is in <code>main.cc</code>, then your name should
be <code>main</code>.

<h4>Implicit output targets</h4>
<ul>
<li><code><var>name</var>.stripped</code> (only built if explicitly requested): A stripped
  version of the binary. <code>strip -g</code> is run on the binary to remove debug
  symbols.  Additional strip options can be provided on the command line using
  <code>--stripopt=-foo</code>.</li>
<li><code><var>name</var>.dwp</code> (only built if explicitly requested): If
  <a href="https://gcc.gnu.org/wiki/DebugFission">Fission</a> is enabled: a debug
  information package file suitable for debugging remotely deployed binaries. Else: an
  empty file.</li>
</ul>
*
nameA unique name for this target. �
additional_compiler_inputs�
Any additional files you might want to pass to the compiler command line, such as sanitizer
ignorelists, for example. Files specified here can then be used in copts with the
$(location) function.
2[]�
additional_linker_inputs�
Dependencies that are only made available to the C++ linker command.
<p>
  Unlike <code>deps</code>, which is conceptually made for both compilation and
  linking dependencies, <code>additional_linker_inputs</code> is specifically
  made for only the latter, and signals a dependency that is required only for
  linking (for example, files that are referenced in <code>linkopts</code>).
</p>
<p>
  For example, compiled Windows .res files can be provided here to be embedded in
  the binary target.
</p>
2[]�
	conlyopts�
Add these options to the C compilation command.
Subject to <a href="${link make-variables}">"Make variable"</a> substitution and
<a href="${link common-definitions#sh-tokenization}">Bourne shell tokenization</a>.
2[]�
copts�
Add these options to the C/C++ compilation command.
Subject to <a href="${link make-variables}">"Make variable"</a> substitution and
<a href="${link common-definitions#sh-tokenization}">Bourne shell tokenization</a>.
<p>
  Each string in this attribute is added in the given order to <code>COPTS</code> before
  compiling the binary target. The flags take effect only for compiling this target, not
  its dependencies, so be careful about header files included elsewhere.
  All paths should be relative to the workspace, not to the current package.
  This attribute should not be needed outside of <code>third_party</code>.
</p>
<p>
  If the package declares the <a href="${link package.features}">feature</a>
  <code>no_copts_tokenization</code>, Bourne shell tokenization applies only to strings
  that consist of a single "Make" variable.
</p>
2[]�
cxxopts�
Add these options to the C++ compilation command.
Subject to <a href="${link make-variables}">"Make variable"</a> substitution and
<a href="${link common-definitions#sh-tokenization}">Bourne shell tokenization</a>.
2[]�
data�
The list of files needed by this library at runtime.

See general comments about <code>data</code>
at <a href="${link common-definitions#typical-attributes}">Typical attributes defined by
most build rules</a>.
<p>If a <code>data</code> is the name of a generated file, then this
   <code>cc_library</code> rule automatically depends on the generating
   rule.
</p>
<p>If a <code>data</code> is a rule name, then this
   <code>cc_library</code> rule automatically depends on that rule,
   and that rule's <code>outs</code> are automatically added to
   this <code>cc_library</code>'s data files.
</p>
<p>Your C++ code can access these data files like so:</p>
<pre><code class="lang-starlark">
  const std::string path = devtools_build::GetDataDependencyFilepath(
      "my/test/data/file");
</code></pre>
2[]�
defines�
List of defines to add to the compile line of this and all dependent targets.
Subject to <a href="${link make-variables}">"Make" variable</a> substitution and
<a href="${link common-definitions#sh-tokenization}">Bourne shell tokenization</a>.
Each string, which must consist of a single Bourne shell token,
is prepended with <code>-D</code> and added to the compile command line to this target,
as well as to every rule that depends on it. Be very careful, since this may have
far-reaching effects -- the defines are added to every target that depends on
this target.  When in doubt, add define values to
<a href="#cc_binary.local_defines"><code>local_defines</code></a> instead.
2[]�
deps�
The list of other libraries to be linked in to the binary target.
<p>These can be <code>cc_library</code> or <code>objc_library</code>
targets.</p>

It is also allowed to
put linker scripts (.lds) into deps, and reference them in
<a href="#cc_binary.linkopts"><code>linkopts</code></a>,
but please consider
<a href="#cc_binary.additional_linker_inputs"><code>additional_linker_inputs</code></a>
for that use case.
*
CcInfo2[]�
dynamic_deps�
These are other <code>cc_shared_library</code> dependencies the current target depends on.

<p>
The <code>cc_shared_library</code> implementation will use the list of
<code>dynamic_deps</code> (transitively, i.e. also the <code>dynamic_deps</code> of the
current target's <code>dynamic_deps</code>) to decide which <code>cc_libraries</code> in
the transitive <code>deps</code> should not be linked in because they are already provided
by a different <code>cc_shared_library</code>.
*
CcSharedLibraryInfo2[]
env
2{}&

hdrs_checkDeprecated, no-op.2""�
includes�
List of include dirs to be added to the compile line.
Subject to <a href="${link make-variables}">"Make variable"</a> substitution.
Each string is prepended with the package path and passed to the C++ toolchain for
expansion via the "include_paths" CROSSTOOL feature. A toolchain running on a POSIX system
with typical feature definitions will produce
<code>-isystem path_to_package/include_entry</code>.
This should only be used for third-party libraries that
do not conform to the Google style of writing #include statements.
Unlike <a href="#cc_binary.copts">COPTS</a>, these flags are added for this rule
and every rule that depends on it. (Note: not the rules it depends upon!) Be
very careful, since this may have far-reaching effects.  When in doubt, add
"-I" flags to <a href="#cc_binary.copts">COPTS</a> instead.
<p>
The added <code>include</code> paths will include generated files as well as
files in the source tree.
</p>
2[]
licenses2[]�
link_extra_lib�
Control linking of extra libraries.
<p>
    By default, C++ binaries are linked against <code>@bazel_tools//tools/cpp:link_extra_lib</code>,
    which by default depends on the label flag <code>@bazel_tools//tools/cpp:link_extra_libs</code>.
    Without setting the flag, this library is empty by default. Setting the label flag
    allows linking optional dependencies, such as overrides for weak symbols, interceptors
    for shared library functions, or special runtime libraries (for malloc replacements,
    prefer <code>malloc</code> or <code>--custom_malloc</code>). Setting this attribute to
    <code>None</code> disables this behaviour.
</p>
*
CcInfo2&@bazel_tools//tools/cpp:link_extra_lib�
linkopts�
Add these flags to the C++ linker command.
Subject to <a href="make-variables.html">"Make" variable</a> substitution,
<a href="common-definitions.html#sh-tokenization">
Bourne shell tokenization</a> and
<a href="common-definitions.html#label-expansion">label expansion</a>.
Each string in this attribute is added to <code>LINKOPTS</code> before
linking the binary target.
<p>
    Each element of this list that does not start with <code>$</code> or <code>-</code> is
    assumed to be the label of a target in <code>deps</code>. The
    list of files generated by that target is appended to the linker
    options.  An error is reported if the label is invalid, or is
    not declared in <code>deps</code>.
</p>
2[]�

linkshared�
Create a shared library.
To enable this attribute, include <code>linkshared=True</code> in your rule. By default
this option is off.
<p>
  The presence of this flag means that linking occurs with the <code>-shared</code> flag
  to <code>gcc</code>, and the resulting shared library is suitable for loading into for
  example a Java program. However, for build purposes it will never be linked into the
  dependent binary, as it is assumed that shared libraries built with a
  <a href="#cc_binary">cc_binary</a> rule are only loaded manually by other programs, so
  it should not be considered a substitute for the <a href="#cc_library">cc_library</a>
  rule. For sake of scalability we recommend avoiding this approach altogether and
  simply letting <code>java_library</code> depend on <code>cc_library</code> rules
  instead.
</p>
<p>
  If you specify both <code>linkopts=['-static']</code> and <code>linkshared=True</code>,
  you get a single completely self-contained unit. If you specify both
  <code>linkstatic=True</code> and <code>linkshared=True</code>, you get a single, mostly
  self-contained unit.
</p>
2False�

linkstatic�
For <a href="${link cc_binary}"><code>cc_binary</code></a> and
<a href="${link cc_test}"><code>cc_test</code></a>: link the binary in static
mode. For <code>cc_library.link_static</code>: see below.
<p>By default this option is on for <code>cc_binary</code> and off for the rest.</p>
<p>
  If enabled and this is a binary or test, this option tells the build tool to link in
  <code>.a</code>'s instead of <code>.so</code>'s for user libraries whenever possible.
  System libraries such as libc (but <i>not</i> the C/C++ runtime libraries,
  see below) are still linked dynamically, as are libraries for which
  there is no static library. So the resulting executable will still be dynamically
  linked, hence only <i>mostly</i> static.
</p>
<p>
There are really three different ways to link an executable:
</p>
<ul>
<li> STATIC with fully_static_link feature, in which everything is linked statically;
  e.g. "<code>gcc -static foo.o libbar.a libbaz.a -lm</code>".<br/>
  This mode is enabled by specifying <code>fully_static_link</code> in the
  <a href="${link common-definitions#features}"><code>features</code></a> attribute.</li>
<li> STATIC, in which all user libraries are linked statically (if a static
  version is available), but where system libraries (excluding C/C++ runtime libraries)
  are linked dynamically, e.g. "<code>gcc foo.o libfoo.a libbaz.a -lm</code>".<br/>
  This mode is enabled by specifying <code>linkstatic=True</code>.</li>
<li> DYNAMIC, in which all libraries are linked dynamically (if a dynamic version is
  available), e.g. "<code>gcc foo.o libfoo.so libbaz.so -lm</code>".<br/>
  This mode is enabled by specifying <code>linkstatic=False</code>.</li>
</ul>
<p>
If the <code>linkstatic</code> attribute or <code>fully_static_link</code> in
<code>features</code> is used outside of <code>//third_party</code>
please include a comment near the rule to explain why.
</p>
<p>
The <code>linkstatic</code> attribute has a different meaning if used on a
<a href="${link cc_library}"><code>cc_library()</code></a> rule.
For a C++ library, <code>linkstatic=True</code> indicates that only
static linking is allowed, so no <code>.so</code> will be produced. linkstatic=False does
not prevent static libraries from being created. The attribute is meant to control the
creation of dynamic libraries.
</p>
<p>
There should be very little code built with <code>linkstatic=False</code> in production.
If <code>linkstatic=False</code>, then the build tool will create symlinks to
depended-upon shared libraries in the <code>*.runfiles</code> area.
</p>
2True�
local_defines�
List of defines to add to the compile line.
Subject to <a href="${link make-variables}">"Make" variable</a> substitution and
<a href="${link common-definitions#sh-tokenization}">Bourne shell tokenization</a>.
Each string, which must consist of a single Bourne shell token,
is prepended with <code>-D</code> and added to the compile command line for this target,
but not to its dependents. Unlike <code>defines</code>, the defines are only added to the
compile command line for this target.
2[]�
malloc�
Override the default dependency on malloc.
<p>
  By default, C++ binaries are linked against <code>//tools/cpp:malloc</code>,
  which is an empty library so the binary ends up using libc malloc.
  This label must refer to a <code>cc_library</code>. If compilation is for a non-C++
  rule, this option has no effect. The value of this attribute is ignored if
  <code>linkshared=True</code> is specified.
</p>
*
CcInfo2@bazel_tools//tools/cpp:malloc�
module_interfaces�
The list of files are regarded as C++20 Modules Interface.

<p>
C++ Standard has no restriction about module interface file extension
<ul>
<li>Clang use cppm </li>
<li>GCC can use any source file extension </li>
<li>MSVC use ixx </li>
</ul>
</p>
<p>The use is guarded by the flag
<code>--experimental_cpp_modules</code>.</p>
2[]�
nocopts�
Remove matching options from the C++ compilation command.
Subject to <a href="${link make-variables}">"Make" variable</a> substitution.
The value of this attribute is interpreted as a regular expression.
Any preexisting <code>COPTS</code> that match this regular expression
(including values explicitly specified in the rule's <a
href="#cc_binary.copts">copts</a> attribute)
will be removed from <code>COPTS</code> for purposes of compiling this rule.
This attribute should not be needed or used
outside of <code>third_party</code>.  The values are not preprocessed
in any way other than the "Make" variable substitution.
2""
reexport_deps2[]�
srcs�
The list of C and C++ files that are processed to create the library target.
These are C/C++ source and header files, either non-generated (normal source
code) or generated.
<p>All <code>.cc</code>, <code>.c</code>, and <code>.cpp</code> files will
   be compiled. These might be generated files: if a named file is in
   the <code>outs</code> of some other rule, this <code>cc_library</code>
   will automatically depend on that other rule.
</p>
<p>Pure assembler files (.s, .asm) are not preprocessed and are typically built using
the assembler. Preprocessed assembly files (.S) are preprocessed and are typically built
using the C/C++ compiler.
</p>
<p>A <code>.h</code> file will not be compiled, but will be available for
   inclusion by sources in this rule. Both <code>.cc</code> and
   <code>.h</code> files can directly include headers listed in
   these <code>srcs</code> or in the <code>hdrs</code> of this rule or any
   rule listed in the <code>deps</code> argument.
</p>
<p>All <code>#include</code>d files must be mentioned in the
   <code>hdrs</code> attribute of this or referenced <code>cc_library</code>
   rules, or they should be listed in <code>srcs</code> if they are private
   to this library. See <a href="#hdrs">"Header inclusion checking"</a> for
   a more detailed description.
</p>
<p><code>.so</code>, <code>.lo</code>, and <code>.a</code> files are
   pre-compiled files. Your library might have these as
   <code>srcs</code> if it uses third-party code for which we don't
   have source code.
</p>
<p>If the <code>srcs</code> attribute includes the label of another rule,
   <code>cc_library</code> will use the output files of that rule as source files to
   compile. This is useful for one-off generation of source code (for more than occasional
   use, it's better to implement a Starlark rule class and use the <code>cc_common</code>
   API)
</p>
<p>
  Permitted <code>srcs</code> file types:
</p>
<ul>
<li>C and C++ source files: <code>.c</code>, <code>.cc</code>, <code>.cpp</code>,
  <code>.cxx</code>, <code>.c++</code>, <code>.C</code></li>
<li>C and C++ header files: <code>.h</code>, <code>.hh</code>, <code>.hpp</code>,
  <code>.hxx</code>, <code>.inc</code>, <code>.inl</code>, <code>.H</code></li>
<li>Assembler with C preprocessor: <code>.S</code></li>
<li>Archive: <code>.a</code>, <code>.pic.a</code></li>
<li>"Always link" library: <code>.lo</code>, <code>.pic.lo</code></li>
<li>Shared library, versioned or unversioned: <code>.so</code>,
  <code>.so.<i>version</i></code></li>
<li>Object file: <code>.o</code>, <code>.pic.o</code></li>
</ul>

<p>
  ... and any rules that produce those files (e.g. <code>cc_embed_data</code>).
  Different extensions denote different programming languages in
  accordance with gcc convention.
</p>
2[]�
stamp�
Whether to encode build information into the binary. Possible values:
<ul>
<li>
  <code>stamp = 1</code>: Always stamp the build information into the binary, even in
  <a href="${link user-manual#flag--stamp}"><code>--nostamp</code></a> builds. <b>This
  setting should be avoided</b>, since it potentially kills remote caching for the
  binary and any downstream actions that depend on it.
</li>
<li>
  <code>stamp = 0</code>: Always replace build information by constant values. This
  gives good build result caching.
</li>
<li>
  <code>stamp = -1</code>: Embedding of build information is controlled by the
  <a href="${link user-manual#flag--stamp}"><code>--[no]stamp</code></a> flag.
</li>
</ul>
<p>Stamped binaries are <em>not</em> rebuilt unless their dependencies change.</p>
2-1�
win_def_file�
The Windows DEF file to be passed to linker.
<p>This attribute should only be used when Windows is the target platform.
It can be used to <a href="https://msdn.microsoft.com/en-us/library/d91k01sh.aspx">
export symbols</a> during linking a shared library.</p>
2None
��,
*
nameA unique name for this target. �
�
additional_compiler_inputs�
Any additional files you might want to pass to the compiler command line, such as sanitizer
ignorelists, for example. Files specified here can then be used in copts with the
$(location) function.
2[]�
�
additional_linker_inputs�
Dependencies that are only made available to the C++ linker command.
<p>
  Unlike <code>deps</code>, which is conceptually made for both compilation and
  linking dependencies, <code>additional_linker_inputs</code> is specifically
  made for only the latter, and signals a dependency that is required only for
  linking (for example, files that are referenced in <code>linkopts</code>).
</p>
<p>
  For example, compiled Windows .res files can be provided here to be embedded in
  the binary target.
</p>
2[]�
�
	conlyopts�
Add these options to the C compilation command.
Subject to <a href="${link make-variables}">"Make variable"</a> substitution and
<a href="${link common-definitions#sh-tokenization}">Bourne shell tokenization</a>.
2[]�
�
copts�
Add these options to the C/C++ compilation command.
Subject to <a href="${link make-variables}">"Make variable"</a> substitution and
<a href="${link common-definitions#sh-tokenization}">Bourne shell tokenization</a>.
<p>
  Each string in this attribute is added in the given order to <code>COPTS</code> before
  compiling the binary target. The flags take effect only for compiling this target, not
  its dependencies, so be careful about header files included elsewhere.
  All paths should be relative to the workspace, not to the current package.
  This attribute should not be needed outside of <code>third_party</code>.
</p>
<p>
  If the package declares the <a href="${link package.features}">feature</a>
  <code>no_copts_tokenization</code>, Bourne shell tokenization applies only to strings
  that consist of a single "Make" variable.
</p>
2[]�
�
cxxopts�
Add these options to the C++ compilation command.
Subject to <a href="${link make-variables}">"Make variable"</a> substitution and
<a href="${link common-definitions#sh-tokenization}">Bourne shell tokenization</a>.
2[]�
�
data�
The list of files needed by this library at runtime.

See general comments about <code>data</code>
at <a href="${link common-definitions#typical-attributes}">Typical attributes defined by
most build rules</a>.
<p>If a <code>data</code> is the name of a generated file, then this
   <code>cc_library</code> rule automatically depends on the generating
   rule.
</p>
<p>If a <code>data</code> is a rule name, then this
   <code>cc_library</code> rule automatically depends on that rule,
   and that rule's <code>outs</code> are automatically added to
   this <code>cc_library</code>'s data files.
</p>
<p>Your C++ code can access these data files like so:</p>
<pre><code class="lang-starlark">
  const std::string path = devtools_build::GetDataDependencyFilepath(
      "my/test/data/file");
</code></pre>
2[]�
�
defines�
List of defines to add to the compile line of this and all dependent targets.
Subject to <a href="${link make-variables}">"Make" variable</a> substitution and
<a href="${link common-definitions#sh-tokenization}">Bourne shell tokenization</a>.
Each string, which must consist of a single Bourne shell token,
is prepended with <code>-D</code> and added to the compile command line to this target,
as well as to every rule that depends on it. Be very careful, since this may have
far-reaching effects -- the defines are added to every target that depends on
this target.  When in doubt, add define values to
<a href="#cc_binary.local_defines"><code>local_defines</code></a> instead.
2[]�
�
deps�
The list of other libraries to be linked in to the binary target.
<p>These can be <code>cc_library</code> or <code>objc_library</code>
targets.</p>

It is also allowed to
put linker scripts (.lds) into deps, and reference them in
<a href="#cc_binary.linkopts"><code>linkopts</code></a>,
but please consider
<a href="#cc_binary.additional_linker_inputs"><code>additional_linker_inputs</code></a>
for that use case.
*
CcInfo2[]�
�
dynamic_deps�
These are other <code>cc_shared_library</code> dependencies the current target depends on.

<p>
The <code>cc_shared_library</code> implementation will use the list of
<code>dynamic_deps</code> (transitively, i.e. also the <code>dynamic_deps</code> of the
current target's <code>dynamic_deps</code>) to decide which <code>cc_libraries</code> in
the transitive <code>deps</code> should not be linked in because they are already provided
by a different <code>cc_shared_library</code>.
*
CcSharedLibraryInfo2[]

env
2{}(
&

hdrs_checkDeprecated, no-op.2""�
�
includes�
List of include dirs to be added to the compile line.
Subject to <a href="${link make-variables}">"Make variable"</a> substitution.
Each string is prepended with the package path and passed to the C++ toolchain for
expansion via the "include_paths" CROSSTOOL feature. A toolchain running on a POSIX system
with typical feature definitions will produce
<code>-isystem path_to_package/include_entry</code>.
This should only be used for third-party libraries that
do not conform to the Google style of writing #include statements.
Unlike <a href="#cc_binary.copts">COPTS</a>, these flags are added for this rule
and every rule that depends on it. (Note: not the rules it depends upon!) Be
very careful, since this may have far-reaching effects.  When in doubt, add
"-I" flags to <a href="#cc_binary.copts">COPTS</a> instead.
<p>
The added <code>include</code> paths will include generated files as well as
files in the source tree.
</p>
2[]

licenses2[]�
�
link_extra_lib�
Control linking of extra libraries.
<p>
    By default, C++ binaries are linked against <code>@bazel_tools//tools/cpp:link_extra_lib</code>,
    which by default depends on the label flag <code>@bazel_tools//tools/cpp:link_extra_libs</code>.
    Without setting the flag, this library is empty by default. Setting the label flag
    allows linking optional dependencies, such as overrides for weak symbols, interceptors
    for shared library functions, or special runtime libraries (for malloc replacements,
    prefer <code>malloc</code> or <code>--custom_malloc</code>). Setting this attribute to
    <code>None</code> disables this behaviour.
</p>
*
CcInfo2&@bazel_tools//tools/cpp:link_extra_lib�
�
linkopts�
Add these flags to the C++ linker command.
Subject to <a href="make-variables.html">"Make" variable</a> substitution,
<a href="common-definitions.html#sh-tokenization">
Bourne shell tokenization</a> and
<a href="common-definitions.html#label-expansion">label expansion</a>.
Each string in this attribute is added to <code>LINKOPTS</code> before
linking the binary target.
<p>
    Each element of this list that does not start with <code>$</code> or <code>-</code> is
    assumed to be the label of a target in <code>deps</code>. The
    list of files generated by that target is appended to the linker
    options.  An error is reported if the label is invalid, or is
    not declared in <code>deps</code>.
</p>
2[]�
�

linkshared�
Create a shared library.
To enable this attribute, include <code>linkshared=True</code> in your rule. By default
this option is off.
<p>
  The presence of this flag means that linking occurs with the <code>-shared</code> flag
  to <code>gcc</code>, and the resulting shared library is suitable for loading into for
  example a Java program. However, for build purposes it will never be linked into the
  dependent binary, as it is assumed that shared libraries built with a
  <a href="#cc_binary">cc_binary</a> rule are only loaded manually by other programs, so
  it should not be considered a substitute for the <a href="#cc_library">cc_library</a>
  rule. For sake of scalability we recommend avoiding this approach altogether and
  simply letting <code>java_library</code> depend on <code>cc_library</code> rules
  instead.
</p>
<p>
  If you specify both <code>linkopts=['-static']</code> and <code>linkshared=True</code>,
  you get a single completely self-contained unit. If you specify both
  <code>linkstatic=True</code> and <code>linkshared=True</code>, you get a single, mostly
  self-contained unit.
</p>
2False�
�

linkstatic�
For <a href="${link cc_binary}"><code>cc_binary</code></a> and
<a href="${link cc_test}"><code>cc_test</code></a>: link the binary in static
mode. For <code>cc_library.link_static</code>: see below.
<p>By default this option is on for <code>cc_binary</code> and off for the rest.</p>
<p>
  If enabled and this is a binary or test, this option tells the build tool to link in
  <code>.a</code>'s instead of <code>.so</code>'s for user libraries whenever possible.
  System libraries such as libc (but <i>not</i> the C/C++ runtime libraries,
  see below) are still linked dynamically, as are libraries for which
  there is no static library. So the resulting executable will still be dynamically
  linked, hence only <i>mostly</i> static.
</p>
<p>
There are really three different ways to link an executable:
</p>
<ul>
<li> STATIC with fully_static_link feature, in which everything is linked statically;
  e.g. "<code>gcc -static foo.o libbar.a libbaz.a -lm</code>".<br/>
  This mode is enabled by specifying <code>fully_static_link</code> in the
  <a href="${link common-definitions#features}"><code>features</code></a> attribute.</li>
<li> STATIC, in which all user libraries are linked statically (if a static
  version is available), but where system libraries (excluding C/C++ runtime libraries)
  are linked dynamically, e.g. "<code>gcc foo.o libfoo.a libbaz.a -lm</code>".<br/>
  This mode is enabled by specifying <code>linkstatic=True</code>.</li>
<li> DYNAMIC, in which all libraries are linked dynamically (if a dynamic version is
  available), e.g. "<code>gcc foo.o libfoo.so libbaz.so -lm</code>".<br/>
  This mode is enabled by specifying <code>linkstatic=False</code>.</li>
</ul>
<p>
If the <code>linkstatic</code> attribute or <code>fully_static_link</code> in
<code>features</code> is used outside of <code>//third_party</code>
please include a comment near the rule to explain why.
</p>
<p>
The <code>linkstatic</code> attribute has a different meaning if used on a
<a href="${link cc_library}"><code>cc_library()</code></a> rule.
For a C++ library, <code>linkstatic=True</code> indicates that only
static linking is allowed, so no <code>.so</code> will be produced. linkstatic=False does
not prevent static libraries from being created. The attribute is meant to control the
creation of dynamic libraries.
</p>
<p>
There should be very little code built with <code>linkstatic=False</code> in production.
If <code>linkstatic=False</code>, then the build tool will create symlinks to
depended-upon shared libraries in the <code>*.runfiles</code> area.
</p>
2True�
�
local_defines�
List of defines to add to the compile line.
Subject to <a href="${link make-variables}">"Make" variable</a> substitution and
<a href="${link common-definitions#sh-tokenization}">Bourne shell tokenization</a>.
Each string, which must consist of a single Bourne shell token,
is prepended with <code>-D</code> and added to the compile command line for this target,
but not to its dependents. Unlike <code>defines</code>, the defines are only added to the
compile command line for this target.
2[]�
�
malloc�
Override the default dependency on malloc.
<p>
  By default, C++ binaries are linked against <code>//tools/cpp:malloc</code>,
  which is an empty library so the binary ends up using libc malloc.
  This label must refer to a <code>cc_library</code>. If compilation is for a non-C++
  rule, this option has no effect. The value of this attribute is ignored if
  <code>linkshared=True</code> is specified.
</p>
*
CcInfo2@bazel_tools//tools/cpp:malloc�
�
module_interfaces�
The list of files are regarded as C++20 Modules Interface.

<p>
C++ Standard has no restriction about module interface file extension
<ul>
<li>Clang use cppm </li>
<li>GCC can use any source file extension </li>
<li>MSVC use ixx </li>
</ul>
</p>
<p>The use is guarded by the flag
<code>--experimental_cpp_modules</code>.</p>
2[]�
�
nocopts�
Remove matching options from the C++ compilation command.
Subject to <a href="${link make-variables}">"Make" variable</a> substitution.
The value of this attribute is interpreted as a regular expression.
Any preexisting <code>COPTS</code> that match this regular expression
(including values explicitly specified in the rule's <a
href="#cc_binary.copts">copts</a> attribute)
will be removed from <code>COPTS</code> for purposes of compiling this rule.
This attribute should not be needed or used
outside of <code>third_party</code>.  The values are not preprocessed
in any way other than the "Make" variable substitution.
2""

reexport_deps2[]�
�
srcs�
The list of C and C++ files that are processed to create the library target.
These are C/C++ source and header files, either non-generated (normal source
code) or generated.
<p>All <code>.cc</code>, <code>.c</code>, and <code>.cpp</code> files will
   be compiled. These might be generated files: if a named file is in
   the <code>outs</code> of some other rule, this <code>cc_library</code>
   will automatically depend on that other rule.
</p>
<p>Pure assembler files (.s, .asm) are not preprocessed and are typically built using
the assembler. Preprocessed assembly files (.S) are preprocessed and are typically built
using the C/C++ compiler.
</p>
<p>A <code>.h</code> file will not be compiled, but will be available for
   inclusion by sources in this rule. Both <code>.cc</code> and
   <code>.h</code> files can directly include headers listed in
   these <code>srcs</code> or in the <code>hdrs</code> of this rule or any
   rule listed in the <code>deps</code> argument.
</p>
<p>All <code>#include</code>d files must be mentioned in the
   <code>hdrs</code> attribute of this or referenced <code>cc_library</code>
   rules, or they should be listed in <code>srcs</code> if they are private
   to this library. See <a href="#hdrs">"Header inclusion checking"</a> for
   a more detailed description.
</p>
<p><code>.so</code>, <code>.lo</code>, and <code>.a</code> files are
   pre-compiled files. Your library might have these as
   <code>srcs</code> if it uses third-party code for which we don't
   have source code.
</p>
<p>If the <code>srcs</code> attribute includes the label of another rule,
   <code>cc_library</code> will use the output files of that rule as source files to
   compile. This is useful for one-off generation of source code (for more than occasional
   use, it's better to implement a Starlark rule class and use the <code>cc_common</code>
   API)
</p>
<p>
  Permitted <code>srcs</code> file types:
</p>
<ul>
<li>C and C++ source files: <code>.c</code>, <code>.cc</code>, <code>.cpp</code>,
  <code>.cxx</code>, <code>.c++</code>, <code>.C</code></li>
<li>C and C++ header files: <code>.h</code>, <code>.hh</code>, <code>.hpp</code>,
  <code>.hxx</code>, <code>.inc</code>, <code>.inl</code>, <code>.H</code></li>
<li>Assembler with C preprocessor: <code>.S</code></li>
<li>Archive: <code>.a</code>, <code>.pic.a</code></li>
<li>"Always link" library: <code>.lo</code>, <code>.pic.lo</code></li>
<li>Shared library, versioned or unversioned: <code>.so</code>,
  <code>.so.<i>version</i></code></li>
<li>Object file: <code>.o</code>, <code>.pic.o</code></li>
</ul>

<p>
  ... and any rules that produce those files (e.g. <code>cc_embed_data</code>).
  Different extensions denote different programming languages in
  accordance with gcc convention.
</p>
2[]�
�
stamp�
Whether to encode build information into the binary. Possible values:
<ul>
<li>
  <code>stamp = 1</code>: Always stamp the build information into the binary, even in
  <a href="${link user-manual#flag--stamp}"><code>--nostamp</code></a> builds. <b>This
  setting should be avoided</b>, since it potentially kills remote caching for the
  binary and any downstream actions that depend on it.
</li>
<li>
  <code>stamp = 0</code>: Always replace build information by constant values. This
  gives good build result caching.
</li>
<li>
  <code>stamp = -1</code>: Embedding of build information is controlled by the
  <a href="${link user-manual#flag--stamp}"><code>--[no]stamp</code></a> flag.
</li>
</ul>
<p>Stamped binaries are <em>not</em> rebuilt unless their dependencies change.</p>
2-1�
�
win_def_file�
The Windows DEF file to be passed to linker.
<p>This attribute should only be used when Windows is the target platform.
It can be used to <a href="https://msdn.microsoft.com/en-us/library/d91k01sh.aspx">
export symbols</a> during linking a shared library.</p>
2None�
2//python/module_extension/private:cc_extension.bzlr�
?

rules_venvpython/module_extension/privatecc_extension.bzl1
py_cc_extension_py_cc_extension

# py_cc_extension�
+

rules_venvpython/mypy/privatemypy.bzl�py_mypy_test+A rule for running mypy on a Python target."�
�
py_mypy_test+A rule for running mypy on a Python target.*
nameA unique name for this target. X
config6The config file (`mypy.ini`) containing mypy settings.2//python/mypy:config4
targetThe target to run `mypy` on. *
PyInfo":
py_mypy_test*@@rules_venv//python/mypy/private:mypy.bzl
BB,
*
nameA unique name for this target. Z
X
config6The config file (`mypy.ini`) containing mypy settings.2//python/mypy:config6
4
targetThe target to run `mypy` on. *
PyInfo�py_mypy_aspect:An aspect for running mypy on targets with Python sources.:�
�
py_mypy_aspect:An aspect for running mypy on targets with Python sources."*
nameA unique name for this target. *<
py_mypy_aspect*@@rules_venv//python/mypy/private:mypy.bzl
��,
*
nameA unique name for this target. k
//python:py_info.bzlrQ
!

rules_venvpythonpy_info.bzl
PyInfoPyInfo
*0
2�
 //python/private:target_srcs.bzlr�
-

rules_venvpython/privatetarget_srcs.bzl$
	find_srcs	find_srcs
6?<
target_sources_aspecttarget_sources_aspect
CX
Z
//python/venv:defs.bzlrc
#

rules_venvpython/venvdefs.bzl.
py_venv_commonpy_venv_common
,:
<Bazel rules for mypy�	
5

rules_venvpython/mypy/privatemypy_toolchain.bzl�current_py_mypy_toolchain?A rule for exposing the current registered `py_mypy_toolchain`."�
�
current_py_mypy_toolchain?A rule for exposing the current registered `py_mypy_toolchain`.*
nameA unique name for this target. "Q
current_py_mypy_toolchain4@@rules_venv//python/mypy/private:mypy_toolchain.bzl
=!=!,
*
nameA unique name for this target. �py_mypy_toolchainIA toolchain for the [mypy](https://mypy.readthedocs.io/) formatter rules."�
�
py_mypy_toolchainIA toolchain for the [mypy](https://mypy.readthedocs.io/) formatter rules.*
nameA unique name for this target. B
mypy,The mypy `py_library` to use with the rules. *
PyInfo"I
py_mypy_toolchain4@@rules_venv//python/mypy/private:mypy_toolchain.bzl
,
*
nameA unique name for this target. D
B
mypy,The mypy `py_library` to use with the rules. *
PyInfok
//python:py_info.bzlrQ
!

rules_venvpythonpy_info.bzl
PyInfoPyInfo
*0
2T	TOOLCHAIN_TYPE@@//python/mypy:toolchain_typej @@//python/mypy:toolchain_typemypy toolchain rules.�
#

rules_venvpython/mypydefs.bzl�py_mypy_toolchainIA toolchain for the [mypy](https://mypy.readthedocs.io/) formatter rules."�
�
py_mypy_toolchainIA toolchain for the [mypy](https://mypy.readthedocs.io/) formatter rules.*
nameA unique name for this target. B
mypy,The mypy `py_library` to use with the rules. *
PyInfo"7
py_mypy_toolchain"@@rules_venv//python/mypy:defs.bzl
,
*
nameA unique name for this target. D
B
mypy,The mypy `py_library` to use with the rules. *
PyInfo�py_mypy_aspect:An aspect for running mypy on targets with Python sources.:�
�
py_mypy_aspect:An aspect for running mypy on targets with Python sources."*
nameA unique name for this target. *4
py_mypy_aspect"@@rules_venv//python/mypy:defs.bzl
��,
*
nameA unique name for this target. �
 //python/mypy:py_mypy_aspect.bzlrn
-

rules_venvpython/mypypy_mypy_aspect.bzl/
py_mypy_aspect_py_mypy_aspect
AA
?B�
//python/mypy:py_mypy_test.bzlrh
+

rules_venvpython/mypypy_mypy_test.bzl+
py_mypy_test_py_mypy_test
EE
CF�
#//python/mypy:py_mypy_toolchain.bzlrw
0

rules_venvpython/mypypy_mypy_toolchain.bzl5
py_mypy_toolchain_py_mypy_toolchain
II
GJ�# rules_mypy

Bazel rules for the Python linter [mypy][mp].

### Setup

First ensure `rules_venv` is setup by referring to [rules_venv setup](../index.md#setup).

Next, the `mypy` rules work mostly off of toolchains which are used to provide the necessary python targets (aka `mypy`)
for the process wrappers. Users will want to make sure they have a way to get the necessary python dependencies. Tools such as
[req-compile](https://github.com/periareon/req-compile) can provide these.

With the appropriate dependencies available, a [py_mypy_toolchain](#py_mypy_toolchain) will need to be configured:

```python
load("@rules_venv//python:defs.bzl", "py_library")
load("@rules_venv//python/mypy:defs.bzl", "py_mypy_toolchain")

py_library(
    name = "mypy_deps",
    deps = [
        "@pip_deps//mypy",

        # Types libraries can also be added here.
    ],
)

py_mypy_toolchain(
    name = "toolchain_impl",
    mypy = ":mypy_deps",
    visibility = ["//visibility:public"]
)

toolchain(
    name = "toolchain",
    toolchain = ":toolchain_impl",
    toolchain_type = "@rules_venv//python/mypy:toolchain_type",
    visibility = ["//visibility:public"]
)
```

This toolchain then needs to be registered in the `MODULE.bazel` file.

```python
register_toolchains("//tools/python/mypy:toolchain")
```

From here, [py_mypy_test](#py_mypy_test) and the [py_mypy_aspect](#py_mypy_aspect)
should now be usable. Both of these rules use a global flag to determine which mypy configuration
file to use with in actions. The following snippet can be added to the `.bazelrc` file to chose the
desired configuration file

```text
build --@rules_mypy//python/mypy:config=//:.mypyrc.toml
```

Note that these files will need to be available via [exports_files](https://bazel.build/reference/be/functions#exports_files)


[mp]: https://mypy.readthedocs.io/
�
-

rules_venvpython/mypypy_mypy_aspect.bzl�py_mypy_aspect:An aspect for running mypy on targets with Python sources.:�
�
py_mypy_aspect:An aspect for running mypy on targets with Python sources."*
nameA unique name for this target. *>
py_mypy_aspect,@@rules_venv//python/mypy:py_mypy_aspect.bzl
��,
*
nameA unique name for this target. �
//python/mypy/private:mypy.bzlrl
+

rules_venvpython/mypy/privatemypy.bzl/
py_mypy_aspect_py_mypy_aspect

# py_mypy_aspect�
0

rules_venvpython/mypypy_mypy_toolchain.bzl�py_mypy_toolchainIA toolchain for the [mypy](https://mypy.readthedocs.io/) formatter rules."�
�
py_mypy_toolchainIA toolchain for the [mypy](https://mypy.readthedocs.io/) formatter rules.*
nameA unique name for this target. B
mypy,The mypy `py_library` to use with the rules. *
PyInfo"D
py_mypy_toolchain/@@rules_venv//python/mypy:py_mypy_toolchain.bzl
,
*
nameA unique name for this target. D
B
mypy,The mypy `py_library` to use with the rules. *
PyInfo�
(//python/mypy/private:mypy_toolchain.bzlr|
5

rules_venvpython/mypy/privatemypy_toolchain.bzl5
py_mypy_toolchain_py_mypy_toolchain

# py_mypy_toolchain@
*

rules_venvpython/privatecoverage.bzlCoverage utilities�
-

rules_venvpython/privatetarget_srcs.bzl�	find_srcs[Find all lintable source files for a given target.

Note that generated files are ignored.
*�
�
	find_srcs)
targetThe target to collect from. (L

aspect_ctx6The context object for an aspect if called within one.None([Find all lintable source files for a given target.

Note that generated files are ignored.
"2
0depset[File]: A depset of lintable source files.29
	find_srcs,@@rules_venv//python/private:target_srcs.bzl
�PySourcesInfo1A container for info on a lintable python target.2�
�
PySourcesInfo1A container for info on a lintable python target.N
importsCDepset[str]: The values of `PyInfo.imports` for the current target..
srcs&depset[File]: All direct source files."=
PySourcesInfo,@@rules_venv//python/private:target_srcs.bzl
P
N
importsCDepset[str]: The values of `PyInfo.imports` for the current target.0
.
srcs&depset[File]: All direct source files.�target_sources_aspect=An aspect for gathering additional data on a lintable target.:�
�
target_sources_aspect=An aspect for gathering additional data on a lintable target."*
nameA unique name for this target. *E
target_sources_aspect,@@rules_venv//python/private:target_srcs.bzl
mm,
*
nameA unique name for this target. a
//lib:paths.bzlrL

bazel_skyliblib	paths.bzl
pathspaths
',
.k
//python:py_info.bzlrQ
!

rules_venvpythonpy_info.bzl
PyInfoPyInfo
*0
2EA utility for collecting info from python targets useful for linting.�
/

rules_venvpython/pylint/private
pylint.bzl�py_pylint_test-A rule for running pylint on a Python target."�
�
py_pylint_test-A rule for running pylint on a Python target.*
nameA unique name for this target. Z
config6The config file (pylintrc) containing pylint settings.2//python/pylint:config6
targetThe target to run `pylint` on. *
PyInfo"@
py_pylint_test.@@rules_venv//python/pylint/private:pylint.bzl
AA,
*
nameA unique name for this target. \
Z
config6The config file (pylintrc) containing pylint settings.2//python/pylint:config8
6
targetThe target to run `pylint` on. *
PyInfo�py_pylint_aspect�An aspect for running pylint on targets with Python sources.

This aspect can be configured by adding the following snippet to a workspace's `.bazelrc` file:

```text
build --aspects=@rules_venv//python/pylint:py_pylint_aspect.bzl%py_pylint_aspect
build --output_groups=+py_pylint_checks
```
:�
�
py_pylint_aspect�An aspect for running pylint on targets with Python sources.

This aspect can be configured by adding the following snippet to a workspace's `.bazelrc` file:

```text
build --aspects=@rules_venv//python/pylint:py_pylint_aspect.bzl%py_pylint_aspect
build --output_groups=+py_pylint_checks
```
"*
nameA unique name for this target. *B
py_pylint_aspect.@@rules_venv//python/pylint/private:pylint.bzl
��,
*
nameA unique name for this target. k
//python:py_info.bzlrQ
!

rules_venvpythonpy_info.bzl
PyInfoPyInfo
*0
2�
 //python/private:target_srcs.bzlr�
-

rules_venvpython/privatetarget_srcs.bzl$
	find_srcs	find_srcs
6?<
target_sources_aspecttarget_sources_aspect
CX
Z
//python/venv:defs.bzlrc
#

rules_venvpython/venvdefs.bzl.
py_venv_commonpy_venv_common
,:
<Bazel rules for Pylint�	
9

rules_venvpython/pylint/privatepylint_toolchain.bzl�current_py_pylint_toolchainAA rule for exposing the current registered `py_pylint_toolchain`."�
�
current_py_pylint_toolchainAA rule for exposing the current registered `py_pylint_toolchain`.*
nameA unique name for this target. "W
current_py_pylint_toolchain8@@rules_venv//python/pylint/private:pylint_toolchain.bzl
=#=#,
*
nameA unique name for this target. �py_pylint_toolchainWA toolchain for the [pylint](https://pylint.readthedocs.io/en/stable/) formatter rules."�
�
py_pylint_toolchainWA toolchain for the [pylint](https://pylint.readthedocs.io/en/stable/) formatter rules.*
nameA unique name for this target. F
pylint.The pylint `py_library` to use with the rules. *
PyInfo"O
py_pylint_toolchain8@@rules_venv//python/pylint/private:pylint_toolchain.bzl
,
*
nameA unique name for this target. H
F
pylint.The pylint `py_library` to use with the rules. *
PyInfok
//python:py_info.bzlrQ
!

rules_venvpythonpy_info.bzl
PyInfoPyInfo
*0
2X	TOOLCHAIN_TYPE @@//python/pylint:toolchain_typej" @@//python/pylint:toolchain_typePylint toolchain rules.�
%

rules_venvpython/pylintdefs.bzl�py_pylint_toolchainWA toolchain for the [pylint](https://pylint.readthedocs.io/en/stable/) formatter rules."�
�
py_pylint_toolchainWA toolchain for the [pylint](https://pylint.readthedocs.io/en/stable/) formatter rules.*
nameA unique name for this target. F
pylint.The pylint `py_library` to use with the rules. *
PyInfo";
py_pylint_toolchain$@@rules_venv//python/pylint:defs.bzl
,
*
nameA unique name for this target. H
F
pylint.The pylint `py_library` to use with the rules. *
PyInfo�py_pylint_aspect�An aspect for running pylint on targets with Python sources.

This aspect can be configured by adding the following snippet to a workspace's `.bazelrc` file:

```text
build --aspects=@rules_venv//python/pylint:py_pylint_aspect.bzl%py_pylint_aspect
build --output_groups=+py_pylint_checks
```
:�
�
py_pylint_aspect�An aspect for running pylint on targets with Python sources.

This aspect can be configured by adding the following snippet to a workspace's `.bazelrc` file:

```text
build --aspects=@rules_venv//python/pylint:py_pylint_aspect.bzl%py_pylint_aspect
build --output_groups=+py_pylint_checks
```
"*
nameA unique name for this target. *8
py_pylint_aspect$@@rules_venv//python/pylint:defs.bzl
��,
*
nameA unique name for this target. �
$//python/pylint:py_pylint_aspect.bzlrv
1

rules_venvpython/pylintpy_pylint_aspect.bzl3
py_pylint_aspect_py_pylint_aspect
77
58�
"//python/pylint:py_pylint_test.bzlrp
/

rules_venvpython/pylintpy_pylint_test.bzl/
py_pylint_test_py_pylint_test
;;
9<�
'//python/pylint:py_pylint_toolchain.bzlr
4

rules_venvpython/pylintpy_pylint_toolchain.bzl9
py_pylint_toolchain_py_pylint_toolchain
??
=@�# Pylint

Bazel rules for the Python linter [Pylint][pl].

### Setup

First ensure `rules_venv` is setup by referring to [rules_venv setup](../index.md#setup).

Next, the `pylint` rules work mostly off of toolchains which are used to provide the necessary python targets (aka `pylint`)
for the process wrappers. Users will want to make sure they have a way to get the necessary python dependencies. Tools such as
[req-compile](https://github.com/periareon/req-compile) can provide these.

With the appropriate dependencies available, a [py_pylint_toolchain](#py_pylint_toolchain) will need to be configured:

```python
load("@rules_venv//python/pylint:defs.bzl", "py_pylint_toolchain")

py_pylint_toolchain(
    name = "toolchain_impl",
    pylint = "@pip_deps//pylint",
    visibility = ["//visibility:public"]
)

toolchain(
    name = "toolchain",
    toolchain = ":toolchain_impl",
    toolchain_type = "@rules_venv//python/pylint:toolchain_type",
    visibility = ["//visibility:public"]
)
```

This toolchain then needs to be registered in the `MODULE.bazel` file.

```python
register_toolchains("//tools/python/pylint:toolchain")
```

From here, [py_pylint_test](#py_pylint_test) and the [py_pylint_aspect](#py_pylint_aspect)
should now be usable. Both of these rules use a global flag to determine which pylint configuration
file to use with in actions. The following snippet can be added to the `.bazelrc` file to chose the
desired configuration file

```text
build --@rules_pylint//python/pylint:config=//:.pylintrc.toml
```

Note that these files will need to be available via [exports_files](https://bazel.build/reference/be/functions#exports_files)


[pl]: https://pylint.pycqa.org/en/latest/
�
1

rules_venvpython/pylintpy_pylint_aspect.bzl�py_pylint_aspect�An aspect for running pylint on targets with Python sources.

This aspect can be configured by adding the following snippet to a workspace's `.bazelrc` file:

```text
build --aspects=@rules_venv//python/pylint:py_pylint_aspect.bzl%py_pylint_aspect
build --output_groups=+py_pylint_checks
```
:�
�
py_pylint_aspect�An aspect for running pylint on targets with Python sources.

This aspect can be configured by adding the following snippet to a workspace's `.bazelrc` file:

```text
build --aspects=@rules_venv//python/pylint:py_pylint_aspect.bzl%py_pylint_aspect
build --output_groups=+py_pylint_checks
```
"*
nameA unique name for this target. *D
py_pylint_aspect0@@rules_venv//python/pylint:py_pylint_aspect.bzl
��,
*
nameA unique name for this target. �
"//python/pylint/private:pylint.bzlrt
/

rules_venvpython/pylint/private
pylint.bzl3
py_pylint_aspect_py_pylint_aspect

# py_pylint_aspect�
4

rules_venvpython/pylintpy_pylint_toolchain.bzl�py_pylint_toolchainWA toolchain for the [pylint](https://pylint.readthedocs.io/en/stable/) formatter rules."�
�
py_pylint_toolchainWA toolchain for the [pylint](https://pylint.readthedocs.io/en/stable/) formatter rules.*
nameA unique name for this target. F
pylint.The pylint `py_library` to use with the rules. *
PyInfo"J
py_pylint_toolchain3@@rules_venv//python/pylint:py_pylint_toolchain.bzl
,
*
nameA unique name for this target. H
F
pylint.The pylint `py_library` to use with the rules. *
PyInfo�
,//python/pylint/private:pylint_toolchain.bzlr�
9

rules_venvpython/pylint/privatepylint_toolchain.bzl9
py_pylint_toolchain_py_pylint_toolchain

# py_pylint_toolchain��
/

rules_venvpython/pytest/private
pytest.bzl�current_py_pytest_toolchainAA rule for exposing the current registered `py_pytest_toolchain`."�
�
current_py_pytest_toolchainAA rule for exposing the current registered `py_pytest_toolchain`.*
nameA unique name for this target. "M
current_py_pytest_toolchain.@@rules_venv//python/pytest/private:pytest.bzl
�#�#,
*
nameA unique name for this target. �#py_pytest_test�	A rule which runs python tests using [pytest][pt] as the [py_test][bpt] test runner.

This rule also supports a build setting for globally applying extra flags to test invocations.
Users can add something similar to the following to their `.bazelrc` files:

```text
build --@rules_venv//python/pytest:extra_args=--color=yes,-vv
```

The example above will add `--colors=yes` and `-vv` arguments to the end of the pytest invocation.

Tips:

- It's common for tests to have some utility code that does not live in a test source file.
To account for this. A `py_library` can be created that contains only these sources which are then
passed to `py_pytest_test` via `deps`.

```python
load("@rules_venv//python:defs.bzl", "py_library")
load("@rules_venv//python/pytest:defs.bzl", "py_pytest_test")

py_library(
    name = "test_utils",
    srcs = [
        "tests/__init__.py",
        "tests/conftest.py",
    ],
    deps = ["@rules_venv//python/pytest:current_py_pytest_toolchain"],
    testonly = True,
)

py_pytest_test(
    name = "test",
    srcs = ["tests/example_test.py"],
    deps = [":test_utils"],
)
```

[pt]: https://docs.pytest.org/en/latest/
[bpt]: https://docs.bazel.build/versions/master/be/python.html#py_test
[ptx]: https://pypi.org/project/pytest-xdist/
"�
�
py_pytest_test�	A rule which runs python tests using [pytest][pt] as the [py_test][bpt] test runner.

This rule also supports a build setting for globally applying extra flags to test invocations.
Users can add something similar to the following to their `.bazelrc` files:

```text
build --@rules_venv//python/pytest:extra_args=--color=yes,-vv
```

The example above will add `--colors=yes` and `-vv` arguments to the end of the pytest invocation.

Tips:

- It's common for tests to have some utility code that does not live in a test source file.
To account for this. A `py_library` can be created that contains only these sources which are then
passed to `py_pytest_test` via `deps`.

```python
load("@rules_venv//python:defs.bzl", "py_library")
load("@rules_venv//python/pytest:defs.bzl", "py_pytest_test")

py_library(
    name = "test_utils",
    srcs = [
        "tests/__init__.py",
        "tests/conftest.py",
    ],
    deps = ["@rules_venv//python/pytest:current_py_pytest_toolchain"],
    testonly = True,
)

py_pytest_test(
    name = "test",
    srcs = ["tests/example_test.py"],
    deps = [":test_utils"],
)
```

[pt]: https://docs.pytest.org/en/latest/
[bpt]: https://docs.bazel.build/versions/master/be/python.html#py_test
[ptx]: https://pypi.org/project/pytest-xdist/
*
nameA unique name for this target. I
config%The pytest configuration file to use.2//python/pytest:configW
coverage_rc)The pytest-cov configuration file to use.2//python/pytest:coverage_rco
dataaFiles needed by this rule at runtime. May list file or rule targets. Generally allows any target.2[]Y
depsAThe list of other libraries to be linked in to the binary target.*
PyInfo2[]h
env[Dictionary of strings; values are subject to `$(location)` and "Make variable" substitution
2{}�
env_inherit~Specifies additional environment variables to inherit from the external environment when the test is executed by `bazel test`.2[]�
numprocesses�If set the [pytest-xdist](https://pypi.org/project/pytest-xdist/) argument `--numprocesses` (`-n`) will be passed to the test. Note that the a value 0 or less indicates this flag should not be passed.207
srcs)An explicit list of source files to test.2[]"@
py_pytest_test.@@rules_venv//python/pytest/private:pytest.bzl
��,
*
nameA unique name for this target. K
I
config%The pytest configuration file to use.2//python/pytest:configY
W
coverage_rc)The pytest-cov configuration file to use.2//python/pytest:coverage_rcq
o
dataaFiles needed by this rule at runtime. May list file or rule targets. Generally allows any target.2[][
Y
depsAThe list of other libraries to be linked in to the binary target.*
PyInfo2[]j
h
env[Dictionary of strings; values are subject to `$(location)` and "Make variable" substitution
2{}�
�
env_inherit~Specifies additional environment variables to inherit from the external environment when the test is executed by `bazel test`.2[]�
�
numprocesses�If set the [pytest-xdist](https://pypi.org/project/pytest-xdist/) argument `--numprocesses` (`-n`) will be passed to the test. Note that the a value 0 or less indicates this flag should not be passed.209
7
srcs)An explicit list of source files to test.2[]�py_pytest_toolchain�A toolchain for the [pytest](https://docs.pytest.org/en/stable/) rules.

The `pytest` attribute accepts a `py_library` target containing the pytest
package and any desired plugins. At minimum, the library must include `pytest`.
Additional dependencies unlock optional features:

- `pytest-cov` + `coverage`: Enables `bazel coverage` support.
- `pytest-xdist`: Enables parallel test execution via the `numprocesses` attribute.
- `pytest-shard`: Enables Bazel test sharding.

**Minimal example** (test-only, no coverage):

```python
load("@rules_venv//python:defs.bzl", "py_library")
load("@rules_venv//python/pytest:defs.bzl", "py_pytest_toolchain")

py_library(
    name = "pytest_lib",
    deps = ["@pip//pytest"],
)

py_pytest_toolchain(
    name = "pytest_toolchain",
    pytest = ":pytest_lib",
)

toolchain(
    name = "toolchain",
    toolchain = ":pytest_toolchain",
    toolchain_type = "@rules_venv//python/pytest:toolchain_type",
)
```

**Full example** (with coverage, xdist, and sharding):

```python
load("@rules_venv//python:defs.bzl", "py_library")
load("@rules_venv//python/pytest:defs.bzl", "py_pytest_toolchain")

py_library(
    name = "pytest_lib",
    deps = [
        "@pip//coverage",
        "@pip//pytest",
        "@pip//pytest_cov",
        "@pip//pytest_shard",
        "@pip//pytest_xdist",
    ],
)

py_pytest_toolchain(
    name = "pytest_toolchain",
    pytest = ":pytest_lib",
)

toolchain(
    name = "toolchain",
    toolchain = ":pytest_toolchain",
    toolchain_type = "@rules_venv//python/pytest:toolchain_type",
)
```
"�
�
py_pytest_toolchain�A toolchain for the [pytest](https://docs.pytest.org/en/stable/) rules.

The `pytest` attribute accepts a `py_library` target containing the pytest
package and any desired plugins. At minimum, the library must include `pytest`.
Additional dependencies unlock optional features:

- `pytest-cov` + `coverage`: Enables `bazel coverage` support.
- `pytest-xdist`: Enables parallel test execution via the `numprocesses` attribute.
- `pytest-shard`: Enables Bazel test sharding.

**Minimal example** (test-only, no coverage):

```python
load("@rules_venv//python:defs.bzl", "py_library")
load("@rules_venv//python/pytest:defs.bzl", "py_pytest_toolchain")

py_library(
    name = "pytest_lib",
    deps = ["@pip//pytest"],
)

py_pytest_toolchain(
    name = "pytest_toolchain",
    pytest = ":pytest_lib",
)

toolchain(
    name = "toolchain",
    toolchain = ":pytest_toolchain",
    toolchain_type = "@rules_venv//python/pytest:toolchain_type",
)
```

**Full example** (with coverage, xdist, and sharding):

```python
load("@rules_venv//python:defs.bzl", "py_library")
load("@rules_venv//python/pytest:defs.bzl", "py_pytest_toolchain")

py_library(
    name = "pytest_lib",
    deps = [
        "@pip//coverage",
        "@pip//pytest",
        "@pip//pytest_cov",
        "@pip//pytest_shard",
        "@pip//pytest_xdist",
    ],
)

py_pytest_toolchain(
    name = "pytest_toolchain",
    pytest = ":pytest_lib",
)

toolchain(
    name = "toolchain",
    toolchain = ":pytest_toolchain",
    toolchain_type = "@rules_venv//python/pytest:toolchain_type",
)
```
*
nameA unique name for this target. Y
pytestAA `py_library` target providing `pytest` and any desired plugins. *
PyInfo"E
py_pytest_toolchain.@@rules_venv//python/pytest/private:pytest.bzl
��,
*
nameA unique name for this target. [
Y
pytestAA `py_library` target providing `pytest` and any desired plugins. *
PyInfo�?py_pytest_test_suite�Generates a [test_suite][ts] which groups various test targets for a set of python sources.

Given an idiomatic python project structure:
```text
BUILD.bazel
my_lib/
    __init__.py
    mod_a.py
    mod_b.py
    mod_c.py
requirements.in
requirements.txt
tests/
    __init__.py
    fixtures.py
    test_mod_a.py
    test_mod_b.py
    test_mod_c.py
```

This rule can be used to easily define test targets:

```python
load("@rules_venv//python:defs.bzl", "py_library")
load("@rules_venv//python/pytest:defs.bzl", "py_pytest_test_suite")

py_library(
    name = "my_lib",
    srcs = glob(["my_lib/**/*.py"])
    imports = ["."],
)

py_pytest_test_suite(
    name = "my_lib_test_suite",
    # Source files containing test helpers should go here.
    # Note that the test sources are excluded. This avoids
    # a test to be updated without invalidating all other
    # targets.
    srcs = glob(
        include = ["tests/**/*.py"],
        exclude = ["tests/**/*_test.py"],
    ),
    # Any data files the tests may need would be passed here
    data = glob(["tests/**/*.json"]),
    # This field is used for dedicated test files.
    tests = glob(["tests/**/*_test.py"]),
    deps = [
        ":my_lib",
    ],
)
```

For each file passed to `tests`, a [py_pytest_test](#py_pytest_test) target will be created. From the example above,
the user should expect to see the following test targets:
```text
//:my_lib_test_suite
//:tests/test_mod_a
//:tests/test_mod_b
//:tests/test_mod_c
```

Additional Notes:
- No file passed to `tests` should be passed found in the `srcs` or `data` attributes or tests will not be able
    to be individually cached.

[pt]: https://docs.bazel.build/versions/master/be/python.html#py_test
[ts]: https://docs.bazel.build/versions/master/be/general.html#test_suite


A rule which runs python tests using [pytest][pt] as the [py_test][bpt] test runner.

This rule also supports a build setting for globally applying extra flags to test invocations.
Users can add something similar to the following to their `.bazelrc` files:

```text
build --@rules_venv//python/pytest:extra_args=--color=yes,-vv
```

The example above will add `--colors=yes` and `-vv` arguments to the end of the pytest invocation.

Tips:

- It's common for tests to have some utility code that does not live in a test source file.
To account for this. A `py_library` can be created that contains only these sources which are then
passed to `py_pytest_test` via `deps`.

```python
load("@rules_venv//python:defs.bzl", "py_library")
load("@rules_venv//python/pytest:defs.bzl", "py_pytest_test")

py_library(
    name = "test_utils",
    srcs = [
        "tests/__init__.py",
        "tests/conftest.py",
    ],
    deps = ["@rules_venv//python/pytest:current_py_pytest_toolchain"],
    testonly = True,
)

py_pytest_test(
    name = "test",
    srcs = ["tests/example_test.py"],
    deps = [":test_utils"],
)
```

[pt]: https://docs.pytest.org/en/latest/
[bpt]: https://docs.bazel.build/versions/master/be/python.html#py_test
[ptx]: https://pypi.org/project/pytest-xdist/
"�'
� 
py_pytest_test_suite�Generates a [test_suite][ts] which groups various test targets for a set of python sources.

Given an idiomatic python project structure:
```text
BUILD.bazel
my_lib/
    __init__.py
    mod_a.py
    mod_b.py
    mod_c.py
requirements.in
requirements.txt
tests/
    __init__.py
    fixtures.py
    test_mod_a.py
    test_mod_b.py
    test_mod_c.py
```

This rule can be used to easily define test targets:

```python
load("@rules_venv//python:defs.bzl", "py_library")
load("@rules_venv//python/pytest:defs.bzl", "py_pytest_test_suite")

py_library(
    name = "my_lib",
    srcs = glob(["my_lib/**/*.py"])
    imports = ["."],
)

py_pytest_test_suite(
    name = "my_lib_test_suite",
    # Source files containing test helpers should go here.
    # Note that the test sources are excluded. This avoids
    # a test to be updated without invalidating all other
    # targets.
    srcs = glob(
        include = ["tests/**/*.py"],
        exclude = ["tests/**/*_test.py"],
    ),
    # Any data files the tests may need would be passed here
    data = glob(["tests/**/*.json"]),
    # This field is used for dedicated test files.
    tests = glob(["tests/**/*_test.py"]),
    deps = [
        ":my_lib",
    ],
)
```

For each file passed to `tests`, a [py_pytest_test](#py_pytest_test) target will be created. From the example above,
the user should expect to see the following test targets:
```text
//:my_lib_test_suite
//:tests/test_mod_a
//:tests/test_mod_b
//:tests/test_mod_c
```

Additional Notes:
- No file passed to `tests` should be passed found in the `srcs` or `data` attributes or tests will not be able
    to be individually cached.

[pt]: https://docs.bazel.build/versions/master/be/python.html#py_test
[ts]: https://docs.bazel.build/versions/master/be/general.html#test_suite


A rule which runs python tests using [pytest][pt] as the [py_test][bpt] test runner.

This rule also supports a build setting for globally applying extra flags to test invocations.
Users can add something similar to the following to their `.bazelrc` files:

```text
build --@rules_venv//python/pytest:extra_args=--color=yes,-vv
```

The example above will add `--colors=yes` and `-vv` arguments to the end of the pytest invocation.

Tips:

- It's common for tests to have some utility code that does not live in a test source file.
To account for this. A `py_library` can be created that contains only these sources which are then
passed to `py_pytest_test` via `deps`.

```python
load("@rules_venv//python:defs.bzl", "py_library")
load("@rules_venv//python/pytest:defs.bzl", "py_pytest_test")

py_library(
    name = "test_utils",
    srcs = [
        "tests/__init__.py",
        "tests/conftest.py",
    ],
    deps = ["@rules_venv//python/pytest:current_py_pytest_toolchain"],
    testonly = True,
)

py_pytest_test(
    name = "test",
    srcs = ["tests/example_test.py"],
    deps = [":test_utils"],
)
```

[pt]: https://docs.pytest.org/en/latest/
[bpt]: https://docs.bazel.build/versions/master/be/python.html#py_test
[ptx]: https://pypi.org/project/pytest-xdist/
*
nameA unique name for this target. I
config%The pytest configuration file to use.2//python/pytest:configW
coverage_rc)The pytest-cov configuration file to use.2//python/pytest:coverage_rco
dataaFiles needed by this rule at runtime. May list file or rule targets. Generally allows any target.2[]Y
depsAThe list of other libraries to be linked in to the binary target.*
PyInfo2[]h
env[Dictionary of strings; values are subject to `$(location)` and "Make variable" substitution
2{}�
env_inherit~Specifies additional environment variables to inherit from the external environment when the test is executed by `bazel test`.2[]�
numprocesses�If set the [pytest-xdist](https://pypi.org/project/pytest-xdist/) argument `--numprocesses` (`-n`) will be passed to the test. Note that the a value 0 or less indicates this flag should not be passed.207
srcs)An explicit list of source files to test.2[]"@
py_pytest_test.@@rules_venv//python/pytest/private:pytest.bzl
��,
*
nameA unique name for this target. K
I
config%The pytest configuration file to use.2//python/pytest:configY
W
coverage_rc)The pytest-cov configuration file to use.2//python/pytest:coverage_rcq
o
dataaFiles needed by this rule at runtime. May list file or rule targets. Generally allows any target.2[][
Y
depsAThe list of other libraries to be linked in to the binary target.*
PyInfo2[]j
h
env[Dictionary of strings; values are subject to `$(location)` and "Make variable" substitution
2{}�
�
env_inherit~Specifies additional environment variables to inherit from the external environment when the test is executed by `bazel test`.2[]�
�
numprocesses�If set the [pytest-xdist](https://pypi.org/project/pytest-xdist/) argument `--numprocesses` (`-n`) will be passed to the test. Note that the a value 0 or less indicates this flag should not be passed.209
7
srcs)An explicit list of source files to test.2[]�
//rules:common_settings.bzlrn
*
bazel_skylibrulescommon_settings.bzl2
BuildSettingInfoBuildSettingInfo
3C
E�
//python:defs.bzlrv


rules_venvpythondefs.bzl
PyInfoPyInfo
'-&

py_library
py_library
1;
=�
//python/private:coverage.bzlrj
*

rules_venvpython/privatecoverage.bzl.
COVERAGE_ATTRSCOVERAGE_ATTRS
3A
C
//python/venv:defs.bzlrc
#

rules_venvpython/venvdefs.bzl.
py_venv_commonpy_venv_common
,:
<Pytest rules for Bazel�
5

rules_venvpython/pytest/privatepytest_utils.bzl�pytest_entrypoint_wrapper:A rule for injecting ignore directives for common linters."�
�
pytest_entrypoint_wrapper:A rule for injecting ignore directives for common linters.*
nameA unique name for this target. (

entrypointThe pytest entrypoint. 
outThe output file. "Q
pytest_entrypoint_wrapper4@@rules_venv//python/pytest/private:pytest_utils.bzl
!!,
*
nameA unique name for this target. *
(

entrypointThe pytest entrypoint. 

outThe output file. )Utility rules for pytest rules and macros�
<

rules_venvpython/pytestcurrent_py_pytest_toolchain.bzl�current_py_pytest_toolchainAA rule for exposing the current registered `py_pytest_toolchain`."�
�
current_py_pytest_toolchainAA rule for exposing the current registered `py_pytest_toolchain`.*
nameA unique name for this target. "Z
current_py_pytest_toolchain;@@rules_venv//python/pytest:current_py_pytest_toolchain.bzl
�#�#,
*
nameA unique name for this target. �
"//python/pytest/private:pytest.bzlr�
/

rules_venvpython/pytest/private
pytest.bzlI
current_py_pytest_toolchain_current_py_pytest_toolchain
!
# current_py_pytest_toolchain�d
%

rules_venvpython/pytestdefs.bzl�current_py_pytest_toolchainAA rule for exposing the current registered `py_pytest_toolchain`."�
�
current_py_pytest_toolchainAA rule for exposing the current registered `py_pytest_toolchain`.*
nameA unique name for this target. "C
current_py_pytest_toolchain$@@rules_venv//python/pytest:defs.bzl
�#�#,
*
nameA unique name for this target. �py_pytest_toolchain�A toolchain for the [pytest](https://docs.pytest.org/en/stable/) rules.

The `pytest` attribute accepts a `py_library` target containing the pytest
package and any desired plugins. At minimum, the library must include `pytest`.
Additional dependencies unlock optional features:

- `pytest-cov` + `coverage`: Enables `bazel coverage` support.
- `pytest-xdist`: Enables parallel test execution via the `numprocesses` attribute.
- `pytest-shard`: Enables Bazel test sharding.

**Minimal example** (test-only, no coverage):

```python
load("@rules_venv//python:defs.bzl", "py_library")
load("@rules_venv//python/pytest:defs.bzl", "py_pytest_toolchain")

py_library(
    name = "pytest_lib",
    deps = ["@pip//pytest"],
)

py_pytest_toolchain(
    name = "pytest_toolchain",
    pytest = ":pytest_lib",
)

toolchain(
    name = "toolchain",
    toolchain = ":pytest_toolchain",
    toolchain_type = "@rules_venv//python/pytest:toolchain_type",
)
```

**Full example** (with coverage, xdist, and sharding):

```python
load("@rules_venv//python:defs.bzl", "py_library")
load("@rules_venv//python/pytest:defs.bzl", "py_pytest_toolchain")

py_library(
    name = "pytest_lib",
    deps = [
        "@pip//coverage",
        "@pip//pytest",
        "@pip//pytest_cov",
        "@pip//pytest_shard",
        "@pip//pytest_xdist",
    ],
)

py_pytest_toolchain(
    name = "pytest_toolchain",
    pytest = ":pytest_lib",
)

toolchain(
    name = "toolchain",
    toolchain = ":pytest_toolchain",
    toolchain_type = "@rules_venv//python/pytest:toolchain_type",
)
```
"�
�
py_pytest_toolchain�A toolchain for the [pytest](https://docs.pytest.org/en/stable/) rules.

The `pytest` attribute accepts a `py_library` target containing the pytest
package and any desired plugins. At minimum, the library must include `pytest`.
Additional dependencies unlock optional features:

- `pytest-cov` + `coverage`: Enables `bazel coverage` support.
- `pytest-xdist`: Enables parallel test execution via the `numprocesses` attribute.
- `pytest-shard`: Enables Bazel test sharding.

**Minimal example** (test-only, no coverage):

```python
load("@rules_venv//python:defs.bzl", "py_library")
load("@rules_venv//python/pytest:defs.bzl", "py_pytest_toolchain")

py_library(
    name = "pytest_lib",
    deps = ["@pip//pytest"],
)

py_pytest_toolchain(
    name = "pytest_toolchain",
    pytest = ":pytest_lib",
)

toolchain(
    name = "toolchain",
    toolchain = ":pytest_toolchain",
    toolchain_type = "@rules_venv//python/pytest:toolchain_type",
)
```

**Full example** (with coverage, xdist, and sharding):

```python
load("@rules_venv//python:defs.bzl", "py_library")
load("@rules_venv//python/pytest:defs.bzl", "py_pytest_toolchain")

py_library(
    name = "pytest_lib",
    deps = [
        "@pip//coverage",
        "@pip//pytest",
        "@pip//pytest_cov",
        "@pip//pytest_shard",
        "@pip//pytest_xdist",
    ],
)

py_pytest_toolchain(
    name = "pytest_toolchain",
    pytest = ":pytest_lib",
)

toolchain(
    name = "toolchain",
    toolchain = ":pytest_toolchain",
    toolchain_type = "@rules_venv//python/pytest:toolchain_type",
)
```
*
nameA unique name for this target. Y
pytestAA `py_library` target providing `pytest` and any desired plugins. *
PyInfo";
py_pytest_toolchain$@@rules_venv//python/pytest:defs.bzl
��,
*
nameA unique name for this target. [
Y
pytestAA `py_library` target providing `pytest` and any desired plugins. *
PyInfo�?py_pytest_test_suite�Generates a [test_suite][ts] which groups various test targets for a set of python sources.

Given an idiomatic python project structure:
```text
BUILD.bazel
my_lib/
    __init__.py
    mod_a.py
    mod_b.py
    mod_c.py
requirements.in
requirements.txt
tests/
    __init__.py
    fixtures.py
    test_mod_a.py
    test_mod_b.py
    test_mod_c.py
```

This rule can be used to easily define test targets:

```python
load("@rules_venv//python:defs.bzl", "py_library")
load("@rules_venv//python/pytest:defs.bzl", "py_pytest_test_suite")

py_library(
    name = "my_lib",
    srcs = glob(["my_lib/**/*.py"])
    imports = ["."],
)

py_pytest_test_suite(
    name = "my_lib_test_suite",
    # Source files containing test helpers should go here.
    # Note that the test sources are excluded. This avoids
    # a test to be updated without invalidating all other
    # targets.
    srcs = glob(
        include = ["tests/**/*.py"],
        exclude = ["tests/**/*_test.py"],
    ),
    # Any data files the tests may need would be passed here
    data = glob(["tests/**/*.json"]),
    # This field is used for dedicated test files.
    tests = glob(["tests/**/*_test.py"]),
    deps = [
        ":my_lib",
    ],
)
```

For each file passed to `tests`, a [py_pytest_test](#py_pytest_test) target will be created. From the example above,
the user should expect to see the following test targets:
```text
//:my_lib_test_suite
//:tests/test_mod_a
//:tests/test_mod_b
//:tests/test_mod_c
```

Additional Notes:
- No file passed to `tests` should be passed found in the `srcs` or `data` attributes or tests will not be able
    to be individually cached.

[pt]: https://docs.bazel.build/versions/master/be/python.html#py_test
[ts]: https://docs.bazel.build/versions/master/be/general.html#test_suite


A rule which runs python tests using [pytest][pt] as the [py_test][bpt] test runner.

This rule also supports a build setting for globally applying extra flags to test invocations.
Users can add something similar to the following to their `.bazelrc` files:

```text
build --@rules_venv//python/pytest:extra_args=--color=yes,-vv
```

The example above will add `--colors=yes` and `-vv` arguments to the end of the pytest invocation.

Tips:

- It's common for tests to have some utility code that does not live in a test source file.
To account for this. A `py_library` can be created that contains only these sources which are then
passed to `py_pytest_test` via `deps`.

```python
load("@rules_venv//python:defs.bzl", "py_library")
load("@rules_venv//python/pytest:defs.bzl", "py_pytest_test")

py_library(
    name = "test_utils",
    srcs = [
        "tests/__init__.py",
        "tests/conftest.py",
    ],
    deps = ["@rules_venv//python/pytest:current_py_pytest_toolchain"],
    testonly = True,
)

py_pytest_test(
    name = "test",
    srcs = ["tests/example_test.py"],
    deps = [":test_utils"],
)
```

[pt]: https://docs.pytest.org/en/latest/
[bpt]: https://docs.bazel.build/versions/master/be/python.html#py_test
[ptx]: https://pypi.org/project/pytest-xdist/
"�'
�
py_pytest_test_suite�Generates a [test_suite][ts] which groups various test targets for a set of python sources.

Given an idiomatic python project structure:
```text
BUILD.bazel
my_lib/
    __init__.py
    mod_a.py
    mod_b.py
    mod_c.py
requirements.in
requirements.txt
tests/
    __init__.py
    fixtures.py
    test_mod_a.py
    test_mod_b.py
    test_mod_c.py
```

This rule can be used to easily define test targets:

```python
load("@rules_venv//python:defs.bzl", "py_library")
load("@rules_venv//python/pytest:defs.bzl", "py_pytest_test_suite")

py_library(
    name = "my_lib",
    srcs = glob(["my_lib/**/*.py"])
    imports = ["."],
)

py_pytest_test_suite(
    name = "my_lib_test_suite",
    # Source files containing test helpers should go here.
    # Note that the test sources are excluded. This avoids
    # a test to be updated without invalidating all other
    # targets.
    srcs = glob(
        include = ["tests/**/*.py"],
        exclude = ["tests/**/*_test.py"],
    ),
    # Any data files the tests may need would be passed here
    data = glob(["tests/**/*.json"]),
    # This field is used for dedicated test files.
    tests = glob(["tests/**/*_test.py"]),
    deps = [
        ":my_lib",
    ],
)
```

For each file passed to `tests`, a [py_pytest_test](#py_pytest_test) target will be created. From the example above,
the user should expect to see the following test targets:
```text
//:my_lib_test_suite
//:tests/test_mod_a
//:tests/test_mod_b
//:tests/test_mod_c
```

Additional Notes:
- No file passed to `tests` should be passed found in the `srcs` or `data` attributes or tests will not be able
    to be individually cached.

[pt]: https://docs.bazel.build/versions/master/be/python.html#py_test
[ts]: https://docs.bazel.build/versions/master/be/general.html#test_suite


A rule which runs python tests using [pytest][pt] as the [py_test][bpt] test runner.

This rule also supports a build setting for globally applying extra flags to test invocations.
Users can add something similar to the following to their `.bazelrc` files:

```text
build --@rules_venv//python/pytest:extra_args=--color=yes,-vv
```

The example above will add `--colors=yes` and `-vv` arguments to the end of the pytest invocation.

Tips:

- It's common for tests to have some utility code that does not live in a test source file.
To account for this. A `py_library` can be created that contains only these sources which are then
passed to `py_pytest_test` via `deps`.

```python
load("@rules_venv//python:defs.bzl", "py_library")
load("@rules_venv//python/pytest:defs.bzl", "py_pytest_test")

py_library(
    name = "test_utils",
    srcs = [
        "tests/__init__.py",
        "tests/conftest.py",
    ],
    deps = ["@rules_venv//python/pytest:current_py_pytest_toolchain"],
    testonly = True,
)

py_pytest_test(
    name = "test",
    srcs = ["tests/example_test.py"],
    deps = [":test_utils"],
)
```

[pt]: https://docs.pytest.org/en/latest/
[bpt]: https://docs.bazel.build/versions/master/be/python.html#py_test
[ptx]: https://pypi.org/project/pytest-xdist/
*
nameA unique name for this target. I
config%The pytest configuration file to use.2//python/pytest:configW
coverage_rc)The pytest-cov configuration file to use.2//python/pytest:coverage_rco
dataaFiles needed by this rule at runtime. May list file or rule targets. Generally allows any target.2[]Y
depsAThe list of other libraries to be linked in to the binary target.*
PyInfo2[]h
env[Dictionary of strings; values are subject to `$(location)` and "Make variable" substitution
2{}�
env_inherit~Specifies additional environment variables to inherit from the external environment when the test is executed by `bazel test`.2[]�
numprocesses�If set the [pytest-xdist](https://pypi.org/project/pytest-xdist/) argument `--numprocesses` (`-n`) will be passed to the test. Note that the a value 0 or less indicates this flag should not be passed.207
srcs)An explicit list of source files to test.2[]
��,
*
nameA unique name for this target. K
I
config%The pytest configuration file to use.2//python/pytest:configY
W
coverage_rc)The pytest-cov configuration file to use.2//python/pytest:coverage_rcq
o
dataaFiles needed by this rule at runtime. May list file or rule targets. Generally allows any target.2[][
Y
depsAThe list of other libraries to be linked in to the binary target.*
PyInfo2[]j
h
env[Dictionary of strings; values are subject to `$(location)` and "Make variable" substitution
2{}�
�
env_inherit~Specifies additional environment variables to inherit from the external environment when the test is executed by `bazel test`.2[]�
�
numprocesses�If set the [pytest-xdist](https://pypi.org/project/pytest-xdist/) argument `--numprocesses` (`-n`) will be passed to the test. Note that the a value 0 or less indicates this flag should not be passed.209
7
srcs)An explicit list of source files to test.2[]�
///python/pytest:current_py_pytest_toolchain.bzlr�
<

rules_venvpython/pytestcurrent_py_pytest_toolchain.bzlI
current_py_pytest_toolchain_current_py_pytest_toolchain
!
	�
"//python/pytest:py_pytest_test.bzlrp
/

rules_venvpython/pytestpy_pytest_test.bzl/
py_pytest_test_py_pytest_test


�
(//python/pytest:py_pytest_test_suite.bzlr�
5

rules_venvpython/pytestpy_pytest_test_suite.bzl;
py_pytest_test_suite_py_pytest_test_suite

�
'//python/pytest:py_pytest_toolchain.bzlr
4

rules_venvpython/pytestpy_pytest_toolchain.bzl9
py_pytest_toolchain_py_pytest_toolchain

b# Pytest

Bazel rules for the python test framework [Pytest](https://docs.pytest.org/en/stable/).
�A
5

rules_venvpython/pytestpy_pytest_test_suite.bzl�?py_pytest_test_suite�Generates a [test_suite][ts] which groups various test targets for a set of python sources.

Given an idiomatic python project structure:
```text
BUILD.bazel
my_lib/
    __init__.py
    mod_a.py
    mod_b.py
    mod_c.py
requirements.in
requirements.txt
tests/
    __init__.py
    fixtures.py
    test_mod_a.py
    test_mod_b.py
    test_mod_c.py
```

This rule can be used to easily define test targets:

```python
load("@rules_venv//python:defs.bzl", "py_library")
load("@rules_venv//python/pytest:defs.bzl", "py_pytest_test_suite")

py_library(
    name = "my_lib",
    srcs = glob(["my_lib/**/*.py"])
    imports = ["."],
)

py_pytest_test_suite(
    name = "my_lib_test_suite",
    # Source files containing test helpers should go here.
    # Note that the test sources are excluded. This avoids
    # a test to be updated without invalidating all other
    # targets.
    srcs = glob(
        include = ["tests/**/*.py"],
        exclude = ["tests/**/*_test.py"],
    ),
    # Any data files the tests may need would be passed here
    data = glob(["tests/**/*.json"]),
    # This field is used for dedicated test files.
    tests = glob(["tests/**/*_test.py"]),
    deps = [
        ":my_lib",
    ],
)
```

For each file passed to `tests`, a [py_pytest_test](#py_pytest_test) target will be created. From the example above,
the user should expect to see the following test targets:
```text
//:my_lib_test_suite
//:tests/test_mod_a
//:tests/test_mod_b
//:tests/test_mod_c
```

Additional Notes:
- No file passed to `tests` should be passed found in the `srcs` or `data` attributes or tests will not be able
    to be individually cached.

[pt]: https://docs.bazel.build/versions/master/be/python.html#py_test
[ts]: https://docs.bazel.build/versions/master/be/general.html#test_suite


A rule which runs python tests using [pytest][pt] as the [py_test][bpt] test runner.

This rule also supports a build setting for globally applying extra flags to test invocations.
Users can add something similar to the following to their `.bazelrc` files:

```text
build --@rules_venv//python/pytest:extra_args=--color=yes,-vv
```

The example above will add `--colors=yes` and `-vv` arguments to the end of the pytest invocation.

Tips:

- It's common for tests to have some utility code that does not live in a test source file.
To account for this. A `py_library` can be created that contains only these sources which are then
passed to `py_pytest_test` via `deps`.

```python
load("@rules_venv//python:defs.bzl", "py_library")
load("@rules_venv//python/pytest:defs.bzl", "py_pytest_test")

py_library(
    name = "test_utils",
    srcs = [
        "tests/__init__.py",
        "tests/conftest.py",
    ],
    deps = ["@rules_venv//python/pytest:current_py_pytest_toolchain"],
    testonly = True,
)

py_pytest_test(
    name = "test",
    srcs = ["tests/example_test.py"],
    deps = [":test_utils"],
)
```

[pt]: https://docs.pytest.org/en/latest/
[bpt]: https://docs.bazel.build/versions/master/be/python.html#py_test
[ptx]: https://pypi.org/project/pytest-xdist/
"�'
�
py_pytest_test_suite�Generates a [test_suite][ts] which groups various test targets for a set of python sources.

Given an idiomatic python project structure:
```text
BUILD.bazel
my_lib/
    __init__.py
    mod_a.py
    mod_b.py
    mod_c.py
requirements.in
requirements.txt
tests/
    __init__.py
    fixtures.py
    test_mod_a.py
    test_mod_b.py
    test_mod_c.py
```

This rule can be used to easily define test targets:

```python
load("@rules_venv//python:defs.bzl", "py_library")
load("@rules_venv//python/pytest:defs.bzl", "py_pytest_test_suite")

py_library(
    name = "my_lib",
    srcs = glob(["my_lib/**/*.py"])
    imports = ["."],
)

py_pytest_test_suite(
    name = "my_lib_test_suite",
    # Source files containing test helpers should go here.
    # Note that the test sources are excluded. This avoids
    # a test to be updated without invalidating all other
    # targets.
    srcs = glob(
        include = ["tests/**/*.py"],
        exclude = ["tests/**/*_test.py"],
    ),
    # Any data files the tests may need would be passed here
    data = glob(["tests/**/*.json"]),
    # This field is used for dedicated test files.
    tests = glob(["tests/**/*_test.py"]),
    deps = [
        ":my_lib",
    ],
)
```

For each file passed to `tests`, a [py_pytest_test](#py_pytest_test) target will be created. From the example above,
the user should expect to see the following test targets:
```text
//:my_lib_test_suite
//:tests/test_mod_a
//:tests/test_mod_b
//:tests/test_mod_c
```

Additional Notes:
- No file passed to `tests` should be passed found in the `srcs` or `data` attributes or tests will not be able
    to be individually cached.

[pt]: https://docs.bazel.build/versions/master/be/python.html#py_test
[ts]: https://docs.bazel.build/versions/master/be/general.html#test_suite


A rule which runs python tests using [pytest][pt] as the [py_test][bpt] test runner.

This rule also supports a build setting for globally applying extra flags to test invocations.
Users can add something similar to the following to their `.bazelrc` files:

```text
build --@rules_venv//python/pytest:extra_args=--color=yes,-vv
```

The example above will add `--colors=yes` and `-vv` arguments to the end of the pytest invocation.

Tips:

- It's common for tests to have some utility code that does not live in a test source file.
To account for this. A `py_library` can be created that contains only these sources which are then
passed to `py_pytest_test` via `deps`.

```python
load("@rules_venv//python:defs.bzl", "py_library")
load("@rules_venv//python/pytest:defs.bzl", "py_pytest_test")

py_library(
    name = "test_utils",
    srcs = [
        "tests/__init__.py",
        "tests/conftest.py",
    ],
    deps = ["@rules_venv//python/pytest:current_py_pytest_toolchain"],
    testonly = True,
)

py_pytest_test(
    name = "test",
    srcs = ["tests/example_test.py"],
    deps = [":test_utils"],
)
```

[pt]: https://docs.pytest.org/en/latest/
[bpt]: https://docs.bazel.build/versions/master/be/python.html#py_test
[ptx]: https://pypi.org/project/pytest-xdist/
*
nameA unique name for this target. I
config%The pytest configuration file to use.2//python/pytest:configW
coverage_rc)The pytest-cov configuration file to use.2//python/pytest:coverage_rco
dataaFiles needed by this rule at runtime. May list file or rule targets. Generally allows any target.2[]Y
depsAThe list of other libraries to be linked in to the binary target.*
PyInfo2[]h
env[Dictionary of strings; values are subject to `$(location)` and "Make variable" substitution
2{}�
env_inherit~Specifies additional environment variables to inherit from the external environment when the test is executed by `bazel test`.2[]�
numprocesses�If set the [pytest-xdist](https://pypi.org/project/pytest-xdist/) argument `--numprocesses` (`-n`) will be passed to the test. Note that the a value 0 or less indicates this flag should not be passed.207
srcs)An explicit list of source files to test.2[]
��,
*
nameA unique name for this target. K
I
config%The pytest configuration file to use.2//python/pytest:configY
W
coverage_rc)The pytest-cov configuration file to use.2//python/pytest:coverage_rcq
o
dataaFiles needed by this rule at runtime. May list file or rule targets. Generally allows any target.2[][
Y
depsAThe list of other libraries to be linked in to the binary target.*
PyInfo2[]j
h
env[Dictionary of strings; values are subject to `$(location)` and "Make variable" substitution
2{}�
�
env_inherit~Specifies additional environment variables to inherit from the external environment when the test is executed by `bazel test`.2[]�
�
numprocesses�If set the [pytest-xdist](https://pypi.org/project/pytest-xdist/) argument `--numprocesses` (`-n`) will be passed to the test. Note that the a value 0 or less indicates this flag should not be passed.209
7
srcs)An explicit list of source files to test.2[]�
"//python/pytest/private:pytest.bzlr|
/

rules_venvpython/pytest/private
pytest.bzl;
py_pytest_test_suite_py_pytest_test_suite

# py_pytest_test_suite�
4

rules_venvpython/pytestpy_pytest_toolchain.bzl�py_pytest_toolchain�A toolchain for the [pytest](https://docs.pytest.org/en/stable/) rules.

The `pytest` attribute accepts a `py_library` target containing the pytest
package and any desired plugins. At minimum, the library must include `pytest`.
Additional dependencies unlock optional features:

- `pytest-cov` + `coverage`: Enables `bazel coverage` support.
- `pytest-xdist`: Enables parallel test execution via the `numprocesses` attribute.
- `pytest-shard`: Enables Bazel test sharding.

**Minimal example** (test-only, no coverage):

```python
load("@rules_venv//python:defs.bzl", "py_library")
load("@rules_venv//python/pytest:defs.bzl", "py_pytest_toolchain")

py_library(
    name = "pytest_lib",
    deps = ["@pip//pytest"],
)

py_pytest_toolchain(
    name = "pytest_toolchain",
    pytest = ":pytest_lib",
)

toolchain(
    name = "toolchain",
    toolchain = ":pytest_toolchain",
    toolchain_type = "@rules_venv//python/pytest:toolchain_type",
)
```

**Full example** (with coverage, xdist, and sharding):

```python
load("@rules_venv//python:defs.bzl", "py_library")
load("@rules_venv//python/pytest:defs.bzl", "py_pytest_toolchain")

py_library(
    name = "pytest_lib",
    deps = [
        "@pip//coverage",
        "@pip//pytest",
        "@pip//pytest_cov",
        "@pip//pytest_shard",
        "@pip//pytest_xdist",
    ],
)

py_pytest_toolchain(
    name = "pytest_toolchain",
    pytest = ":pytest_lib",
)

toolchain(
    name = "toolchain",
    toolchain = ":pytest_toolchain",
    toolchain_type = "@rules_venv//python/pytest:toolchain_type",
)
```
"�
�
py_pytest_toolchain�A toolchain for the [pytest](https://docs.pytest.org/en/stable/) rules.

The `pytest` attribute accepts a `py_library` target containing the pytest
package and any desired plugins. At minimum, the library must include `pytest`.
Additional dependencies unlock optional features:

- `pytest-cov` + `coverage`: Enables `bazel coverage` support.
- `pytest-xdist`: Enables parallel test execution via the `numprocesses` attribute.
- `pytest-shard`: Enables Bazel test sharding.

**Minimal example** (test-only, no coverage):

```python
load("@rules_venv//python:defs.bzl", "py_library")
load("@rules_venv//python/pytest:defs.bzl", "py_pytest_toolchain")

py_library(
    name = "pytest_lib",
    deps = ["@pip//pytest"],
)

py_pytest_toolchain(
    name = "pytest_toolchain",
    pytest = ":pytest_lib",
)

toolchain(
    name = "toolchain",
    toolchain = ":pytest_toolchain",
    toolchain_type = "@rules_venv//python/pytest:toolchain_type",
)
```

**Full example** (with coverage, xdist, and sharding):

```python
load("@rules_venv//python:defs.bzl", "py_library")
load("@rules_venv//python/pytest:defs.bzl", "py_pytest_toolchain")

py_library(
    name = "pytest_lib",
    deps = [
        "@pip//coverage",
        "@pip//pytest",
        "@pip//pytest_cov",
        "@pip//pytest_shard",
        "@pip//pytest_xdist",
    ],
)

py_pytest_toolchain(
    name = "pytest_toolchain",
    pytest = ":pytest_lib",
)

toolchain(
    name = "toolchain",
    toolchain = ":pytest_toolchain",
    toolchain_type = "@rules_venv//python/pytest:toolchain_type",
)
```
*
nameA unique name for this target. Y
pytestAA `py_library` target providing `pytest` and any desired plugins. *
PyInfo"J
py_pytest_toolchain3@@rules_venv//python/pytest:py_pytest_toolchain.bzl
��,
*
nameA unique name for this target. [
Y
pytestAA `py_library` target providing `pytest` and any desired plugins. *
PyInfo�
"//python/pytest/private:pytest.bzlrz
/

rules_venvpython/pytest/private
pytest.bzl9
py_pytest_toolchain_py_pytest_toolchain

# py_pytest_toolchain�
8

rules_venvpython/ruff/privatepy_ruff_mode_flag.bzl�py_ruff_mode_flagEA string list-typed build setting that can be set on the command line"�
�
py_ruff_mode_flagEA string list-typed build setting that can be set on the command line*
nameA unique name for this target. I
scope1The scope indicates where a flag can propagate to2"universal"l
values\The list of allowed values for this setting. An error is raised if any other value is given.2[]"L
py_ruff_mode_flag7@@rules_venv//python/ruff/private:py_ruff_mode_flag.bzl
,
*
nameA unique name for this target. K
I
scope1The scope indicates where a flag can propagate to2"universal"n
l
values\The list of allowed values for this setting. An error is raised if any other value is given.2[]�
//rules:common_settings.bzlrn
*
bazel_skylibrulescommon_settings.bzl2
BuildSettingInfoBuildSettingInfo
3C
Epy_ruff_mode_flag�
+

rules_venvpython/ruff/privateruff.bzl�py_ruff_check_test3A rule for running `ruff check` on a Python target."�
�
py_ruff_check_test3A rule for running `ruff check` on a Python target.*
nameA unique name for this target. W
config5The config file (ruff.toml) containing ruff settings.2//python/ruff:config4
targetThe target to run `ruff` on. *
PyInfo"@
py_ruff_check_test*@@rules_venv//python/ruff/private:ruff.bzl
__,
*
nameA unique name for this target. Y
W
config5The config file (ruff.toml) containing ruff settings.2//python/ruff:config6
4
targetThe target to run `ruff` on. *
PyInfo�py_ruff_format_test4A rule for running `ruff format` on a Python target."�
�
py_ruff_format_test4A rule for running `ruff format` on a Python target.*
nameA unique name for this target. W
config5The config file (ruff.toml) containing ruff settings.2//python/ruff:config4
targetThe target to run `ruff` on. *
PyInfo"A
py_ruff_format_test*@@rules_venv//python/ruff/private:ruff.bzl
mm,
*
nameA unique name for this target. Y
W
config5The config file (ruff.toml) containing ruff settings.2//python/ruff:config6
4
targetThe target to run `ruff` on. *
PyInfo�py_ruff_aspect�An aspect for running ruff on targets with Python sources.

This aspect can be configured by adding the following snippet to a workspace's `.bazelrc` file:

```text
build --aspects=@rules_venv//python/ruff:py_ruff_aspect.bzl%py_ruff_aspect
build --output_groups=+py_ruff_checks
```
:�
�
py_ruff_aspect�An aspect for running ruff on targets with Python sources.

This aspect can be configured by adding the following snippet to a workspace's `.bazelrc` file:

```text
build --aspects=@rules_venv//python/ruff:py_ruff_aspect.bzl%py_ruff_aspect
build --output_groups=+py_ruff_checks
```
"*
nameA unique name for this target. *<
py_ruff_aspect*@@rules_venv//python/ruff/private:ruff.bzl
��,
*
nameA unique name for this target. �
//rules:common_settings.bzlrn
*
bazel_skylibrulescommon_settings.bzl2
BuildSettingInfoBuildSettingInfo
3C
Ek
//python:py_info.bzlrQ
!

rules_venvpythonpy_info.bzl
PyInfoPyInfo
*0
2�
 //python/private:target_srcs.bzlr�
-

rules_venvpython/privatetarget_srcs.bzl$
	find_srcs	find_srcs
6?<
target_sources_aspecttarget_sources_aspect
CX
Z�
(//python/ruff/private:ruff_toolchain.bzlr�
5

rules_venvpython/ruff/privateruff_toolchain.bzl.
TOOLCHAIN_TYPETOOLCHAIN_TYPE
>L,
rlocationpathrlocationpath
P]
_
//python/venv:defs.bzlrc
#

rules_venvpython/venvdefs.bzl.
py_venv_commonpy_venv_common
,:
<Bazel rules for ruff�
5

rules_venvpython/ruff/privateruff_toolchain.bzl�current_py_ruff_toolchain?A rule for exposing the current registered `py_ruff_toolchain`."�
�
current_py_ruff_toolchain?A rule for exposing the current registered `py_ruff_toolchain`.*
nameA unique name for this target. "Q
current_py_ruff_toolchain4@@rules_venv//python/ruff/private:ruff_toolchain.bzl
�!�!,
*
nameA unique name for this target. �py_ruff_toolchainTA toolchain for the [ruff](https://docs.astral.sh/ruff/) linter and formatter rules."�
�
py_ruff_toolchainTA toolchain for the [ruff](https://docs.astral.sh/ruff/) linter and formatter rules.*
nameA unique name for this target. ?
ruff%The ruff `py_library` with the rules.*
PyInfo2None:
ruff_bin&A `ruff` binary to use with the rules.2None"I
py_ruff_toolchain4@@rules_venv//python/ruff/private:ruff_toolchain.bzl
QQ,
*
nameA unique name for this target. A
?
ruff%The ruff `py_library` with the rules.*
PyInfo2None<
:
ruff_bin&A `ruff` binary to use with the rules.2None�rlocationpath*�
x
rlocationpath

file (
workspace_name (2E
rlocationpath4@@rules_venv//python/ruff/private:ruff_toolchain.bzl
k
//python:py_info.bzlrQ
!

rules_venvpythonpy_info.bzl
PyInfoPyInfo
*0
2T	TOOLCHAIN_TYPE@@//python/ruff:toolchain_typej @@//python/ruff:toolchain_typeruff toolchain rules.�%
#

rules_venvpython/ruffdefs.bzl�py_ruff_toolchainTA toolchain for the [ruff](https://docs.astral.sh/ruff/) linter and formatter rules."�
�
py_ruff_toolchainTA toolchain for the [ruff](https://docs.astral.sh/ruff/) linter and formatter rules.*
nameA unique name for this target. ?
ruff%The ruff `py_library` with the rules.*
PyInfo2None:
ruff_bin&A `ruff` binary to use with the rules.2None"7
py_ruff_toolchain"@@rules_venv//python/ruff:defs.bzl
QQ,
*
nameA unique name for this target. A
?
ruff%The ruff `py_library` with the rules.*
PyInfo2None<
:
ruff_bin&A `ruff` binary to use with the rules.2None�py_ruff_aspect�An aspect for running ruff on targets with Python sources.

This aspect can be configured by adding the following snippet to a workspace's `.bazelrc` file:

```text
build --aspects=@rules_venv//python/ruff:py_ruff_aspect.bzl%py_ruff_aspect
build --output_groups=+py_ruff_checks
```
:�
�
py_ruff_aspect�An aspect for running ruff on targets with Python sources.

This aspect can be configured by adding the following snippet to a workspace's `.bazelrc` file:

```text
build --aspects=@rules_venv//python/ruff:py_ruff_aspect.bzl%py_ruff_aspect
build --output_groups=+py_ruff_checks
```
"*
nameA unique name for this target. *4
py_ruff_aspect"@@rules_venv//python/ruff:defs.bzl
��,
*
nameA unique name for this target. �
 //python/ruff:py_ruff_aspect.bzlrn
-

rules_venvpython/ruffpy_ruff_aspect.bzl/
py_ruff_aspect_py_ruff_aspect
RR
PS�
$//python/ruff:py_ruff_check_test.bzlrz
1

rules_venvpython/ruffpy_ruff_check_test.bzl7
py_ruff_check_test_py_ruff_check_test
VV
TW�
%//python/ruff:py_ruff_format_test.bzlr}
2

rules_venvpython/ruffpy_ruff_format_test.bzl9
py_ruff_format_test_py_ruff_format_test
ZZ
X[�
//python/ruff:py_ruff_test.bzlrh
+

rules_venvpython/ruffpy_ruff_test.bzl+
py_ruff_test_py_ruff_test
^^
\_�
#//python/ruff:py_ruff_toolchain.bzlrw
0

rules_venvpython/ruffpy_ruff_toolchain.bzl5
py_ruff_toolchain_py_ruff_toolchain
bb
`c�# ruff

Bazel rules for the Python linter [ruff][rf].

### Setup

First ensure `rules_venv` is setup by referring to [rules_venv setup](../index.md#setup).

Next, the `ruff` rules work mostly off of toolchains which are used to provide the necessary python targets (aka `ruff`)
for the process wrappers. Users will want to make sure they have a way to get the necessary python dependencies. Tools such as
[req-compile](https://github.com/periareon/req-compile) can provide these.

With the appropriate dependencies available, a [py_ruff_toolchain](#py_ruff_toolchain) will need to be configured.
The toolchain accepts either `ruff` (a `py_library`, e.g. from pip) or `ruff_bin` (an executable); the two are mutually exclusive.

```python
load("@rules_venv//python/ruff:defs.bzl", "py_ruff_toolchain")

py_ruff_toolchain(
    name = "toolchain_impl",
    ruff = "@pip_deps//ruff",
    visibility = ["//visibility:public"]
)

toolchain(
    name = "toolchain",
    toolchain = ":toolchain_impl",
    toolchain_type = "@rules_venv//python/ruff:toolchain_type",
    visibility = ["//visibility:public"]
)
```

This toolchain then needs to be registered in the `MODULE.bazel` file.

```python
register_toolchains("//tools/python/ruff:toolchain")
```

From here, [py_ruff_test](#py_ruff_test) and the [py_ruff_aspect](#py_ruff_aspect)
should now be usable. [py_ruff_test](#py_ruff_test) is a convenience that creates a test suite running both
[py_ruff_check_test](#py_ruff_check_test) and [py_ruff_format_test](#py_ruff_format_test). Both the test rules and the aspect
use a global flag to determine which ruff configuration file to use in actions. The default config is
`//python/ruff:ruff.toml`; the chosen file must be a valid label (e.g. `ruff.toml` or `pyproject.toml`).
Add the following to `.bazelrc` to choose a different configuration file:

```text
build --@rules_venv//python/ruff:config=//:.ruffrc.toml
```

To use the aspect, you must also enable it and request its output group in `.bazelrc`:

```text
build --aspects=@rules_venv//python/ruff:py_ruff_aspect.bzl%py_ruff_aspect
build --output_groups=+py_ruff_checks
```

Test rules can override the config per target via the `config` attribute (they default to the label flag above).


### Usage

Python code can be formatted using:

```bash
bazel run @rules_venv//python/ruff:format
```

Lint issues that support auto-fix can be applied using:

```bash
bazel run @rules_venv//python/ruff:fix
```

Both commands accept optional Bazel scope arguments (e.g. `//...` or `//some/package:all`); the default is `//...:all`.


[rf]: https://docs.astral.sh/ruff/
�
-

rules_venvpython/ruffpy_ruff_aspect.bzl�py_ruff_aspect�An aspect for running ruff on targets with Python sources.

This aspect can be configured by adding the following snippet to a workspace's `.bazelrc` file:

```text
build --aspects=@rules_venv//python/ruff:py_ruff_aspect.bzl%py_ruff_aspect
build --output_groups=+py_ruff_checks
```
:�
�
py_ruff_aspect�An aspect for running ruff on targets with Python sources.

This aspect can be configured by adding the following snippet to a workspace's `.bazelrc` file:

```text
build --aspects=@rules_venv//python/ruff:py_ruff_aspect.bzl%py_ruff_aspect
build --output_groups=+py_ruff_checks
```
"*
nameA unique name for this target. *>
py_ruff_aspect,@@rules_venv//python/ruff:py_ruff_aspect.bzl
��,
*
nameA unique name for this target. �
//python/ruff/private:ruff.bzlrl
+

rules_venvpython/ruff/privateruff.bzl/
py_ruff_aspect_py_ruff_aspect

# py_ruff_aspect�
0

rules_venvpython/ruffpy_ruff_toolchain.bzl�py_ruff_toolchainTA toolchain for the [ruff](https://docs.astral.sh/ruff/) linter and formatter rules."�
�
py_ruff_toolchainTA toolchain for the [ruff](https://docs.astral.sh/ruff/) linter and formatter rules.*
nameA unique name for this target. ?
ruff%The ruff `py_library` with the rules.*
PyInfo2None:
ruff_bin&A `ruff` binary to use with the rules.2None"D
py_ruff_toolchain/@@rules_venv//python/ruff:py_ruff_toolchain.bzl
QQ,
*
nameA unique name for this target. A
?
ruff%The ruff `py_library` with the rules.*
PyInfo2None<
:
ruff_bin&A `ruff` binary to use with the rules.2None�
(//python/ruff/private:ruff_toolchain.bzlr|
5

rules_venvpython/ruff/privateruff_toolchain.bzl5
py_ruff_toolchain_py_ruff_toolchain

# py_ruff_toolchain�
'

rules_venvpython/ty/privatety.bzl�
py_ty_test1A rule for running `ty check` on a Python target."�
�

py_ty_test1A rule for running `ty check` on a Python target.*
nameA unique name for this target. S
config3The config file (`ty.toml`) containing ty settings.2//python/ty:config2
targetThe target to run `ty` on. *
PyInfo"4

py_ty_test&@@rules_venv//python/ty/private:ty.bzl
@@,
*
nameA unique name for this target. U
S
config3The config file (`ty.toml`) containing ty settings.2//python/ty:config4
2
targetThe target to run `ty` on. *
PyInfo�py_ty_aspect�An aspect for running ty on targets with Python sources.

This aspect can be configured by adding the following snippet to a workspace's `.bazelrc` file:

```text
build --aspects=@rules_venv//python/ty:py_ty_aspect.bzl%py_ty_aspect
build --output_groups=+py_ty_checks
```
:�
�
py_ty_aspect�An aspect for running ty on targets with Python sources.

This aspect can be configured by adding the following snippet to a workspace's `.bazelrc` file:

```text
build --aspects=@rules_venv//python/ty:py_ty_aspect.bzl%py_ty_aspect
build --output_groups=+py_ty_checks
```
"*
nameA unique name for this target. *6
py_ty_aspect&@@rules_venv//python/ty/private:ty.bzl
��,
*
nameA unique name for this target. k
//python:py_info.bzlrQ
!

rules_venvpythonpy_info.bzl
PyInfoPyInfo
*0
2�
 //python/private:target_srcs.bzlr�
-

rules_venvpython/privatetarget_srcs.bzl$
	find_srcs	find_srcs
6?<
target_sources_aspecttarget_sources_aspect
CX
Z�
$//python/ty/private:ty_toolchain.bzlr�
1

rules_venvpython/ty/privatety_toolchain.bzl.
TOOLCHAIN_TYPETOOLCHAIN_TYPE
:H,
rlocationpathrlocationpath
LY
[
//python/venv:defs.bzlrc
#

rules_venvpython/venvdefs.bzl.
py_venv_commonpy_venv_common
,:
<Bazel rules for ty�

1

rules_venvpython/ty/privatety_toolchain.bzl�current_py_ty_toolchain=A rule for exposing the current registered `py_ty_toolchain`."�
�
current_py_ty_toolchain=A rule for exposing the current registered `py_ty_toolchain`.*
nameA unique name for this target. "K
current_py_ty_toolchain0@@rules_venv//python/ty/private:ty_toolchain.bzl
}},
*
nameA unique name for this target. �py_ty_toolchainHA toolchain for the [ty](https://docs.astral.sh/ty/) type checker rules."�
�
py_ty_toolchainHA toolchain for the [ty](https://docs.astral.sh/ty/) type checker rules.*
nameA unique name for this target. B
ty*The ty `py_library` to use with the rules.*
PyInfo2None6
ty_bin$A `ty` binary to use with the rules.2None"C
py_ty_toolchain0@@rules_venv//python/ty/private:ty_toolchain.bzl
QQ,
*
nameA unique name for this target. D
B
ty*The ty `py_library` to use with the rules.*
PyInfo2None8
6
ty_bin$A `ty` binary to use with the rules.2None�rlocationpath*�
t
rlocationpath

file (
workspace_name (2A
rlocationpath0@@rules_venv//python/ty/private:ty_toolchain.bzl
k
//python:py_info.bzlrQ
!

rules_venvpythonpy_info.bzl
PyInfoPyInfo
*0
2P	TOOLCHAIN_TYPE@@//python/ty:toolchain_typej@@//python/ty:toolchain_typety toolchain rules.�
!

rules_venv	python/tydefs.bzl�py_ty_toolchainHA toolchain for the [ty](https://docs.astral.sh/ty/) type checker rules."�
�
py_ty_toolchainHA toolchain for the [ty](https://docs.astral.sh/ty/) type checker rules.*
nameA unique name for this target. B
ty*The ty `py_library` to use with the rules.*
PyInfo2None6
ty_bin$A `ty` binary to use with the rules.2None"3
py_ty_toolchain @@rules_venv//python/ty:defs.bzl
QQ,
*
nameA unique name for this target. D
B
ty*The ty `py_library` to use with the rules.*
PyInfo2None8
6
ty_bin$A `ty` binary to use with the rules.2None�py_ty_aspect�An aspect for running ty on targets with Python sources.

This aspect can be configured by adding the following snippet to a workspace's `.bazelrc` file:

```text
build --aspects=@rules_venv//python/ty:py_ty_aspect.bzl%py_ty_aspect
build --output_groups=+py_ty_checks
```
:�
�
py_ty_aspect�An aspect for running ty on targets with Python sources.

This aspect can be configured by adding the following snippet to a workspace's `.bazelrc` file:

```text
build --aspects=@rules_venv//python/ty:py_ty_aspect.bzl%py_ty_aspect
build --output_groups=+py_ty_checks
```
"*
nameA unique name for this target. *0
py_ty_aspect @@rules_venv//python/ty:defs.bzl
��,
*
nameA unique name for this target. �
//python/ty:py_ty_aspect.bzlrf
)

rules_venv	python/typy_ty_aspect.bzl+
py_ty_aspect_py_ty_aspect
@@
>A�
//python/ty:py_ty_test.bzlr`
'

rules_venv	python/typy_ty_test.bzl'

py_ty_test_py_ty_test
DD
BE�
//python/ty:py_ty_toolchain.bzlro
,

rules_venv	python/typy_ty_toolchain.bzl1
py_ty_toolchain_py_ty_toolchain
HH
FI�# ty

Bazel rules for the Python type checker [ty][ty].

### Setup

First ensure `rules_venv` is setup by referring to [rules_venv setup](../index.md#setup).

Next, the `ty` rules work mostly off of toolchains which are used to provide the necessary python targets (aka `ty`)
for the process wrappers. Users will want to make sure they have a way to get the necessary python dependencies. Tools such as
[req-compile](https://github.com/periareon/req-compile) can provide these.

With the appropriate dependencies available, a [py_ty_toolchain](#py_ty_toolchain) will need to be configured.
The toolchain accepts either `ty` (a `py_library`, e.g. from pip) or `ty_bin` (an executable); the two are mutually exclusive.

```python
load("@rules_venv//python/ty:defs.bzl", "py_ty_toolchain")

py_ty_toolchain(
    name = "toolchain_impl",
    ty = "@pip_deps//ty",
    visibility = ["//visibility:public"]
)

toolchain(
    name = "toolchain",
    toolchain = ":toolchain_impl",
    toolchain_type = "@rules_venv//python/ty:toolchain_type",
    visibility = ["//visibility:public"]
)
```

This toolchain then needs to be registered in the `MODULE.bazel` file.

```python
register_toolchains("//tools/python/ty:toolchain")
```

From here, [py_ty_test](#py_ty_test) and the [py_ty_aspect](#py_ty_aspect)
should now be usable. Both the test rule and the aspect
use a global flag to determine which ty configuration file to use in actions. The default config is
`//python/ty:ty.toml`; the chosen file must be a valid label (e.g. `ty.toml` or `pyproject.toml`).
Add the following to `.bazelrc` to choose a different configuration file:

```text
build --@rules_venv//python/ty:config=//:ty.toml
```

To use the aspect, you must also enable it and request its output group in `.bazelrc`:

```text
build --aspects=@rules_venv//python/ty:py_ty_aspect.bzl%py_ty_aspect
build --output_groups=+py_ty_checks
```

Test rules can override the config per target via the `config` attribute (they default to the label flag above).


[ty]: https://docs.astral.sh/ty/
�
)

rules_venv	python/typy_ty_aspect.bzl�py_ty_aspect�An aspect for running ty on targets with Python sources.

This aspect can be configured by adding the following snippet to a workspace's `.bazelrc` file:

```text
build --aspects=@rules_venv//python/ty:py_ty_aspect.bzl%py_ty_aspect
build --output_groups=+py_ty_checks
```
:�
�
py_ty_aspect�An aspect for running ty on targets with Python sources.

This aspect can be configured by adding the following snippet to a workspace's `.bazelrc` file:

```text
build --aspects=@rules_venv//python/ty:py_ty_aspect.bzl%py_ty_aspect
build --output_groups=+py_ty_checks
```
"*
nameA unique name for this target. *8
py_ty_aspect(@@rules_venv//python/ty:py_ty_aspect.bzl
��,
*
nameA unique name for this target. �
//python/ty/private:ty.bzlrd
'

rules_venvpython/ty/privatety.bzl+
py_ty_aspect_py_ty_aspect

# py_ty_aspect�
,

rules_venv	python/typy_ty_toolchain.bzl�py_ty_toolchainHA toolchain for the [ty](https://docs.astral.sh/ty/) type checker rules."�
�
py_ty_toolchainHA toolchain for the [ty](https://docs.astral.sh/ty/) type checker rules.*
nameA unique name for this target. B
ty*The ty `py_library` to use with the rules.*
PyInfo2None6
ty_bin$A `ty` binary to use with the rules.2None">
py_ty_toolchain+@@rules_venv//python/ty:py_ty_toolchain.bzl
QQ,
*
nameA unique name for this target. D
B
ty*The ty `py_library` to use with the rules.*
PyInfo2None8
6
ty_bin$A `ty` binary to use with the rules.2None�
$//python/ty/private:ty_toolchain.bzlrt
1

rules_venvpython/ty/privatety_toolchain.bzl1
py_ty_toolchain_py_ty_toolchain

# py_ty_toolchain�
M

rules_venv*python/venv/private/tests/data_dir/privatedirectory_maker.bzl�directory_maker>A rule that creates a directory with nested files for testing."�
�
directory_maker>A rule that creates a directory with nested files for testing.*
nameA unique name for this target. @
content1The content to write to the nested data.txt file. "_
directory_makerL@@rules_venv//python/venv/private/tests/data_dir/private:directory_maker.bzl
,
*
nameA unique name for this target. B
@
content1The content to write to the nested data.txt file. 2A rule that creates a directory with nested files.�
L

rules_venv python/venv/private/tests/zipapppython_zip_file_consumer.bzl�python_zip_file_consumer=A rule for invoking the zipapp from `py_venv_zipapp` targets."�
�
python_zip_file_consumer=A rule for invoking the zipapp from `py_venv_zipapp` targets.*
nameA unique name for this target. *
zip_fileA `py_venv_zipapp` target. "g
python_zip_file_consumerK@@rules_venv//python/venv/private/tests/zipapp:python_zip_file_consumer.bzl
    ,
*
nameA unique name for this target. ,
*
zip_fileA `py_venv_zipapp` target. "Rules that consume python_zip_file�
7

rules_venvpython/venv/privaterunfiles_enabled.bzl�runfiles_enabled_settingAA bool-typed build setting that cannot be set on the command line"�
�
runfiles_enabled_settingAA bool-typed build setting that cannot be set on the command line*
nameA unique name for this target. 
valueA boolean value "R
runfiles_enabled_setting6@@rules_venv//python/venv/private:runfiles_enabled.bzl
  ,
*
nameA unique name for this target. 

valueA boolean value �runfiles_enabled_build_setting~Define a build setting identifying if runfiles are enabled.

A bool-typed build setting that cannot be set on the command line"�
�
runfiles_enabled_build_setting~Define a build setting identifying if runfiles are enabled.

A bool-typed build setting that cannot be set on the command line*
nameA unique name for this target. 
valueA boolean value "R
runfiles_enabled_setting6@@rules_venv//python/venv/private:runfiles_enabled.bzl
**,
*
nameA unique name for this target. 

valueA boolean value �is_runfiles_enabled.Determine whether or not runfiles are enabled.*�
�
is_runfiles_enabled6
attr*A rule's struct of attributes (`ctx.attr`) (.Determine whether or not runfiles are enabled.""
 bool: The enable_runfiles value.2M
is_runfiles_enabled6@@rules_venv//python/venv/private:runfiles_enabled.bzl
���runfiles_enabled_attr*�
�
runfiles_enabled_attr
default (	
cfg (2O
runfiles_enabled_attr6@@rules_venv//python/venv/private:runfiles_enabled.bzl
  �RunfilesEnabledInfoCA singleton provider that contains the raw value of a build setting2�
�
RunfilesEnabledInfoCA singleton provider that contains the raw value of a build setting�
value�The value of the build setting in the current configuration. This value may come from the command line or an upstream transition, or else it will be the build setting's default."M
RunfilesEnabledInfo6@@rules_venv//python/venv/private:runfiles_enabled.bzl
�
�
value�The value of the build setting in the current configuration. This value may come from the command line or an upstream transition, or else it will be the build setting's default.i
//lib:selects.bzlrR
 
bazel_skyliblibselects.bzl 
selectsselects
)0
2�
//rules:common_settings.bzlrf
*
bazel_skylibrulescommon_settings.bzl*
bool_settingbool_setting
3?
AeA small utility module dedicated to detecting whether or not the `--enable_runfiles` flag is enabled
�
,

rules_venvpython/venv/private	utils.bzl�venv_entrypoint:Generates the entrypoint for `py_venv_*` executable rules."�
�
venv_entrypoint:Generates the entrypoint for `py_venv_*` executable rules.*
nameA unique name for this target. .

entrypointThe entrypoint template.2None">
venv_entrypoint+@@rules_venv//python/venv/private:utils.bzl
@@,
*
nameA unique name for this target. 0
.

entrypointThe entrypoint template.2NoneVenv utilities�6
+

rules_venvpython/venv/privatevenv.bzl�py_venv_binary�A `py_venv_binary` is an executable Python program consisting of a collection of
`.py` source files (possibly belonging to other `py_library` rules), a `*.runfiles`
directory tree containing all the code and data needed by the program at run-time,
and a stub script that starts up the program with the correct initial environment
and data.

```python
load("@rules_venv//python/venv:defs.bzl", "py_venv_binary")

py_venv_binary(
    name = "foo",
    srcs = ["foo.py"],
    data = [":transform"],  # a cc_binary which we invoke at run time
    deps = [
        ":bar",  # a py_library
    ],
)
```
"�
�
py_venv_binary�A `py_venv_binary` is an executable Python program consisting of a collection of
`.py` source files (possibly belonging to other `py_library` rules), a `*.runfiles`
directory tree containing all the code and data needed by the program at run-time,
and a stub script that starts up the program with the correct initial environment
and data.

```python
load("@rules_venv//python/venv:defs.bzl", "py_venv_binary")

py_venv_binary(
    name = "foo",
    srcs = ["foo.py"],
    data = [":transform"],  # a cc_binary which we invoke at run time
    deps = [
        ":bar",  # a py_library
    ],
)
```
*
nameA unique name for this target. o
dataaFiles needed by this rule at runtime. May list file or rule targets. Generally allows any target.2[]K
deps3Other python targets to link to the current target.*
PyInfo2[]i
env\Dictionary of strings; values are subject to `$(location)` and "Make variable" substitution.
2{}L
imports;List of import directories to be added to the `PYTHONPATH`.2[]�
main�The name of the source file that is the main entry point of the application. This file must also be listed in `srcs`. If left unspecified, `name` is used instead. If `name` does not match any filename in `srcs`, `main` must be specified. 2NoneU
srcsGThe list of source (.py) files that are processed to create the target.2[]"<
py_venv_binary*@@rules_venv//python/venv/private:venv.bzl
��,
*
nameA unique name for this target. q
o
dataaFiles needed by this rule at runtime. May list file or rule targets. Generally allows any target.2[]M
K
deps3Other python targets to link to the current target.*
PyInfo2[]k
i
env\Dictionary of strings; values are subject to `$(location)` and "Make variable" substitution.
2{}N
L
imports;List of import directories to be added to the `PYTHONPATH`.2[]�
�
main�The name of the source file that is the main entry point of the application. This file must also be listed in `srcs`. If left unspecified, `name` is used instead. If `name` does not match any filename in `srcs`, `main` must be specified. 2NoneW
U
srcsGThe list of source (.py) files that are processed to create the target.2[]�py_venv_library4A library of Python code that can be depended upon.
"�
�
py_venv_library4A library of Python code that can be depended upon.
*
nameA unique name for this target. o
dataaFiles needed by this rule at runtime. May list file or rule targets. Generally allows any target.2[]K
deps3Other python targets to link to the current target.*
PyInfo2[]L
imports;List of import directories to be added to the `PYTHONPATH`.2[]U
srcsGThe list of source (.py) files that are processed to create the target.2[]"=
py_venv_library*@@rules_venv//python/venv/private:venv.bzl
==,
*
nameA unique name for this target. q
o
dataaFiles needed by this rule at runtime. May list file or rule targets. Generally allows any target.2[]M
K
deps3Other python targets to link to the current target.*
PyInfo2[]N
L
imports;List of import directories to be added to the `PYTHONPATH`.2[]W
U
srcsGThe list of source (.py) files that are processed to create the target.2[]�py_venv_testYA `py_venv_test` rule compiles a test. A test is a binary wrapper around some test code.
"�
�
py_venv_testYA `py_venv_test` rule compiles a test. A test is a binary wrapper around some test code.
*
nameA unique name for this target. o
dataaFiles needed by this rule at runtime. May list file or rule targets. Generally allows any target.2[]K
deps3Other python targets to link to the current target.*
PyInfo2[]i
env\Dictionary of strings; values are subject to `$(location)` and "Make variable" substitution.
2{}�
env_inherit~Specifies additional environment variables to inherit from the external environment when the test is executed by `bazel test`.2[]L
imports;List of import directories to be added to the `PYTHONPATH`.2[]�
main�The name of the source file that is the main entry point of the application. This file must also be listed in `srcs`. If left unspecified, `name` is used instead. If `name` does not match any filename in `srcs`, `main` must be specified. 2NoneU
srcsGThe list of source (.py) files that are processed to create the target.2[]":
py_venv_test*@@rules_venv//python/venv/private:venv.bzl
��,
*
nameA unique name for this target. q
o
dataaFiles needed by this rule at runtime. May list file or rule targets. Generally allows any target.2[]M
K
deps3Other python targets to link to the current target.*
PyInfo2[]k
i
env\Dictionary of strings; values are subject to `$(location)` and "Make variable" substitution.
2{}�
�
env_inherit~Specifies additional environment variables to inherit from the external environment when the test is executed by `bazel test`.2[]N
L
imports;List of import directories to be added to the `PYTHONPATH`.2[]�
�
main�The name of the source file that is the main entry point of the application. This file must also be listed in `srcs`. If left unspecified, `name` is used instead. If `name` does not match any filename in `srcs`, `main` must be specified. 2NoneW
U
srcsGThe list of source (.py) files that are processed to create the target.2[]�compute_main3Determine the main entrypoint for executable rules.*�
�
compute_main)
labelThe label of the srcs owner. (#
srcsA list of File objects. (>
main.An explicit contender for the main entrypoint.None(3Determine the main entrypoint for executable rules."0
.File: The file to use for the main entrypoint.2:
compute_main*@@rules_venv//python/venv/private:venv.bzl
rrk
//python:py_info.bzlrQ
!

rules_venvpythonpy_info.bzl
PyInfoPyInfo
*0
2�
//python/private:coverage.bzlrj
*

rules_venvpython/privatecoverage.bzl.
COVERAGE_ATTRSCOVERAGE_ATTRS
3A
C�
%//python/venv/private:venv_common.bzlro
2

rules_venvpython/venv/privatevenv_common.bzl+
py_venv_commonvenv_common
:E
YBazel rules for Python venvs�
2

rules_venvpython/venv/privatevenv_common.bzl�create_python_startup_args�Construct an Args object for running python scripts.

A python script can be added to the resulting Args object to spawn
a process for it.
*�
�
create_python_startup_args%
ctxThe rule's context object. (<
version_info(Python version info from `py_toolchain`. (�Construct an Args object for running python scripts.

A python script can be added to the resulting Args object to spawn
a process for it.
"
Args: An args object.2O
create_python_startup_args1@@rules_venv//python/venv/private:venv_common.bzl
���create_venv_config_info$Construct info used to create venvs.*�
�
create_venv_config_info8
label+The label of the target that owns the venv. ("
nameThe name for the venv. (?
imports0A list of import paths to write to `.pth` files. (�
static_repos�Repos whose files are all source (no generated outputs).
When set, the process wrapper will resolve `.pth` entries for these repos
directly from the external directory instead of the runfiles collection.None($Construct info used to create venvs."
struct: the data.2L
create_venv_config_info1@@rules_venv//python/venv/private:venv_common.bzl
ii2struct2struct�zip_resource_setNA `ctx.actions.run.resource_set` function intended for python zipfile actions.*�
�
zip_resource_set6
_os_name&The name of the exec operating system. (0
inputs"The number if inputs to the action (NA `ctx.actions.run.resource_set` function intended for python zipfile actions.";
9dict: A mapping of resource name to their desired values.2E
zip_resource_set1@@rules_venv//python/venv/private:venv_common.bzl
��a
//lib:paths.bzlrL

bazel_skyliblib	paths.bzl
pathspaths
',
.k
//python:py_info.bzlrQ
!

rules_venvpythonpy_info.bzl
PyInfoPyInfo
*0
22Interfaces for rule authors to use in custom rules�

5

rules_venvpython/venv/privatevenv_toolchain.bzl�current_py_venv_toolchain=Access the `py_venv_toolchain` for the current configuration."�
�
current_py_venv_toolchain=Access the `py_venv_toolchain` for the current configuration.*
nameA unique name for this target. "Q
current_py_venv_toolchain4@@rules_venv//python/venv/private:venv_toolchain.bzl
S!S!,
*
nameA unique name for this target. �py_venv_toolchain+Declare a toolchain for `rules_venv` rules."�
�
py_venv_toolchain+Declare a toolchain for `rules_venv` rules.*
nameA unique name for this target. e
zipapp_shebangMThe shebang to use when creating zipapps (`OutputGroupInfo.python_zip_file`).2"""I
py_venv_toolchain4@@rules_venv//python/venv/private:venv_toolchain.bzl
,
*
nameA unique name for this target. g
e
zipapp_shebangMThe shebang to use when creating zipapps (`OutputGroupInfo.python_zip_file`).2""�
//rules:common_settings.bzlrn
*
bazel_skylibrulescommon_settings.bzl2
BuildSettingInfoBuildSettingInfo
3C
E�
*//python/venv/private:runfiles_enabled.bzlr�
7

rules_venvpython/venv/privaterunfiles_enabled.bzl8
is_runfiles_enabledis_runfiles_enabled
@S<
runfiles_enabled_attrrunfiles_enabled_attr
Wl
nBazel rules for Python venvs�(
2

rules_venvpython/venv/privatevenv_zipapp.bzl�py_venv_zipapp�A `py_venv_zipapp` is an executable [Python zipapp](https://docs.python.org/3/library/zipapp.html)
which contains all of the dependencies and runfiles for a given executable.

```python
load("@rules_venv//python/venv:defs.bzl", "py_venv_binary", "py_venv_zipapp")

py_venv_binary(
    name = "foo",
    srcs = ["foo.py"],
)

py_venv_zipapp(
    name = "foo_pyz",
    binary = ":foo",
)
```
"�
�
py_venv_zipapp�A `py_venv_zipapp` is an executable [Python zipapp](https://docs.python.org/3/library/zipapp.html)
which contains all of the dependencies and runfiles for a given executable.

```python
load("@rules_venv//python/venv:defs.bzl", "py_venv_binary", "py_venv_zipapp")

py_venv_binary(
    name = "foo",
    srcs = ["foo.py"],
)

py_venv_zipapp(
    name = "foo_pyz",
    binary = ":foo",
)
```
*
nameA unique name for this target. Q
argsCArguments to add to the beginning of all invocations of the zipapp.2[]>
binary"The binary to package as a zipapp.*
PyInfo2NoneP
envCEnvironment variables to inject into all invocations of the zipapp.
2{}T
inherit_args;Inherit template variable expanded arguments from `binary`.2False_
inherit_envGInherit template variable expanded environment variables from `binary`.2False^
shebangMOptional shebang line to prepend to the zip (provided as content after `#!`).2"""C
py_venv_zipapp1@@rules_venv//python/venv/private:venv_zipapp.bzl
��,
*
nameA unique name for this target. S
Q
argsCArguments to add to the beginning of all invocations of the zipapp.2[]@
>
binary"The binary to package as a zipapp.*
PyInfo2NoneR
P
envCEnvironment variables to inject into all invocations of the zipapp.
2{}V
T
inherit_args;Inherit template variable expanded arguments from `binary`.2Falsea
_
inherit_envGInherit template variable expanded environment variables from `binary`.2False`
^
shebangMOptional shebang line to prepend to the zip (provided as content after `#!`).2""�create_python_zip_fileCreate a zipapp.*�
�
create_python_zip_file%
ctxThe rule's context object. (6
venv_toolchain A `py_venv_toolchain` toolchain. (<
py_info-The `PyInfo` provider for the current target. ('
mainThe main python entrypoint. (\
inject_argsIA list of arguments to inject to the beginning of all zipapp invocations. (Z

inject_envHA map of arguments to inject to the beginning of all zipapp invocations. (8
runfiles(Runfiles associated with the executable. (@
files_to_run,Files to run associated with the executable. (x
py_toolchain`A `py_toolchain` toolchain. If one is not
provided one will be acquired via `py_venv_toolchain`.None(�
py_toolchain_exec{A `py_toolchain` toolchain for the execution
platform. If one is not provided one will be acquired via `py_venv_toolchain`.None(R
shebang?Optional shebang contents to include, overriding the toolchain.None(Create a zipapp."
File: The generated zip file.2K
create_python_zip_file1@@rules_venv//python/venv/private:venv_zipapp.bzl
OO�
PyMainInfo[`rules_venv` internal provider to inform consumers of binaries about their main entrypoint.2�
�

PyMainInfo[`rules_venv` internal provider to inform consumers of binaries about their main entrypoint.7
args/List[str]: Template variable expanded arguments3
data+list[Target]: Data targets from the binary.H
envADict[str, str]: Template variable expanded environment variables.1
main)File: The main entrypoint for the target.P
srcsHlist[File]: The list of source files that directly belong to the binary."?

PyMainInfo1@@rules_venv//python/venv/private:venv_zipapp.bzl
9
7
args/List[str]: Template variable expanded arguments5
3
data+list[Target]: Data targets from the binary.J
H
envADict[str, str]: Template variable expanded environment variables.3
1
main)File: The main entrypoint for the target.R
P
srcsHlist[File]: The list of source files that directly belong to the binary.�py_main_aspectSAn aspect used to collect arguments and environment variables from zipapp binaries.:�
�
py_main_aspectSAn aspect used to collect arguments and environment variables from zipapp binaries."*
nameA unique name for this target. *C
py_main_aspect1@@rules_venv//python/venv/private:venv_zipapp.bzl
DD,
*
nameA unique name for this target. k
//python:py_info.bzlrQ
!

rules_venvpythonpy_info.bzl
PyInfoPyInfo
*0
2�
//python/venv/private:venv.bzlrg
+

rules_venvpython/venv/privatevenv.bzl*
compute_maincompute_main
4@
B�
%//python/venv/private:venv_common.bzlr�
2

rules_venvpython/venv/privatevenv_common.bzlF
create_python_startup_argscreate_python_startup_args
 @
create_venv_config_infocreate_venv_config_info
2
zip_resource_setzip_resource_set
		+
py_venv_commonvenv_common



Rules for producing zipapps�9
#

rules_venvpython/venvdefs.bzl�py_venv_binary�A `py_venv_binary` is an executable Python program consisting of a collection of
`.py` source files (possibly belonging to other `py_library` rules), a `*.runfiles`
directory tree containing all the code and data needed by the program at run-time,
and a stub script that starts up the program with the correct initial environment
and data.

```python
load("@rules_venv//python/venv:defs.bzl", "py_venv_binary")

py_venv_binary(
    name = "foo",
    srcs = ["foo.py"],
    data = [":transform"],  # a cc_binary which we invoke at run time
    deps = [
        ":bar",  # a py_library
    ],
)
```
"�
�
py_venv_binary�A `py_venv_binary` is an executable Python program consisting of a collection of
`.py` source files (possibly belonging to other `py_library` rules), a `*.runfiles`
directory tree containing all the code and data needed by the program at run-time,
and a stub script that starts up the program with the correct initial environment
and data.

```python
load("@rules_venv//python/venv:defs.bzl", "py_venv_binary")

py_venv_binary(
    name = "foo",
    srcs = ["foo.py"],
    data = [":transform"],  # a cc_binary which we invoke at run time
    deps = [
        ":bar",  # a py_library
    ],
)
```
*
nameA unique name for this target. o
dataaFiles needed by this rule at runtime. May list file or rule targets. Generally allows any target.2[]K
deps3Other python targets to link to the current target.*
PyInfo2[]i
env\Dictionary of strings; values are subject to `$(location)` and "Make variable" substitution.
2{}L
imports;List of import directories to be added to the `PYTHONPATH`.2[]�
main�The name of the source file that is the main entry point of the application. This file must also be listed in `srcs`. If left unspecified, `name` is used instead. If `name` does not match any filename in `srcs`, `main` must be specified. 2NoneU
srcsGThe list of source (.py) files that are processed to create the target.2[]"4
py_venv_binary"@@rules_venv//python/venv:defs.bzl
��,
*
nameA unique name for this target. q
o
dataaFiles needed by this rule at runtime. May list file or rule targets. Generally allows any target.2[]M
K
deps3Other python targets to link to the current target.*
PyInfo2[]k
i
env\Dictionary of strings; values are subject to `$(location)` and "Make variable" substitution.
2{}N
L
imports;List of import directories to be added to the `PYTHONPATH`.2[]�
�
main�The name of the source file that is the main entry point of the application. This file must also be listed in `srcs`. If left unspecified, `name` is used instead. If `name` does not match any filename in `srcs`, `main` must be specified. 2NoneW
U
srcsGThe list of source (.py) files that are processed to create the target.2[]�py_venv_library4A library of Python code that can be depended upon.
"�
�
py_venv_library4A library of Python code that can be depended upon.
*
nameA unique name for this target. o
dataaFiles needed by this rule at runtime. May list file or rule targets. Generally allows any target.2[]K
deps3Other python targets to link to the current target.*
PyInfo2[]L
imports;List of import directories to be added to the `PYTHONPATH`.2[]U
srcsGThe list of source (.py) files that are processed to create the target.2[]"5
py_venv_library"@@rules_venv//python/venv:defs.bzl
==,
*
nameA unique name for this target. q
o
dataaFiles needed by this rule at runtime. May list file or rule targets. Generally allows any target.2[]M
K
deps3Other python targets to link to the current target.*
PyInfo2[]N
L
imports;List of import directories to be added to the `PYTHONPATH`.2[]W
U
srcsGThe list of source (.py) files that are processed to create the target.2[]�py_venv_toolchain+Declare a toolchain for `rules_venv` rules."�
�
py_venv_toolchain+Declare a toolchain for `rules_venv` rules.*
nameA unique name for this target. e
zipapp_shebangMThe shebang to use when creating zipapps (`OutputGroupInfo.python_zip_file`).2"""7
py_venv_toolchain"@@rules_venv//python/venv:defs.bzl
,
*
nameA unique name for this target. g
e
zipapp_shebangMThe shebang to use when creating zipapps (`OutputGroupInfo.python_zip_file`).2""�py_venv_zipapp�A `py_venv_zipapp` is an executable [Python zipapp](https://docs.python.org/3/library/zipapp.html)
which contains all of the dependencies and runfiles for a given executable.

```python
load("@rules_venv//python/venv:defs.bzl", "py_venv_binary", "py_venv_zipapp")

py_venv_binary(
    name = "foo",
    srcs = ["foo.py"],
)

py_venv_zipapp(
    name = "foo_pyz",
    binary = ":foo",
)
```
"�
�
py_venv_zipapp�A `py_venv_zipapp` is an executable [Python zipapp](https://docs.python.org/3/library/zipapp.html)
which contains all of the dependencies and runfiles for a given executable.

```python
load("@rules_venv//python/venv:defs.bzl", "py_venv_binary", "py_venv_zipapp")

py_venv_binary(
    name = "foo",
    srcs = ["foo.py"],
)

py_venv_zipapp(
    name = "foo_pyz",
    binary = ":foo",
)
```
*
nameA unique name for this target. Q
argsCArguments to add to the beginning of all invocations of the zipapp.2[]>
binary"The binary to package as a zipapp.*
PyInfo2NoneP
envCEnvironment variables to inject into all invocations of the zipapp.
2{}T
inherit_args;Inherit template variable expanded arguments from `binary`.2False_
inherit_envGInherit template variable expanded environment variables from `binary`.2False^
shebangMOptional shebang line to prepend to the zip (provided as content after `#!`).2"""4
py_venv_zipapp"@@rules_venv//python/venv:defs.bzl
��,
*
nameA unique name for this target. S
Q
argsCArguments to add to the beginning of all invocations of the zipapp.2[]@
>
binary"The binary to package as a zipapp.*
PyInfo2NoneR
P
envCEnvironment variables to inject into all invocations of the zipapp.
2{}V
T
inherit_args;Inherit template variable expanded arguments from `binary`.2Falsea
_
inherit_envGInherit template variable expanded environment variables from `binary`.2False`
^
shebangMOptional shebang line to prepend to the zip (provided as content after `#!`).2""�
 //python/venv:py_venv_binary.bzlrn
-

rules_venvpython/venvpy_venv_binary.bzl/
py_venv_binary_py_venv_binary
		

�
 //python/venv:py_venv_common.bzlrn
-

rules_venvpython/venvpy_venv_common.bzl/
py_venv_common_py_venv_common

�
!//python/venv:py_venv_library.bzlrq
.

rules_venvpython/venvpy_venv_library.bzl1
py_venv_library_py_venv_library

�
//python/venv:py_venv_test.bzlrh
+

rules_venvpython/venvpy_venv_test.bzl+
py_venv_test_py_venv_test

�
#//python/venv:py_venv_toolchain.bzlrw
0

rules_venvpython/venvpy_venv_toolchain.bzl5
py_venv_toolchain_py_venv_toolchain

�
 //python/venv:py_venv_zipapp.bzlrn
-

rules_venvpython/venvpy_venv_zipapp.bzl/
py_venv_zipapp_py_venv_zipapp

7# Venv

Core Bazel rules for defining Python targets.

�
-

rules_venvpython/venvpy_venv_binary.bzl�py_venv_binary�A `py_venv_binary` is an executable Python program consisting of a collection of
`.py` source files (possibly belonging to other `py_library` rules), a `*.runfiles`
directory tree containing all the code and data needed by the program at run-time,
and a stub script that starts up the program with the correct initial environment
and data.

```python
load("@rules_venv//python/venv:defs.bzl", "py_venv_binary")

py_venv_binary(
    name = "foo",
    srcs = ["foo.py"],
    data = [":transform"],  # a cc_binary which we invoke at run time
    deps = [
        ":bar",  # a py_library
    ],
)
```
"�
�
py_venv_binary�A `py_venv_binary` is an executable Python program consisting of a collection of
`.py` source files (possibly belonging to other `py_library` rules), a `*.runfiles`
directory tree containing all the code and data needed by the program at run-time,
and a stub script that starts up the program with the correct initial environment
and data.

```python
load("@rules_venv//python/venv:defs.bzl", "py_venv_binary")

py_venv_binary(
    name = "foo",
    srcs = ["foo.py"],
    data = [":transform"],  # a cc_binary which we invoke at run time
    deps = [
        ":bar",  # a py_library
    ],
)
```
*
nameA unique name for this target. o
dataaFiles needed by this rule at runtime. May list file or rule targets. Generally allows any target.2[]K
deps3Other python targets to link to the current target.*
PyInfo2[]i
env\Dictionary of strings; values are subject to `$(location)` and "Make variable" substitution.
2{}L
imports;List of import directories to be added to the `PYTHONPATH`.2[]�
main�The name of the source file that is the main entry point of the application. This file must also be listed in `srcs`. If left unspecified, `name` is used instead. If `name` does not match any filename in `srcs`, `main` must be specified. 2NoneU
srcsGThe list of source (.py) files that are processed to create the target.2[]">
py_venv_binary,@@rules_venv//python/venv:py_venv_binary.bzl
��,
*
nameA unique name for this target. q
o
dataaFiles needed by this rule at runtime. May list file or rule targets. Generally allows any target.2[]M
K
deps3Other python targets to link to the current target.*
PyInfo2[]k
i
env\Dictionary of strings; values are subject to `$(location)` and "Make variable" substitution.
2{}N
L
imports;List of import directories to be added to the `PYTHONPATH`.2[]�
�
main�The name of the source file that is the main entry point of the application. This file must also be listed in `srcs`. If left unspecified, `name` is used instead. If `name` does not match any filename in `srcs`, `main` must be specified. 2NoneW
U
srcsGThe list of source (.py) files that are processed to create the target.2[]�
//python/venv/private:venv.bzlrl
+

rules_venvpython/venv/privatevenv.bzl/
py_venv_binary_py_venv_binary

# py_venv_binary�
-

rules_venvpython/venvpy_venv_common.bzl�
%//python/venv/private:venv_common.bzlrs
2

rules_venvpython/venv/privatevenv_common.bzl/
py_venv_common_py_venv_common

# py_venv_common�I
.

rules_venvpython/venvpy_venv_library.bzl�py_venv_binary�A `py_venv_binary` is an executable Python program consisting of a collection of
`.py` source files (possibly belonging to other `py_library` rules), a `*.runfiles`
directory tree containing all the code and data needed by the program at run-time,
and a stub script that starts up the program with the correct initial environment
and data.

```python
load("@rules_venv//python/venv:defs.bzl", "py_venv_binary")

py_venv_binary(
    name = "foo",
    srcs = ["foo.py"],
    data = [":transform"],  # a cc_binary which we invoke at run time
    deps = [
        ":bar",  # a py_library
    ],
)
```
"�
�
py_venv_binary�A `py_venv_binary` is an executable Python program consisting of a collection of
`.py` source files (possibly belonging to other `py_library` rules), a `*.runfiles`
directory tree containing all the code and data needed by the program at run-time,
and a stub script that starts up the program with the correct initial environment
and data.

```python
load("@rules_venv//python/venv:defs.bzl", "py_venv_binary")

py_venv_binary(
    name = "foo",
    srcs = ["foo.py"],
    data = [":transform"],  # a cc_binary which we invoke at run time
    deps = [
        ":bar",  # a py_library
    ],
)
```
*
nameA unique name for this target. o
dataaFiles needed by this rule at runtime. May list file or rule targets. Generally allows any target.2[]K
deps3Other python targets to link to the current target.*
PyInfo2[]i
env\Dictionary of strings; values are subject to `$(location)` and "Make variable" substitution.
2{}L
imports;List of import directories to be added to the `PYTHONPATH`.2[]�
main�The name of the source file that is the main entry point of the application. This file must also be listed in `srcs`. If left unspecified, `name` is used instead. If `name` does not match any filename in `srcs`, `main` must be specified. 2NoneU
srcsGThe list of source (.py) files that are processed to create the target.2[]"?
py_venv_binary-@@rules_venv//python/venv:py_venv_library.bzl
��,
*
nameA unique name for this target. q
o
dataaFiles needed by this rule at runtime. May list file or rule targets. Generally allows any target.2[]M
K
deps3Other python targets to link to the current target.*
PyInfo2[]k
i
env\Dictionary of strings; values are subject to `$(location)` and "Make variable" substitution.
2{}N
L
imports;List of import directories to be added to the `PYTHONPATH`.2[]�
�
main�The name of the source file that is the main entry point of the application. This file must also be listed in `srcs`. If left unspecified, `name` is used instead. If `name` does not match any filename in `srcs`, `main` must be specified. 2NoneW
U
srcsGThe list of source (.py) files that are processed to create the target.2[]�py_venv_library4A library of Python code that can be depended upon.
"�
�
py_venv_library4A library of Python code that can be depended upon.
*
nameA unique name for this target. o
dataaFiles needed by this rule at runtime. May list file or rule targets. Generally allows any target.2[]K
deps3Other python targets to link to the current target.*
PyInfo2[]L
imports;List of import directories to be added to the `PYTHONPATH`.2[]U
srcsGThe list of source (.py) files that are processed to create the target.2[]"@
py_venv_library-@@rules_venv//python/venv:py_venv_library.bzl
==,
*
nameA unique name for this target. q
o
dataaFiles needed by this rule at runtime. May list file or rule targets. Generally allows any target.2[]M
K
deps3Other python targets to link to the current target.*
PyInfo2[]N
L
imports;List of import directories to be added to the `PYTHONPATH`.2[]W
U
srcsGThe list of source (.py) files that are processed to create the target.2[]�py_venv_testYA `py_venv_test` rule compiles a test. A test is a binary wrapper around some test code.
"�
�
py_venv_testYA `py_venv_test` rule compiles a test. A test is a binary wrapper around some test code.
*
nameA unique name for this target. o
dataaFiles needed by this rule at runtime. May list file or rule targets. Generally allows any target.2[]K
deps3Other python targets to link to the current target.*
PyInfo2[]i
env\Dictionary of strings; values are subject to `$(location)` and "Make variable" substitution.
2{}�
env_inherit~Specifies additional environment variables to inherit from the external environment when the test is executed by `bazel test`.2[]L
imports;List of import directories to be added to the `PYTHONPATH`.2[]�
main�The name of the source file that is the main entry point of the application. This file must also be listed in `srcs`. If left unspecified, `name` is used instead. If `name` does not match any filename in `srcs`, `main` must be specified. 2NoneU
srcsGThe list of source (.py) files that are processed to create the target.2[]"=
py_venv_test-@@rules_venv//python/venv:py_venv_library.bzl
��,
*
nameA unique name for this target. q
o
dataaFiles needed by this rule at runtime. May list file or rule targets. Generally allows any target.2[]M
K
deps3Other python targets to link to the current target.*
PyInfo2[]k
i
env\Dictionary of strings; values are subject to `$(location)` and "Make variable" substitution.
2{}�
�
env_inherit~Specifies additional environment variables to inherit from the external environment when the test is executed by `bazel test`.2[]N
L
imports;List of import directories to be added to the `PYTHONPATH`.2[]�
�
main�The name of the source file that is the main entry point of the application. This file must also be listed in `srcs`. If left unspecified, `name` is used instead. If `name` does not match any filename in `srcs`, `main` must be specified. 2NoneW
U
srcsGThe list of source (.py) files that are processed to create the target.2[]�py_venv_toolchain+Declare a toolchain for `rules_venv` rules."�
�
py_venv_toolchain+Declare a toolchain for `rules_venv` rules.*
nameA unique name for this target. e
zipapp_shebangMThe shebang to use when creating zipapps (`OutputGroupInfo.python_zip_file`).2"""B
py_venv_toolchain-@@rules_venv//python/venv:py_venv_library.bzl
,
*
nameA unique name for this target. g
e
zipapp_shebangMThe shebang to use when creating zipapps (`OutputGroupInfo.python_zip_file`).2""�py_venv_zipapp�A `py_venv_zipapp` is an executable [Python zipapp](https://docs.python.org/3/library/zipapp.html)
which contains all of the dependencies and runfiles for a given executable.

```python
load("@rules_venv//python/venv:defs.bzl", "py_venv_binary", "py_venv_zipapp")

py_venv_binary(
    name = "foo",
    srcs = ["foo.py"],
)

py_venv_zipapp(
    name = "foo_pyz",
    binary = ":foo",
)
```
"�
�
py_venv_zipapp�A `py_venv_zipapp` is an executable [Python zipapp](https://docs.python.org/3/library/zipapp.html)
which contains all of the dependencies and runfiles for a given executable.

```python
load("@rules_venv//python/venv:defs.bzl", "py_venv_binary", "py_venv_zipapp")

py_venv_binary(
    name = "foo",
    srcs = ["foo.py"],
)

py_venv_zipapp(
    name = "foo_pyz",
    binary = ":foo",
)
```
*
nameA unique name for this target. Q
argsCArguments to add to the beginning of all invocations of the zipapp.2[]>
binary"The binary to package as a zipapp.*
PyInfo2NoneP
envCEnvironment variables to inject into all invocations of the zipapp.
2{}T
inherit_args;Inherit template variable expanded arguments from `binary`.2False_
inherit_envGInherit template variable expanded environment variables from `binary`.2False^
shebangMOptional shebang line to prepend to the zip (provided as content after `#!`).2"""?
py_venv_zipapp-@@rules_venv//python/venv:py_venv_library.bzl
��,
*
nameA unique name for this target. S
Q
argsCArguments to add to the beginning of all invocations of the zipapp.2[]@
>
binary"The binary to package as a zipapp.*
PyInfo2NoneR
P
envCEnvironment variables to inject into all invocations of the zipapp.
2{}V
T
inherit_args;Inherit template variable expanded arguments from `binary`.2Falsea
_
inherit_envGInherit template variable expanded environment variables from `binary`.2False`
^
shebangMOptional shebang line to prepend to the zip (provided as content after `#!`).2""�
//python/venv/private:venv.bzlr�
+

rules_venvpython/venv/privatevenv.bzl/
py_venv_binary_py_venv_binary
		1
py_venv_library_py_venv_library


+
py_venv_test_py_venv_test

�
%//python/venv/private:venv_common.bzlrs
2

rules_venvpython/venv/privatevenv_common.bzl/
py_venv_common_py_venv_common

�
(//python/venv/private:venv_toolchain.bzlr|
5

rules_venvpython/venv/privatevenv_toolchain.bzl5
py_venv_toolchain_py_venv_toolchain

�
%//python/venv/private:venv_zipapp.bzlrs
2

rules_venvpython/venv/privatevenv_zipapp.bzl/
py_venv_zipapp_py_venv_zipapp

7# Venv

Core Bazel rules for defining Python targets.

�
0

rules_venvpython/venvpy_venv_toolchain.bzl�py_venv_toolchain+Declare a toolchain for `rules_venv` rules."�
�
py_venv_toolchain+Declare a toolchain for `rules_venv` rules.*
nameA unique name for this target. e
zipapp_shebangMThe shebang to use when creating zipapps (`OutputGroupInfo.python_zip_file`).2"""D
py_venv_toolchain/@@rules_venv//python/venv:py_venv_toolchain.bzl
,
*
nameA unique name for this target. g
e
zipapp_shebangMThe shebang to use when creating zipapps (`OutputGroupInfo.python_zip_file`).2""�
(//python/venv/private:venv_toolchain.bzlr|
5

rules_venvpython/venv/privatevenv_toolchain.bzl5
py_venv_toolchain_py_venv_toolchain

# py_venv_toolchain�
-

rules_venvpython/venvpy_venv_zipapp.bzl�py_venv_zipapp�A `py_venv_zipapp` is an executable [Python zipapp](https://docs.python.org/3/library/zipapp.html)
which contains all of the dependencies and runfiles for a given executable.

```python
load("@rules_venv//python/venv:defs.bzl", "py_venv_binary", "py_venv_zipapp")

py_venv_binary(
    name = "foo",
    srcs = ["foo.py"],
)

py_venv_zipapp(
    name = "foo_pyz",
    binary = ":foo",
)
```
"�
�
py_venv_zipapp�A `py_venv_zipapp` is an executable [Python zipapp](https://docs.python.org/3/library/zipapp.html)
which contains all of the dependencies and runfiles for a given executable.

```python
load("@rules_venv//python/venv:defs.bzl", "py_venv_binary", "py_venv_zipapp")

py_venv_binary(
    name = "foo",
    srcs = ["foo.py"],
)

py_venv_zipapp(
    name = "foo_pyz",
    binary = ":foo",
)
```
*
nameA unique name for this target. Q
argsCArguments to add to the beginning of all invocations of the zipapp.2[]>
binary"The binary to package as a zipapp.*
PyInfo2NoneP
envCEnvironment variables to inject into all invocations of the zipapp.
2{}T
inherit_args;Inherit template variable expanded arguments from `binary`.2False_
inherit_envGInherit template variable expanded environment variables from `binary`.2False^
shebangMOptional shebang line to prepend to the zip (provided as content after `#!`).2""">
py_venv_zipapp,@@rules_venv//python/venv:py_venv_zipapp.bzl
��,
*
nameA unique name for this target. S
Q
argsCArguments to add to the beginning of all invocations of the zipapp.2[]@
>
binary"The binary to package as a zipapp.*
PyInfo2NoneR
P
envCEnvironment variables to inject into all invocations of the zipapp.
2{}V
T
inherit_args;Inherit template variable expanded arguments from `binary`.2Falsea
_
inherit_envGInherit template variable expanded environment variables from `binary`.2False`
^
shebangMOptional shebang line to prepend to the zip (provided as content after `#!`).2""�
%//python/venv/private:venv_zipapp.bzlrs
2

rules_venvpython/venv/privatevenv_zipapp.bzl/
py_venv_zipapp_py_venv_zipapp

# py_venv_zipapp��
-

rules_venvpython/wheel/private	wheel.bzl�$current_py_wheel_toolchain_for_twineTA rule for accessing the twine library provided to the current `py_wheel_toolchain`."�
�
$current_py_wheel_toolchain_for_twineTA rule for accessing the twine library provided to the current `py_wheel_toolchain`.*
nameA unique name for this target. "T
$current_py_wheel_toolchain_for_twine,@@rules_venv//python/wheel/private:wheel.bzl
�,�,,
*
nameA unique name for this target. �Gpy_wheel�Internal rule used by the [py_wheel macro](/docs/packaging.md#py_wheel).

These intentionally have the same name to avoid sharp edges with Bazel macros.
For example, a `bazel query` for a user's `py_wheel` macro expands to `py_wheel` targets,
in the way they expect.
"�E
�#
py_wheel�Internal rule used by the [py_wheel macro](/docs/packaging.md#py_wheel).

These intentionally have the same name to avoid sharp edges with Bazel macros.
For example, a `bazel query` for a user's `py_wheel` macro expands to `py_wheel` targets,
in the way they expect.
*
nameA unique name for this target. ?
abi.Python ABI tag. 'none' for pure-Python wheels.2"none">
author.A string specifying the author of the package.2""R
author_email<A string specifying the email address of the package author.2""�
classifierssA list of strings describing the categories for the package. For valid classifiers see https://pypi.org/classifiers2[]�
console_scripts�Deprecated console_script entry points, e.g. `{'main': 'examples.wheel.main:main'}`.

Deprecated: prefer the `entry_points` attribute, which supports `console_scripts` as well as other entry points.

2{}�
deps�Targets to be included in the distribution.

The targets to package are usually `py_library` rules or filesets (for packaging data files).

Note it's usually better to package `py_library` targets and use
`entry_points` attribute to specify `console_scripts` than to package
`py_binary` rules. `py_binary` targets would wrap a executable script that
tries to locate `.runfiles` directory which is not packaged in the wheel.
2[]J
description_file.A file containing text describing the package.2None�
distribution�Name of the distribution.

This should match the project name onm PyPI. It's also the name that is used to
refer to the package in other packages' dependencies.
 c
entry_pointsOentry_points, e.g. `{'console_scripts': ['main = examples.wheel.main:main']}`.
 V
extra_distinfo_files8Extra files to add to distinfo directory in the archive.	2{}D
extra_requires.List of optional requirements for this package G
homepage5A string specifying the URL for the package homepage.2""@
license/A string specifying the license of the package.2""�
platform�Supported platform. Use 'any' for pure-Python wheel.

If you have included platform-specific data, such as a .pyd or .so
extension module, you will need to specify the platform in standard
pip format. If you support multiple platforms, you can define
platform constraints, then use a select() to specify the appropriate
specifier, eg:

`
platform = select({
    "//platforms:windows_x86_64": "win_amd64",
    "//platforms:macos_x86_64": "macosx_10_7_x86_64",
    "//platforms:linux_x86_64": "manylinux2014_x86_64",
})
`
2"any"Y
python_requires@Python versions required by this distribution, e.g. '>=3.5,<3.7'2""N

python_tag7Supported Python version(s), eg `py3`, `cp35.cp36`, etc2"py3"�
requires�List of requirements for this package. See the section on [Declaring required dependency](https://setuptools.readthedocs.io/en/latest/userguide/dependency_management.html#declaring-dependencies) for details and examples of the format of this argument.2[]�
stamp�Whether to encode build information into the wheel. Possible values:

- `stamp = 1`: Always stamp the build information into the wheel, even in [--nostamp](https://docs.bazel.build/versions/main/user-manual.html#flag--stamp) builds. This setting should be avoided, since it potentially kills remote caching for the target and any downstream actions that depend on it.

- `stamp = 0`: Always replace build information by constant values. This gives good build result caching.

- `stamp = -1`: Embedding of build information is controlled by the [--[no]stamp](https://docs.bazel.build/versions/main/user-manual.html#flag--stamp) flag.

Stamped targets are not rebuilt unless their dependencies change.
2-1]
strip_path_prefixes@path prefixes to strip from files added to the generated package2[]�
version�Version number of the package.

Note that this attribute supports stamp format strings as well as 'make variables'.
For example:
  - `version = "1.2.3-{BUILD_TIMESTAMP}"`
  - `version = "{BUILD_EMBED_LABEL}"`
  - `version = "$(VERSION)"`

Note that Bazel's output filename cannot include the stamp information, as outputs must be known
during the analysis phase and the stamp data is available only during the action execution.

The [`py_wheel`](/docs/packaging.md#py_wheel) macro produces a `.dist`-suffix target which creates a
`dist/` folder containing the wheel with the stamped name, suitable for publishing.

See [`py_wheel_dist`](/docs/packaging.md#py_wheel_dist) for more info.
 "8
py_wheel,@@rules_venv//python/wheel/private:wheel.bzl
��,
*
nameA unique name for this target. A
?
abi.Python ABI tag. 'none' for pure-Python wheels.2"none"@
>
author.A string specifying the author of the package.2""T
R
author_email<A string specifying the email address of the package author.2""�
�
classifierssA list of strings describing the categories for the package. For valid classifiers see https://pypi.org/classifiers2[]�
�
console_scripts�Deprecated console_script entry points, e.g. `{'main': 'examples.wheel.main:main'}`.

Deprecated: prefer the `entry_points` attribute, which supports `console_scripts` as well as other entry points.

2{}�
�
deps�Targets to be included in the distribution.

The targets to package are usually `py_library` rules or filesets (for packaging data files).

Note it's usually better to package `py_library` targets and use
`entry_points` attribute to specify `console_scripts` than to package
`py_binary` rules. `py_binary` targets would wrap a executable script that
tries to locate `.runfiles` directory which is not packaged in the wheel.
2[]L
J
description_file.A file containing text describing the package.2None�
�
distribution�Name of the distribution.

This should match the project name onm PyPI. It's also the name that is used to
refer to the package in other packages' dependencies.
 e
c
entry_pointsOentry_points, e.g. `{'console_scripts': ['main = examples.wheel.main:main']}`.
 X
V
extra_distinfo_files8Extra files to add to distinfo directory in the archive.	2{}F
D
extra_requires.List of optional requirements for this package I
G
homepage5A string specifying the URL for the package homepage.2""B
@
license/A string specifying the license of the package.2""�
�
platform�Supported platform. Use 'any' for pure-Python wheel.

If you have included platform-specific data, such as a .pyd or .so
extension module, you will need to specify the platform in standard
pip format. If you support multiple platforms, you can define
platform constraints, then use a select() to specify the appropriate
specifier, eg:

`
platform = select({
    "//platforms:windows_x86_64": "win_amd64",
    "//platforms:macos_x86_64": "macosx_10_7_x86_64",
    "//platforms:linux_x86_64": "manylinux2014_x86_64",
})
`
2"any"[
Y
python_requires@Python versions required by this distribution, e.g. '>=3.5,<3.7'2""P
N

python_tag7Supported Python version(s), eg `py3`, `cp35.cp36`, etc2"py3"�
�
requires�List of requirements for this package. See the section on [Declaring required dependency](https://setuptools.readthedocs.io/en/latest/userguide/dependency_management.html#declaring-dependencies) for details and examples of the format of this argument.2[]�
�
stamp�Whether to encode build information into the wheel. Possible values:

- `stamp = 1`: Always stamp the build information into the wheel, even in [--nostamp](https://docs.bazel.build/versions/main/user-manual.html#flag--stamp) builds. This setting should be avoided, since it potentially kills remote caching for the target and any downstream actions that depend on it.

- `stamp = 0`: Always replace build information by constant values. This gives good build result caching.

- `stamp = -1`: Embedding of build information is controlled by the [--[no]stamp](https://docs.bazel.build/versions/main/user-manual.html#flag--stamp) flag.

Stamped targets are not rebuilt unless their dependencies change.
2-1_
]
strip_path_prefixes@path prefixes to strip from files added to the generated package2[]�
�
version�Version number of the package.

Note that this attribute supports stamp format strings as well as 'make variables'.
For example:
  - `version = "1.2.3-{BUILD_TIMESTAMP}"`
  - `version = "{BUILD_EMBED_LABEL}"`
  - `version = "$(VERSION)"`

Note that Bazel's output filename cannot include the stamp information, as outputs must be known
during the analysis phase and the stamp data is available only during the action execution.

The [`py_wheel`](/docs/packaging.md#py_wheel) macro produces a `.dist`-suffix target which creates a
`dist/` folder containing the wheel with the stamped name, suitable for publishing.

See [`py_wheel_dist`](/docs/packaging.md#py_wheel_dist) for more info.
 �py_wheel_packageAA rule for collecting all files associated with a Python package."�
�
py_wheel_packageAA rule for collecting all files associated with a Python package.*
nameA unique name for this target. {
constraints_file_A file containing python constraints to attach to the detected requirements (`py_library.deps`)2NoneI
out_requires5The output name of the `py_wheel.requires_file` file. D
package+The target representing the Python package. *
PyInfo"@
py_wheel_package,@@rules_venv//python/wheel/private:wheel.bzl
��,
*
nameA unique name for this target. }
{
constraints_file_A file containing python constraints to attach to the detected requirements (`py_library.deps`)2NoneK
I
out_requires5The output name of the `py_wheel.requires_file` file. F
D
package+The target representing the Python package. *
PyInfo�	py_wheel_publisher�A rule for publishing wheels to pypi registries.

The rule uses [twine][tw] to python registries. Users should refer to the documentation there
for any configuration flags (such as auth) needed to deploy to the desired location.

[tw]: https://twine.readthedocs.io/en/stable/index.html#twine
"�
�
py_wheel_publisher�A rule for publishing wheels to pypi registries.

The rule uses [twine][tw] to python registries. Users should refer to the documentation there
for any configuration flags (such as auth) needed to deploy to the desired location.

[tw]: https://twine.readthedocs.io/en/stable/index.html#twine
*
nameA unique name for this target. �
repository_url�The repository (package index) URL to upload the wheel to. If passed the `twine` arg `--repository-url` will be set to this value.2"""
wheelThe wheel to extract. "B
py_wheel_publisher,@@rules_venv//python/wheel/private:wheel.bzl
��,
*
nameA unique name for this target. �
�
repository_url�The repository (package index) URL to upload the wheel to. If passed the `twine` arg `--repository-url` will be set to this value.2""$
"
wheelThe wheel to extract. �py_wheel_toolchain�A toolchain for powering the `py_wheel` rules.

```python
load("@rules_venv//python/wheel:defs.bzl", "py_wheel_toolchain")

py_wheel_toolchain(
    name = "py_wheel_toolchain_impl",
    # Definable using bzlmod modules like: https://github.com/periareon/req-compile
    twine = "@pip_deps//twine",
    visibility = ["//visibility:public"],
)

toolchain(
    name = "py_wheel_toolchain",
    toolchain = ":py_wheel_toolchain_impl",
    toolchain_type = "@rules_venv//python/wheel:toolchain_type",
    visibility = ["//visibility:public"],
)
```
"�
�
py_wheel_toolchain�A toolchain for powering the `py_wheel` rules.

```python
load("@rules_venv//python/wheel:defs.bzl", "py_wheel_toolchain")

py_wheel_toolchain(
    name = "py_wheel_toolchain_impl",
    # Definable using bzlmod modules like: https://github.com/periareon/req-compile
    twine = "@pip_deps//twine",
    visibility = ["//visibility:public"],
)

toolchain(
    name = "py_wheel_toolchain",
    toolchain = ":py_wheel_toolchain_impl",
    toolchain_type = "@rules_venv//python/wheel:toolchain_type",
    visibility = ["//visibility:public"],
)
```
*
nameA unique name for this target. [
twineDA `py_library` for [twine](https://twine.readthedocs.io/en/stable/). *
PyInfo"B
py_wheel_toolchain,@@rules_venv//python/wheel/private:wheel.bzl
��,
*
nameA unique name for this target. ]
[
twineDA `py_library` for [twine](https://twine.readthedocs.io/en/stable/). *
PyInfo�py_wheel_library�	Define a `py_library` with an associated wheel.

This rule will traverse dependencies (`deps`) to collect all data and dependencies
that belong to the current package. Any dependency tagged with the `package_tag` whose
name matches this targets name will be considered a submodule and included in the package.

Example:

```python
load("@rules_venv//python:defs.bzl", "py_library")
load("@rules_venv//python/wheel:defs.bzl", "package_tag", "py_wheel_library")

py_library(
    name = "submodule",
    srcs = ["submodule.py"],
    tags = [
        # Note this name matches the name of the `py_wheel_library` target
        # and as a result will be included as a submodule within the wheel.
        package_tag("my_py_package")
    ],
)

py_wheel_library(
    name = "my_py_package",
    deps = [":submodule"],
)
```

Targets created by this library:

| name | details |
| --- | --- |
| `{name}` | The `py_library` target for the wheel. |
| `{name}.whl` | The `py_wheel` target created from the `{name}` target. |
| `{name}.publish` | A [`py_wheel_publisher`](#py_wheel_publisher) target for publishing the wheel to a remote index. Defined only with `repository_url`. |


A library of Python code that can be depended upon.
"�
�
py_wheel_library�	Define a `py_library` with an associated wheel.

This rule will traverse dependencies (`deps`) to collect all data and dependencies
that belong to the current package. Any dependency tagged with the `package_tag` whose
name matches this targets name will be considered a submodule and included in the package.

Example:

```python
load("@rules_venv//python:defs.bzl", "py_library")
load("@rules_venv//python/wheel:defs.bzl", "package_tag", "py_wheel_library")

py_library(
    name = "submodule",
    srcs = ["submodule.py"],
    tags = [
        # Note this name matches the name of the `py_wheel_library` target
        # and as a result will be included as a submodule within the wheel.
        package_tag("my_py_package")
    ],
)

py_wheel_library(
    name = "my_py_package",
    deps = [":submodule"],
)
```

Targets created by this library:

| name | details |
| --- | --- |
| `{name}` | The `py_library` target for the wheel. |
| `{name}.whl` | The `py_wheel` target created from the `{name}` target. |
| `{name}.publish` | A [`py_wheel_publisher`](#py_wheel_publisher) target for publishing the wheel to a remote index. Defined only with `repository_url`. |


A library of Python code that can be depended upon.
*
nameA unique name for this target. o
dataaFiles needed by this rule at runtime. May list file or rule targets. Generally allows any target.2[]K
deps3Other python targets to link to the current target.*
PyInfo2[]L
imports;List of import directories to be added to the `PYTHONPATH`.2[]U
srcsGThe list of source (.py) files that are processed to create the target.2[]
��,
*
nameA unique name for this target. q
o
dataaFiles needed by this rule at runtime. May list file or rule targets. Generally allows any target.2[]M
K
deps3Other python targets to link to the current target.*
PyInfo2[]N
L
imports;List of import directories to be added to the `PYTHONPATH`.2[]W
U
srcsGThe list of source (.py) files that are processed to create the target.2[]�package_tag�Generate a tag used to associate the target with a python package.

This tag should only be applied to other `py_*` targets.

Example:

```python
load("@rules_venv//python:defs.bzl", "py_library")
load("@rules_venv//python/wheel:defs.bzl", "package_tag")

py_library(
    name = "my_target",
    tags = [package_tag("my_python_package")],
    # ...
    # ...
    # ...
)
```
*�
�
package_tag#
nameThe name of the package (�Generate a tag used to associate the target with a python package.

This tag should only be applied to other `py_*` targets.

Example:

```python
load("@rules_venv//python:defs.bzl", "py_library")
load("@rules_venv//python/wheel:defs.bzl", "package_tag")

py_library(
    name = "my_target",
    tags = [package_tag("my_python_package")],
    # ...
    # ...
    # ...
)
```
"
str: The tag.2;
package_tag,@@rules_venv//python/wheel/private:wheel.bzl
�PyWheelPackageInfoHA provider describing the association of a target with a Python package.2�
�
PyWheelPackageInfoHA provider describing the association of a target with a Python package.`
depsXDepset[Label]: The labels of all direct dependencies to the package and it's submodules.l
filescDepset[File]: A collection of all files (including runfiles) from the target and it's dependencies.~
packagesrDepset[str]: The name of all top level packages the current target can opt into. `*` is reserved for all packages."B
PyWheelPackageInfo,@@rules_venv//python/wheel/private:wheel.bzl
((b
`
depsXDepset[Label]: The labels of all direct dependencies to the package and it's submodules.n
l
filescDepset[File]: A collection of all files (including runfiles) from the target and it's dependencies.�
~
packagesrDepset[str]: The name of all top level packages the current target can opt into. `*` is reserved for all packages.�py_wheel_package_aspectRAn aspect for collecting info and data from python submodules of a python package.:�
�
py_wheel_package_aspectRAn aspect for collecting info and data from python submodules of a python package.deps"*
nameA unique name for this target. *G
py_wheel_package_aspect,@@rules_venv//python/wheel/private:wheel.bzl
}!}!,
*
nameA unique name for this target. �
//python:packaging.bzlr�
%
rules_pythonpythonpackaging.bzl(
PyWheelInfoPyWheelInfo
.9,
py_wheel_rulepy_wheel_rule
=J
L�
//python:defs.bzlrv


rules_venvpythondefs.bzl
PyInfoPyInfo
'-&

py_library
py_library
1;
=Bazel rules for Python wheels.�H
$

rules_venvpython/wheeldefs.bzl�	py_wheel_publisher�A rule for publishing wheels to pypi registries.

The rule uses [twine][tw] to python registries. Users should refer to the documentation there
for any configuration flags (such as auth) needed to deploy to the desired location.

[tw]: https://twine.readthedocs.io/en/stable/index.html#twine
"�
�
py_wheel_publisher�A rule for publishing wheels to pypi registries.

The rule uses [twine][tw] to python registries. Users should refer to the documentation there
for any configuration flags (such as auth) needed to deploy to the desired location.

[tw]: https://twine.readthedocs.io/en/stable/index.html#twine
*
nameA unique name for this target. �
repository_url�The repository (package index) URL to upload the wheel to. If passed the `twine` arg `--repository-url` will be set to this value.2"""
wheelThe wheel to extract. "9
py_wheel_publisher#@@rules_venv//python/wheel:defs.bzl
��,
*
nameA unique name for this target. �
�
repository_url�The repository (package index) URL to upload the wheel to. If passed the `twine` arg `--repository-url` will be set to this value.2""$
"
wheelThe wheel to extract. �py_wheel_toolchain�A toolchain for powering the `py_wheel` rules.

```python
load("@rules_venv//python/wheel:defs.bzl", "py_wheel_toolchain")

py_wheel_toolchain(
    name = "py_wheel_toolchain_impl",
    # Definable using bzlmod modules like: https://github.com/periareon/req-compile
    twine = "@pip_deps//twine",
    visibility = ["//visibility:public"],
)

toolchain(
    name = "py_wheel_toolchain",
    toolchain = ":py_wheel_toolchain_impl",
    toolchain_type = "@rules_venv//python/wheel:toolchain_type",
    visibility = ["//visibility:public"],
)
```
"�
�
py_wheel_toolchain�A toolchain for powering the `py_wheel` rules.

```python
load("@rules_venv//python/wheel:defs.bzl", "py_wheel_toolchain")

py_wheel_toolchain(
    name = "py_wheel_toolchain_impl",
    # Definable using bzlmod modules like: https://github.com/periareon/req-compile
    twine = "@pip_deps//twine",
    visibility = ["//visibility:public"],
)

toolchain(
    name = "py_wheel_toolchain",
    toolchain = ":py_wheel_toolchain_impl",
    toolchain_type = "@rules_venv//python/wheel:toolchain_type",
    visibility = ["//visibility:public"],
)
```
*
nameA unique name for this target. [
twineDA `py_library` for [twine](https://twine.readthedocs.io/en/stable/). *
PyInfo"9
py_wheel_toolchain#@@rules_venv//python/wheel:defs.bzl
��,
*
nameA unique name for this target. ]
[
twineDA `py_library` for [twine](https://twine.readthedocs.io/en/stable/). *
PyInfo�py_wheel_library�	Define a `py_library` with an associated wheel.

This rule will traverse dependencies (`deps`) to collect all data and dependencies
that belong to the current package. Any dependency tagged with the `package_tag` whose
name matches this targets name will be considered a submodule and included in the package.

Example:

```python
load("@rules_venv//python:defs.bzl", "py_library")
load("@rules_venv//python/wheel:defs.bzl", "package_tag", "py_wheel_library")

py_library(
    name = "submodule",
    srcs = ["submodule.py"],
    tags = [
        # Note this name matches the name of the `py_wheel_library` target
        # and as a result will be included as a submodule within the wheel.
        package_tag("my_py_package")
    ],
)

py_wheel_library(
    name = "my_py_package",
    deps = [":submodule"],
)
```

Targets created by this library:

| name | details |
| --- | --- |
| `{name}` | The `py_library` target for the wheel. |
| `{name}.whl` | The `py_wheel` target created from the `{name}` target. |
| `{name}.publish` | A [`py_wheel_publisher`](#py_wheel_publisher) target for publishing the wheel to a remote index. Defined only with `repository_url`. |


A library of Python code that can be depended upon.
"�
�
py_wheel_library�	Define a `py_library` with an associated wheel.

This rule will traverse dependencies (`deps`) to collect all data and dependencies
that belong to the current package. Any dependency tagged with the `package_tag` whose
name matches this targets name will be considered a submodule and included in the package.

Example:

```python
load("@rules_venv//python:defs.bzl", "py_library")
load("@rules_venv//python/wheel:defs.bzl", "package_tag", "py_wheel_library")

py_library(
    name = "submodule",
    srcs = ["submodule.py"],
    tags = [
        # Note this name matches the name of the `py_wheel_library` target
        # and as a result will be included as a submodule within the wheel.
        package_tag("my_py_package")
    ],
)

py_wheel_library(
    name = "my_py_package",
    deps = [":submodule"],
)
```

Targets created by this library:

| name | details |
| --- | --- |
| `{name}` | The `py_library` target for the wheel. |
| `{name}.whl` | The `py_wheel` target created from the `{name}` target. |
| `{name}.publish` | A [`py_wheel_publisher`](#py_wheel_publisher) target for publishing the wheel to a remote index. Defined only with `repository_url`. |


A library of Python code that can be depended upon.
*
nameA unique name for this target. o
dataaFiles needed by this rule at runtime. May list file or rule targets. Generally allows any target.2[]K
deps3Other python targets to link to the current target.*
PyInfo2[]L
imports;List of import directories to be added to the `PYTHONPATH`.2[]U
srcsGThe list of source (.py) files that are processed to create the target.2[]
��,
*
nameA unique name for this target. q
o
dataaFiles needed by this rule at runtime. May list file or rule targets. Generally allows any target.2[]M
K
deps3Other python targets to link to the current target.*
PyInfo2[]N
L
imports;List of import directories to be added to the `PYTHONPATH`.2[]W
U
srcsGThe list of source (.py) files that are processed to create the target.2[]�package_tag�Generate a tag used to associate the target with a python package.

This tag should only be applied to other `py_*` targets.

Example:

```python
load("@rules_venv//python:defs.bzl", "py_library")
load("@rules_venv//python/wheel:defs.bzl", "package_tag")

py_library(
    name = "my_target",
    tags = [package_tag("my_python_package")],
    # ...
    # ...
    # ...
)
```
*�
�
package_tag#
nameThe name of the package (�Generate a tag used to associate the target with a python package.

This tag should only be applied to other `py_*` targets.

Example:

```python
load("@rules_venv//python:defs.bzl", "py_library")
load("@rules_venv//python/wheel:defs.bzl", "package_tag")

py_library(
    name = "my_target",
    tags = [package_tag("my_python_package")],
    # ...
    # ...
    # ...
)
```
"
str: The tag.2;
package_tag,@@rules_venv//python/wheel/private:wheel.bzl
�
//python/wheel:package_tag.bzlrf
+

rules_venvpython/wheelpackage_tag.bzl)
package_tag_package_tag
;;
9<�
#//python/wheel:py_wheel_library.bzlru
0

rules_venvpython/wheelpy_wheel_library.bzl3
py_wheel_library_py_wheel_library
??
=@�
%//python/wheel:py_wheel_publisher.bzlr{
2

rules_venvpython/wheelpy_wheel_publisher.bzl7
py_wheel_publisher_py_wheel_publisher
CC
AD�
%//python/wheel:py_wheel_toolchain.bzlr{
2

rules_venvpython/wheelpy_wheel_toolchain.bzl7
py_wheel_toolchain_py_wheel_toolchain
GG
EH�# Wheel

A framework for defining [wheels][whl] from a tree of Bazel targets.

[whl]: https://packaging.python.org/en/latest/specifications/binary-distribution-format/

## Why use this over what `rules_python` provides?

The rules here primarily wrap what rules_python provides but offers some improvements:

1. Requirements are collected from transitive dependencies and added as `Require-Dist` to the wheel.
2. Sources and data are automatically collected.

## Setup

Building wheels requires no setup, however, to activate all features of
the wheel rules, a toolchain must be registered.

First some external python requirements will be required. There is guidance on
how to configure this in projects like [rules_req_compile]( https://github.com/periareon/req-compile).
Once there is a means to fetch external dependencies within your repository, a
toolchain can be defined in a `BUILD.bazel` file.

Example `//:BUILD.bazel`:

```python
load("@rules_venv//python/wheel:defs.bzl", "py_wheel_toolchain")

py_wheel_toolchain(
    name = "py_wheel_toolchain_impl",
    # Definable using bzlmod modules like: https://github.com/periareon/req-compile
    twine = "@pip_deps//twine",
    visibility = ["//visibility:public"],
)

toolchain(
    name = "py_wheel_toolchain",
    toolchain = ":py_wheel_toolchain_impl",
    toolchain_type = "@rules_venv//python/wheel:toolchain_type",
    visibility = ["//visibility:public"],
)
```

Once the toolchain is defined, it should be registered in the `MODULE.bazel` file

Example `//:MODULE.bazel`:

```python
register_toolchains(
    "//:py_wheel_toolchain",
)
```

This will ensure all features of the wheel rules are available and usable.
�
+

rules_venvpython/wheelpackage_tag.bzl�package_tag�Generate a tag used to associate the target with a python package.

This tag should only be applied to other `py_*` targets.

Example:

```python
load("@rules_venv//python:defs.bzl", "py_library")
load("@rules_venv//python/wheel:defs.bzl", "package_tag")

py_library(
    name = "my_target",
    tags = [package_tag("my_python_package")],
    # ...
    # ...
    # ...
)
```
*�
�
package_tag#
nameThe name of the package (�Generate a tag used to associate the target with a python package.

This tag should only be applied to other `py_*` targets.

Example:

```python
load("@rules_venv//python:defs.bzl", "py_library")
load("@rules_venv//python/wheel:defs.bzl", "package_tag")

py_library(
    name = "my_target",
    tags = [package_tag("my_python_package")],
    # ...
    # ...
    # ...
)
```
"
str: The tag.2;
package_tag,@@rules_venv//python/wheel/private:wheel.bzl
�
 //python/wheel/private:wheel.bzlrh
-

rules_venvpython/wheel/private	wheel.bzl)
package_tag_package_tag

# package_tag�
0

rules_venvpython/wheelpy_wheel_library.bzl�py_wheel_library�	Define a `py_library` with an associated wheel.

This rule will traverse dependencies (`deps`) to collect all data and dependencies
that belong to the current package. Any dependency tagged with the `package_tag` whose
name matches this targets name will be considered a submodule and included in the package.

Example:

```python
load("@rules_venv//python:defs.bzl", "py_library")
load("@rules_venv//python/wheel:defs.bzl", "package_tag", "py_wheel_library")

py_library(
    name = "submodule",
    srcs = ["submodule.py"],
    tags = [
        # Note this name matches the name of the `py_wheel_library` target
        # and as a result will be included as a submodule within the wheel.
        package_tag("my_py_package")
    ],
)

py_wheel_library(
    name = "my_py_package",
    deps = [":submodule"],
)
```

Targets created by this library:

| name | details |
| --- | --- |
| `{name}` | The `py_library` target for the wheel. |
| `{name}.whl` | The `py_wheel` target created from the `{name}` target. |
| `{name}.publish` | A [`py_wheel_publisher`](#py_wheel_publisher) target for publishing the wheel to a remote index. Defined only with `repository_url`. |


A library of Python code that can be depended upon.
"�
�
py_wheel_library�	Define a `py_library` with an associated wheel.

This rule will traverse dependencies (`deps`) to collect all data and dependencies
that belong to the current package. Any dependency tagged with the `package_tag` whose
name matches this targets name will be considered a submodule and included in the package.

Example:

```python
load("@rules_venv//python:defs.bzl", "py_library")
load("@rules_venv//python/wheel:defs.bzl", "package_tag", "py_wheel_library")

py_library(
    name = "submodule",
    srcs = ["submodule.py"],
    tags = [
        # Note this name matches the name of the `py_wheel_library` target
        # and as a result will be included as a submodule within the wheel.
        package_tag("my_py_package")
    ],
)

py_wheel_library(
    name = "my_py_package",
    deps = [":submodule"],
)
```

Targets created by this library:

| name | details |
| --- | --- |
| `{name}` | The `py_library` target for the wheel. |
| `{name}.whl` | The `py_wheel` target created from the `{name}` target. |
| `{name}.publish` | A [`py_wheel_publisher`](#py_wheel_publisher) target for publishing the wheel to a remote index. Defined only with `repository_url`. |


A library of Python code that can be depended upon.
*
nameA unique name for this target. o
dataaFiles needed by this rule at runtime. May list file or rule targets. Generally allows any target.2[]K
deps3Other python targets to link to the current target.*
PyInfo2[]L
imports;List of import directories to be added to the `PYTHONPATH`.2[]U
srcsGThe list of source (.py) files that are processed to create the target.2[]
��,
*
nameA unique name for this target. q
o
dataaFiles needed by this rule at runtime. May list file or rule targets. Generally allows any target.2[]M
K
deps3Other python targets to link to the current target.*
PyInfo2[]N
L
imports;List of import directories to be added to the `PYTHONPATH`.2[]W
U
srcsGThe list of source (.py) files that are processed to create the target.2[]�
 //python/wheel/private:wheel.bzlrr
-

rules_venvpython/wheel/private	wheel.bzl3
py_wheel_library_py_wheel_library

# py_wheel_library�
2

rules_venvpython/wheelpy_wheel_publisher.bzl�	py_wheel_publisher�A rule for publishing wheels to pypi registries.

The rule uses [twine][tw] to python registries. Users should refer to the documentation there
for any configuration flags (such as auth) needed to deploy to the desired location.

[tw]: https://twine.readthedocs.io/en/stable/index.html#twine
"�
�
py_wheel_publisher�A rule for publishing wheels to pypi registries.

The rule uses [twine][tw] to python registries. Users should refer to the documentation there
for any configuration flags (such as auth) needed to deploy to the desired location.

[tw]: https://twine.readthedocs.io/en/stable/index.html#twine
*
nameA unique name for this target. �
repository_url�The repository (package index) URL to upload the wheel to. If passed the `twine` arg `--repository-url` will be set to this value.2"""
wheelThe wheel to extract. "G
py_wheel_publisher1@@rules_venv//python/wheel:py_wheel_publisher.bzl
��,
*
nameA unique name for this target. �
�
repository_url�The repository (package index) URL to upload the wheel to. If passed the `twine` arg `--repository-url` will be set to this value.2""$
"
wheelThe wheel to extract. �
 //python/wheel/private:wheel.bzlrv
-

rules_venvpython/wheel/private	wheel.bzl7
py_wheel_publisher_py_wheel_publisher

# py_wheel_publisher�
2

rules_venvpython/wheelpy_wheel_toolchain.bzl�py_wheel_toolchain�A toolchain for powering the `py_wheel` rules.

```python
load("@rules_venv//python/wheel:defs.bzl", "py_wheel_toolchain")

py_wheel_toolchain(
    name = "py_wheel_toolchain_impl",
    # Definable using bzlmod modules like: https://github.com/periareon/req-compile
    twine = "@pip_deps//twine",
    visibility = ["//visibility:public"],
)

toolchain(
    name = "py_wheel_toolchain",
    toolchain = ":py_wheel_toolchain_impl",
    toolchain_type = "@rules_venv//python/wheel:toolchain_type",
    visibility = ["//visibility:public"],
)
```
"�
�
py_wheel_toolchain�A toolchain for powering the `py_wheel` rules.

```python
load("@rules_venv//python/wheel:defs.bzl", "py_wheel_toolchain")

py_wheel_toolchain(
    name = "py_wheel_toolchain_impl",
    # Definable using bzlmod modules like: https://github.com/periareon/req-compile
    twine = "@pip_deps//twine",
    visibility = ["//visibility:public"],
)

toolchain(
    name = "py_wheel_toolchain",
    toolchain = ":py_wheel_toolchain_impl",
    toolchain_type = "@rules_venv//python/wheel:toolchain_type",
    visibility = ["//visibility:public"],
)
```
*
nameA unique name for this target. [
twineDA `py_library` for [twine](https://twine.readthedocs.io/en/stable/). *
PyInfo"G
py_wheel_toolchain1@@rules_venv//python/wheel:py_wheel_toolchain.bzl
��,
*
nameA unique name for this target. ]
[
twineDA `py_library` for [twine](https://twine.readthedocs.io/en/stable/). *
PyInfo�
 //python/wheel/private:wheel.bzlrv
-

rules_venvpython/wheel/private	wheel.bzl7
py_wheel_toolchain_py_wheel_toolchain

# py_wheel_toolchain��


rules_venvpythondefs.bzl�	py_binary�A `py_venv_binary` is an executable Python program consisting of a collection of
`.py` source files (possibly belonging to other `py_library` rules), a `*.runfiles`
directory tree containing all the code and data needed by the program at run-time,
and a stub script that starts up the program with the correct initial environment
and data.

```python
load("@rules_venv//python/venv:defs.bzl", "py_venv_binary")

py_venv_binary(
    name = "foo",
    srcs = ["foo.py"],
    data = [":transform"],  # a cc_binary which we invoke at run time
    deps = [
        ":bar",  # a py_library
    ],
)
```
"�
�
	py_binary�A `py_venv_binary` is an executable Python program consisting of a collection of
`.py` source files (possibly belonging to other `py_library` rules), a `*.runfiles`
directory tree containing all the code and data needed by the program at run-time,
and a stub script that starts up the program with the correct initial environment
and data.

```python
load("@rules_venv//python/venv:defs.bzl", "py_venv_binary")

py_venv_binary(
    name = "foo",
    srcs = ["foo.py"],
    data = [":transform"],  # a cc_binary which we invoke at run time
    deps = [
        ":bar",  # a py_library
    ],
)
```
*
nameA unique name for this target. o
dataaFiles needed by this rule at runtime. May list file or rule targets. Generally allows any target.2[]K
deps3Other python targets to link to the current target.*
PyInfo2[]i
env\Dictionary of strings; values are subject to `$(location)` and "Make variable" substitution.
2{}L
imports;List of import directories to be added to the `PYTHONPATH`.2[]�
main�The name of the source file that is the main entry point of the application. This file must also be listed in `srcs`. If left unspecified, `name` is used instead. If `name` does not match any filename in `srcs`, `main` must be specified. 2NoneU
srcsGThe list of source (.py) files that are processed to create the target.2[]"*
	py_binary@@rules_venv//python:defs.bzl
��,
*
nameA unique name for this target. q
o
dataaFiles needed by this rule at runtime. May list file or rule targets. Generally allows any target.2[]M
K
deps3Other python targets to link to the current target.*
PyInfo2[]k
i
env\Dictionary of strings; values are subject to `$(location)` and "Make variable" substitution.
2{}N
L
imports;List of import directories to be added to the `PYTHONPATH`.2[]�
�
main�The name of the source file that is the main entry point of the application. This file must also be listed in `srcs`. If left unspecified, `name` is used instead. If `name` does not match any filename in `srcs`, `main` must be specified. 2NoneW
U
srcsGThe list of source (.py) files that are processed to create the target.2[]�	py_import�This rule allows the use of Python packages as dependencies.

It imports the given `.egg` file(s), which might be checked in source files,
fetched externally as with `http_file`, or produced as outputs of other rules.

It may be used like a `py_library`, in the `deps` of other Python rules.

This is similar to [java_import](https://docs.bazel.build/versions/master/be/java.html#java_import).
"�	
�
	py_import�This rule allows the use of Python packages as dependencies.

It imports the given `.egg` file(s), which might be checked in source files,
fetched externally as with `http_file`, or produced as outputs of other rules.

It may be used like a `py_library`, in the `deps` of other Python rules.

This is similar to [java_import](https://docs.bazel.build/versions/master/be/java.html#java_import).
*
nameA unique name for this target. Y
depsAThe list of other libraries to be linked in to the binary target.*
PyInfo2[]�
srcs�The list of Python package files provided to Python targets that depend on this target. Note that currently only the .egg format is accepted. For .whl files, try the whl_library rule. We accept contributions to extend py_import to handle .whl.2[]"*
	py_import@@rules_venv//python:defs.bzl
**,
*
nameA unique name for this target. [
Y
depsAThe list of other libraries to be linked in to the binary target.*
PyInfo2[]�
�
srcs�The list of Python package files provided to Python targets that depend on this target. Note that currently only the .egg format is accepted. For .whl files, try the whl_library rule. We accept contributions to extend py_import to handle .whl.2[]�
py_library4A library of Python code that can be depended upon.
"�
�

py_library4A library of Python code that can be depended upon.
*
nameA unique name for this target. o
dataaFiles needed by this rule at runtime. May list file or rule targets. Generally allows any target.2[]K
deps3Other python targets to link to the current target.*
PyInfo2[]L
imports;List of import directories to be added to the `PYTHONPATH`.2[]U
srcsGThe list of source (.py) files that are processed to create the target.2[]"+

py_library@@rules_venv//python:defs.bzl
==,
*
nameA unique name for this target. q
o
dataaFiles needed by this rule at runtime. May list file or rule targets. Generally allows any target.2[]M
K
deps3Other python targets to link to the current target.*
PyInfo2[]N
L
imports;List of import directories to be added to the `PYTHONPATH`.2[]W
U
srcsGThe list of source (.py) files that are processed to create the target.2[]�
py_runtime�Creates an executable Python program.

This is the public macro wrapping the underlying rule. Args are forwarded
on as-is unless otherwise specified. See
{rule}`py_runtime`
for detailed attribute documentation.

This macro affects the following args:
* `python_version`: cannot be `PY2`
* `srcs_version`: cannot be `PY2` or `PY2ONLY`
* `tags`: May have special marker values added, if not already present.
*�
�

py_runtime=
attrs2Rule attributes forwarded onto {rule}`py_runtime`.(�Creates an executable Python program.

This is the public macro wrapping the underlying rule. Args are forwarded
on as-is unless otherwise specified. See
{rule}`py_runtime`
for detailed attribute documentation.

This macro affects the following args:
* `python_version`: cannot be `PY2`
* `srcs_version`: cannot be `PY2` or `PY2ONLY`
* `tags`: May have special marker values added, if not already present.
23

py_runtime%@@rules_python//python:py_runtime.bzl
*_py_runtime�QPyInfo�Encapsulates information provided by the Python rules.

Instead of creating this object directly, use {obj}`PyInfoBuilder` and
the {obj}`PyCommonApi` utilities.
2�O
�(
PyInfo�Encapsulates information provided by the Python rules.

Instead of creating this object directly, use {obj}`PyInfoBuilder` and
the {obj}`PyCommonApi` utilities.
�
direct_original_sources�
:type: depset[File]

The `.py` source files (if any) that are considered directly provided by
the target. This field is intended so that static analysis tools can recover the
original Python source files, regardless of any build settings (e.g.
precompiling), so they can analyze source code. The values are typically the
`.py` files in the `srcs` attribute (or equivalent).

::::{versionadded} 1.1.0
::::
�
direct_pyc_files�
:type: depset[File]

Precompiled Python files that are considered directly provided
by the target and **must be included**.

These files usually come from, e.g., a library setting {attr}`precompile=enabled`
to forcibly enable precompiling for itself. Downstream binaries are expected
to always include these files, as the originating target expects them to exist.
�
direct_pyi_files�
:type: depset[File]

Type definition files (usually `.pyi` files) for the Python modules provided by
this target. Usually they describe the source files listed in
`direct_original_sources`. This field is primarily for static analysis tools.

These files are _usually_ build-time only and not included as part of a runnable
program.

:::{note}
This may contain implementation-specific file types specific to a particular
type checker.
:::

::::{versionadded} 1.1.0
::::
s
has_py2_only_sources[
:type: bool

Whether any of this target's transitive sources requires a Python 2 runtime.
s
has_py3_only_sources[
:type: bool

Whether any of this target's transitive sources requires a Python 3 runtime.
�
imports�:type: depset[str]

A depset of import path strings to be added to the `PYTHONPATH` of executable
Python targets. These are accumulated from the transitive `deps`.
The order of the depset is not guaranteed and may be changed in the future. It
is recommended to use `default` order (the default).
�
transitive_implicit_pyc_files�
:type: depset[File]

Automatically generated pyc files that downstream binaries (or equivalent)
can choose to include in their output. If not included, then
{obj}`transitive_implicit_pyc_source_files` should be included instead.

::::{versionadded} 0.37.0
::::
�
$transitive_implicit_pyc_source_files�
:type: depset[File]

Source `.py` files for {obj}`transitive_implicit_pyc_files` that downstream
binaries (or equivalent) can choose to include in their output. If not included,
then {obj}`transitive_implicit_pyc_files` should be included instead.

::::{versionadded} 0.37.0
::::
�
transitive_original_sources�
:type: depset[File]

The transitive set of `.py` source files (if any) that are considered the
original sources for this target and its transitive dependencies. This field is
intended so that static analysis tools can recover the original Python source
files, regardless of any build settings (e.g. precompiling), so they can analyze
source code. The values are typically the `.py` files in the `srcs` attribute
(or equivalent).

This is superset of `direct_original_sources`.

::::{versionadded} 1.1.0
::::
�
transitive_pyc_files�
:type: depset[File]

The transitive set of precompiled files that must be included.

These files usually come from, e.g., a library setting {attr}`precompile=enabled`
to forcibly enable precompiling for itself. Downstream binaries are expected
to always include these files, as the originating target expects them to exist.
�
transitive_pyi_files�
:type: depset[File]

The transitive set of type definition files (usually `.pyi` files) for the
Python modules for this target and its transitive dependencies. this target.
Usually they describe the source files listed in `transitive_original_sources`.
This field is primarily for static analysis tools.

These files are _usually_ build-time only and not included as part of a runnable
program.

:::{note}
This may contain implementation-specific file types specific to a particular
type checker.
:::

::::{versionadded} 1.1.0
::::
�
transitive_sources�:type: depset[File]

A (`postorder`-compatible) depset of `.py` files that are considered required
and downstream binaries (or equivalent) **must** include in their outputs
to have a functioning program.

Normally, these are the `.py` files in the appearing in the target's `srcs` and
the `srcs` of the target's transitive `deps`, **however**, precompile settings
may cause `.py` files to be omitted. In particular, pyc-only builds may result
in this depset being **empty**.

::::{versionchanged} 0.37.0
The files are considered necessary for downstream binaries to function;
previously they were considerd informational and largely unused.
::::
�
uses_shared_libraries�
:type: bool

Whether any of this target's transitive `deps` has a shared library file (such
as a `.so` file).

This field is currently unused in Bazel and may go away in the future.
�
venv_symlinkso
:type: depset[VenvSymlinkEntry]

:::{include} /_includes/experimental_api.md
:::

:::{versionadded} 1.5.0
:::
"'
PyInfo@@rules_venv//python:defs.bzl
�,�,�
�
direct_original_sources�
:type: depset[File]

The `.py` source files (if any) that are considered directly provided by
the target. This field is intended so that static analysis tools can recover the
original Python source files, regardless of any build settings (e.g.
precompiling), so they can analyze source code. The values are typically the
`.py` files in the `srcs` attribute (or equivalent).

::::{versionadded} 1.1.0
::::
�
�
direct_pyc_files�
:type: depset[File]

Precompiled Python files that are considered directly provided
by the target and **must be included**.

These files usually come from, e.g., a library setting {attr}`precompile=enabled`
to forcibly enable precompiling for itself. Downstream binaries are expected
to always include these files, as the originating target expects them to exist.
�
�
direct_pyi_files�
:type: depset[File]

Type definition files (usually `.pyi` files) for the Python modules provided by
this target. Usually they describe the source files listed in
`direct_original_sources`. This field is primarily for static analysis tools.

These files are _usually_ build-time only and not included as part of a runnable
program.

:::{note}
This may contain implementation-specific file types specific to a particular
type checker.
:::

::::{versionadded} 1.1.0
::::
u
s
has_py2_only_sources[
:type: bool

Whether any of this target's transitive sources requires a Python 2 runtime.
u
s
has_py3_only_sources[
:type: bool

Whether any of this target's transitive sources requires a Python 3 runtime.
�
�
imports�:type: depset[str]

A depset of import path strings to be added to the `PYTHONPATH` of executable
Python targets. These are accumulated from the transitive `deps`.
The order of the depset is not guaranteed and may be changed in the future. It
is recommended to use `default` order (the default).
�
�
transitive_implicit_pyc_files�
:type: depset[File]

Automatically generated pyc files that downstream binaries (or equivalent)
can choose to include in their output. If not included, then
{obj}`transitive_implicit_pyc_source_files` should be included instead.

::::{versionadded} 0.37.0
::::
�
�
$transitive_implicit_pyc_source_files�
:type: depset[File]

Source `.py` files for {obj}`transitive_implicit_pyc_files` that downstream
binaries (or equivalent) can choose to include in their output. If not included,
then {obj}`transitive_implicit_pyc_files` should be included instead.

::::{versionadded} 0.37.0
::::
�
�
transitive_original_sources�
:type: depset[File]

The transitive set of `.py` source files (if any) that are considered the
original sources for this target and its transitive dependencies. This field is
intended so that static analysis tools can recover the original Python source
files, regardless of any build settings (e.g. precompiling), so they can analyze
source code. The values are typically the `.py` files in the `srcs` attribute
(or equivalent).

This is superset of `direct_original_sources`.

::::{versionadded} 1.1.0
::::
�
�
transitive_pyc_files�
:type: depset[File]

The transitive set of precompiled files that must be included.

These files usually come from, e.g., a library setting {attr}`precompile=enabled`
to forcibly enable precompiling for itself. Downstream binaries are expected
to always include these files, as the originating target expects them to exist.
�
�
transitive_pyi_files�
:type: depset[File]

The transitive set of type definition files (usually `.pyi` files) for the
Python modules for this target and its transitive dependencies. this target.
Usually they describe the source files listed in `transitive_original_sources`.
This field is primarily for static analysis tools.

These files are _usually_ build-time only and not included as part of a runnable
program.

:::{note}
This may contain implementation-specific file types specific to a particular
type checker.
:::

::::{versionadded} 1.1.0
::::
�
�
transitive_sources�:type: depset[File]

A (`postorder`-compatible) depset of `.py` files that are considered required
and downstream binaries (or equivalent) **must** include in their outputs
to have a functioning program.

Normally, these are the `.py` files in the appearing in the target's `srcs` and
the `srcs` of the target's transitive `deps`, **however**, precompile settings
may cause `.py` files to be omitted. In particular, pyc-only builds may result
in this depset being **empty**.

::::{versionchanged} 0.37.0
The files are considered necessary for downstream binaries to function;
previously they were considerd informational and largely unused.
::::
�
�
uses_shared_libraries�
:type: bool

Whether any of this target's transitive `deps` has a shared library file (such
as a `.so` file).

This field is currently unused in Bazel and may go away in the future.
�
�
venv_symlinkso
:type: depset[VenvSymlinkEntry]

:::{include} /_includes/experimental_api.md
:::

:::{versionadded} 1.5.0
:::
�PyRuntimeInfo�Contains information about a Python runtime, as returned by the `py_runtime`
rule.

:::{warning}
This is an **unstable public** API. It may change more frequently and has weaker
compatibility guarantees.
:::

A Python runtime describes either a *platform runtime* or an *in-build runtime*.
A platform runtime accesses a system-installed interpreter at a known path,
whereas an in-build runtime points to a `File` that acts as the interpreter. In
both cases, an "interpreter" is really any executable binary or wrapper script
that is capable of running a Python script passed on the command line, following
the same conventions as the standard CPython interpreter.
2È
�F
PyRuntimeInfo�Contains information about a Python runtime, as returned by the `py_runtime`
rule.

:::{warning}
This is an **unstable public** API. It may change more frequently and has weaker
compatibility guarantees.
:::

A Python runtime describes either a *platform runtime* or an *in-build runtime*.
A platform runtime accesses a system-installed interpreter at a known path,
whereas an in-build runtime points to a `File` that acts as the interpreter. In
both cases, an "interpreter" is really any executable binary or wrapper script
that is capable of running a Python script passed on the command line, following
the same conventions as the standard CPython interpreter.
e
	abi_flagsX
:type: str

The runtime's ABI flags, i.e. `sys.abiflags`.

:::{versionadded} 1.0.0
:::
�
bootstrap_template�
:type: File

A template of code responsible for the initial startup of a program.

This code is responsible for:

* Locating the target interpreter. Typically it is in runfiles, but not always.
* Setting necessary environment variables, command line flags, or other
  configuration that can't be modified after the interpreter starts.
* Invoking the appropriate entry point. This is usually a second-stage bootstrap
  that performs additional setup prior to running a program's actual entry point.

The {obj}`--bootstrap_impl` flag affects how this stage 1 bootstrap
is expected to behave and the substutitions performed.

* `--bootstrap_impl=system_python` substitutions: `%is_zipfile%`, `%python_binary%`,
  `%target%`, `%workspace_name`, `%coverage_tool%`, `%import_all%`, `%imports%`,
  `%main%`, `%shebang%`
* `--bootstrap_impl=script` substititions: `%is_zipfile%`, `%python_binary%`,
  `%python_binary_actual%`, `%target%`, `%workspace_name`,
  `%shebang%`, `%stage2_bootstrap%`

Substitution definitions:

* `%shebang%`: The shebang to use with the bootstrap; the bootstrap template
  may choose to ignore this.
* `%stage2_bootstrap%`: A runfiles-relative path to the stage 2 bootstrap.
* `%python_binary%`: The path to the target Python interpreter. There are three
  types of paths:
  * An absolute path to a system interpreter (e.g. begins with `/`).
  * A runfiles-relative path to an interpreter (e.g. `somerepo/bin/python3`)
  * A program to search for on PATH, i.e. a word without spaces, e.g. `python3`.

  When `--bootstrap_impl=script` is used, this is always a runfiles-relative
  path to a venv-based interpreter executable.

* `%python_binary_actual%`: The path to the interpreter that
  `%python_binary%` invokes. There are three types of paths:
  * An absolute path to a system interpreter (e.g. begins with `/`).
  * A runfiles-relative path to an interpreter (e.g. `somerepo/bin/python3`)
  * A program to search for on PATH, i.e. a word without spaces, e.g. `python3`.

  Only set for zip builds with `--bootstrap_impl=script`; other builds will use
  an empty string.

* `%workspace_name%`: The name of the workspace the target belongs to.
* `%is_zipfile%`: The string `1` if this template is prepended to a zipfile to
  create a self-executable zip file. The string `0` otherwise.

For the other substitution definitions, see the {obj}`stage2_bootstrap_template`
docs.

:::{versionchanged} 0.33.0
The set of substitutions depends on {obj}`--bootstrap_impl`
:::
�
coverage_files�
:type: depset[File] | None

The files required at runtime for using `coverage_tool`. Will be `None` if no
`coverage_tool` was provided.
�
coverage_tool�
:type: File | None

If set, this field is a `File` representing tool used for collecting code
coverage information from python tests. Otherwise, this is `None`.
�
files�
:type: depset[File] | None

If this is an in-build runtime, this field is a `depset` of `File`s that need to
be added to the runfiles of an executable target that uses this runtime (in
particular, files needed by `interpreter`). The value of `interpreter` need not
be included in this field. If this is a platform runtime then this field is
`None`.
f
implementation_nameO
:type: str | None

The Python implementation name (`sys.implementation.name`)
�
interpreter�
:type: File | None

If this is an in-build runtime, this field is a `File` representing the
interpreter. Otherwise, this is `None`. Note that an in-build runtime can use
either a prebuilt, checked-in interpreter or an interpreter built from source.
�
interpreter_path�
:type: str | None

If this is a platform runtime, this field is the absolute filesystem path to the
interpreter on the target platform. Otherwise, this is `None`.
�
interpreter_version_info�
:type: struct

Version information about the interpreter this runtime provides.
It should match the format given by `sys.version_info`, however
for simplicity, the micro, releaselevel, and serial values are
optional.
A struct with the following fields:
* `major`: {type}`int`, the major version number
* `minor`: {type}`int`, the minor version number
* `micro`: {type}`int | None`, the micro version number
* `releaselevel`: {type}`str | None`, the release level
* `serial`: {type}`int | None`, the serial number of the release
�
pyc_tag�
:type: str | None

The tag portion of a pyc filename, e.g. the `cpython-39` infix
of `foo.cpython-39.pyc`. See PEP 3147. If not specified, it will be computed
from {obj}`implementation_name` and {obj}`interpreter_version_info`. If no
pyc_tag is available, then only source-less pyc generation will function
correctly.
�
python_version{
:type: str

Indicates whether this runtime uses Python major version 2 or 3. Valid values
are (only) `"PY2"` and `"PY3"`.
�
site_init_template�
:type: File

The template to use for the binary-specific site-init hook run by the
interpreter at startup.

:::{versionadded} 1.0.0
:::
�
stage2_bootstrap_template�
:type: File

A template of Python code that runs under the desired interpreter and is
responsible for orchestrating calling the program's actual main code. This
bootstrap is responsible for affecting the current runtime's state, such as
import paths or enabling coverage, so that, when it runs the program's actual
main code, it works properly under Bazel.

The following substitutions are made during template expansion:
* `%main%`: A runfiles-relative path to the program's actual main file. This
  can be a `.py` or `.pyc` file, depending on precompile settings.
* `%coverage_tool%`: Runfiles-relative path to the coverage library's entry point.
  If coverage is not enabled or available, an empty string.
* `%import_all%`: The string `True` if all repositories in the runfiles should
  be added to sys.path. The string `False` otherwise.
* `%imports%`: A colon-delimited string of runfiles-relative paths to add to
  sys.path.
* `%target%`: The name of the target this is for.
* `%workspace_name%`: The name of the workspace the target belongs to.

:::{versionadded} 0.33.0
:::
�
stub_shebang�
:type: str

"Shebang" expression prepended to the bootstrapping Python stub
script used when executing {obj}`py_binary` targets.  Does not
apply to Windows.
�
supports_build_time_venv�
:type: bool

True if this toolchain supports the build-time created virtual environment.
False if not or unknown. If build-time venv creation isn't supported, then binaries may
fallback to non-venv solutions or creating a venv at runtime.

In order to use the build-time created virtual environment, a toolchain needs
to meet two criteria:
1. Specifying the underlying executable (e.g. `/usr/bin/python3`, as reported by
   `sys._base_executable`) for the venv executable (`$venv/bin/python3`, as reported
   by `sys.executable`). This typically requires relative symlinking the venv
   path to the underlying path at build time, or using the `PYTHONEXECUTABLE`
   environment variable (Python 3.11+) at runtime.
2. Having the build-time created site-packages directory
   (`<venv>/lib/python{version}/site-packages`) recognized by the runtime
   interpreter. This typically requires the Python version to be known at
   build-time and match at runtime.

:::{versionadded} 1.5.0
:::
�
zip_main_template�
:type: File

A template of Python code that becomes a zip file's top-level `__main__.py`
file. The top-level `__main__.py` file is used when the zip file is explicitly
passed to a Python interpreter. See PEP 441 for more information about zipapp
support. Note that py_binary-generated zip files are self-executing and
skip calling `__main__.py`.

The following substitutions are made during template expansion:
* `%stage2_bootstrap%`: A runfiles-relative string to the stage 2 bootstrap file.
* `%python_binary%`: The path to the target Python interpreter. There are three
  types of paths:
  * An absolute path to a system interpreter (e.g. begins with `/`).
  * A runfiles-relative path to an interpreter (e.g. `somerepo/bin/python3`)
  * A program to search for on PATH, i.e. a word without spaces, e.g. `python3`.
* `%workspace_name%`: The name of the workspace for the built target.

:::{versionadded} 0.33.0
:::
".
PyRuntimeInfo@@rules_venv//python:defs.bzl
};};g
e
	abi_flagsX
:type: str

The runtime's ABI flags, i.e. `sys.abiflags`.

:::{versionadded} 1.0.0
:::
�
�
bootstrap_template�
:type: File

A template of code responsible for the initial startup of a program.

This code is responsible for:

* Locating the target interpreter. Typically it is in runfiles, but not always.
* Setting necessary environment variables, command line flags, or other
  configuration that can't be modified after the interpreter starts.
* Invoking the appropriate entry point. This is usually a second-stage bootstrap
  that performs additional setup prior to running a program's actual entry point.

The {obj}`--bootstrap_impl` flag affects how this stage 1 bootstrap
is expected to behave and the substutitions performed.

* `--bootstrap_impl=system_python` substitutions: `%is_zipfile%`, `%python_binary%`,
  `%target%`, `%workspace_name`, `%coverage_tool%`, `%import_all%`, `%imports%`,
  `%main%`, `%shebang%`
* `--bootstrap_impl=script` substititions: `%is_zipfile%`, `%python_binary%`,
  `%python_binary_actual%`, `%target%`, `%workspace_name`,
  `%shebang%`, `%stage2_bootstrap%`

Substitution definitions:

* `%shebang%`: The shebang to use with the bootstrap; the bootstrap template
  may choose to ignore this.
* `%stage2_bootstrap%`: A runfiles-relative path to the stage 2 bootstrap.
* `%python_binary%`: The path to the target Python interpreter. There are three
  types of paths:
  * An absolute path to a system interpreter (e.g. begins with `/`).
  * A runfiles-relative path to an interpreter (e.g. `somerepo/bin/python3`)
  * A program to search for on PATH, i.e. a word without spaces, e.g. `python3`.

  When `--bootstrap_impl=script` is used, this is always a runfiles-relative
  path to a venv-based interpreter executable.

* `%python_binary_actual%`: The path to the interpreter that
  `%python_binary%` invokes. There are three types of paths:
  * An absolute path to a system interpreter (e.g. begins with `/`).
  * A runfiles-relative path to an interpreter (e.g. `somerepo/bin/python3`)
  * A program to search for on PATH, i.e. a word without spaces, e.g. `python3`.

  Only set for zip builds with `--bootstrap_impl=script`; other builds will use
  an empty string.

* `%workspace_name%`: The name of the workspace the target belongs to.
* `%is_zipfile%`: The string `1` if this template is prepended to a zipfile to
  create a self-executable zip file. The string `0` otherwise.

For the other substitution definitions, see the {obj}`stage2_bootstrap_template`
docs.

:::{versionchanged} 0.33.0
The set of substitutions depends on {obj}`--bootstrap_impl`
:::
�
�
coverage_files�
:type: depset[File] | None

The files required at runtime for using `coverage_tool`. Will be `None` if no
`coverage_tool` was provided.
�
�
coverage_tool�
:type: File | None

If set, this field is a `File` representing tool used for collecting code
coverage information from python tests. Otherwise, this is `None`.
�
�
files�
:type: depset[File] | None

If this is an in-build runtime, this field is a `depset` of `File`s that need to
be added to the runfiles of an executable target that uses this runtime (in
particular, files needed by `interpreter`). The value of `interpreter` need not
be included in this field. If this is a platform runtime then this field is
`None`.
h
f
implementation_nameO
:type: str | None

The Python implementation name (`sys.implementation.name`)
�
�
interpreter�
:type: File | None

If this is an in-build runtime, this field is a `File` representing the
interpreter. Otherwise, this is `None`. Note that an in-build runtime can use
either a prebuilt, checked-in interpreter or an interpreter built from source.
�
�
interpreter_path�
:type: str | None

If this is a platform runtime, this field is the absolute filesystem path to the
interpreter on the target platform. Otherwise, this is `None`.
�
�
interpreter_version_info�
:type: struct

Version information about the interpreter this runtime provides.
It should match the format given by `sys.version_info`, however
for simplicity, the micro, releaselevel, and serial values are
optional.
A struct with the following fields:
* `major`: {type}`int`, the major version number
* `minor`: {type}`int`, the minor version number
* `micro`: {type}`int | None`, the micro version number
* `releaselevel`: {type}`str | None`, the release level
* `serial`: {type}`int | None`, the serial number of the release
�
�
pyc_tag�
:type: str | None

The tag portion of a pyc filename, e.g. the `cpython-39` infix
of `foo.cpython-39.pyc`. See PEP 3147. If not specified, it will be computed
from {obj}`implementation_name` and {obj}`interpreter_version_info`. If no
pyc_tag is available, then only source-less pyc generation will function
correctly.
�
�
python_version{
:type: str

Indicates whether this runtime uses Python major version 2 or 3. Valid values
are (only) `"PY2"` and `"PY3"`.
�
�
site_init_template�
:type: File

The template to use for the binary-specific site-init hook run by the
interpreter at startup.

:::{versionadded} 1.0.0
:::
�
�
stage2_bootstrap_template�
:type: File

A template of Python code that runs under the desired interpreter and is
responsible for orchestrating calling the program's actual main code. This
bootstrap is responsible for affecting the current runtime's state, such as
import paths or enabling coverage, so that, when it runs the program's actual
main code, it works properly under Bazel.

The following substitutions are made during template expansion:
* `%main%`: A runfiles-relative path to the program's actual main file. This
  can be a `.py` or `.pyc` file, depending on precompile settings.
* `%coverage_tool%`: Runfiles-relative path to the coverage library's entry point.
  If coverage is not enabled or available, an empty string.
* `%import_all%`: The string `True` if all repositories in the runfiles should
  be added to sys.path. The string `False` otherwise.
* `%imports%`: A colon-delimited string of runfiles-relative paths to add to
  sys.path.
* `%target%`: The name of the target this is for.
* `%workspace_name%`: The name of the workspace the target belongs to.

:::{versionadded} 0.33.0
:::
�
�
stub_shebang�
:type: str

"Shebang" expression prepended to the bootstrapping Python stub
script used when executing {obj}`py_binary` targets.  Does not
apply to Windows.
�
�
supports_build_time_venv�
:type: bool

True if this toolchain supports the build-time created virtual environment.
False if not or unknown. If build-time venv creation isn't supported, then binaries may
fallback to non-venv solutions or creating a venv at runtime.

In order to use the build-time created virtual environment, a toolchain needs
to meet two criteria:
1. Specifying the underlying executable (e.g. `/usr/bin/python3`, as reported by
   `sys._base_executable`) for the venv executable (`$venv/bin/python3`, as reported
   by `sys.executable`). This typically requires relative symlinking the venv
   path to the underlying path at build time, or using the `PYTHONEXECUTABLE`
   environment variable (Python 3.11+) at runtime.
2. Having the build-time created site-packages directory
   (`<venv>/lib/python{version}/site-packages`) recognized by the runtime
   interpreter. This typically requires the Python version to be known at
   build-time and match at runtime.

:::{versionadded} 1.5.0
:::
�
�
zip_main_template�
:type: File

A template of Python code that becomes a zip file's top-level `__main__.py`
file. The top-level `__main__.py` file is used when the zip file is explicitly
passed to a Python interpreter. See PEP 441 for more information about zipapp
support. Note that py_binary-generated zip files are self-executing and
skip calling `__main__.py`.

The following substitutions are made during template expansion:
* `%stage2_bootstrap%`: A runfiles-relative string to the stage 2 bootstrap file.
* `%python_binary%`: The path to the target Python interpreter. There are three
  types of paths:
  * An absolute path to a system interpreter (e.g. begins with `/`).
  * A runfiles-relative path to an interpreter (e.g. `somerepo/bin/python3`)
  * A program to search for on PATH, i.e. a word without spaces, e.g. `python3`.
* `%workspace_name%`: The name of the workspace for the built target.

:::{versionadded} 0.33.0
:::
x
//python:py_import.bzlr\
%
rules_pythonpythonpy_import.bzl%
	py_import
_py_import

|
//python:py_runtime.bzlr_
&
rules_pythonpythonpy_runtime.bzl'

py_runtime_py_runtime
		

�
//python:py_runtime_info.bzlrj
+
rules_pythonpythonpy_runtime_info.bzl-
PyRuntimeInfo_PyRuntimeInfo

l
//python:py_info.bzlrR
!

rules_venvpythonpy_info.bzl
PyInfo_PyInfo

�
 //python/venv:py_venv_binary.bzlrm
-

rules_venvpython/venvpy_venv_binary.bzl.
py_venv_binarypy_venv_binary

�
!//python/venv:py_venv_library.bzlrp
.

rules_venvpython/venvpy_venv_library.bzl0
py_venv_librarypy_venv_library

�
//python/venv:py_venv_test.bzlrg
+

rules_venvpython/venvpy_venv_test.bzl*
py_venv_testpy_venv_test

;`rules_venv` exports to match the `rules_python` interface.�
#

rules_venvpythonpy_binary.bzl�	py_binary�A `py_venv_binary` is an executable Python program consisting of a collection of
`.py` source files (possibly belonging to other `py_library` rules), a `*.runfiles`
directory tree containing all the code and data needed by the program at run-time,
and a stub script that starts up the program with the correct initial environment
and data.

```python
load("@rules_venv//python/venv:defs.bzl", "py_venv_binary")

py_venv_binary(
    name = "foo",
    srcs = ["foo.py"],
    data = [":transform"],  # a cc_binary which we invoke at run time
    deps = [
        ":bar",  # a py_library
    ],
)
```
"�
�
	py_binary�A `py_venv_binary` is an executable Python program consisting of a collection of
`.py` source files (possibly belonging to other `py_library` rules), a `*.runfiles`
directory tree containing all the code and data needed by the program at run-time,
and a stub script that starts up the program with the correct initial environment
and data.

```python
load("@rules_venv//python/venv:defs.bzl", "py_venv_binary")

py_venv_binary(
    name = "foo",
    srcs = ["foo.py"],
    data = [":transform"],  # a cc_binary which we invoke at run time
    deps = [
        ":bar",  # a py_library
    ],
)
```
*
nameA unique name for this target. o
dataaFiles needed by this rule at runtime. May list file or rule targets. Generally allows any target.2[]K
deps3Other python targets to link to the current target.*
PyInfo2[]i
env\Dictionary of strings; values are subject to `$(location)` and "Make variable" substitution.
2{}L
imports;List of import directories to be added to the `PYTHONPATH`.2[]�
main�The name of the source file that is the main entry point of the application. This file must also be listed in `srcs`. If left unspecified, `name` is used instead. If `name` does not match any filename in `srcs`, `main` must be specified. 2NoneU
srcsGThe list of source (.py) files that are processed to create the target.2[]"/
	py_binary"@@rules_venv//python:py_binary.bzl
��,
*
nameA unique name for this target. q
o
dataaFiles needed by this rule at runtime. May list file or rule targets. Generally allows any target.2[]M
K
deps3Other python targets to link to the current target.*
PyInfo2[]k
i
env\Dictionary of strings; values are subject to `$(location)` and "Make variable" substitution.
2{}N
L
imports;List of import directories to be added to the `PYTHONPATH`.2[]�
�
main�The name of the source file that is the main entry point of the application. This file must also be listed in `srcs`. If left unspecified, `name` is used instead. If `name` does not match any filename in `srcs`, `main` must be specified. 2NoneW
U
srcsGThe list of source (.py) files that are processed to create the target.2[]�
 //python/venv:py_venv_binary.bzlrm
-

rules_venvpython/venvpy_venv_binary.bzl.
py_venv_binarypy_venv_binary
6D
F	py_binary�R
!

rules_venvpythonpy_info.bzl�QPyInfo�Encapsulates information provided by the Python rules.

Instead of creating this object directly, use {obj}`PyInfoBuilder` and
the {obj}`PyCommonApi` utilities.
2�O
�(
PyInfo�Encapsulates information provided by the Python rules.

Instead of creating this object directly, use {obj}`PyInfoBuilder` and
the {obj}`PyCommonApi` utilities.
�
direct_original_sources�
:type: depset[File]

The `.py` source files (if any) that are considered directly provided by
the target. This field is intended so that static analysis tools can recover the
original Python source files, regardless of any build settings (e.g.
precompiling), so they can analyze source code. The values are typically the
`.py` files in the `srcs` attribute (or equivalent).

::::{versionadded} 1.1.0
::::
�
direct_pyc_files�
:type: depset[File]

Precompiled Python files that are considered directly provided
by the target and **must be included**.

These files usually come from, e.g., a library setting {attr}`precompile=enabled`
to forcibly enable precompiling for itself. Downstream binaries are expected
to always include these files, as the originating target expects them to exist.
�
direct_pyi_files�
:type: depset[File]

Type definition files (usually `.pyi` files) for the Python modules provided by
this target. Usually they describe the source files listed in
`direct_original_sources`. This field is primarily for static analysis tools.

These files are _usually_ build-time only and not included as part of a runnable
program.

:::{note}
This may contain implementation-specific file types specific to a particular
type checker.
:::

::::{versionadded} 1.1.0
::::
s
has_py2_only_sources[
:type: bool

Whether any of this target's transitive sources requires a Python 2 runtime.
s
has_py3_only_sources[
:type: bool

Whether any of this target's transitive sources requires a Python 3 runtime.
�
imports�:type: depset[str]

A depset of import path strings to be added to the `PYTHONPATH` of executable
Python targets. These are accumulated from the transitive `deps`.
The order of the depset is not guaranteed and may be changed in the future. It
is recommended to use `default` order (the default).
�
transitive_implicit_pyc_files�
:type: depset[File]

Automatically generated pyc files that downstream binaries (or equivalent)
can choose to include in their output. If not included, then
{obj}`transitive_implicit_pyc_source_files` should be included instead.

::::{versionadded} 0.37.0
::::
�
$transitive_implicit_pyc_source_files�
:type: depset[File]

Source `.py` files for {obj}`transitive_implicit_pyc_files` that downstream
binaries (or equivalent) can choose to include in their output. If not included,
then {obj}`transitive_implicit_pyc_files` should be included instead.

::::{versionadded} 0.37.0
::::
�
transitive_original_sources�
:type: depset[File]

The transitive set of `.py` source files (if any) that are considered the
original sources for this target and its transitive dependencies. This field is
intended so that static analysis tools can recover the original Python source
files, regardless of any build settings (e.g. precompiling), so they can analyze
source code. The values are typically the `.py` files in the `srcs` attribute
(or equivalent).

This is superset of `direct_original_sources`.

::::{versionadded} 1.1.0
::::
�
transitive_pyc_files�
:type: depset[File]

The transitive set of precompiled files that must be included.

These files usually come from, e.g., a library setting {attr}`precompile=enabled`
to forcibly enable precompiling for itself. Downstream binaries are expected
to always include these files, as the originating target expects them to exist.
�
transitive_pyi_files�
:type: depset[File]

The transitive set of type definition files (usually `.pyi` files) for the
Python modules for this target and its transitive dependencies. this target.
Usually they describe the source files listed in `transitive_original_sources`.
This field is primarily for static analysis tools.

These files are _usually_ build-time only and not included as part of a runnable
program.

:::{note}
This may contain implementation-specific file types specific to a particular
type checker.
:::

::::{versionadded} 1.1.0
::::
�
transitive_sources�:type: depset[File]

A (`postorder`-compatible) depset of `.py` files that are considered required
and downstream binaries (or equivalent) **must** include in their outputs
to have a functioning program.

Normally, these are the `.py` files in the appearing in the target's `srcs` and
the `srcs` of the target's transitive `deps`, **however**, precompile settings
may cause `.py` files to be omitted. In particular, pyc-only builds may result
in this depset being **empty**.

::::{versionchanged} 0.37.0
The files are considered necessary for downstream binaries to function;
previously they were considerd informational and largely unused.
::::
�
uses_shared_libraries�
:type: bool

Whether any of this target's transitive `deps` has a shared library file (such
as a `.so` file).

This field is currently unused in Bazel and may go away in the future.
�
venv_symlinkso
:type: depset[VenvSymlinkEntry]

:::{include} /_includes/experimental_api.md
:::

:::{versionadded} 1.5.0
:::
"*
PyInfo @@rules_venv//python:py_info.bzl
�,�,�
�
direct_original_sources�
:type: depset[File]

The `.py` source files (if any) that are considered directly provided by
the target. This field is intended so that static analysis tools can recover the
original Python source files, regardless of any build settings (e.g.
precompiling), so they can analyze source code. The values are typically the
`.py` files in the `srcs` attribute (or equivalent).

::::{versionadded} 1.1.0
::::
�
�
direct_pyc_files�
:type: depset[File]

Precompiled Python files that are considered directly provided
by the target and **must be included**.

These files usually come from, e.g., a library setting {attr}`precompile=enabled`
to forcibly enable precompiling for itself. Downstream binaries are expected
to always include these files, as the originating target expects them to exist.
�
�
direct_pyi_files�
:type: depset[File]

Type definition files (usually `.pyi` files) for the Python modules provided by
this target. Usually they describe the source files listed in
`direct_original_sources`. This field is primarily for static analysis tools.

These files are _usually_ build-time only and not included as part of a runnable
program.

:::{note}
This may contain implementation-specific file types specific to a particular
type checker.
:::

::::{versionadded} 1.1.0
::::
u
s
has_py2_only_sources[
:type: bool

Whether any of this target's transitive sources requires a Python 2 runtime.
u
s
has_py3_only_sources[
:type: bool

Whether any of this target's transitive sources requires a Python 3 runtime.
�
�
imports�:type: depset[str]

A depset of import path strings to be added to the `PYTHONPATH` of executable
Python targets. These are accumulated from the transitive `deps`.
The order of the depset is not guaranteed and may be changed in the future. It
is recommended to use `default` order (the default).
�
�
transitive_implicit_pyc_files�
:type: depset[File]

Automatically generated pyc files that downstream binaries (or equivalent)
can choose to include in their output. If not included, then
{obj}`transitive_implicit_pyc_source_files` should be included instead.

::::{versionadded} 0.37.0
::::
�
�
$transitive_implicit_pyc_source_files�
:type: depset[File]

Source `.py` files for {obj}`transitive_implicit_pyc_files` that downstream
binaries (or equivalent) can choose to include in their output. If not included,
then {obj}`transitive_implicit_pyc_files` should be included instead.

::::{versionadded} 0.37.0
::::
�
�
transitive_original_sources�
:type: depset[File]

The transitive set of `.py` source files (if any) that are considered the
original sources for this target and its transitive dependencies. This field is
intended so that static analysis tools can recover the original Python source
files, regardless of any build settings (e.g. precompiling), so they can analyze
source code. The values are typically the `.py` files in the `srcs` attribute
(or equivalent).

This is superset of `direct_original_sources`.

::::{versionadded} 1.1.0
::::
�
�
transitive_pyc_files�
:type: depset[File]

The transitive set of precompiled files that must be included.

These files usually come from, e.g., a library setting {attr}`precompile=enabled`
to forcibly enable precompiling for itself. Downstream binaries are expected
to always include these files, as the originating target expects them to exist.
�
�
transitive_pyi_files�
:type: depset[File]

The transitive set of type definition files (usually `.pyi` files) for the
Python modules for this target and its transitive dependencies. this target.
Usually they describe the source files listed in `transitive_original_sources`.
This field is primarily for static analysis tools.

These files are _usually_ build-time only and not included as part of a runnable
program.

:::{note}
This may contain implementation-specific file types specific to a particular
type checker.
:::

::::{versionadded} 1.1.0
::::
�
�
transitive_sources�:type: depset[File]

A (`postorder`-compatible) depset of `.py` files that are considered required
and downstream binaries (or equivalent) **must** include in their outputs
to have a functioning program.

Normally, these are the `.py` files in the appearing in the target's `srcs` and
the `srcs` of the target's transitive `deps`, **however**, precompile settings
may cause `.py` files to be omitted. In particular, pyc-only builds may result
in this depset being **empty**.

::::{versionchanged} 0.37.0
The files are considered necessary for downstream binaries to function;
previously they were considerd informational and largely unused.
::::
�
�
uses_shared_libraries�
:type: bool

Whether any of this target's transitive `deps` has a shared library file (such
as a `.so` file).

This field is currently unused in Bazel and may go away in the future.
�
�
venv_symlinkso
:type: depset[VenvSymlinkEntry]

:::{include} /_includes/experimental_api.md
:::

:::{versionadded} 1.5.0
:::
n
//python:py_info.bzlrT
#
rules_pythonpythonpy_info.bzl
PyInfo_PyInfo
+2
>PyInfo�	
$

rules_venvpythonpy_library.bzl�
py_library4A library of Python code that can be depended upon.
"�
�

py_library4A library of Python code that can be depended upon.
*
nameA unique name for this target. o
dataaFiles needed by this rule at runtime. May list file or rule targets. Generally allows any target.2[]K
deps3Other python targets to link to the current target.*
PyInfo2[]L
imports;List of import directories to be added to the `PYTHONPATH`.2[]U
srcsGThe list of source (.py) files that are processed to create the target.2[]"1

py_library#@@rules_venv//python:py_library.bzl
==,
*
nameA unique name for this target. q
o
dataaFiles needed by this rule at runtime. May list file or rule targets. Generally allows any target.2[]M
K
deps3Other python targets to link to the current target.*
PyInfo2[]N
L
imports;List of import directories to be added to the `PYTHONPATH`.2[]W
U
srcsGThe list of source (.py) files that are processed to create the target.2[]�
!//python/venv:py_venv_library.bzlrp
.

rules_venvpython/venvpy_venv_library.bzl0
py_venv_librarypy_venv_library
7F
H
py_libraryO


rules_venvversion.bzl	VERSION0.17.0j0.17.0"rules_venv version 