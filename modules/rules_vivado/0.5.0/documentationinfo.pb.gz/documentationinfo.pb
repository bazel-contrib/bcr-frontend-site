��
*
rules_vivadovivado/private
common.bzl�action_attrsGReturn the private attrs every rule that runs `run_tcl_template` needs.*�
�
action_attrsGReturn the private attrs every rule that runs `run_tcl_template` needs."
}dict[str, Attribute]: the shared-Tcl-library attr whose file
`run_tcl_template` stages and exposes as `{{RULES_VIVADO_TCL}}`.29
action_attrs)@@rules_vivado//vivado/private:common.bzl
���block_designs_dataCExtract `block_designs` deps into a substitution-ready Tcl literal.*�
�
block_designs_data:
block_designs%providers of `VivadoBlockDesignInfo`. (CExtract `block_designs` deps into a substitution-ready Tcl literal."�
�struct: `block_designs` (str, a Tcl literal); `input_files`
(list[File]) — each BD's `bd_dir` plus its transitively
referenced IP-block repo dirs; and `ip_repo_paths` (list[str]) —
just those repo paths, which consumers must fold into their own
`ip_repo_paths` for `create_bd_cell -vlnv` inside the BD to
resolve when the BD is reloaded downstream.2?
block_designs_data)@@rules_vivado//vivado/private:common.bzl
���encrypt_dataFProduce substitution data + post-processing command for IP encryption.*�
�
encrypt_data
ctxthe rule context. (V
	all_filesEevery file the IP depends on; filtered to
`.v` / `.sv` / `.vhd` here. (9

ip_dir_src'path of the IP repo's `src/` directory. (FProduce substitution data + post-processing command for IP encryption."v
tstruct: `encrypt_files` (str, a Tcl literal),
`encrypted_outputs` (list[File]), and
`post_processing_command` (str).29
encrypt_data)@@rules_vivado//vivado/private:common.bzl
���exec_hooks_data�Build subprocess invocations for executable hooks.

Hooks run in listed order under `set -e`; the first non-zero exit fails
the action.
*�
�
exec_hooks_dataA
targets2Targets from an executable-only hook
`label_list`. (@
project_dir_path(path of the rule's project TreeArtifact. (>
export_dir_path'path of the rule's export TreeArtifact. (�Build subprocess invocations for executable hooks.

Hooks run in listed order under `set -e`; the first non-zero exit fails
the action.
"�
�struct: `command` (str), `env` (dict[str, str]), and `tools`
(list[FilesToRunProvider]) — pass `tools` to
`run_shell(tools=…)` so hook runfiles stage in the sandbox.2<
exec_hooks_data)@@rules_vivado//vivado/private:common.bzl
���get_vivado_toolchain4Resolve the Vivado toolchain settings for an action.*�
�
get_vivado_toolchain	
ctx (4Resolve the Vivado toolchain settings for an action.2A
get_vivado_toolchain)@@rules_vivado//vivado/private:common.bzl
jj�hdl_sources_data�Walk a module's transitive sources and split into per-kind Tcl lists.

Walks `VerilogInfo.vhdl_deps` and `VhdlInfo.verilog_deps` so cross-lang
instantiations reach the synth project. Without this, synth fails with
`[Synth 8-439] module '<entity>' not found`.

`.vhd` files reached via `VerilogInfo.data` (no `VhdlInfo` context) fall
back to (`xil_defaultlib`, `2008`).

TreeArtifact directory Files (e.g. from `vivado_xci` categorized outputs)
are collected into `src_dirs` and consumed by templates via `add_files`
— Vivado auto-classifies files by extension inside the directory.
*�
�
hdl_sources_data/
module!the top-level HDL library target. (�Walk a module's transitive sources and split into per-kind Tcl lists.

Walks `VerilogInfo.vhdl_deps` and `VhdlInfo.verilog_deps` so cross-lang
instantiations reach the synth project. Without this, synth fails with
`[Synth 8-439] module '<entity>' not found`.

`.vhd` files reached via `VerilogInfo.data` (no `VhdlInfo` context) fall
back to (`xil_defaultlib`, `2008`).

TreeArtifact directory Files (e.g. from `vivado_xci` categorized outputs)
are collected into `src_dirs` and consumed by templates via `add_files`
— Vivado auto-classifies files by extension inside the directory.
"w
ustruct: `all_files` (list[File]) plus the Tcl literals
`hdl_sources`, `src_dirs`, `xdc_files`, and `tcl_files` (str).2=
hdl_sources_data)@@rules_vivado//vivado/private:common.bzl
���
hook_attrs�Return the standard `pre_hooks` / `post_hooks` / allowlist attrs.

Rules merge the result into their own `attrs` dict so every
hook-having rule shares one attr shape. Every hook-having rule also
runs Vivado, so the result folds in `action_attrs` and
`tcl_hook_flag_attrs`.
*�
�

hook_attrs8
pre_doc)doc string body for the `pre_hooks` attr. (:
post_doc*doc string body for the `post_hooks` attr. (�

extensionsyallowed file extensions. Defaults to
`.tcl`/`.xdc`/`.sdc`; simulation rules pass `[".tcl"]` when
constraints don't apply.None(�Return the standard `pre_hooks` / `post_hooks` / allowlist attrs.

Rules merge the result into their own `attrs` dict so every
hook-having rule shares one attr shape. Every hook-having rule also
runs Vivado, so the result folds in `action_attrs` and
`tcl_hook_flag_attrs`.
"c
adict[str, Attribute]: the `pre_hooks` / `post_hooks` attrs plus
the private attrs they depend on.27

hook_attrs)@@rules_vivado//vivado/private:common.bzl
���!hook_invocation�Resolve hook targets into sourceable paths and tools to stage.

An executable target contributes its wrapper exe, staged via
`FilesToRunProvider` so Bazel renders the runfiles tree next to it —
that's how a `tcl_binary` wrapper self-locates its dep tree. Anything
else (raw `.tcl`/`.xdc`/`.sdc`, `filegroup`, `tcl_library`)
contributes each of its files, in order, staged individually; no
runfiles tree exists for those, so they only get the files they list.

`pkgIndex.tcl` stages but is never sourced — it binds `$dir` and
errors when sourced directly. Skipping it lets one `tcl_library`
serve both hook consumers (sourced file-by-file) and
`package require` consumers (loaded via `auto_path`).

Under `//vivado/settings:incompatible_eager_tcl_hook_load`, each
target's transitive `tcl_library` srcs are sourced first, in
dependency order, so a hook resolves procs it never declared a
`package require` for.

Each file is sourced at most once, keeping its earliest position.
Listing a library both as its own hook and as another hook's dep is
ordinary Bazel composition, but Tcl has no include guard — sourcing
twice re-runs the file, so a `namespace eval` that appends to a list
or bumps a counter would do it again. Dependency order is preserved
because the first occurrence is the one deep enough for every later
consumer.

`script` is the rule's Tcl script, which every template sources right
after this list. Under the flag its `tcl_library` closure is appended
last, so the script resolves procs from libraries it declared in
`deps` — the same reach a hook gets. Without it the two attrs
disagree: a library named in `pre_hooks` is sourced, while the same
library in the script's own `deps` is only staged into runfiles, and
the script dies on `invalid command name`. `script` itself is not
added here; the template sources it.
*�
�
hook_invocationd
ctxYthe rule context; the rule must carry
`tcl_hook_flag_attrs()` (`hook_attrs` includes it). (0
targets!Targets from a hook `label_list`. (u
scriptcthe `tcl_script_attr` target sourced
after these hooks. Only its dependency closure is contributed.None(�Resolve hook targets into sourceable paths and tools to stage.

An executable target contributes its wrapper exe, staged via
`FilesToRunProvider` so Bazel renders the runfiles tree next to it —
that's how a `tcl_binary` wrapper self-locates its dep tree. Anything
else (raw `.tcl`/`.xdc`/`.sdc`, `filegroup`, `tcl_library`)
contributes each of its files, in order, staged individually; no
runfiles tree exists for those, so they only get the files they list.

`pkgIndex.tcl` stages but is never sourced — it binds `$dir` and
errors when sourced directly. Skipping it lets one `tcl_library`
serve both hook consumers (sourced file-by-file) and
`package require` consumers (loaded via `auto_path`).

Under `//vivado/settings:incompatible_eager_tcl_hook_load`, each
target's transitive `tcl_library` srcs are sourced first, in
dependency order, so a hook resolves procs it never declared a
`package require` for.

Each file is sourced at most once, keeping its earliest position.
Listing a library both as its own hook and as another hook's dep is
ordinary Bazel composition, but Tcl has no include guard — sourcing
twice re-runs the file, so a `namespace eval` that appends to a list
or bumps a counter would do it again. Dependency order is preserved
because the first occurrence is the one deep enough for every later
consumer.

`script` is the rule's Tcl script, which every template sources right
after this list. Under the flag its `tcl_library` closure is appended
last, so the script resolves procs from libraries it declared in
`deps` — the same reach a hook gets. Without it the two attrs
disagree: a library named in `pre_hooks` is sourced, while the same
library in the script's own `deps` is only staged into runfiles, and
the script dies on `invalid command name`. `script` itself is not
added here; the template sources it.
"�
�struct: `files_literal` (str) — a Tcl list literal of exec-root
paths Vivado `source`s in order — and `tools`
(list[File|FilesToRunProvider]) for `run_shell(tools=…)`.2<
hook_invocation)@@rules_vivado//vivado/private:common.bzl
���ip_blocks_data>Extract `ip_blocks` deps into substitution-ready Tcl literals.*�
�
ip_blocks_data2
	ip_blocks!providers of `VivadoIPBlockInfo`. (>Extract `ip_blocks` deps into substitution-ready Tcl literals."�
�struct: the Tcl literals `ip_repos`, `ip_configured_instances`,
and `ip_instances` (str), plus `ip_repo_paths` (list[str]) and
`input_files` (list[File]).2;
ip_blocks_data)@@rules_vivado//vivado/private:common.bzl
���	 merge_project_hook_contributions�Union the `project_hooks` Targets that BD / IP providers contribute.

Merged in dep order (BDs first, then IPs, each in list order) and run
through `hook_invocation` like any other hook attr. Duplicates are
dropped keeping the FIRST occurrence — a setup hook contributed by two
BDs is normal composition, and sourcing it twice would re-run whatever
it does (`create_bd_cell`, `set_property`, counter bumps).
*�
�
 merge_project_hook_contributions4
ctx)the rule context (see `hook_invocation`). (:
block_designs%providers of `VivadoBlockDesignInfo`. (2
	ip_blocks!providers of `VivadoIPBlockInfo`. (�Union the `project_hooks` Targets that BD / IP providers contribute.

Merged in dep order (BDs first, then IPs, each in list order) and run
through `hook_invocation` like any other hook attr. Duplicates are
dropped keeping the FIRST occurrence — a setup hook contributed by two
BDs is normal composition, and sourcing it twice would re-run whatever
it does (`create_bd_cell`, `set_property`, counter bumps).
"*
(struct: same shape as `hook_invocation`.2M
 merge_project_hook_contributions)@@rules_vivado//vivado/private:common.bzl
���project_hooks_attrBReturn the `project_hooks` attr shared by IP / BD producing rules.*�
�
project_hooks_attrI
doc:rule-specific doc string; defaults to the
generic wording.None(BReturn the `project_hooks` attr shared by IP / BD producing rules."�
�Attribute: an `attr.label_list` for a rule's
`attrs = {"project_hooks": ...}`. Rules using it must also
declare `_allowlist_function_transition` (included via
`hook_attrs`).2?
project_hooks_attr)@@rules_vivado//vivado/private:common.bzl
���reports_data1Render the `reports` attr into substitution data.*�
�
reports_data
ctxthe rule context. (:
reports+report types; each must key `REPORT_TYPES`. (1Render the `reports` attr into substitution data."l
jstruct: `commands_dict` (str), `requested` (str), `files`
(list[File]), and `file_dict` (dict[str, File]).29
reports_data)@@rules_vivado//vivado/private:common.bzl
���tcl_args�Format a starlark `string_list` as a brace-quoted Tcl word list.

Items containing whitespace are brace-wrapped so they survive Tcl list
parsing as a single token. Literal Tcl quoting metacharacters
(`{`, `}`, `\`, `"`) must be brace-quoted by the caller.
*�
�
tcl_args#
argsCLI args; may be empty. (�Format a starlark `string_list` as a brace-quoted Tcl word list.

Items containing whitespace are brace-wrapped so they survive Tcl list
parsing as a single token. Literal Tcl quoting metacharacters
(`{`, `}`, `\`, `"`) must be brace-quoted by the caller.
"
str: a Tcl word-list literal.25
tcl_args)@@rules_vivado//vivado/private:common.bzl
55�tcl_hook_flag_attrs�Return the private attr every rule that calls `hook_invocation` needs.

Carries `//vivado/settings:incompatible_eager_tcl_hook_load` into the
rule so `hook_invocation` can read it off `ctx`. Rules that take
`hook_attrs` get it for free; rules declaring hook attrs by hand
(`vivado_project`) merge this in themselves.
*�
�
tcl_hook_flag_attrs�Return the private attr every rule that calls `hook_invocation` needs.

Carries `//vivado/settings:incompatible_eager_tcl_hook_load` into the
rule so `hook_invocation` can read it off `ctx`. Rules that take
`hook_attrs` get it for free; rules declaring hook attrs by hand
(`vivado_project`) merge this in themselves.
"8
6dict[str, Attribute]: the `_eager_tcl_hook_load` attr.2@
tcl_hook_flag_attrs)@@rules_vivado//vivado/private:common.bzl
���tcl_list_literalJPublic wrapper of `_tcl_list` for rule files that build Tcl list literals.*�
�
tcl_list_literal
items (JPublic wrapper of `_tcl_list` for rule files that build Tcl list literals.2=
tcl_list_literal)@@rules_vivado//vivado/private:common.bzl
  �tcl_script_attr�Return the standard `script` attr for rules driven by a Tcl script.

Requires an executable target — in practice a `tcl_binary`. A bare
`.tcl` file is deliberately not accepted: it has no `deps`, so it can
never `package require` a `tcl_library`, and nothing puts one on its
`auto_path`. Only an executable carries the runfiles tree and the
`.vhook.tcl` wrapper that make dependency-bearing Tcl work at all, so
requiring one here is what makes `script` dep-capable by construction
rather than by flag. Wrapping a self-contained script is three lines
and costs nothing.

`cfg = hook_transition` prepends the Vivado tcl toolchain to
`--extra_toolchains` for the subgraph rooted at `script`, so the
`tcl_binary` resolves against the Vivado-flavored toolchain rather
than whatever the consumer registered, and its wrapper comes out as a
`.vhook.tcl` Vivado can source. Rules using this attr must also pull
in `_allowlist_function_transition` (already included via
`hook_attrs`).
*�

�

tcl_script_attr�
doc�override the attr doc string. Defaults to
the generic wording; pass a rule-specific one where the
script has a contract to describe.None(�Return the standard `script` attr for rules driven by a Tcl script.

Requires an executable target — in practice a `tcl_binary`. A bare
`.tcl` file is deliberately not accepted: it has no `deps`, so it can
never `package require` a `tcl_library`, and nothing puts one on its
`auto_path`. Only an executable carries the runfiles tree and the
`.vhook.tcl` wrapper that make dependency-bearing Tcl work at all, so
requiring one here is what makes `script` dep-capable by construction
rather than by flag. Wrapping a self-contained script is three lines
and costs nothing.

`cfg = hook_transition` prepends the Vivado tcl toolchain to
`--extra_toolchains` for the subgraph rooted at `script`, so the
`tcl_binary` resolves against the Vivado-flavored toolchain rather
than whatever the consumer registered, and its wrapper comes out as a
`.vhook.tcl` Vivado can source. Rules using this attr must also pull
in `_allowlist_function_transition` (already included via
`hook_attrs`).
"D
BAttribute: an `attr.label` for a rule's `attrs = {"script": ...}`.2<
tcl_script_attr)@@rules_vivado//vivado/private:common.bzl
���tcl_script_data�Resolve a `tcl_script_attr`-shaped attribute to path + tools.

The target contributes its wrapper exe and a `FilesToRunProvider`,
which is what stages the runfiles tree next to it — that's how the
`.vhook.tcl` wrapper self-locates its `tcl_library` closure and sets
`auto_path`. `cfg = hook_transition` makes the attr a 1-element list
at the callsite, so pass `ctx.attr.script[0]`.
*�
�
tcl_script_data>
target0the single Target from a `tcl_script_attr` attr. (�Resolve a `tcl_script_attr`-shaped attribute to path + tools.

The target contributes its wrapper exe and a `FilesToRunProvider`,
which is what stages the runfiles tree next to it — that's how the
`.vhook.tcl` wrapper self-locates its `tcl_library` closure and sets
`auto_path`. `cfg = hook_transition` makes the attr a 1-element list
at the callsite, so pass `ctx.attr.script[0]`.
"f
dstruct: `path` (str) and `tools` (list[File|FilesToRunProvider],
as `run_shell(tools=…)` accepts).2<
tcl_script_data)@@rules_vivado//vivado/private:common.bzl
���validate_args�Fail loudly if user-supplied args contain rule-controlled flags.

Templates also emit user args BEFORE the rule's flags
(`<cmd> {*}$ARGS -my_flag VAL`), so the rule wins if a new flag slips
past `forbidden`.
*�
�
validate_args0
label#`ctx.label`, for the error message. (-
	attr_namethe attr the args came from. (#
argsthe user-supplied args. (/
	forbiddenflag strings the rule manages. (�Fail loudly if user-supplied args contain rule-controlled flags.

Templates also emit user args BEFORE the rule's flags
(`<cmd> {*}$ARGS -my_flag VAL`), so the rule wins if a new flag slips
past `forbidden`.
2:
validate_args)@@rules_vivado//vivado/private:common.bzl
LL�
//rules:common_settings.bzlrn
*
bazel_skylibrulescommon_settings.bzl2
BuildSettingInfoBuildSettingInfo
3C
Eh
//tcl:tcl_info.bzlrP

	rules_tcltcltcl_info.bzl 
TclInfoTclInfo
'.
0t
//verilog:defs.bzlr\
"
rules_verilogverilogdefs.bzl(
VerilogInfoVerilogInfo
	+	6
		8e
//vhdl:defs.bzlrP


rules_vhdlvhdldefs.bzl"
VhdlInfoVhdlInfo

%
-


/�
//vivado:providers.bzlr�
%
rules_vivadovivadoproviders.bzl<
VivadoBlockDesignInfoVivadoBlockDesignInfo
.C4
VivadoIPBlockInfoVivadoIPBlockInfo
GX
Z�
//vivado:toolchain.bzlrf
%
rules_vivadovivadotoolchain.bzl/
TOOLCHAIN_TYPE_TOOLCHAIN_TYPE
-<
P�
!//vivado/private:resource_set.bzlrt
0
rules_vivadovivado/privateresource_set.bzl2
get_resource_setget_resource_set
9I
K�
 //vivado/private:transitions.bzlrq
/
rules_vivadovivado/privatetransitions.bzl0
hook_transitionhook_transition
8G
I?	DEFAULT_HOOK_EXTSj(2&
.tcl
.xdc
.sdc

.vhook.tcl/	EXECROOT_MARKER<execroot>/j<execroot>/J	TOOLCHAIN_TYPE@@//vivado:toolchain_typej@@//vivado:toolchain_type�Shared helpers used by every vivado rule.

Helpers return DATA (Tcl list / dict literals) for substitution into rule
templates. Templates own all Tcl code; rules emit only data.
�	
0
rules_vivadovivado/privateresource_set.bzl�get_resource_set>Get the `ctx.actions.run.resource_set` for the Vivado actions.*�
�
get_resource_set�
jobs�The number of jobs the action is expected to consume.
Values above MAX_VIVADO_THREADS are clamped (Vivado will not use
more threads than that even if asked). Values below 1 are
clamped to 1 — a Vivado process always occupies at least one
CPU, and the raw dict lookup would otherwise fail with an
unactionable `key 0 not found in dictionary`. Rules validate
the user-facing attr up front (see `run_tcl_template`), so this
clamp is only a backstop. (>Get the `ctx.actions.run.resource_set` for the Vivado actions."O
MOptional[Callable]: A resource set appropriate for the current configuration.2C
get_resource_set/@@rules_vivado//vivado/private:resource_set.bzl
��	MAX_VIVADO_THREADSj �Resource set definitions for Vivado actions.

Vivado's `general.maxThreads` property caps at 32 on Linux (8 on Windows) for
the multi-threaded commands (`synth_design`, `opt_design`, `place_design`,
`phys_opt_design`, `route_design`). Asking for more is silently clamped, so we
only enumerate `cpu_1` .. `cpu_32`. `get_resource_set` saturates above that.
T
/
rules_vivadovivado/privatetransitions.bzl!Transitions used by rules_vivado.�	
,
rules_vivadovivado/privateversions.bzl�	VIVADO_VERSIONSj�2�
2012.1
2012.2
2012.3
2012.4
2013.1
2013.2
2013.3
2013.4
2014.1
2014.2
2014.3
2014.4
2015.1
2015.2
2015.3
2015.4
2016.1
2016.2
2016.3
2016.4
2017.1
2017.2
2017.3
2017.4
2018.1
2018.2
2018.3
2019.1
2019.2
2020.1
2020.2
2021.1
2021.2
2022.1
2022.2
2023.1
2023.2
2024.1
2024.2
2025.1
2025.2�Known Vivado versions.

`VIVADO_VERSIONS` is the single source of truth for the version strings
this ruleset knows about. `//vivado/constraints/version:BUILD.bazel`
generates one `constraint_value` per entry under the `:version`
`constraint_setting`; toolchain resolution picks a Vivado install by
matching a platform's `constraint_values` against a `toolchain()`
registration's `exec_compatible_with`. There is no version *flag* â
selection happens through platforms, e.g.
`--platforms=//tests/toolchains:vivado_2025_1_platform` or a
`cfg = transition(...)` wrapper (see `//tests:transition.bzl`).

Add patch releases (e.g. "2024.1.1") to this list as you need them; the
constraint values follow automatically.
�
-
rules_vivadovivado/settingssettings.bzl� incompatible_eager_tcl_hook_load�Declare the eager-tcl-hook-load flag.

When enabled, each hook's transitive `tcl_library` srcs are sourced
dependency-first ahead of the hook itself, instead of being reached
through `package require` and `auto_path`.

This is the file-to-file sharing model: the whole closure evaluates into
Vivado's interpreter before the hook runs, so a script resolves procs it
never declared a `package require` for. Off (the default), only the
hook's own files are sourced, and a shared library has to carry
`package provide` + `pkgIndex.tcl` for consumers to reach it.

`incompatible_` because flipping it changes which scripts resolve, in
both directions: enabling it hides missing `package require` lines, and
disabling it surfaces every one of them at Vivado runtime. Intended as a
migration lever for consumers porting a file-DAG build (a `-source`
list built from a dependency graph) onto rules_vivado — not a mode to
settle on, because eager loading also runs each file's top-level code
for every hook in the closure, used or not.

Being temporary, the flag is kept excisable. Everything that exists
only to serve it is tagged `EAGER-TCL-HOOK-LOAD`, so `grep -rn
EAGER-TCL-HOOK-LOAD` enumerates the removal set: this macro and its
`BUILD.bazel` call, `tcl_hook_flag_attrs` and the `_eager_tcl_hook_load`
attribute it puts on every hook-having rule, `_eager_tcl_srcs` and
the `if eager:` branch in `hook_invocation`,
and the flag-gated fixtures and tests under `//tests/analysis`.
Nothing else reads the setting, and the default-path behaviour
(`lazy_tcl_hook_load_test`, `hook_pkg_index_test`) is written against
the unflagged rules, so it survives the removal unchanged.
*�
�
 incompatible_eager_tcl_hook_loadP
name"name of the generated `bool_flag`.""incompatible_eager_tcl_hook_load"(�Declare the eager-tcl-hook-load flag.

When enabled, each hook's transitive `tcl_library` srcs are sourced
dependency-first ahead of the hook itself, instead of being reached
through `package require` and `auto_path`.

This is the file-to-file sharing model: the whole closure evaluates into
Vivado's interpreter before the hook runs, so a script resolves procs it
never declared a `package require` for. Off (the default), only the
hook's own files are sourced, and a shared library has to carry
`package provide` + `pkgIndex.tcl` for consumers to reach it.

`incompatible_` because flipping it changes which scripts resolve, in
both directions: enabling it hides missing `package require` lines, and
disabling it surfaces every one of them at Vivado runtime. Intended as a
migration lever for consumers porting a file-DAG build (a `-source`
list built from a dependency graph) onto rules_vivado — not a mode to
settle on, because eager loading also runs each file's top-level code
for every hook in the closure, used or not.

Being temporary, the flag is kept excisable. Everything that exists
only to serve it is tagged `EAGER-TCL-HOOK-LOAD`, so `grep -rn
EAGER-TCL-HOOK-LOAD` enumerates the removal set: this macro and its
`BUILD.bazel` call, `tcl_hook_flag_attrs` and the `_eager_tcl_hook_load`
attribute it puts on every hook-having rule, `_eager_tcl_srcs` and
the `if eager:` branch in `hook_invocation`,
and the flag-gated fixtures and tests under `//tests/analysis`.
Nothing else reads the setting, and the default-path behaviour
(`lazy_tcl_hook_load_test`, `hook_pkg_index_test`) is written against
the unflagged rules, so it survives the removal unchanged.
2P
 incompatible_eager_tcl_hook_load,@@rules_vivado//vivado/settings:settings.bzl
"	bool_flag2	bool_flag�
//rules:common_settings.bzlr`
*
bazel_skylibrulescommon_settings.bzl$
	bool_flag	bool_flag
3<
># rules_vivado settings�A
%
rules_vivadovivadobitstream.bzl�vivado_bitstream�Write a Vivado bitstream (.bit) from a routed checkpoint. For the `.xsa` hardware-platform handoff artifact, compose `vivado_hw_platform` on the same checkpoint."�
�

vivado_bitstream�Write a Vivado bitstream (.bit) from a routed checkpoint. For the `.xsa` hardware-platform handoff artifact, compose `vivado_hw_platform` on the same checkpoint.*
nameA unique name for this target. C

checkpointRouted checkpoint. *
VivadoRoutingCheckpointInfo�

post_hookso`.tcl`/`.xdc`/`.sdc` files OR `tcl_binary` targets sourced after a successful `write_bitstream`, in list order.2[]�
	pre_hooksm`.tcl`/`.xdc`/`.sdc` files OR `tcl_binary` targets sourced on the opened checkpoint before `write_bitstream`.2[]R
threadsBThreads to pass to vivado which defines the amount of parallelism.28�
timing_check�Policy for post-route timing violations. Both setup (WNS) and hold (WHS) worst slack are probed. `error` (default) fails the action; `warn` logs a CRITICAL WARNING and runs `write_bitstream` anyway; `none` skips the gate entirely. A design with no post-route timing paths at all is always treated as unconstrained (warning, not failure).2"error"�

write_args�Extra flags passed through to `write_bitstream`. Cannot contain `-force` (always emitted by the rule) or `-file` (the rule's declared output path is the positional arg).2[]m
write_bitstream_template The write bitstream tcl template2-//vivado/private:write_bitstream.tcl.template"8
vivado_bitstream$@@rules_vivado//vivado:bitstream.bzl
kk,
*
nameA unique name for this target. E
C

checkpointRouted checkpoint. *
VivadoRoutingCheckpointInfo�
�

post_hookso`.tcl`/`.xdc`/`.sdc` files OR `tcl_binary` targets sourced after a successful `write_bitstream`, in list order.2[]�
�
	pre_hooksm`.tcl`/`.xdc`/`.sdc` files OR `tcl_binary` targets sourced on the opened checkpoint before `write_bitstream`.2[]T
R
threadsBThreads to pass to vivado which defines the amount of parallelism.28�
�
timing_check�Policy for post-route timing violations. Both setup (WNS) and hold (WHS) worst slack are probed. `error` (default) fails the action; `warn` logs a CRITICAL WARNING and runs `write_bitstream` anyway; `none` skips the gate entirely. A design with no post-route timing paths at all is always treated as unconstrained (warning, not failure).2"error"�
�

write_args�Extra flags passed through to `write_bitstream`. Cannot contain `-force` (always emitted by the rule) or `-file` (the rule's declared output path is the positional arg).2[]o
m
write_bitstream_template The write bitstream tcl template2-//vivado/private:write_bitstream.tcl.template�&vivado_device_image�Write a Versal device image (.pdi) from a routed checkpoint. For non-Versal architectures use `vivado_bitstream` instead. For the `.xsa` hardware-platform handoff artifact, compose `vivado_hw_platform` on the same checkpoint."�$
�
vivado_device_image�Write a Versal device image (.pdi) from a routed checkpoint. For non-Versal architectures use `vivado_bitstream` instead. For the `.xsa` hardware-platform handoff artifact, compose `vivado_hw_platform` on the same checkpoint.*
nameA unique name for this target. C

checkpointRouted checkpoint. *
VivadoRoutingCheckpointInfo�
no_pdi�Skip Vivado's internal bootgen wrap and shift PDI-production to `post_hooks`. When True, Vivado runs `write_device_image` with `-no_pdi` â only the intermediate `.rcdo` / `.rnpi` files (base name = `$env(VIVADO_PDI_INTERMEDIATE_BASE)`) plus a `gen_files/` directory are emitted. A `post_hooks` entry MUST produce the final `.pdi` at `$env(VIVADO_PDI_OUT)` (typically via `exec bootgen -arch versal -image <BIF> -w -o $env(VIVADO_PDI_OUT)`); Bazel fails the action if the file is missing. Both paths are exported as process env vars so hooks read them via the standard `$env(...)` channel without depending on Tcl globals the caller can't see. Note: the resulting 'declared output was not created' error surfaces at the rule level, not the hook, so hook authors need to know they own the PDI when this is set.2False�

post_hooks�`.tcl`/`.xdc`/`.sdc` files OR `tcl_binary` targets sourced after a successful `write_device_image`, in list order. When `no_pdi = True`, at least one post_hook MUST produce the final `.pdi` at `$env(VIVADO_PDI_OUT)`.2[]�
	pre_hooksp`.tcl`/`.xdc`/`.sdc` files OR `tcl_binary` targets sourced on the opened checkpoint before `write_device_image`.2[]R
threadsBThreads to pass to vivado which defines the amount of parallelism.28�
timing_check�Policy for post-route timing violations. Both setup (WNS) and hold (WHS) worst slack are probed. `error` (default) fails the action; `warn` logs a CRITICAL WARNING and runs `write_device_image` anyway; `none` skips the gate entirely. A design with no post-route timing paths at all is always treated as unconstrained (warning, not failure).2"error"�

write_args�Extra flags passed through to `write_device_image`. Cannot contain `-force` (always emitted by the rule), `-file` (the rule's declared output path is the positional arg), or `-no_pdi` (use the dedicated `no_pdi` attr).2[]v
write_device_image_template#The write device image tcl template20//vivado/private:write_device_image.tcl.template";
vivado_device_image$@@rules_vivado//vivado:bitstream.bzl
��,
*
nameA unique name for this target. E
C

checkpointRouted checkpoint. *
VivadoRoutingCheckpointInfo�
�
no_pdi�Skip Vivado's internal bootgen wrap and shift PDI-production to `post_hooks`. When True, Vivado runs `write_device_image` with `-no_pdi` â only the intermediate `.rcdo` / `.rnpi` files (base name = `$env(VIVADO_PDI_INTERMEDIATE_BASE)`) plus a `gen_files/` directory are emitted. A `post_hooks` entry MUST produce the final `.pdi` at `$env(VIVADO_PDI_OUT)` (typically via `exec bootgen -arch versal -image <BIF> -w -o $env(VIVADO_PDI_OUT)`); Bazel fails the action if the file is missing. Both paths are exported as process env vars so hooks read them via the standard `$env(...)` channel without depending on Tcl globals the caller can't see. Note: the resulting 'declared output was not created' error surfaces at the rule level, not the hook, so hook authors need to know they own the PDI when this is set.2False�
�

post_hooks�`.tcl`/`.xdc`/`.sdc` files OR `tcl_binary` targets sourced after a successful `write_device_image`, in list order. When `no_pdi = True`, at least one post_hook MUST produce the final `.pdi` at `$env(VIVADO_PDI_OUT)`.2[]�
�
	pre_hooksp`.tcl`/`.xdc`/`.sdc` files OR `tcl_binary` targets sourced on the opened checkpoint before `write_device_image`.2[]T
R
threadsBThreads to pass to vivado which defines the amount of parallelism.28�
�
timing_check�Policy for post-route timing violations. Both setup (WNS) and hold (WHS) worst slack are probed. `error` (default) fails the action; `warn` logs a CRITICAL WARNING and runs `write_device_image` anyway; `none` skips the gate entirely. A design with no post-route timing paths at all is always treated as unconstrained (warning, not failure).2"error"�
�

write_args�Extra flags passed through to `write_device_image`. Cannot contain `-force` (always emitted by the rule), `-file` (the rule's declared output path is the positional arg), or `-no_pdi` (use the dedicated `no_pdi` attr).2[]x
v
write_device_image_template#The write device image tcl template20//vivado/private:write_device_image.tcl.template�
//vivado:providers.bzlr�
%
rules_vivadovivadoproviders.bzl,
VivadoLogInfoVivadoLogInfo
.;H
VivadoRoutingCheckpointInfoVivadoRoutingCheckpointInfo
?Z
\�
//vivado/private:common.bzlr�
*
rules_vivadovivado/private
common.bzl.
TOOLCHAIN_TYPETOOLCHAIN_TYPE
:
get_vivado_toolchainget_vivado_toolchain
&

hook_attrs
hook_attrs
0
hook_invocationhook_invocation
		2
run_tcl_templaterun_tcl_template


"
tcl_argstcl_args
,
validate_argsvalidate_args

)# Bitstream-phase rule: vivado_bitstream.�5
(
rules_vivadovivadoblock_design.bzl�/vivado_block_design�Build a Vivado block design (.bd) from a user-authored Tcl script.

`script` is sourced inside a fresh Vivado project. It must call
`create_bd_design "<module_top>"`, add/connect cells, and end with
`save_bd_design`. The attr takes an executable target â in practice a
`tcl_binary`, which is what carries the `deps` a script needs to
`package require` shared `tcl_library` helpers. An extra-toolchains
transition routes it through the Vivado tcl toolchain, so its wrapper
comes out as a `.vhook.tcl` Vivado can source directly and its deps land
on `auto_path`.

The resulting `.bd` is normalized to `<bd_dir>/<module_top>.bd` so
consumers can reference it predictably.

Use the `block_designs` attribute on `vivado_project` to fold this BD
into a synth project; `vivado_synthesis` picks it up and runs
`generate_target {synthesis implementation}` on it automatically.

Block designs may reference packaged IP via the `ip_blocks` attribute; those
IP repos are propagated to consumers so the synth project's IP catalog
resolves the same `create_ip` calls baked into the BD.
"�&
�
vivado_block_design�Build a Vivado block design (.bd) from a user-authored Tcl script.

`script` is sourced inside a fresh Vivado project. It must call
`create_bd_design "<module_top>"`, add/connect cells, and end with
`save_bd_design`. The attr takes an executable target â in practice a
`tcl_binary`, which is what carries the `deps` a script needs to
`package require` shared `tcl_library` helpers. An extra-toolchains
transition routes it through the Vivado tcl toolchain, so its wrapper
comes out as a `.vhook.tcl` Vivado can source directly and its deps land
on `auto_path`.

The resulting `.bd` is normalized to `<bd_dir>/<module_top>.bd` so
consumers can reference it predictably.

Use the `block_designs` attribute on `vivado_project` to fold this BD
into a synth project; `vivado_synthesis` picks it up and runs
`generate_target {synthesis implementation}` on it automatically.

Block designs may reference packaged IP via the `ip_blocks` attribute; those
IP repos are propagated to consumers so the synth project's IP catalog
resolves the same `create_ip` calls baked into the BD.
*
nameA unique name for this target. _
block_design_templateThe create-bd tcl template.2'//vivado/private:create_bd.tcl.templatei
	ip_blocksAPackaged IP blocks referenced by the BD's `create_bd_cell` calls.*
VivadoIPBlockInfo2[]I
jobs<Jobs to pass to vivado (resource hint to Bazel's scheduler).21c

module_topQName passed to `create_bd_design` in `script`. Used to locate the produced `.bd`. >
part_number+Xilinx part number the BD is generated for. �

post_hooks�`.tcl`/`.xdc`/`.sdc` files OR `tcl_binary` targets sourced after `generate_target all`, before the project closes. Sourced in list order. Useful for `make_wrapper` (auto-generated HDL wrapper) or `write_bd_tcl` round-tripping.2[]�
	pre_hooks�`.tcl`/`.xdc`/`.sdc` files OR `tcl_binary` targets sourced after project + IP-block setup, before sourcing the user's BD TCL. Sourced in list order.2[]�
project_hooks�`.tcl`/`.xdc`/`.sdc` files OR `tcl_binary` targets sourced INSIDE any downstream `vivado_project` action that folds this target in via `ip_blocks` / `block_designs`. Fires right after `create_project` + `source_mgmt_mode`, before any `add_files`. Home for setup the target needs to work in context (`board_part`, `set_msg_config`, TCL procs). Does NOT run in this target's own action â for that use `pre_hooks` / `post_hooks`. Sourced in list order; multiple targets' contributions concat in project-attr dep order; the project's own `pre_hooks_early` fires last so it wins on override.2[]�
script�Executable target (a `tcl_binary`) whose script is sourced inside a fresh Vivado project to build the block design. Must call `create_bd_design "<module_top>"` and end with `save_bd_design`. Its `tcl_library` deps are staged as runfiles and reached with `package require`. A bare `.tcl` file is not accepted; wrap it in a `tcl_binary`. ">
vivado_block_design'@@rules_vivado//vivado:block_design.bzl
GG,
*
nameA unique name for this target. a
_
block_design_templateThe create-bd tcl template.2'//vivado/private:create_bd.tcl.templatek
i
	ip_blocksAPackaged IP blocks referenced by the BD's `create_bd_cell` calls.*
VivadoIPBlockInfo2[]K
I
jobs<Jobs to pass to vivado (resource hint to Bazel's scheduler).21e
c

module_topQName passed to `create_bd_design` in `script`. Used to locate the produced `.bd`. @
>
part_number+Xilinx part number the BD is generated for. �
�

post_hooks�`.tcl`/`.xdc`/`.sdc` files OR `tcl_binary` targets sourced after `generate_target all`, before the project closes. Sourced in list order. Useful for `make_wrapper` (auto-generated HDL wrapper) or `write_bd_tcl` round-tripping.2[]�
�
	pre_hooks�`.tcl`/`.xdc`/`.sdc` files OR `tcl_binary` targets sourced after project + IP-block setup, before sourcing the user's BD TCL. Sourced in list order.2[]�
�
project_hooks�`.tcl`/`.xdc`/`.sdc` files OR `tcl_binary` targets sourced INSIDE any downstream `vivado_project` action that folds this target in via `ip_blocks` / `block_designs`. Fires right after `create_project` + `source_mgmt_mode`, before any `add_files`. Home for setup the target needs to work in context (`board_part`, `set_msg_config`, TCL procs). Does NOT run in this target's own action â for that use `pre_hooks` / `post_hooks`. Sourced in list order; multiple targets' contributions concat in project-attr dep order; the project's own `pre_hooks_early` fires last so it wins on override.2[]�
�
script�Executable target (a `tcl_binary`) whose script is sourced inside a fresh Vivado project to build the block design. Must call `create_bd_design "<module_top>"` and end with `save_bd_design`. Its `tcl_library` deps are staged as runfiles and reached with `package require`. A bare `.tcl` file is not accepted; wrap it in a `tcl_binary`. �
//vivado:providers.bzlr�
%
rules_vivadovivadoproviders.bzl<
VivadoBlockDesignInfoVivadoBlockDesignInfo
.C4
VivadoIPBlockInfoVivadoIPBlockInfo
GX
Z�
//vivado/private:common.bzlr�
*
rules_vivadovivado/private
common.bzl.
TOOLCHAIN_TYPETOOLCHAIN_TYPE
:
get_vivado_toolchainget_vivado_toolchain
&

hook_attrs
hook_attrs
0
hook_invocationhook_invocation
		.
ip_blocks_dataip_blocks_data


6
project_hooks_attrproject_hooks_attr
2
run_tcl_templaterun_tcl_template
0
tcl_script_attrtcl_script_attr
0
tcl_script_datatcl_script_data

'Block-design rule: vivado_block_design.�
(
rules_vivadovivadodebug_probes.bzl�vivado_debug_probes�Emit a `.ltx` debug-probes file from a phase checkpoint via `write_debug_probes`.

Vivado's Hardware Manager reads the `.ltx` during ILA / VIO bring-up to
map probe nets back to design signals. Any phase checkpoint works, so
point `checkpoint` at whichever phase suits the design â usually
post-place or post-route, since probes track physical resources.

Provides `VivadoDebugProbesInfo`.
"�
�	
vivado_debug_probes�Emit a `.ltx` debug-probes file from a phase checkpoint via `write_debug_probes`.

Vivado's Hardware Manager reads the `.ltx` during ILA / VIO bring-up to
map probe nets back to design signals. Any phase checkpoint works, so
point `checkpoint` at whichever phase suits the design â usually
post-place or post-route, since probes track physical resources.

Provides `VivadoDebugProbesInfo`.
*
nameA unique name for this target. �

checkpointmPhase checkpoint (synth, placement, or routing). Rule picks the most-specific provider present on the target. *
VivadoSynthCheckpointInfo*
VivadoPlacementCheckpointInfo*
VivadoRoutingCheckpointInfou

post_hooksa`.tcl` files OR `tcl_binary` targets sourced after `write_debug_probes` completes, in list order.2[]�
	pre_hooksq`.tcl` files OR `tcl_binary` targets sourced on the opened checkpoint before `write_debug_probes`, in list order.2[]7
threads'Threads passed to `general.maxThreads`.28w
write_debug_probes_template$The write_debug_probes tcl template.20//vivado/private:write_debug_probes.tcl.template">
vivado_debug_probes'@@rules_vivado//vivado:debug_probes.bzl
YY,
*
nameA unique name for this target. �
�

checkpointmPhase checkpoint (synth, placement, or routing). Rule picks the most-specific provider present on the target. *
VivadoSynthCheckpointInfo*
VivadoPlacementCheckpointInfo*
VivadoRoutingCheckpointInfow
u

post_hooksa`.tcl` files OR `tcl_binary` targets sourced after `write_debug_probes` completes, in list order.2[]�
�
	pre_hooksq`.tcl` files OR `tcl_binary` targets sourced on the opened checkpoint before `write_debug_probes`, in list order.2[]9
7
threads'Threads passed to `general.maxThreads`.28y
w
write_debug_probes_template$The write_debug_probes tcl template.20//vivado/private:write_debug_probes.tcl.template�
//vivado:providers.bzlr�
%
rules_vivadovivadoproviders.bzl<
VivadoDebugProbesInfoVivadoDebugProbesInfo
,
VivadoLogInfoVivadoLogInfo
L
VivadoPlacementCheckpointInfoVivadoPlacementCheckpointInfo
#H
VivadoRoutingCheckpointInfoVivadoRoutingCheckpointInfo
!D
VivadoSynthCheckpointInfoVivadoSynthCheckpointInfo
		

�
//vivado/private:common.bzlr�
*
rules_vivadovivado/private
common.bzl.
TOOLCHAIN_TYPETOOLCHAIN_TYPE
:
get_vivado_toolchainget_vivado_toolchain
&

hook_attrs
hook_attrs
0
hook_invocationhook_invocation
2
run_tcl_templaterun_tcl_template

# vivado_debug_probes rule.��
 
rules_vivadovivadodefs.bzl�vivado_bitstream�Write a Vivado bitstream (.bit) from a routed checkpoint. For the `.xsa` hardware-platform handoff artifact, compose `vivado_hw_platform` on the same checkpoint."�
�

vivado_bitstream�Write a Vivado bitstream (.bit) from a routed checkpoint. For the `.xsa` hardware-platform handoff artifact, compose `vivado_hw_platform` on the same checkpoint.*
nameA unique name for this target. C

checkpointRouted checkpoint. *
VivadoRoutingCheckpointInfo�

post_hookso`.tcl`/`.xdc`/`.sdc` files OR `tcl_binary` targets sourced after a successful `write_bitstream`, in list order.2[]�
	pre_hooksm`.tcl`/`.xdc`/`.sdc` files OR `tcl_binary` targets sourced on the opened checkpoint before `write_bitstream`.2[]R
threadsBThreads to pass to vivado which defines the amount of parallelism.28�
timing_check�Policy for post-route timing violations. Both setup (WNS) and hold (WHS) worst slack are probed. `error` (default) fails the action; `warn` logs a CRITICAL WARNING and runs `write_bitstream` anyway; `none` skips the gate entirely. A design with no post-route timing paths at all is always treated as unconstrained (warning, not failure).2"error"�

write_args�Extra flags passed through to `write_bitstream`. Cannot contain `-force` (always emitted by the rule) or `-file` (the rule's declared output path is the positional arg).2[]m
write_bitstream_template The write bitstream tcl template2-//vivado/private:write_bitstream.tcl.template"3
vivado_bitstream@@rules_vivado//vivado:defs.bzl
kk,
*
nameA unique name for this target. E
C

checkpointRouted checkpoint. *
VivadoRoutingCheckpointInfo�
�

post_hookso`.tcl`/`.xdc`/`.sdc` files OR `tcl_binary` targets sourced after a successful `write_bitstream`, in list order.2[]�
�
	pre_hooksm`.tcl`/`.xdc`/`.sdc` files OR `tcl_binary` targets sourced on the opened checkpoint before `write_bitstream`.2[]T
R
threadsBThreads to pass to vivado which defines the amount of parallelism.28�
�
timing_check�Policy for post-route timing violations. Both setup (WNS) and hold (WHS) worst slack are probed. `error` (default) fails the action; `warn` logs a CRITICAL WARNING and runs `write_bitstream` anyway; `none` skips the gate entirely. A design with no post-route timing paths at all is always treated as unconstrained (warning, not failure).2"error"�
�

write_args�Extra flags passed through to `write_bitstream`. Cannot contain `-force` (always emitted by the rule) or `-file` (the rule's declared output path is the positional arg).2[]o
m
write_bitstream_template The write bitstream tcl template2-//vivado/private:write_bitstream.tcl.template�/vivado_block_design�Build a Vivado block design (.bd) from a user-authored Tcl script.

`script` is sourced inside a fresh Vivado project. It must call
`create_bd_design "<module_top>"`, add/connect cells, and end with
`save_bd_design`. The attr takes an executable target â in practice a
`tcl_binary`, which is what carries the `deps` a script needs to
`package require` shared `tcl_library` helpers. An extra-toolchains
transition routes it through the Vivado tcl toolchain, so its wrapper
comes out as a `.vhook.tcl` Vivado can source directly and its deps land
on `auto_path`.

The resulting `.bd` is normalized to `<bd_dir>/<module_top>.bd` so
consumers can reference it predictably.

Use the `block_designs` attribute on `vivado_project` to fold this BD
into a synth project; `vivado_synthesis` picks it up and runs
`generate_target {synthesis implementation}` on it automatically.

Block designs may reference packaged IP via the `ip_blocks` attribute; those
IP repos are propagated to consumers so the synth project's IP catalog
resolves the same `create_ip` calls baked into the BD.
"�&
�
vivado_block_design�Build a Vivado block design (.bd) from a user-authored Tcl script.

`script` is sourced inside a fresh Vivado project. It must call
`create_bd_design "<module_top>"`, add/connect cells, and end with
`save_bd_design`. The attr takes an executable target â in practice a
`tcl_binary`, which is what carries the `deps` a script needs to
`package require` shared `tcl_library` helpers. An extra-toolchains
transition routes it through the Vivado tcl toolchain, so its wrapper
comes out as a `.vhook.tcl` Vivado can source directly and its deps land
on `auto_path`.

The resulting `.bd` is normalized to `<bd_dir>/<module_top>.bd` so
consumers can reference it predictably.

Use the `block_designs` attribute on `vivado_project` to fold this BD
into a synth project; `vivado_synthesis` picks it up and runs
`generate_target {synthesis implementation}` on it automatically.

Block designs may reference packaged IP via the `ip_blocks` attribute; those
IP repos are propagated to consumers so the synth project's IP catalog
resolves the same `create_ip` calls baked into the BD.
*
nameA unique name for this target. _
block_design_templateThe create-bd tcl template.2'//vivado/private:create_bd.tcl.templatei
	ip_blocksAPackaged IP blocks referenced by the BD's `create_bd_cell` calls.*
VivadoIPBlockInfo2[]I
jobs<Jobs to pass to vivado (resource hint to Bazel's scheduler).21c

module_topQName passed to `create_bd_design` in `script`. Used to locate the produced `.bd`. >
part_number+Xilinx part number the BD is generated for. �

post_hooks�`.tcl`/`.xdc`/`.sdc` files OR `tcl_binary` targets sourced after `generate_target all`, before the project closes. Sourced in list order. Useful for `make_wrapper` (auto-generated HDL wrapper) or `write_bd_tcl` round-tripping.2[]�
	pre_hooks�`.tcl`/`.xdc`/`.sdc` files OR `tcl_binary` targets sourced after project + IP-block setup, before sourcing the user's BD TCL. Sourced in list order.2[]�
project_hooks�`.tcl`/`.xdc`/`.sdc` files OR `tcl_binary` targets sourced INSIDE any downstream `vivado_project` action that folds this target in via `ip_blocks` / `block_designs`. Fires right after `create_project` + `source_mgmt_mode`, before any `add_files`. Home for setup the target needs to work in context (`board_part`, `set_msg_config`, TCL procs). Does NOT run in this target's own action â for that use `pre_hooks` / `post_hooks`. Sourced in list order; multiple targets' contributions concat in project-attr dep order; the project's own `pre_hooks_early` fires last so it wins on override.2[]�
script�Executable target (a `tcl_binary`) whose script is sourced inside a fresh Vivado project to build the block design. Must call `create_bd_design "<module_top>"` and end with `save_bd_design`. Its `tcl_library` deps are staged as runfiles and reached with `package require`. A bare `.tcl` file is not accepted; wrap it in a `tcl_binary`. "6
vivado_block_design@@rules_vivado//vivado:defs.bzl
GG,
*
nameA unique name for this target. a
_
block_design_templateThe create-bd tcl template.2'//vivado/private:create_bd.tcl.templatek
i
	ip_blocksAPackaged IP blocks referenced by the BD's `create_bd_cell` calls.*
VivadoIPBlockInfo2[]K
I
jobs<Jobs to pass to vivado (resource hint to Bazel's scheduler).21e
c

module_topQName passed to `create_bd_design` in `script`. Used to locate the produced `.bd`. @
>
part_number+Xilinx part number the BD is generated for. �
�

post_hooks�`.tcl`/`.xdc`/`.sdc` files OR `tcl_binary` targets sourced after `generate_target all`, before the project closes. Sourced in list order. Useful for `make_wrapper` (auto-generated HDL wrapper) or `write_bd_tcl` round-tripping.2[]�
�
	pre_hooks�`.tcl`/`.xdc`/`.sdc` files OR `tcl_binary` targets sourced after project + IP-block setup, before sourcing the user's BD TCL. Sourced in list order.2[]�
�
project_hooks�`.tcl`/`.xdc`/`.sdc` files OR `tcl_binary` targets sourced INSIDE any downstream `vivado_project` action that folds this target in via `ip_blocks` / `block_designs`. Fires right after `create_project` + `source_mgmt_mode`, before any `add_files`. Home for setup the target needs to work in context (`board_part`, `set_msg_config`, TCL procs). Does NOT run in this target's own action â for that use `pre_hooks` / `post_hooks`. Sourced in list order; multiple targets' contributions concat in project-attr dep order; the project's own `pre_hooks_early` fires last so it wins on override.2[]�
�
script�Executable target (a `tcl_binary`) whose script is sourced inside a fresh Vivado project to build the block design. Must call `create_bd_design "<module_top>"` and end with `save_bd_design`. Its `tcl_library` deps are staged as runfiles and reached with `package require`. A bare `.tcl` file is not accepted; wrap it in a `tcl_binary`. �"vivado_compile_simlib�Pre-compile the Xilinx baseline simulation libraries (`unisim`,
`unimacro`, `secureip`, `unifast`, ...) for a third-party simulator. Output is
a TreeArtifact at the layout `compile_simlib -directory <dir>` produces.

`compile_simlib` is hours of work for `-family all`; pass a specific silicon
family to bound the scope. The simulator install is located via an env-var
lookup on the exec platform (`$RIVIERA_HOME` for riviera, etc.) because
`compile_simlib` shells out to vsimsa AND its peer tools.
"�
�
vivado_compile_simlib�Pre-compile the Xilinx baseline simulation libraries (`unisim`,
`unimacro`, `secureip`, `unifast`, ...) for a third-party simulator. Output is
a TreeArtifact at the layout `compile_simlib -directory <dir>` produces.

`compile_simlib` is hours of work for `-family all`; pass a specific silicon
family to bound the scope. The simulator install is located via an env-var
lookup on the exec platform (`$RIVIERA_HOME` for riviera, etc.) because
`compile_simlib` shells out to vsimsa AND its peer tools.
*
nameA unique name for this target. y
compile_simlib_template.The tcl template that drives `compile_simlib`.2,//vivado/private:compile_simlib.tcl.template�
family�Xilinx silicon family, passed to `compile_simlib -family <X>`. Common values: `all` (hours), `versal`, `kintexuplus`, `zynquplus`. L
language7HDL language, passed to `compile_simlib -language <X>`.2"all"�
library�Simulation library set, passed to `compile_simlib -library <X>`. For families whose `all` set omits a needed library, compile that library in a second target with `no_ip_compile = True` and chain via `vmap -link` at consume time.2"all"�
license_resource_countiNumber of `license_resource_name` units to claim. Values <= 0 fall back to 1 when a resource name is set.20�
license_resource_name�FlexLM feature name to claim from Bazel's local resource pool. Callers wire the pool via `--local_extra_resources=<name>=N`. Overrides the built-in default map (activehdl, riviera). Empty falls back to that map.2""�
no_ip_compile�Pass `-no_ip_compile`. Required on chained follow-up targets: Vivado rewrites `library.cfg` on each `compile_simlib`, so a later call's IP compile pass errors with `Library "<baseline>" not found` because the fresh `library.cfg` lacks the baseline mappings the IPs reference.2False�
no_systemc_compile�Pass `-no_systemc_compile` (default true). The SystemC libs require a working SystemC install reachable by the simulator's C++ toolchain, which often isn't present in CI images.2True[
	simulatorJTarget simulator. `xsim` is built into Vivado and doesn't need precompile. "8
vivado_compile_simlib@@rules_vivado//vivado:defs.bzl
��,
*
nameA unique name for this target. {
y
compile_simlib_template.The tcl template that drives `compile_simlib`.2,//vivado/private:compile_simlib.tcl.template�
�
family�Xilinx silicon family, passed to `compile_simlib -family <X>`. Common values: `all` (hours), `versal`, `kintexuplus`, `zynquplus`. N
L
language7HDL language, passed to `compile_simlib -language <X>`.2"all"�
�
library�Simulation library set, passed to `compile_simlib -library <X>`. For families whose `all` set omits a needed library, compile that library in a second target with `no_ip_compile = True` and chain via `vmap -link` at consume time.2"all"�
�
license_resource_countiNumber of `license_resource_name` units to claim. Values <= 0 fall back to 1 when a resource name is set.20�
�
license_resource_name�FlexLM feature name to claim from Bazel's local resource pool. Callers wire the pool via `--local_extra_resources=<name>=N`. Overrides the built-in default map (activehdl, riviera). Empty falls back to that map.2""�
�
no_ip_compile�Pass `-no_ip_compile`. Required on chained follow-up targets: Vivado rewrites `library.cfg` on each `compile_simlib`, so a later call's IP compile pass errors with `Library "<baseline>" not found` because the fresh `library.cfg` lacks the baseline mappings the IPs reference.2False�
�
no_systemc_compile�Pass `-no_systemc_compile` (default true). The SystemC libs require a working SystemC install reachable by the simulator's C++ toolchain, which often isn't present in CI images.2True]
[
	simulatorJTarget simulator. `xsim` is built into Vivado and doesn't need precompile. �vivado_debug_probes�Emit a `.ltx` debug-probes file from a phase checkpoint via `write_debug_probes`.

Vivado's Hardware Manager reads the `.ltx` during ILA / VIO bring-up to
map probe nets back to design signals. Any phase checkpoint works, so
point `checkpoint` at whichever phase suits the design â usually
post-place or post-route, since probes track physical resources.

Provides `VivadoDebugProbesInfo`.
"�
�	
vivado_debug_probes�Emit a `.ltx` debug-probes file from a phase checkpoint via `write_debug_probes`.

Vivado's Hardware Manager reads the `.ltx` during ILA / VIO bring-up to
map probe nets back to design signals. Any phase checkpoint works, so
point `checkpoint` at whichever phase suits the design â usually
post-place or post-route, since probes track physical resources.

Provides `VivadoDebugProbesInfo`.
*
nameA unique name for this target. �

checkpointmPhase checkpoint (synth, placement, or routing). Rule picks the most-specific provider present on the target. *
VivadoSynthCheckpointInfo*
VivadoPlacementCheckpointInfo*
VivadoRoutingCheckpointInfou

post_hooksa`.tcl` files OR `tcl_binary` targets sourced after `write_debug_probes` completes, in list order.2[]�
	pre_hooksq`.tcl` files OR `tcl_binary` targets sourced on the opened checkpoint before `write_debug_probes`, in list order.2[]7
threads'Threads passed to `general.maxThreads`.28w
write_debug_probes_template$The write_debug_probes tcl template.20//vivado/private:write_debug_probes.tcl.template"6
vivado_debug_probes@@rules_vivado//vivado:defs.bzl
YY,
*
nameA unique name for this target. �
�

checkpointmPhase checkpoint (synth, placement, or routing). Rule picks the most-specific provider present on the target. *
VivadoSynthCheckpointInfo*
VivadoPlacementCheckpointInfo*
VivadoRoutingCheckpointInfow
u

post_hooksa`.tcl` files OR `tcl_binary` targets sourced after `write_debug_probes` completes, in list order.2[]�
�
	pre_hooksq`.tcl` files OR `tcl_binary` targets sourced on the opened checkpoint before `write_debug_probes`, in list order.2[]9
7
threads'Threads passed to `general.maxThreads`.28y
w
write_debug_probes_template$The write_debug_probes tcl template.20//vivado/private:write_debug_probes.tcl.template�&vivado_device_image�Write a Versal device image (.pdi) from a routed checkpoint. For non-Versal architectures use `vivado_bitstream` instead. For the `.xsa` hardware-platform handoff artifact, compose `vivado_hw_platform` on the same checkpoint."�$
�
vivado_device_image�Write a Versal device image (.pdi) from a routed checkpoint. For non-Versal architectures use `vivado_bitstream` instead. For the `.xsa` hardware-platform handoff artifact, compose `vivado_hw_platform` on the same checkpoint.*
nameA unique name for this target. C

checkpointRouted checkpoint. *
VivadoRoutingCheckpointInfo�
no_pdi�Skip Vivado's internal bootgen wrap and shift PDI-production to `post_hooks`. When True, Vivado runs `write_device_image` with `-no_pdi` â only the intermediate `.rcdo` / `.rnpi` files (base name = `$env(VIVADO_PDI_INTERMEDIATE_BASE)`) plus a `gen_files/` directory are emitted. A `post_hooks` entry MUST produce the final `.pdi` at `$env(VIVADO_PDI_OUT)` (typically via `exec bootgen -arch versal -image <BIF> -w -o $env(VIVADO_PDI_OUT)`); Bazel fails the action if the file is missing. Both paths are exported as process env vars so hooks read them via the standard `$env(...)` channel without depending on Tcl globals the caller can't see. Note: the resulting 'declared output was not created' error surfaces at the rule level, not the hook, so hook authors need to know they own the PDI when this is set.2False�

post_hooks�`.tcl`/`.xdc`/`.sdc` files OR `tcl_binary` targets sourced after a successful `write_device_image`, in list order. When `no_pdi = True`, at least one post_hook MUST produce the final `.pdi` at `$env(VIVADO_PDI_OUT)`.2[]�
	pre_hooksp`.tcl`/`.xdc`/`.sdc` files OR `tcl_binary` targets sourced on the opened checkpoint before `write_device_image`.2[]R
threadsBThreads to pass to vivado which defines the amount of parallelism.28�
timing_check�Policy for post-route timing violations. Both setup (WNS) and hold (WHS) worst slack are probed. `error` (default) fails the action; `warn` logs a CRITICAL WARNING and runs `write_device_image` anyway; `none` skips the gate entirely. A design with no post-route timing paths at all is always treated as unconstrained (warning, not failure).2"error"�

write_args�Extra flags passed through to `write_device_image`. Cannot contain `-force` (always emitted by the rule), `-file` (the rule's declared output path is the positional arg), or `-no_pdi` (use the dedicated `no_pdi` attr).2[]v
write_device_image_template#The write device image tcl template20//vivado/private:write_device_image.tcl.template"6
vivado_device_image@@rules_vivado//vivado:defs.bzl
��,
*
nameA unique name for this target. E
C

checkpointRouted checkpoint. *
VivadoRoutingCheckpointInfo�
�
no_pdi�Skip Vivado's internal bootgen wrap and shift PDI-production to `post_hooks`. When True, Vivado runs `write_device_image` with `-no_pdi` â only the intermediate `.rcdo` / `.rnpi` files (base name = `$env(VIVADO_PDI_INTERMEDIATE_BASE)`) plus a `gen_files/` directory are emitted. A `post_hooks` entry MUST produce the final `.pdi` at `$env(VIVADO_PDI_OUT)` (typically via `exec bootgen -arch versal -image <BIF> -w -o $env(VIVADO_PDI_OUT)`); Bazel fails the action if the file is missing. Both paths are exported as process env vars so hooks read them via the standard `$env(...)` channel without depending on Tcl globals the caller can't see. Note: the resulting 'declared output was not created' error surfaces at the rule level, not the hook, so hook authors need to know they own the PDI when this is set.2False�
�

post_hooks�`.tcl`/`.xdc`/`.sdc` files OR `tcl_binary` targets sourced after a successful `write_device_image`, in list order. When `no_pdi = True`, at least one post_hook MUST produce the final `.pdi` at `$env(VIVADO_PDI_OUT)`.2[]�
�
	pre_hooksp`.tcl`/`.xdc`/`.sdc` files OR `tcl_binary` targets sourced on the opened checkpoint before `write_device_image`.2[]T
R
threadsBThreads to pass to vivado which defines the amount of parallelism.28�
�
timing_check�Policy for post-route timing violations. Both setup (WNS) and hold (WHS) worst slack are probed. `error` (default) fails the action; `warn` logs a CRITICAL WARNING and runs `write_device_image` anyway; `none` skips the gate entirely. A design with no post-route timing paths at all is always treated as unconstrained (warning, not failure).2"error"�
�

write_args�Extra flags passed through to `write_device_image`. Cannot contain `-force` (always emitted by the rule), `-file` (the rule's declared output path is the positional arg), or `-no_pdi` (use the dedicated `no_pdi` attr).2[]x
v
write_device_image_template#The write device image tcl template20//vivado/private:write_device_image.tcl.template�vivado_export_simulation�Run Vivado's `export_simulation` over a `vivado_project` and
stage the resulting directory as a TreeArtifact. The downstream
simulator is not run; consumers compose against `VivadoExportSimulationInfo`.

The exported `compile.sh` / `elaborate.sh` / `simulate.sh` scripts are
path-sanitized like every other output: absolute paths become
`<execroot>/` so the tree stays cacheable across hosts and RBE workers.
The bundle is therefore not runnable straight out of `bazel-bin` â a
consumer re-points the marker at its own root first (`sed -i
"s|<execroot>/|$PWD/|g"`). See `vivado_toolchain(sanitizer = ...)`.
"�
�
vivado_export_simulation�Run Vivado's `export_simulation` over a `vivado_project` and
stage the resulting directory as a TreeArtifact. The downstream
simulator is not run; consumers compose against `VivadoExportSimulationInfo`.

The exported `compile.sh` / `elaborate.sh` / `simulate.sh` scripts are
path-sanitized like every other output: absolute paths become
`<execroot>/` so the tree stays cacheable across hosts and RBE workers.
The bundle is therefore not runnable straight out of `bazel-bin` â a
consumer re-points the marker at its own root first (`sed -i
"s|<execroot>/|$PWD/|g"`). See `vivado_toolchain(sanitizer = ...)`.
*
nameA unique name for this target. �
export_simulation_template1The tcl template that drives `export_simulation`.2///vivado/private:export_simulation.tcl.templates

module_topaSimulation-fileset top module. Typically the testbench name, or `<bd>_wrapper` for a BD-only sim. �
post_hook_tools�Executable targets invoked in the same Bazel action AFTER Vivado exits. Each receives `--project-dir <path> --export-dir <path>` and the same paths via `VIVADO_PROJECT_DIR` / `VIVADO_EXPORT_DIR` env vars. Order is preserved; first non-zero exit fails the action.2[]�

post_hooks�`.tcl` files OR `tcl_binary` targets sourced inside Vivado at the end of the export body, with the project still open. Sourced in list order.2[]_
pre_hook_toolsGExecutable targets invoked BEFORE Vivado starts; see `post_hook_tools`.2[]�
	pre_hooks�`.tcl` files OR `tcl_binary` targets sourced after the project script + sim elaboration, before `export_simulation` runs. Sourced in list order.2[]�
project�`vivado_project` target carrying the emitted project TCL script + its transitive input closure. All project-shape attrs (module, part_number, block_designs, ip_blocks, pre_hooks_early, etc.) live on that target. *
VivadoProjectInfo1
	simulator Target simulator for the export. ";
vivado_export_simulation@@rules_vivado//vivado:defs.bzl
� � ,
*
nameA unique name for this target. �
�
export_simulation_template1The tcl template that drives `export_simulation`.2///vivado/private:export_simulation.tcl.templateu
s

module_topaSimulation-fileset top module. Typically the testbench name, or `<bd>_wrapper` for a BD-only sim. �
�
post_hook_tools�Executable targets invoked in the same Bazel action AFTER Vivado exits. Each receives `--project-dir <path> --export-dir <path>` and the same paths via `VIVADO_PROJECT_DIR` / `VIVADO_EXPORT_DIR` env vars. Order is preserved; first non-zero exit fails the action.2[]�
�

post_hooks�`.tcl` files OR `tcl_binary` targets sourced inside Vivado at the end of the export body, with the project still open. Sourced in list order.2[]a
_
pre_hook_toolsGExecutable targets invoked BEFORE Vivado starts; see `post_hook_tools`.2[]�
�
	pre_hooks�`.tcl` files OR `tcl_binary` targets sourced after the project script + sim elaboration, before `export_simulation` runs. Sourced in list order.2[]�
�
project�`vivado_project` target carrying the emitted project TCL script + its transitive input closure. All project-shape attrs (module, part_number, block_designs, ip_blocks, pre_hooks_early, etc.) live on that target. *
VivadoProjectInfo3
1
	simulator Target simulator for the export. � vivado_hw_platform�Write a Xilinx `.xsa` hardware-platform archive from a routed checkpoint via `write_hw_platform`.

The `.xsa` is the handoff artifact for Vitis, PetaLinux, and the rest of
the Xilinx SDK tooling. Compose this directly on `vivado_routing` (or
any `VivadoRoutingCheckpointInfo` provider) so `.xsa` production is its
own target, independent of whether a bitstream or device image is also
being built.

Provides `VivadoHwPlatformInfo`.
"�
�
vivado_hw_platform�Write a Xilinx `.xsa` hardware-platform archive from a routed checkpoint via `write_hw_platform`.

The `.xsa` is the handoff artifact for Vitis, PetaLinux, and the rest of
the Xilinx SDK tooling. Compose this directly on `vivado_routing` (or
any `VivadoRoutingCheckpointInfo` provider) so `.xsa` production is its
own target, independent of whether a bitstream or device image is also
being built.

Provides `VivadoHwPlatformInfo`.
*
nameA unique name for this target. `

checkpoint/Routed checkpoint the platform is written from. *
VivadoRoutingCheckpointInfo�
hw_only�Pass `-hw_only` to `write_hw_platform`. When True, produces a hardware-only platform (no bitstream embedded); overrides `include_bit`.2False�
include_bit�Embed a bitstream in the `.xsa` (`-include_bit`). `write_hw_platform` can only embed a bitstream written in the same Vivado session, so the action first runs `write_bitstream` on the opened checkpoint â a full bitstream generation, with no `timing_check` gate â and then packs the result. Set False to skip that cost when the `.xsa` only needs the hardware description, or `hw_only = True` for an explicitly hardware-only platform (which overrides this). Default True matches the historical `with_xsa` bolt-on behavior.2Truet

post_hooks``.tcl` files OR `tcl_binary` targets sourced after `write_hw_platform` completes, in list order.2[]�
	pre_hooksu`.tcl` files OR `tcl_binary` targets sourced on the opened checkpoint before `write_hw_platform` runs, in list order.2[]7
threads'Threads passed to `general.maxThreads`.28�

write_args�Extra flags passed through to `write_hw_platform`. Cannot contain `-file` (the rule's declared `.xsa` path is the argument), `-force` (always emitted), `-fixed` (always emitted for single-image platforms), `-hw_only` / `-include_bit` (use dedicated attrs).2[]t
write_hw_platform_template#The write_hw_platform tcl template.2///vivado/private:write_hw_platform.tcl.template"5
vivado_hw_platform@@rules_vivado//vivado:defs.bzl
VV,
*
nameA unique name for this target. b
`

checkpoint/Routed checkpoint the platform is written from. *
VivadoRoutingCheckpointInfo�
�
hw_only�Pass `-hw_only` to `write_hw_platform`. When True, produces a hardware-only platform (no bitstream embedded); overrides `include_bit`.2False�
�
include_bit�Embed a bitstream in the `.xsa` (`-include_bit`). `write_hw_platform` can only embed a bitstream written in the same Vivado session, so the action first runs `write_bitstream` on the opened checkpoint â a full bitstream generation, with no `timing_check` gate â and then packs the result. Set False to skip that cost when the `.xsa` only needs the hardware description, or `hw_only = True` for an explicitly hardware-only platform (which overrides this). Default True matches the historical `with_xsa` bolt-on behavior.2Truev
t

post_hooks``.tcl` files OR `tcl_binary` targets sourced after `write_hw_platform` completes, in list order.2[]�
�
	pre_hooksu`.tcl` files OR `tcl_binary` targets sourced on the opened checkpoint before `write_hw_platform` runs, in list order.2[]9
7
threads'Threads passed to `general.maxThreads`.28�
�

write_args�Extra flags passed through to `write_hw_platform`. Cannot contain `-file` (the rule's declared `.xsa` path is the argument), `-force` (always emitted), `-fixed` (always emitted for single-image platforms), `-hw_only` / `-include_bit` (use dedicated attrs).2[]v
t
write_hw_platform_template#The write_hw_platform tcl template.2///vivado/private:write_hw_platform.tcl.template�vivado_interface_definitioncGenerate Vivado IP-XACT interface definition files (bus definition and abstraction definition XML)."�
�

vivado_interface_definitioncGenerate Vivado IP-XACT interface definition files (bus definition and abstraction definition XML).*
nameA unique name for this target. �
abstraction_definition_template(The abstraction definition XML template.24//vivado/private:abstraction_definition.xml.templatek
bus_definition_template The bus definition XML template.2,//vivado/private:bus_definition.xml.template3
descriptionDescription for the interface.2""D
direct_connection'Whether direct connections are allowed.2TrueE
interface_name/The name of the interface (e.g., 'hbm_reader'). n
interface_setup_template!The interface setup TCL template.2-//vivado/private:interface_setup.tcl.template?
is_addressable%Whether the interface is addressable.2TrueI
library/The library VLNV component (e.g., 'interface').2"interface".
max_mastersMaximum number of masters.21,

max_slavesMaximum number of slaves.21u
parserDPython parser script (SV -> JSON). Override to customize SV parsing.2#//vivado/private:parse_sv_interface<
src1The SystemVerilog interface source file to parse. @
vendor2The vendor VLNV component (e.g., 'mycompany.com'). =
version)The version VLNV component (e.g., '1.0').2"1.0"">
vivado_interface_definition@@rules_vivado//vivado:defs.bzl
�#�#,
*
nameA unique name for this target. �
�
abstraction_definition_template(The abstraction definition XML template.24//vivado/private:abstraction_definition.xml.templatem
k
bus_definition_template The bus definition XML template.2,//vivado/private:bus_definition.xml.template5
3
descriptionDescription for the interface.2""F
D
direct_connection'Whether direct connections are allowed.2TrueG
E
interface_name/The name of the interface (e.g., 'hbm_reader'). p
n
interface_setup_template!The interface setup TCL template.2-//vivado/private:interface_setup.tcl.templateA
?
is_addressable%Whether the interface is addressable.2TrueK
I
library/The library VLNV component (e.g., 'interface').2"interface"0
.
max_mastersMaximum number of masters.21.
,

max_slavesMaximum number of slaves.21w
u
parserDPython parser script (SV -> JSON). Override to customize SV parsing.2#//vivado/private:parse_sv_interface>
<
src1The SystemVerilog interface source file to parse. B
@
vendor2The vendor VLNV component (e.g., 'mycompany.com'). ?
=
version)The version VLNV component (e.g., '1.0').2"1.0"�vivado_interface_ippPackage a Vivado interface definition as an IP block. Unlike vivado_ip_core, this does not require a top module."�
�
vivado_interface_ippPackage a Vivado interface definition as an IP block. Unlike vivado_ip_core, this does not require a top module.*
nameA unique name for this target. �
create_interface_ip_template+The TCL template for creating interface IP.21//vivado/private:create_interface_ip.tcl.templateL
	interface$The interface definition to package. *
VivadoInterfaceInfo�
module�The `verilog_library` / `vhdl_library` containing the interface source file(s). Optional. The default template doesn't read these â Vivado discovers bus and abstraction definitions from the repo path alone â but the transitive sources are staged into the action sandbox so a caller-supplied `create_interface_ip_template` can, and so the interface's HDL shows up in coverage instrumentation.*
VerilogInfo*

VhdlInfo2None"6
vivado_interface_ip@@rules_vivado//vivado:defs.bzl
��,
*
nameA unique name for this target. �
�
create_interface_ip_template+The TCL template for creating interface IP.21//vivado/private:create_interface_ip.tcl.templateN
L
	interface$The interface definition to package. *
VivadoInterfaceInfo�
�
module�The `verilog_library` / `vhdl_library` containing the interface source file(s). Optional. The default template doesn't read these â Vivado discovers bus and abstraction definitions from the repo path alone â but the transitive sources are staged into the action sandbox so a caller-supplied `create_interface_ip_template` can, and so the interface's HDL shows up in coverage instrumentation.*
VerilogInfo*

VhdlInfo2None� vivado_ip_core.Use vivado to package a module into an IP core"�
�
vivado_ip_core.Use vivado to package a module into an IP core*
nameA unique name for this target. l
create_ip_block_templateThe create project tcl template2-//vivado/private:create_ip_block.tcl.template�
encryptrEncrypt the sources. Note: This requires a license. See: https://support.xilinx.com/s/article/68071?language=en_US2FalseL
	ip_blocks$Ip blocks to include in this design.*
VivadoIPBlockInfo2[].

ip_libraryThe version of this ip core. -
	ip_vendorThe version of this ip core. .

ip_versionThe version of this ip core. L
jobs?Jobs to pass to vivado which defines the amount of parallelism.24_
keyfile-The keyfile to use when optionally encrypting2#//vivado/private:xilinx_keyfile.txt=
moduleThe top level build. *
VerilogInfo*

VhdlInfo;

module_top)The name of the top level verilog module. ,
part_numberThe targeted xilinx part. �
project_hooks�`.tcl`/`.xdc`/`.sdc` files OR `tcl_binary` targets sourced INSIDE any downstream `vivado_project` action that folds this target in via `ip_blocks` / `block_designs`. Fires right after `create_project` + `source_mgmt_mode`, before any `add_files`. Home for setup the target needs to work in context (`board_part`, `set_msg_config`, TCL procs). Does NOT run in this target's own action â for that use `pre_hooks` / `post_hooks`. Sourced in list order; multiple targets' contributions concat in project-attr dep order; the project's own `pre_hooks_early` fires last so it wins on override.2[]�
supported_families�Xilinx device families this IP can be consumed by (e.g. `["zynq", "zynquplus", "versal"]`). Each entry is registered at `Production` lifecycle. Leave empty to keep whatever `ipx::package_project` inferred from `part_number` â which restricts downstream consumers to the same family and produces `[Coretcl 2-1132] No IP matching VLNV ... is accessible for the current part '<other-family-part>'` when the consumer sits on a different family.2[]"1
vivado_ip_core@@rules_vivado//vivado:defs.bzl
jj,
*
nameA unique name for this target. n
l
create_ip_block_templateThe create project tcl template2-//vivado/private:create_ip_block.tcl.template�
�
encryptrEncrypt the sources. Note: This requires a license. See: https://support.xilinx.com/s/article/68071?language=en_US2FalseN
L
	ip_blocks$Ip blocks to include in this design.*
VivadoIPBlockInfo2[]0
.

ip_libraryThe version of this ip core. /
-
	ip_vendorThe version of this ip core. 0
.

ip_versionThe version of this ip core. N
L
jobs?Jobs to pass to vivado which defines the amount of parallelism.24a
_
keyfile-The keyfile to use when optionally encrypting2#//vivado/private:xilinx_keyfile.txt?
=
moduleThe top level build. *
VerilogInfo*

VhdlInfo=
;

module_top)The name of the top level verilog module. .
,
part_numberThe targeted xilinx part. �
�
project_hooks�`.tcl`/`.xdc`/`.sdc` files OR `tcl_binary` targets sourced INSIDE any downstream `vivado_project` action that folds this target in via `ip_blocks` / `block_designs`. Fires right after `create_project` + `source_mgmt_mode`, before any `add_files`. Home for setup the target needs to work in context (`board_part`, `set_msg_config`, TCL procs). Does NOT run in this target's own action â for that use `pre_hooks` / `post_hooks`. Sourced in list order; multiple targets' contributions concat in project-attr dep order; the project's own `pre_hooks_early` fires last so it wins on override.2[]�
�
supported_families�Xilinx device families this IP can be consumed by (e.g. `["zynq", "zynquplus", "versal"]`). Each entry is registered at `Production` lifecycle. Leave empty to keep whatever `ipx::package_project` inferred from `part_number` â which restricts downstream consumers to the same family and produces `[Coretcl 2-1132] No IP matching VLNV ... is accessible for the current part '<other-family-part>'` when the consumer sits on a different family.2[]�vivado_packaged_ip�Wrap a pre-packaged Vivado IP directory as a consumable IP repo.

For third-party / vendor-supplied IPs â a tree rooted at one or more
`component.xml` files. For Xilinx-catalog IPs configured via a
`create_ip` Tcl use `vivado_xci`; for your own HDL packaged as new IP
use `vivado_ip_core`.

Stages each file in `srcs` into a TreeArtifact, preserving its path
relative to the rule's package (with optional `strip_prefix` applied), and
exposes the staged directory via `VivadoIPBlockInfo.repo`. Consumers list
the target in their `ip_blocks` attr; the existing IP-block plumbing adds
the directory to `ip_repo_paths` in the consumer's project so any
`create_ip` calls referencing the IP's VLNV resolve via the catalog.

The rule is repository-agnostic: it works identically in the main repo,
inside an `http_archive`-fetched external repo, or in any custom
repository rule's generated BUILD file.
"�
�
vivado_packaged_ip�Wrap a pre-packaged Vivado IP directory as a consumable IP repo.

For third-party / vendor-supplied IPs â a tree rooted at one or more
`component.xml` files. For Xilinx-catalog IPs configured via a
`create_ip` Tcl use `vivado_xci`; for your own HDL packaged as new IP
use `vivado_ip_core`.

Stages each file in `srcs` into a TreeArtifact, preserving its path
relative to the rule's package (with optional `strip_prefix` applied), and
exposes the staged directory via `VivadoIPBlockInfo.repo`. Consumers list
the target in their `ip_blocks` attr; the existing IP-block plumbing adds
the directory to `ip_repo_paths` in the consumer's project so any
`create_ip` calls referencing the IP's VLNV resolve via the catalog.

The rule is repository-agnostic: it works identically in the main repo,
inside an `http_archive`-fetched external repo, or in any custom
repository rule's generated BUILD file.
*
nameA unique name for this target. �
hdl_libraries�HDL libraries whose transitive sources contribute to the staged IP tree. Walks `VhdlInfo` / `VerilogInfo` providers and stages each `File` at its package-relative path under the staged root (same path computation as `srcs`).*
VerilogInfo*

VhdlInfo2[]�
srcsrFiles under the IP repo root â typically the non-HDL portion: `component.xml`, `xgui/**`, vendor TCL scripts.2[]�
strip_prefix�Optional package-relative prefix to strip from each src's staging path. Mirrors `http_archive.strip_prefix` semantics. Use when the BUILD file is at a higher level than the IP repo root and you want a flatter staged tree. Vivado walks `ip_repo_paths` recursively for `component.xml`, so this is hygiene/predictability only â leaving it empty doesn't affect correctness.2"""5
vivado_packaged_ip@@rules_vivado//vivado:defs.bzl
^^,
*
nameA unique name for this target. �
�
hdl_libraries�HDL libraries whose transitive sources contribute to the staged IP tree. Walks `VhdlInfo` / `VerilogInfo` providers and stages each `File` at its package-relative path under the staged root (same path computation as `srcs`).*
VerilogInfo*

VhdlInfo2[]�
�
srcsrFiles under the IP repo root â typically the non-HDL portion: `component.xml`, `xgui/**`, vendor TCL scripts.2[]�
�
strip_prefix�Optional package-relative prefix to strip from each src's staging path. Mirrors `http_archive.strip_prefix` semantics. Use when the BUILD file is at a higher level than the IP repo root and you want a flatter staged tree. Vivado walks `ip_repo_paths` recursively for `component.xml`, so this is hygiene/predictability only â leaving it empty doesn't affect correctness.2""�vivado_place_optimize)Run post-placement physical optimization."�
�
vivado_place_optimize)Run post-placement physical optimization.*
nameA unique name for this target. H

checkpointPlacement checkpoint. *
VivadoPlacementCheckpointInfoG
phys_opt_args0Extra flags passed through to `phys_opt_design`.2[]e
place_optimize_templateThe placement tcl template2,//vivado/private:place_optimize.tcl.templatev

post_hooksb`.tcl`/`.xdc`/`.sdc` files OR `tcl_binary` targets sourced after `phys_opt_design`, in list order.2[]�
	pre_hooksm`.tcl`/`.xdc`/`.sdc` files OR `tcl_binary` targets sourced on the opened checkpoint before `phys_opt_design`.2[]�
reportskReport types to run after the phase's main transformation. See `vivado_synthesis.reports` for the full API.2!["timing_summary", "utilization"]R
threadsBThreads to pass to vivado which defines the amount of parallelism.28"8
vivado_place_optimize@@rules_vivado//vivado:defs.bzl
��,
*
nameA unique name for this target. J
H

checkpointPlacement checkpoint. *
VivadoPlacementCheckpointInfoI
G
phys_opt_args0Extra flags passed through to `phys_opt_design`.2[]g
e
place_optimize_templateThe placement tcl template2,//vivado/private:place_optimize.tcl.templatex
v

post_hooksb`.tcl`/`.xdc`/`.sdc` files OR `tcl_binary` targets sourced after `phys_opt_design`, in list order.2[]�
�
	pre_hooksm`.tcl`/`.xdc`/`.sdc` files OR `tcl_binary` targets sourced on the opened checkpoint before `phys_opt_design`.2[]�
�
reportskReport types to run after the phase's main transformation. See `vivado_synthesis.reports` for the full API.2!["timing_summary", "utilization"]T
R
threadsBThreads to pass to vivado which defines the amount of parallelism.28�vivado_placement4Run placement on a (synthesis-optimized) checkpoint."�
�
vivado_placement4Run placement on a (synthesis-optimized) checkpoint.*
nameA unique name for this target. D

checkpointSynthesis checkpoint. *
VivadoSynthCheckpointInfoA

place_args-Extra flags passed through to `place_design`.2[][
placement_templateThe placement tcl template2'//vivado/private:placement.tcl.templates

post_hooks_`.tcl`/`.xdc`/`.sdc` files OR `tcl_binary` targets sourced after `place_design`, in list order.2[]}
	pre_hooksj`.tcl`/`.xdc`/`.sdc` files OR `tcl_binary` targets sourced on the opened checkpoint before `place_design`.2[]�
reportskReport types to run after the phase's main transformation. See `vivado_synthesis.reports` for the full API.2!["timing_summary", "utilization"]R
threadsBThreads to pass to vivado which defines the amount of parallelism.28"3
vivado_placement@@rules_vivado//vivado:defs.bzl
nn,
*
nameA unique name for this target. F
D

checkpointSynthesis checkpoint. *
VivadoSynthCheckpointInfoC
A

place_args-Extra flags passed through to `place_design`.2[]]
[
placement_templateThe placement tcl template2'//vivado/private:placement.tcl.templateu
s

post_hooks_`.tcl`/`.xdc`/`.sdc` files OR `tcl_binary` targets sourced after `place_design`, in list order.2[]
}
	pre_hooksj`.tcl`/`.xdc`/`.sdc` files OR `tcl_binary` targets sourced on the opened checkpoint before `place_design`.2[]�
�
reportskReport types to run after the phase's main transformation. See `vivado_synthesis.reports` for the full API.2!["timing_summary", "utilization"]T
R
threadsBThreads to pass to vivado which defines the amount of parallelism.28�<vivado_project�Emit a TCL project-creation script. Does NOT invoke Vivado.

A spec-carrying rule: its sole build-time action is a template expansion
producing `<name>.project.tcl`, which â sourced inside a Vivado process
â runs `create_project`, source ingest, constraints, and hooks. It stops
short of `generate_target`, because the right intent (`{synthesis
implementation}` vs `simulation`) depends on the consumer; each consumer
issues its own after sourcing.

Two ways to consume it:

- `vivado_synthesis` (and the other phase rules) take
  `project = <label>` and source the emitted script inside their Vivado
  action before doing their own work.
- A GUI launcher can `vivado -source <name>.project.tcl` directly. The
  script's `PROJECT_MODE` / `PROJECT_DIR` variables default to `project`
  mode in `.`; override them with `VIVADO_PROJECT_MODE` /
  `VIVADO_PROJECT_DIR`, or by pre-setting the Tcl variables before
  sourcing.

Provides `VivadoProjectInfo`.
"�4
�
vivado_project�Emit a TCL project-creation script. Does NOT invoke Vivado.

A spec-carrying rule: its sole build-time action is a template expansion
producing `<name>.project.tcl`, which â sourced inside a Vivado process
â runs `create_project`, source ingest, constraints, and hooks. It stops
short of `generate_target`, because the right intent (`{synthesis
implementation}` vs `simulation`) depends on the consumer; each consumer
issues its own after sourcing.

Two ways to consume it:

- `vivado_synthesis` (and the other phase rules) take
  `project = <label>` and source the emitted script inside their Vivado
  action before doing their own work.
- A GUI launcher can `vivado -source <name>.project.tcl` directly. The
  script's `PROJECT_MODE` / `PROJECT_DIR` variables default to `project`
  mode in `.`; override them with `VIVADO_PROJECT_MODE` /
  `VIVADO_PROJECT_DIR`, or by pre-setting the Tcl variables before
  sourcing.

Provides `VivadoProjectInfo`.
*
nameA unique name for this target. �
block_designs�Block designs (`vivado_block_design` targets) to fold into the project. Copied under `$PROJECT_DIR/imported_bds/<name>/` and `add_files`d. The consumer (`vivado_synthesis` / `vivado_xsim_test`) picks the appropriate `generate_target` intent (`{synthesis implementation}` vs `simulation`).*
VivadoBlockDesignInfo2[]�
data�Constraint / setup files (`.xdc`, `.sdc`, `.tcl`) loaded in EXACT list order â the escape hatch for files whose relative ordering matters (e.g. a `set_clock_groups.xdc` that references clocks defined in a `create_clock.xdc` sourced earlier). Loaded AFTER the HDL-walk-swept `.xdc` files from `verilog_library.data` / `vhdl_library.data`, so project-scope constraints layer on top of per-library foundations. `.xdc`/`.sdc` â `read_xdc`, `.tcl` â `source`. Files whose order doesn't matter should live on the HDL library's `.data` instead and ride the HDL dep graph.

Put a `# do not sort` comment above an order-sensitive list. buildifier sorts `data` lists by default, so without it a routine format pass silently rewrites the constraint load order â nothing fails until Vivado applies the wrong constraints.2[]L
	ip_blocks$IP blocks to include in this design.*
VivadoIPBlockInfo2[]�
module�Top-level HDL library. Optional â omit for IP-only projects (e.g. `vivado_export_simulation` in sim-from-packaged-IPs mode). When set, its transitive sources are `read_verilog` / `read_vhdl`d and its `.xdc` / `.tcl` files are added; when unset, only `ip_blocks` / `block_designs` contribute sources.*
VerilogInfo*

VhdlInfo2None;

module_top)The name of the top level verilog module. ,
part_numberThe targeted xilinx part. �
	pre_hooks�`.tcl`/`.xdc`/`.sdc` files OR `tcl_binary` targets sourced AFTER all `add_files` but BEFORE the emitted script returns control to its caller. Home for hooks that need sources loaded but must run before any `generate_target` â e.g. `fixup_constraints.tcl` calling `get_files -of [get_ips]`. For post-elaboration hooks, use the consumer's `pre_hooks` (`vivado_synthesis.pre_hooks`, `vivado_xsim_test.pre_hooks`). For hooks that set project properties (`board_part`) or define TCL procs used by BD sources, use `pre_hooks_early`. Sourced in list order.2[]�
pre_hooks_early�`.tcl`/`.xdc`/`.sdc` files OR `tcl_binary` targets sourced AFTER `create_project` but BEFORE any `add_files`. Home for hooks that set project-scope properties (`board_part`, `set_msg_config`) or define TCL procs consumed by BD `.tcl` scripts loaded during add_files (e.g. `amba::add_associated_busif`, `noc::*`). Sourced in list order.2[]j
project_tcl_template)Template driving the emitted project TCL.2%//vivado/private:project.tcl.template"1
vivado_project@@rules_vivado//vivado:defs.bzl
��,
*
nameA unique name for this target. �
�
block_designs�Block designs (`vivado_block_design` targets) to fold into the project. Copied under `$PROJECT_DIR/imported_bds/<name>/` and `add_files`d. The consumer (`vivado_synthesis` / `vivado_xsim_test`) picks the appropriate `generate_target` intent (`{synthesis implementation}` vs `simulation`).*
VivadoBlockDesignInfo2[]�
�
data�Constraint / setup files (`.xdc`, `.sdc`, `.tcl`) loaded in EXACT list order â the escape hatch for files whose relative ordering matters (e.g. a `set_clock_groups.xdc` that references clocks defined in a `create_clock.xdc` sourced earlier). Loaded AFTER the HDL-walk-swept `.xdc` files from `verilog_library.data` / `vhdl_library.data`, so project-scope constraints layer on top of per-library foundations. `.xdc`/`.sdc` â `read_xdc`, `.tcl` â `source`. Files whose order doesn't matter should live on the HDL library's `.data` instead and ride the HDL dep graph.

Put a `# do not sort` comment above an order-sensitive list. buildifier sorts `data` lists by default, so without it a routine format pass silently rewrites the constraint load order â nothing fails until Vivado applies the wrong constraints.2[]N
L
	ip_blocks$IP blocks to include in this design.*
VivadoIPBlockInfo2[]�
�
module�Top-level HDL library. Optional â omit for IP-only projects (e.g. `vivado_export_simulation` in sim-from-packaged-IPs mode). When set, its transitive sources are `read_verilog` / `read_vhdl`d and its `.xdc` / `.tcl` files are added; when unset, only `ip_blocks` / `block_designs` contribute sources.*
VerilogInfo*

VhdlInfo2None=
;

module_top)The name of the top level verilog module. .
,
part_numberThe targeted xilinx part. �
�
	pre_hooks�`.tcl`/`.xdc`/`.sdc` files OR `tcl_binary` targets sourced AFTER all `add_files` but BEFORE the emitted script returns control to its caller. Home for hooks that need sources loaded but must run before any `generate_target` â e.g. `fixup_constraints.tcl` calling `get_files -of [get_ips]`. For post-elaboration hooks, use the consumer's `pre_hooks` (`vivado_synthesis.pre_hooks`, `vivado_xsim_test.pre_hooks`). For hooks that set project properties (`board_part`) or define TCL procs used by BD sources, use `pre_hooks_early`. Sourced in list order.2[]�
�
pre_hooks_early�`.tcl`/`.xdc`/`.sdc` files OR `tcl_binary` targets sourced AFTER `create_project` but BEFORE any `add_files`. Home for hooks that set project-scope properties (`board_part`, `set_msg_config`) or define TCL procs consumed by BD `.tcl` scripts loaded during add_files (e.g. `amba::add_associated_busif`, `noc::*`). Sourced in list order.2[]l
j
project_tcl_template)Template driving the emitted project TCL.2%//vivado/private:project.tcl.template�%vivado_project_export�Run a user-provided Tcl script against a `vivado_project`, declaring the file and directory outputs the script produces.

Shaped like a `genrule`: you supply the Tcl and declare what it writes;
the rule sources the project's emitted TCL, sources your script, then
verifies every declared output exists. `script` takes an executable
target â in practice a `tcl_binary` â so the script can `package
require` shared `tcl_library` helpers.

Prefer a typed rule (`vivado_synthesis`, `vivado_export_simulation`,
`vivado_hw_platform`, â¦) whenever your workflow maps to one â this is
the escape hatch for workflows that map to none and don't justify a new
rule. Two consumers writing the same invocation with the same Tcl body
is the signal to promote it to a typed rule.

Project-input only: phases whose input is a checkpoint (`write_edif`,
`write_verilog`, `write_hw_platform`, â¦) do not fit this shape.

Provides only `DefaultInfo`, by design â escape-hatch consumers work off
file paths, not typed contracts.
"�
�
vivado_project_export�Run a user-provided Tcl script against a `vivado_project`, declaring the file and directory outputs the script produces.

Shaped like a `genrule`: you supply the Tcl and declare what it writes;
the rule sources the project's emitted TCL, sources your script, then
verifies every declared output exists. `script` takes an executable
target â in practice a `tcl_binary` â so the script can `package
require` shared `tcl_library` helpers.

Prefer a typed rule (`vivado_synthesis`, `vivado_export_simulation`,
`vivado_hw_platform`, â¦) whenever your workflow maps to one â this is
the escape hatch for workflows that map to none and don't justify a new
rule. Two consumers writing the same invocation with the same Tcl body
is the signal to promote it to a typed rule.

Project-input only: phases whose input is a checkpoint (`write_edif`,
`write_verilog`, `write_hw_platform`, â¦) do not fit this shape.

Provides only `DefaultInfo`, by design â escape-hatch consumers work off
file paths, not typed contracts.
*
nameA unique name for this target. ,
jobsJobs hint to Bazel's scheduler.21�
out_dirs�Declared TreeArtifact outputs. Each becomes a `ctx.actions.declare_directory`; paths land in `$OUT_DIRS` (Tcl list, in declared order). User's Tcl must ensure each directory exists at action completion.2[]�
outs�Declared File outputs. Each becomes a `ctx.actions.declare_file`; paths land in `$OUTS` (Tcl list, in declared order). User's Tcl must ensure each file exists at action completion or Bazel fails the action.w

post_hooksc`.tcl` files OR `tcl_binary` targets sourced after the user's Tcl completes. Sourced in list order.2[]�
	pre_hooksv`.tcl` files OR `tcl_binary` targets sourced after the project loads but BEFORE the user's Tcl. Sourced in list order.2[]�
project�`vivado_project` target. The emitted project TCL is sourced BEFORE the user's Tcl, so the user script runs against a fully-loaded project. *
VivadoProjectInfo�
script�Executable target (a `tcl_binary`) whose script is sourced after `vivado_project`'s TCL loads. Sees `$OUTS`, `$OUT_DIRS`, and `$PROJECT_DIR` as pre-set variables. Its `tcl_library` deps are staged as runfiles and reached with `package require`. A bare `.tcl` file is not accepted; wrap it in a `tcl_binary`. "8
vivado_project_export@@rules_vivado//vivado:defs.bzl
>>,
*
nameA unique name for this target. .
,
jobsJobs hint to Bazel's scheduler.21�
�
out_dirs�Declared TreeArtifact outputs. Each becomes a `ctx.actions.declare_directory`; paths land in `$OUT_DIRS` (Tcl list, in declared order). User's Tcl must ensure each directory exists at action completion.2[]�
�
outs�Declared File outputs. Each becomes a `ctx.actions.declare_file`; paths land in `$OUTS` (Tcl list, in declared order). User's Tcl must ensure each file exists at action completion or Bazel fails the action.y
w

post_hooksc`.tcl` files OR `tcl_binary` targets sourced after the user's Tcl completes. Sourced in list order.2[]�
�
	pre_hooksv`.tcl` files OR `tcl_binary` targets sourced after the project loads but BEFORE the user's Tcl. Sourced in list order.2[]�
�
project�`vivado_project` target. The emitted project TCL is sourced BEFORE the user's Tcl, so the user script runs against a fully-loaded project. *
VivadoProjectInfo�
�
script�Executable target (a `tcl_binary`) whose script is sourced after `vivado_project`'s TCL loads. Sees `$OUTS`, `$OUT_DIRS`, and `$PROJECT_DIR` as pre-set variables. Its `tcl_library` deps are staged as runfiles and reached with `package require`. A bare `.tcl` file is not accepted; wrap it in a `tcl_binary`. �vivado_routing&Run routing on a placement checkpoint."�
�
vivado_routing&Run routing on a placement checkpoint.*
nameA unique name for this target. H

checkpointPlacement checkpoint. *
VivadoPlacementCheckpointInfos

post_hooks_`.tcl`/`.xdc`/`.sdc` files OR `tcl_binary` targets sourced after `route_design`, in list order.2[]}
	pre_hooksj`.tcl`/`.xdc`/`.sdc` files OR `tcl_binary` targets sourced on the opened checkpoint before `route_design`.2[]�
reportskReport types to run after the phase's main transformation. See `vivado_synthesis.reports` for the full API.2@["io", "power", "route_status", "timing_summary", "utilization"]A

route_args-Extra flags passed through to `route_design`.2[]Q
route_templateThe routing tcl template2#//vivado/private:route.tcl.templateR
threadsBThreads to pass to vivado which defines the amount of parallelism.28"1
vivado_routing@@rules_vivado//vivado:defs.bzl
��,
*
nameA unique name for this target. J
H

checkpointPlacement checkpoint. *
VivadoPlacementCheckpointInfou
s

post_hooks_`.tcl`/`.xdc`/`.sdc` files OR `tcl_binary` targets sourced after `route_design`, in list order.2[]
}
	pre_hooksj`.tcl`/`.xdc`/`.sdc` files OR `tcl_binary` targets sourced on the opened checkpoint before `route_design`.2[]�
�
reportskReport types to run after the phase's main transformation. See `vivado_synthesis.reports` for the full API.2@["io", "power", "route_status", "timing_summary", "utilization"]C
A

route_args-Extra flags passed through to `route_design`.2[]S
Q
route_templateThe routing tcl template2#//vivado/private:route.tcl.templateT
R
threadsBThreads to pass to vivado which defines the amount of parallelism.28�/vivado_synthesis�Run synthesis on a `vivado_project`. Sources the project's emitted TCL script inside a single Vivado action, generates IP / BD targets (global synthesis â no OOC runs), runs the top synth (`launch_runs` or `synth_design`), and writes a `.dcp` checkpoint + impl-XDC bundle for downstream implementation phases."�,
�
vivado_synthesis�Run synthesis on a `vivado_project`. Sources the project's emitted TCL script inside a single Vivado action, generates IP / BD targets (global synthesis â no OOC runs), runs the top synth (`launch_runs` or `synth_design`), and writes a `.dcp` checkpoint + impl-XDC bundle for downstream implementation phases.*
nameA unique name for this target. L
jobs?Jobs to pass to vivado which defines the amount of parallelism.24�

post_hooks�`.tcl`/`.xdc`/`.sdc` files OR `tcl_binary` targets sourced on the open synthesized design (after `open_run "synth_1"`), before checkpoint write and reports. Sourced in list order.2[]�
	pre_hooks�`.tcl`/`.xdc`/`.sdc` files OR `tcl_binary` targets sourced after the project script finishes (post `generate_target`) but before synth runs are launched. Sourced in list order.2[]�
project�`vivado_project` target carrying the emitted project TCL script + its transitive input closure. All project-shape attrs (module, module_top, part_number, block_designs, ip_blocks, pre_hooks_early, etc.) live on that target, not here. *
VivadoProjectInfo�
project_mode�How Vivado stores project state. `project` creates a named on-disk project so managed-run infrastructure (`launch_runs`, `synth_1`) is available. `in_memory` calls `create_project -in_memory`; managed runs are unavailable, so `synth_invocation = launch_runs` requires `project`. The two modes can produce different netlist hierarchies for block-design-instantiated IPs, affecting downstream physical constraints that target IP-internal cells/nets.2	"project"�
reports�Report types to run after `synth_design`, before checkpoint write. Each entry must be a key in `REPORT_TYPES` (`vivado/private/common.bzl`). Reports live at `<target>.reports/<filename>` and are wrapped in `catch` so a single failure writes an empty file rather than aborting. Pass `reports = []` to disable.2!["timing_summary", "utilization"]�

synth_args�Extra flags for `synth_design` in the `synth_design` invocation path. Cannot contain `-top` (the rule emits that from the project's `module_top`). Not consulted on the `launch_runs` path; there, set `STEPS.SYNTH_DESIGN.ARGS.*` run properties from a `pre_hooks` script.2[]�
synth_invocation�How `synth_design` is invoked. `launch_runs` wraps it in a managed `synth_1` design-run (fresh Vivado process re-loads project state from disk). `synth_design` invokes it in the same process. Multi-config XCI consumer instantiations require `synth_design`: in `launch_runs` the re-loading process binds consumer wrappers to the IP's project-managed synth wrapper (which doesn't propagate consumer-side generics), so wrappers passing distinct generic combinations surface as `__parameterized<N>` black boxes.2"launch_runs"O
synth_strategyThe synthesis strategy to use.2"Vivado Synthesis Defaults"`
synthesis_tcl_templateThe synthesis tcl template.2'//vivado/private:synthesis.tcl.template"3
vivado_synthesis@@rules_vivado//vivado:defs.bzl
��,
*
nameA unique name for this target. N
L
jobs?Jobs to pass to vivado which defines the amount of parallelism.24�
�

post_hooks�`.tcl`/`.xdc`/`.sdc` files OR `tcl_binary` targets sourced on the open synthesized design (after `open_run "synth_1"`), before checkpoint write and reports. Sourced in list order.2[]�
�
	pre_hooks�`.tcl`/`.xdc`/`.sdc` files OR `tcl_binary` targets sourced after the project script finishes (post `generate_target`) but before synth runs are launched. Sourced in list order.2[]�
�
project�`vivado_project` target carrying the emitted project TCL script + its transitive input closure. All project-shape attrs (module, module_top, part_number, block_designs, ip_blocks, pre_hooks_early, etc.) live on that target, not here. *
VivadoProjectInfo�
�
project_mode�How Vivado stores project state. `project` creates a named on-disk project so managed-run infrastructure (`launch_runs`, `synth_1`) is available. `in_memory` calls `create_project -in_memory`; managed runs are unavailable, so `synth_invocation = launch_runs` requires `project`. The two modes can produce different netlist hierarchies for block-design-instantiated IPs, affecting downstream physical constraints that target IP-internal cells/nets.2	"project"�
�
reports�Report types to run after `synth_design`, before checkpoint write. Each entry must be a key in `REPORT_TYPES` (`vivado/private/common.bzl`). Reports live at `<target>.reports/<filename>` and are wrapped in `catch` so a single failure writes an empty file rather than aborting. Pass `reports = []` to disable.2!["timing_summary", "utilization"]�
�

synth_args�Extra flags for `synth_design` in the `synth_design` invocation path. Cannot contain `-top` (the rule emits that from the project's `module_top`). Not consulted on the `launch_runs` path; there, set `STEPS.SYNTH_DESIGN.ARGS.*` run properties from a `pre_hooks` script.2[]�
�
synth_invocation�How `synth_design` is invoked. `launch_runs` wraps it in a managed `synth_1` design-run (fresh Vivado process re-loads project state from disk). `synth_design` invokes it in the same process. Multi-config XCI consumer instantiations require `synth_design`: in `launch_runs` the re-loading process binds consumer wrappers to the IP's project-managed synth wrapper (which doesn't propagate consumer-side generics), so wrappers passing distinct generic combinations surface as `__parameterized<N>` black boxes.2"launch_runs"Q
O
synth_strategyThe synthesis strategy to use.2"Vivado Synthesis Defaults"b
`
synthesis_tcl_templateThe synthesis tcl template.2'//vivado/private:synthesis.tcl.template�vivado_synthesis_optimize:Run post-synthesis optimization on a synthesis checkpoint."�
�
vivado_synthesis_optimize:Run post-synthesis optimization on a synthesis checkpoint.*
nameA unique name for this target. D

checkpointSynthesis checkpoint. *
VivadoSynthCheckpointInfo=
opt_args+Extra flags passed through to `opt_design`.2[]�

post_hooks�`.tcl`/`.xdc`/`.sdc` files OR `tcl_binary` targets sourced after `opt_design`, before reports and checkpoint write. Sourced in list order.2[]�
	pre_hooks�`.tcl`/`.xdc`/`.sdc` files OR `tcl_binary` targets sourced on the opened synth checkpoint, before `opt_design`. Sourced in list order.2[]~
reportsGReport types to run after `opt_design`; see `vivado_synthesis.reports`.2(["drc", "timing_summary", "utilization"]v
synthesis_optimize_template'The synthesis optimization tcl template2,//vivado/private:synth_optimize.tcl.templateR
threadsBThreads to pass to vivado which defines the amount of parallelism.28"<
vivado_synthesis_optimize@@rules_vivado//vivado:defs.bzl
�!�!,
*
nameA unique name for this target. F
D

checkpointSynthesis checkpoint. *
VivadoSynthCheckpointInfo?
=
opt_args+Extra flags passed through to `opt_design`.2[]�
�

post_hooks�`.tcl`/`.xdc`/`.sdc` files OR `tcl_binary` targets sourced after `opt_design`, before reports and checkpoint write. Sourced in list order.2[]�
�
	pre_hooks�`.tcl`/`.xdc`/`.sdc` files OR `tcl_binary` targets sourced on the opened synth checkpoint, before `opt_design`. Sourced in list order.2[]�
~
reportsGReport types to run after `opt_design`; see `vivado_synthesis.reports`.2(["drc", "timing_summary", "utilization"]x
v
synthesis_optimize_template'The synthesis optimization tcl template2,//vivado/private:synth_optimize.tcl.templateT
R
threadsBThreads to pass to vivado which defines the amount of parallelism.28�2vivado_toolchain�Declares a Vivado toolchain.

Wrap it with `toolchain(...)` and register that via
`register_toolchains(...)` in MODULE.bazel; every `vivado_*` rule then
resolves the Xilinx environment automatically, with no per-target
`xilinx_env` to thread through. Registering one is required.

Multiple instances can be registered side-by-side and selected via
`target_settings` (flag-driven) or `exec_compatible_with`
(platform-driven) â the latter against the per-version `constraint_value`s
in `//vivado/constraints/version`.

Emits `VivadoToolchainInfo` on `ToolchainInfo.vivado_info`.
"�-
�
vivado_toolchain�Declares a Vivado toolchain.

Wrap it with `toolchain(...)` and register that via
`register_toolchains(...)` in MODULE.bazel; every `vivado_*` rule then
resolves the Xilinx environment automatically, with no per-target
`xilinx_env` to thread through. Registering one is required.

Multiple instances can be registered side-by-side and selected via
`target_settings` (flag-driven) or `exec_compatible_with`
(platform-driven) â the latter against the per-version `constraint_value`s
in `//vivado/constraints/version`.

Emits `VivadoToolchainInfo` on `ToolchainInfo.vivado_info`.
*
nameA unique name for this target. A
env4Environment variables passed to every Vivado action.
2{}�
requires_network�Sets the `requires-network` execution requirement on every `vivado_*` action. True (the default) is correct for a floating license server (`XILINXD_LICENSE_FILE=PORT@HOST`); set it False for license-free editions (Vivado ML Standard / WebPACK) or node-locked `.lic` files read from disk.2True�
	resources�`--local_resources` slots every Vivado action claims: resource name -> per-action count (as a string). Each entry becomes `execution_requirements["resources:<name>"] = <count>`, letting you serialize Vivado runs against a budget declared with `--local_resources=<name>=<total>` â license seats, container concurrency, whatever. `{"vivado_license": "1"}` is the common case. Every name used here needs a matching `--local_resources` registration or actions fail to schedule. Empty by default, so actions schedule freely.
2{}�
	sanitizer�Executable called from every Vivado action's EXIT trap to rewrite the sandbox-root prefix baked into declared outputs with the fixed marker `<execroot>/`. That makes outputs byte-identical across hosts, sandbox strategies, and RBE-worker sandbox UUIDs, so caches hit and shipped artifacts don't leak a worker's path.

Invoked as `<sanitizer> <sandbox_root> <marker> <path>...`, where each path is a declared output â a file, or a TreeArtifact directory to walk. Its exit status is ignored: sanitization must never fail an otherwise-successful Vivado run.

Built for the exec platform and staged with its runfiles, so any `*_binary` works; the default is a `sh_binary` doing a `sed` sweep that skips known binary formats. Override only for custom semantics.2//vivado/private:sanitize_pathsF
version5The version of Vivado associated with this toolchain.2""�
vivado�The Vivado executable. Typically a small bash shim that `exec`s the real `vivado` out of a known install path (e.g. baked into a container image), but any `*_binary` rule works too â runfiles travel along. Defaults to a stock shim that calls `vivado` from the exec platform's `PATH` as a migration aid; production toolchains should pin the install path with their own shim.2//vivado/private:vivado.sh�

xilinx_env�Optional escape hatch â a shell script sourced inside the action shell immediately before `vivado` runs, for shell-side env composition `env` cannot express. Prefer `env`. `vivado_xsim_test` also sources it at test time to put `xvlog` / `xelab` / `xsim` on `PATH`.2None"3
vivado_toolchain@@rules_vivado//vivado:defs.bzl
==,
*
nameA unique name for this target. C
A
env4Environment variables passed to every Vivado action.
2{}�
�
requires_network�Sets the `requires-network` execution requirement on every `vivado_*` action. True (the default) is correct for a floating license server (`XILINXD_LICENSE_FILE=PORT@HOST`); set it False for license-free editions (Vivado ML Standard / WebPACK) or node-locked `.lic` files read from disk.2True�
�
	resources�`--local_resources` slots every Vivado action claims: resource name -> per-action count (as a string). Each entry becomes `execution_requirements["resources:<name>"] = <count>`, letting you serialize Vivado runs against a budget declared with `--local_resources=<name>=<total>` â license seats, container concurrency, whatever. `{"vivado_license": "1"}` is the common case. Every name used here needs a matching `--local_resources` registration or actions fail to schedule. Empty by default, so actions schedule freely.
2{}�
�
	sanitizer�Executable called from every Vivado action's EXIT trap to rewrite the sandbox-root prefix baked into declared outputs with the fixed marker `<execroot>/`. That makes outputs byte-identical across hosts, sandbox strategies, and RBE-worker sandbox UUIDs, so caches hit and shipped artifacts don't leak a worker's path.

Invoked as `<sanitizer> <sandbox_root> <marker> <path>...`, where each path is a declared output â a file, or a TreeArtifact directory to walk. Its exit status is ignored: sanitization must never fail an otherwise-successful Vivado run.

Built for the exec platform and staged with its runfiles, so any `*_binary` works; the default is a `sh_binary` doing a `sed` sweep that skips known binary formats. Override only for custom semantics.2//vivado/private:sanitize_pathsH
F
version5The version of Vivado associated with this toolchain.2""�
�
vivado�The Vivado executable. Typically a small bash shim that `exec`s the real `vivado` out of a known install path (e.g. baked into a container image), but any `*_binary` rule works too â runfiles travel along. Defaults to a stock shim that calls `vivado` from the exec platform's `PATH` as a migration aid; production toolchains should pin the install path with their own shim.2//vivado/private:vivado.sh�
�

xilinx_env�Optional escape hatch â a shell script sourced inside the action shell immediately before `vivado` runs, for shell-side env composition `env` cannot express. Prefer `env`. `vivado_xsim_test` also sources it at test time to put `xvlog` / `xelab` / `xsim` on `PATH`.2None�D
vivado_xci�Package a Xilinx-catalog IP from a configuration TCL into a consumable IP repo.

`script` is the configuration script sourced inside a fresh Vivado
project. It must call
`create_ip -name <ip> -vendor xilinx.com -library ip -version <ver> \
    -module_name <module_top> -dir . -force` and (optionally) configure
the IP via `set_property -dict {...} [get_ips <module_top>]`. The attr
takes an executable target â in practice a `tcl_binary`, which is what
carries the `deps` a script needs to `package require` shared
`tcl_library` helpers. An extra-toolchains transition routes it through
the Vivado tcl toolchain, so its wrapper comes out as a `.vhook.tcl`
Vivado can source directly and its deps land on `auto_path`.

The resulting `.xci` plus generated HDL/sim files are captured into a
TreeArtifact directory and exposed via `VivadoIPBlockInfo` so the IP
repo is auto-added to the consumer's `ip_repo_paths`.

Alongside `VivadoIPBlockInfo`, the rule also exposes `VerilogInfo` and
`VhdlInfo` so the target is `deps`-interchangeable with `verilog_library`
and `vhdl_library`. Generated files are split by extension into four
sibling TreeArtifacts â `<name>.verilog` (`.v` / `.sv`), `<name>.vhdl`
(`.vhd` / `.vhdl`), `<name>.verilog_header` (`.vh` / `.svh`), and
`<name>.data` (everything else) â which are placed on the appropriate
`srcs` / `hdrs` / `data` fields of the two providers. Consuming rules
add each directory via `add_files`; Vivado auto-classifies files
inside by extension. The split carries the IP's `sim/` behavioural model
and `hdl/` sources; the `synth/` wrapper (a second definition of the same
module) and copies of upstream `ip_blocks` are left out, so a
`verilog_library`-shaped consumer sees each module exactly once. Vivado
flows should consume the IP through `ip_blocks` (the `.xci`) rather than
through these directories.

Use the `ip_blocks` attribute on `vivado_project`, `vivado_block_design`,
or `vivado_ip_core` to make this IP available to that consumer. BD
cells that reference the IP's VLNV (e.g.
`create_bd_cell -vlnv xilinx.com:ip:axi_dma:7.1`) will then resolve via
the catalog.

For your own HDL packaged as a new reusable IP, use `vivado_ip_core`
instead.
"�2
�"

vivado_xci�Package a Xilinx-catalog IP from a configuration TCL into a consumable IP repo.

`script` is the configuration script sourced inside a fresh Vivado
project. It must call
`create_ip -name <ip> -vendor xilinx.com -library ip -version <ver> \
    -module_name <module_top> -dir . -force` and (optionally) configure
the IP via `set_property -dict {...} [get_ips <module_top>]`. The attr
takes an executable target â in practice a `tcl_binary`, which is what
carries the `deps` a script needs to `package require` shared
`tcl_library` helpers. An extra-toolchains transition routes it through
the Vivado tcl toolchain, so its wrapper comes out as a `.vhook.tcl`
Vivado can source directly and its deps land on `auto_path`.

The resulting `.xci` plus generated HDL/sim files are captured into a
TreeArtifact directory and exposed via `VivadoIPBlockInfo` so the IP
repo is auto-added to the consumer's `ip_repo_paths`.

Alongside `VivadoIPBlockInfo`, the rule also exposes `VerilogInfo` and
`VhdlInfo` so the target is `deps`-interchangeable with `verilog_library`
and `vhdl_library`. Generated files are split by extension into four
sibling TreeArtifacts â `<name>.verilog` (`.v` / `.sv`), `<name>.vhdl`
(`.vhd` / `.vhdl`), `<name>.verilog_header` (`.vh` / `.svh`), and
`<name>.data` (everything else) â which are placed on the appropriate
`srcs` / `hdrs` / `data` fields of the two providers. Consuming rules
add each directory via `add_files`; Vivado auto-classifies files
inside by extension. The split carries the IP's `sim/` behavioural model
and `hdl/` sources; the `synth/` wrapper (a second definition of the same
module) and copies of upstream `ip_blocks` are left out, so a
`verilog_library`-shaped consumer sees each module exactly once. Vivado
flows should consume the IP through `ip_blocks` (the `.xci`) rather than
through these directories.

Use the `ip_blocks` attribute on `vivado_project`, `vivado_block_design`,
or `vivado_ip_core` to make this IP available to that consumer. BD
cells that reference the IP's VLNV (e.g.
`create_bd_cell -vlnv xilinx.com:ip:axi_dma:7.1`) will then resolve via
the catalog.

For your own HDL packaged as a new reusable IP, use `vivado_ip_core`
instead.
*
nameA unique name for this target. �
data�Additional files the IP-config TCL needs available in the action's sandbox. Each file is materialized at its workspace-relative path; the TCL can reference it via that path (e.g., to `exec patch -i ...` against the generated HDL, or to `read` a side data file). Same semantics as `cc_library.data`, `py_test.data`, etc.2[]n
	ip_blocksFOther IP blocks the configuration TCL depends on (rare; mostly empty).*
VivadoIPBlockInfo2[]I
jobs<Jobs to pass to vivado (resource hint to Bazel's scheduler).21j

module_topXThe `module_name` passed to `create_ip` in `script`. Used to locate the produced `.xci`. ?
part_number,Xilinx part number the IP is configured for. �

post_hooks�`.tcl`/`.xdc`/`.sdc` files OR `tcl_binary` targets sourced after `generate_target`, before the project closes. Sourced in list order.2[]�
	pre_hooks�`.tcl`/`.xdc`/`.sdc` files OR `tcl_binary` targets sourced after project + IP-block setup, before sourcing the user IP TCL. Sourced in list order.2[]�
project_hooks�`.tcl`/`.xdc`/`.sdc` files OR `tcl_binary` targets sourced INSIDE any downstream `vivado_project` action that folds this target in via `ip_blocks` / `block_designs`. Fires right after `create_project` + `source_mgmt_mode`, before any `add_files`. Home for setup the target needs to work in context (`board_part`, `set_msg_config`, TCL procs). Does NOT run in this target's own action â for that use `pre_hooks` / `post_hooks`. Sourced in list order; multiple targets' contributions concat in project-attr dep order; the project's own `pre_hooks_early` fires last so it wins on override.2[]�
script�Executable target (a `tcl_binary`) whose script is sourced inside a fresh Vivado project to configure the IP. Must call `create_ip ... -module_name <module_top>`. Its `tcl_library` deps are staged as runfiles and reached with `package require`. A bare `.tcl` file is not accepted; wrap it in a `tcl_binary`. Q
xci_templateThe XCI tcl template.2(//vivado/private:create_xci.tcl.template"-

vivado_xci@@rules_vivado//vivado:defs.bzl
��,
*
nameA unique name for this target. �
�
data�Additional files the IP-config TCL needs available in the action's sandbox. Each file is materialized at its workspace-relative path; the TCL can reference it via that path (e.g., to `exec patch -i ...` against the generated HDL, or to `read` a side data file). Same semantics as `cc_library.data`, `py_test.data`, etc.2[]p
n
	ip_blocksFOther IP blocks the configuration TCL depends on (rare; mostly empty).*
VivadoIPBlockInfo2[]K
I
jobs<Jobs to pass to vivado (resource hint to Bazel's scheduler).21l
j

module_topXThe `module_name` passed to `create_ip` in `script`. Used to locate the produced `.xci`. A
?
part_number,Xilinx part number the IP is configured for. �
�

post_hooks�`.tcl`/`.xdc`/`.sdc` files OR `tcl_binary` targets sourced after `generate_target`, before the project closes. Sourced in list order.2[]�
�
	pre_hooks�`.tcl`/`.xdc`/`.sdc` files OR `tcl_binary` targets sourced after project + IP-block setup, before sourcing the user IP TCL. Sourced in list order.2[]�
�
project_hooks�`.tcl`/`.xdc`/`.sdc` files OR `tcl_binary` targets sourced INSIDE any downstream `vivado_project` action that folds this target in via `ip_blocks` / `block_designs`. Fires right after `create_project` + `source_mgmt_mode`, before any `add_files`. Home for setup the target needs to work in context (`board_part`, `set_msg_config`, TCL procs). Does NOT run in this target's own action â for that use `pre_hooks` / `post_hooks`. Sourced in list order; multiple targets' contributions concat in project-attr dep order; the project's own `pre_hooks_early` fires last so it wins on override.2[]�
�
script�Executable target (a `tcl_binary`) whose script is sourced inside a fresh Vivado project to configure the IP. Must call `create_ip ... -module_name <module_top>`. Its `tcl_library` deps are staged as runfiles and reached with `package require`. A bare `.tcl` file is not accepted; wrap it in a `tcl_binary`. S
Q
xci_templateThe XCI tcl template.2(//vivado/private:create_xci.tcl.template�.vivado_xsim_test�Run a Vivado xsim simulation as a Bazel test.

A build action sources the `vivado_project`-emitted project TCL,
generates simulation targets on any BDs, and calls `export_simulation`
to produce a self-contained xsim script bundle; the test binary runs
`simulate.sh` at test time. Log-scan patterns catch `$error` output,
which xsim prints but doesn't exit nonzero for. The wrapper writes a
JUnit XML at `$XML_OUTPUT_FILE` and copies the sim log, per-tool logs,
and any `.wdb` waveform into `$TEST_UNDECLARED_OUTPUTS_DIR`.

At test time the wrapper re-points the bundle's sanitized `<execroot>/`
paths at its runfiles, then needs `xvlog` / `xelab` / `xsim` on `PATH`.
Bazel hands tests a minimal `PATH`, so supply them through the
toolchain's `xilinx_env` script (sourced by the wrapper) or an
`env = {"PATH": ...}` entry; failing both, the wrapper boots the
toolchain's `vivado` shim once to discover the install's `bin` dir.
"�'
�
vivado_xsim_test�Run a Vivado xsim simulation as a Bazel test.

A build action sources the `vivado_project`-emitted project TCL,
generates simulation targets on any BDs, and calls `export_simulation`
to produce a self-contained xsim script bundle; the test binary runs
`simulate.sh` at test time. Log-scan patterns catch `$error` output,
which xsim prints but doesn't exit nonzero for. The wrapper writes a
JUnit XML at `$XML_OUTPUT_FILE` and copies the sim log, per-tool logs,
and any `.wdb` waveform into `$TEST_UNDECLARED_OUTPUTS_DIR`.

At test time the wrapper re-points the bundle's sanitized `<execroot>/`
paths at its runfiles, then needs `xvlog` / `xelab` / `xsim` on `PATH`.
Bazel hands tests a minimal `PATH`, so supply them through the
toolchain's `xilinx_env` script (sourced by the wrapper) or an
`env = {"PATH": ...}` entry; failing both, the wrapper boots the
toolchain's `vivado` shim once to discover the install's `bin` dir.
*
nameA unique name for this target. �
completion_pattern�ERE pattern the simulation log must match for the test to pass. Set to `""` to disable. Only consulted when the driver script exited 0.2
"\$finish"�
error_patterns�ERE patterns that mark the simulation log as failed. Joined with `|` and passed to `grep -E`. Pass `[]` to disable log scanning.22["^Error: ", "^ERROR:", "FATAL_ERROR", "\\$fatal"]�
export_simulation_template1The tcl template that drives `export_simulation`.2///vivado/private:export_simulation.tcl.templates

module_topaSimulation-fileset top module. Typically the testbench name, or `<bd>_wrapper` for a BD-only sim. �
post_hook_tools�Executable targets invoked in the same Bazel action AFTER Vivado exits. Each receives `--project-dir <path> --export-dir <path>` and the same paths via `VIVADO_PROJECT_DIR` / `VIVADO_EXPORT_DIR` env vars. Order is preserved; first non-zero exit fails the action.2[]�

post_hooks�`.tcl` files OR `tcl_binary` targets sourced after `export_simulation` completes, with the project still open. Sourced in list order.2[]_
pre_hook_toolsGExecutable targets invoked BEFORE Vivado starts; see `post_hook_tools`.2[]�
	pre_hooks�`.tcl` files OR `tcl_binary` targets sourced after the project script + sim elaboration, before `export_simulation` runs. Sourced in list order.2[]�
project�`vivado_project` target carrying the emitted project TCL script + its transitive input closure. All project-shape attrs (module, part_number, block_designs, ip_blocks, pre_hooks_early, etc.) live on that target. *
VivadoProjectInfo�
with_waveform�Only `False` is accepted; `True` fails at analysis. To capture waveforms, add a `pre_hooks` Tcl script that sets `xsim.simulate.log_all_signals` on the sim fileset.2False�
xsim_test_wrapper_template>Bash template driving the exported `simulate.sh` at test time.2.//vivado/private:xsim_test_wrapper.sh.template"3
vivado_xsim_test@@rules_vivado//vivado:defs.bzl
��,
*
nameA unique name for this target. �
�
completion_pattern�ERE pattern the simulation log must match for the test to pass. Set to `""` to disable. Only consulted when the driver script exited 0.2
"\$finish"�
�
error_patterns�ERE patterns that mark the simulation log as failed. Joined with `|` and passed to `grep -E`. Pass `[]` to disable log scanning.22["^Error: ", "^ERROR:", "FATAL_ERROR", "\\$fatal"]�
�
export_simulation_template1The tcl template that drives `export_simulation`.2///vivado/private:export_simulation.tcl.templateu
s

module_topaSimulation-fileset top module. Typically the testbench name, or `<bd>_wrapper` for a BD-only sim. �
�
post_hook_tools�Executable targets invoked in the same Bazel action AFTER Vivado exits. Each receives `--project-dir <path> --export-dir <path>` and the same paths via `VIVADO_PROJECT_DIR` / `VIVADO_EXPORT_DIR` env vars. Order is preserved; first non-zero exit fails the action.2[]�
�

post_hooks�`.tcl` files OR `tcl_binary` targets sourced after `export_simulation` completes, with the project still open. Sourced in list order.2[]a
_
pre_hook_toolsGExecutable targets invoked BEFORE Vivado starts; see `post_hook_tools`.2[]�
�
	pre_hooks�`.tcl` files OR `tcl_binary` targets sourced after the project script + sim elaboration, before `export_simulation` runs. Sourced in list order.2[]�
�
project�`vivado_project` target carrying the emitted project TCL script + its transitive input closure. All project-shape attrs (module, part_number, block_designs, ip_blocks, pre_hooks_early, etc.) live on that target. *
VivadoProjectInfo�
�
with_waveform�Only `False` is accepted; `True` fails at analysis. To capture waveforms, add a `pre_hooks` Tcl script that sets `xsim.simulate.log_all_signals` on the sim fileset.2False�
�
xsim_test_wrapper_template>Bash template driving the exported `simulate.sh` at test time.2.//vivado/private:xsim_test_wrapper.sh.template�xdc_library�Bundle a set of Xilinx constraint files with other constraint files they must run after.

The only relationship this rule expresses is between XDC files â
`create_clock` before `set_clock_groups`, primary constraints before
secondary. It is deliberately independent of HDL: no `hdl_deps` attr, no
HDL provider re-export.

The transitive XDC set is exposed in `deps`-first (topological) order,
so consumers `read_xdc` files in the sequence inter-XDC ordering
requires. Two ways to consume it:

- **Direct.** List the target in `vivado_project.data`; Bazel walks the
  ordered `DefaultInfo.files` depset into the project's
  `$PROJECT_DATA_FILES` foreach in dep-first order.
- **Aspect.** `XdcInfo` is a first-class marker, so an aspect walking
  any dep graph can filter on `XdcInfo in target` and collect the
  constraint contributions.

Provides `XdcInfo`.
"�
�	
xdc_library�Bundle a set of Xilinx constraint files with other constraint files they must run after.

The only relationship this rule expresses is between XDC files â
`create_clock` before `set_clock_groups`, primary constraints before
secondary. It is deliberately independent of HDL: no `hdl_deps` attr, no
HDL provider re-export.

The transitive XDC set is exposed in `deps`-first (topological) order,
so consumers `read_xdc` files in the sequence inter-XDC ordering
requires. Two ways to consume it:

- **Direct.** List the target in `vivado_project.data`; Bazel walks the
  ordered `DefaultInfo.files` depset into the project's
  `$PROJECT_DATA_FILES` foreach in dep-first order.
- **Aspect.** `XdcInfo` is a first-class marker, so an aspect walking
  any dep graph can filter on `XdcInfo in target` and collect the
  constraint contributions.

Provides `XdcInfo`.
*
nameA unique name for this target. �
depsgOther `xdc_library` targets whose constraint files must be `read_xdc`d BEFORE this target's own `srcs`.*	
XdcInfo2[]I
srcs;Xilinx constraint files (`.xdc` / `.sdc`) this target owns.2[]".
xdc_library@@rules_vivado//vivado:defs.bzl
,
*
nameA unique name for this target. �
�
depsgOther `xdc_library` targets whose constraint files must be `read_xdc`d BEFORE this target's own `srcs`.*	
XdcInfo2[]K
I
srcs;Xilinx constraint files (`.xdc` / `.sdc`) this target owns.2[]�VivadoBlockDesignInfoGInfo for a Vivado block design (.bd) produced by `vivado_block_design`.2�
�	
VivadoBlockDesignInfoGInfo for a Vivado block design (.bd) produced by `vivado_block_design`.�
bd_dir�File: tree-artifact directory containing the generated `.bd` and its supporting files. The `.bd` itself is normalized to `<bd_dir>/<module_top>.bd` by the rule.�
ip_block_repos�list[File]: IP repo directories from `ip_blocks` deps that must be added to the consuming project's `ip_repo_paths` for the BD to resolve.�

module_top�string: The block-design name (the argument to `create_bd_design` in the source TCL). Consumers use `<bd_dir>/<module_top>.bd` to find the file.�
project_hooks�list[Target]: hook Targets this target contributes as `project_hooks` to any downstream `vivado_project` that lists it in `ip_blocks` / `block_designs`. The consumer passes the merged Target list through `hook_invocation` to derive both the sourceable paths (for the emitted TCL) and the tools list (for `run_shell(tools = ...)` staging). Sourced right after `create_project` + `source_mgmt_mode` and before the project's own `pre_hooks_early`. Empty when the target declares no `project_hooks`."8
VivadoBlockDesignInfo@@rules_vivado//vivado:defs.bzl
�!�!�
�
bd_dir�File: tree-artifact directory containing the generated `.bd` and its supporting files. The `.bd` itself is normalized to `<bd_dir>/<module_top>.bd` by the rule.�
�
ip_block_repos�list[File]: IP repo directories from `ip_blocks` deps that must be added to the consuming project's `ip_repo_paths` for the BD to resolve.�
�

module_top�string: The block-design name (the argument to `create_bd_design` in the source TCL). Consumers use `<bd_dir>/<module_top>.bd` to find the file.�
�
project_hooks�list[Target]: hook Targets this target contributes as `project_hooks` to any downstream `vivado_project` that lists it in `ip_blocks` / `block_designs`. The consumer passes the merged Target list through `hook_invocation` to derive both the sourceable paths (for the emitted TCL) and the tools list (for `run_shell(tools = ...)` staging). Sourced right after `create_project` + `source_mgmt_mode` and before the project's own `pre_hooks_early`. Empty when the target declares no `project_hooks`.�VivadoCompiledSimlibInfo�Output of `vivado_compile_simlib`. Layout matches `compile_simlib -directory <dir>`: `<simlib_dir>/<simulator>/` contains the simulator's link-config file plus per-library compiled artifacts.2�
�
VivadoCompiledSimlibInfo�Output of `vivado_compile_simlib`. Layout matches `compile_simlib -directory <dir>`: `<simlib_dir>/<simulator>/` contains the simulator's link-config file plus per-library compiled artifacts.�

simlib_dir�File: TreeArtifact directory containing the compiled simlib. The link-config file lives at `<simlib_dir>/<simulator>/<link_config_basename>` (e.g. `<simlib_dir>/riviera/library.cfg`).k
	simulator^string: The simulator the simlib targets. One of Vivado's `compile_simlib -simulator` choices.";
VivadoCompiledSimlibInfo@@rules_vivado//vivado:defs.bzl
�$�$�
�

simlib_dir�File: TreeArtifact directory containing the compiled simlib. The link-config file lives at `<simlib_dir>/<simulator>/<link_config_basename>` (e.g. `<simlib_dir>/riviera/library.cfg`).m
k
	simulator^string: The simulator the simlib targets. One of Vivado's `compile_simlib -simulator` choices.�VivadoDebugProbesInfo�Output of `vivado_debug_probes`. Wraps `write_debug_probes`; produces the `.ltx` probe file consumed by Vivado's Hardware Manager during ILA bring-up.2�
�
VivadoDebugProbesInfo�Output of `vivado_debug_probes`. Wraps `write_debug_probes`; produces the `.ltx` probe file consumed by Vivado's Hardware Manager during ILA bring-up.2
ltx+File: the emitted `.ltx` debug-probes file.r
project_infobVivadoProjectInfo: typed back-reference to the originating project (through the checkpoint chain).A
tcl:File: the fully-substituted TCL script the action sourced."8
VivadoDebugProbesInfo@@rules_vivado//vivado:defs.bzl
�!�!4
2
ltx+File: the emitted `.ltx` debug-probes file.t
r
project_infobVivadoProjectInfo: typed back-reference to the originating project (through the checkpoint chain).C
A
tcl:File: the fully-substituted TCL script the action sourced.�
VivadoExportSimulationInfo�Output of `vivado_export_simulation` â the directory Vivado writes when invoked with `export_simulation -directory <dir>`. Contents follow Vivado's contract for the chosen simulator (see UG835).2�
�
VivadoExportSimulationInfo�Output of `vivado_export_simulation` â the directory Vivado writes when invoked with `export_simulation -directory <dir>`. Contents follow Vivado's contract for the chosen simulator (see UG835).A

export_dir3File: TreeArtifact directory containing the export.|
project_infolVivadoProjectInfo: typed back-reference to the originating project. Same purpose as on checkpoint providers.@
	simulator3string: The `-simulator` argument passed to Vivado.f
tcl_File: the fully-substituted TCL script the action sourced. See `VivadoSynthCheckpointInfo.tcl`."=
VivadoExportSimulationInfo@@rules_vivado//vivado:defs.bzl
�&�&C
A

export_dir3File: TreeArtifact directory containing the export.~
|
project_infolVivadoProjectInfo: typed back-reference to the originating project. Same purpose as on checkpoint providers.B
@
	simulator3string: The `-simulator` argument passed to Vivado.h
f
tcl_File: the fully-substituted TCL script the action sourced. See `VivadoSynthCheckpointInfo.tcl`.�VivadoHwPlatformInfo�Output of `vivado_hw_platform`. Wraps `write_hw_platform`; produces the `.xsa` handoff artifact consumed by Vitis, PetaLinux, and other Xilinx SDK tooling.2�
�
VivadoHwPlatformInfo�Output of `vivado_hw_platform`. Wraps `write_hw_platform`; produces the `.xsa` handoff artifact consumed by Vitis, PetaLinux, and other Xilinx SDK tooling.r
project_infobVivadoProjectInfo: typed back-reference to the originating project (through the checkpoint chain).A
tcl:File: the fully-substituted TCL script the action sourced.:
xsa3File: the emitted `.xsa` hardware platform archive."7
VivadoHwPlatformInfo@@rules_vivado//vivado:defs.bzl
� � t
r
project_infobVivadoProjectInfo: typed back-reference to the originating project (through the checkpoint chain).C
A
tcl:File: the fully-substituted TCL script the action sourced.<
:
xsa3File: the emitted `.xsa` hardware platform archive.�VivadoIPBlockInfo�Describes the contents of a Vivado IP artifact. Consumers read the fields to decide whether to call `create_ip`, `add_files` a configured `.xci`, or just expose the repo on `ip_repo_paths`.2�
�
VivadoIPBlockInfo�Describes the contents of a Vivado IP artifact. Consumers read the fields to decide whether to call `create_ip`, `add_files` a configured `.xci`, or just expose the repo on `ip_repo_paths`.�
configured_instance�Optional[struct(repo_dir: File, xci_relpath: str, module_top: str)]: Set when the artifact contains a pre-configured IP instance. Consumers add `<repo_dir>/<xci_relpath>` to their source set. None when there is no configured instance.�
instantiable�Optional[struct(vendor: str, library: str, name: str, version: str, module_name: str)]: Set when consumers are expected to `create_ip` with these VLNV identifiers and `-module_name <module_name>`. None otherwise.�
project_hooks�list[Target]: hook Targets this target contributes as `project_hooks` to any downstream `vivado_project` that lists it in `ip_blocks` / `block_designs`. The consumer passes the merged Target list through `hook_invocation` to derive both the sourceable paths (for the emitted TCL) and the tools list (for `run_shell(tools = ...)` staging). Sourced right after `create_project` + `source_mgmt_mode` and before the project's own `pre_hooks_early`. Empty when the target declares no `project_hooks`.�
repo�list[File]: Directory artifacts forming an IP repository (`component.xml`-rooted tree). Added to the consuming project's `ip_repo_paths`."4
VivadoIPBlockInfo@@rules_vivado//vivado:defs.bzl
���
�
configured_instance�Optional[struct(repo_dir: File, xci_relpath: str, module_top: str)]: Set when the artifact contains a pre-configured IP instance. Consumers add `<repo_dir>/<xci_relpath>` to their source set. None when there is no configured instance.�
�
instantiable�Optional[struct(vendor: str, library: str, name: str, version: str, module_name: str)]: Set when consumers are expected to `create_ip` with these VLNV identifiers and `-module_name <module_name>`. None otherwise.�
�
project_hooks�list[Target]: hook Targets this target contributes as `project_hooks` to any downstream `vivado_project` that lists it in `ip_blocks` / `block_designs`. The consumer passes the merged Target list through `hook_invocation` to derive both the sourceable paths (for the emitted TCL) and the tools list (for `run_shell(tools = ...)` staging). Sourced right after `create_project` + `source_mgmt_mode` and before the project's own `pre_hooks_early`. Empty when the target declares no `project_hooks`.�
�
repo�list[File]: Directory artifacts forming an IP repository (`component.xml`-rooted tree). Added to the consuming project's `ip_repo_paths`.�VivadoInterfaceInfo.Info for a Vivado IP-XACT interface definition2�
�
VivadoInterfaceInfo.Info for a Vivado IP-XACT interface definitionD
abstraction_definition*File: The abstraction definition XML file.4
bus_definition"File: The bus definition XML file..
library#string: The library VLNV component.#
namestring: The interface name.7
	setup_tcl*File: The TCL setup file for IP packaging.,
vendor"string: The vendor VLNV component..
version#string: The version VLNV component."6
VivadoInterfaceInfo@@rules_vivado//vivado:defs.bzl
��F
D
abstraction_definition*File: The abstraction definition XML file.6
4
bus_definition"File: The bus definition XML file.0
.
library#string: The library VLNV component.%
#
namestring: The interface name.9
7
	setup_tcl*File: The TCL setup file for IP packaging..
,
vendor"string: The vendor VLNV component.0
.
version#string: The version VLNV component.�VivadoLogInfo�Aggregated Vivado `.log` and `.jou` files for a phase target and all its transitive upstream phases. Keys are short phase names (`synth`, `synth_opt`, `place`, `place_opt`, `route`, `write_bitstream`, `write_device_image`).2�
�
VivadoLogInfo�Aggregated Vivado `.log` and `.jou` files for a phase target and all its transitive upstream phases. Keys are short phase names (`synth`, `synth_opt`, `place`, `place_opt`, `route`, `write_bitstream`, `write_device_image`).8
journals,dict[str, File]: phase name -> journal File.0
logs(dict[str, File]: phase name -> log File."0
VivadoLogInfo@@rules_vivado//vivado:defs.bzl
��:
8
journals,dict[str, File]: phase name -> journal File.2
0
logs(dict[str, File]: phase name -> log File.�VivadoPlacementCheckpointInfoMOutput of the placement phase (`vivado_placement` / `vivado_place_optimize`).2�
�
VivadoPlacementCheckpointInfoMOutput of the placement phase (`vivado_placement` / `vivado_place_optimize`).D

checkpoint6File: the Vivado checkpoint (.dcp) this phase emitted.�
input_files�depset[File]: transitive files needed to re-open the checkpoint with `read_checkpoint` + `link_design`. Includes the upstream project's `input_files`, the upstream checkpoint file itself, and any impl-XDC bundle.

Most consumers do NOT need this. A `.dcp` is self-contained, so every in-tree phase rule that only `open_checkpoint`s (`vivado_placement`, `vivado_place_optimize`, `vivado_routing`, `vivado_synthesis_optimize`, `vivado_bitstream`, `vivado_device_image`, `vivado_hw_platform`, `vivado_debug_probes`) stages just the `.dcp` and keeps the action's input set small. Pass `input_files.to_list()` only when an action re-links the design against its original sources or re-sources the project script.�

module_top�str: top-module name (propagated from the originating `vivado_project.module_top`). May be `""` if the upstream provider carried no top.�
part_number�str: Xilinx part string (propagated from the originating `vivado_project.part_number`). Consumers use this to open the checkpoint on the correct part.�
project_info�VivadoProjectInfo: typed back-reference to the originating project. Enables consumers to trace a checkpoint back to design intent (module tops, block designs, constraints) without needing a separate `project = ...` attr on every downstream rule.�
tcl�File: the fully-substituted TCL script the action sourced. Useful for debugging (`bazel build //foo:x` produces this) and for reproducing the phase outside Bazel (`vivado -source <this-file>`)."@
VivadoPlacementCheckpointInfo@@rules_vivado//vivado:defs.bzl
�)�)F
D

checkpoint6File: the Vivado checkpoint (.dcp) this phase emitted.�
�
input_files�depset[File]: transitive files needed to re-open the checkpoint with `read_checkpoint` + `link_design`. Includes the upstream project's `input_files`, the upstream checkpoint file itself, and any impl-XDC bundle.

Most consumers do NOT need this. A `.dcp` is self-contained, so every in-tree phase rule that only `open_checkpoint`s (`vivado_placement`, `vivado_place_optimize`, `vivado_routing`, `vivado_synthesis_optimize`, `vivado_bitstream`, `vivado_device_image`, `vivado_hw_platform`, `vivado_debug_probes`) stages just the `.dcp` and keeps the action's input set small. Pass `input_files.to_list()` only when an action re-links the design against its original sources or re-sources the project script.�
�

module_top�str: top-module name (propagated from the originating `vivado_project.module_top`). May be `""` if the upstream provider carried no top.�
�
part_number�str: Xilinx part string (propagated from the originating `vivado_project.part_number`). Consumers use this to open the checkpoint on the correct part.�
�
project_info�VivadoProjectInfo: typed back-reference to the originating project. Enables consumers to trace a checkpoint back to design intent (module tops, block designs, constraints) without needing a separate `project = ...` attr on every downstream rule.�
�
tcl�File: the fully-substituted TCL script the action sourced. Useful for debugging (`bazel build //foo:x` produces this) and for reproducing the phase outside Bazel (`vivado -source <this-file>`).�2VivadoProjectInfo�Output of `vivado_project`. Carries a self-contained TCL script (produced by Starlark template expansion, no Vivado invocation) that, when sourced inside a Vivado process, does `create_project` + source ingest + constraints + hooks (but NOT `generate_target` â the consumer picks that intent). Downstream consumers (`vivado_synthesis`, `vivado_export_simulation`, GUI launchers, `vivado_project_export`) source this script in their own Vivado action. The provider also carries the transitive input closure the script references, plus typed access to the sub-providers folded into the project, so consumers only need to depend on the `vivado_project` target â never on its individual inputs.2�,
�
VivadoProjectInfo�Output of `vivado_project`. Carries a self-contained TCL script (produced by Starlark template expansion, no Vivado invocation) that, when sourced inside a Vivado process, does `create_project` + source ingest + constraints + hooks (but NOT `generate_target` â the consumer picks that intent). Downstream consumers (`vivado_synthesis`, `vivado_export_simulation`, GUI launchers, `vivado_project_export`) source this script in their own Vivado action. The provider also carries the transitive input closure the script references, plus typed access to the sub-providers folded into the project, so consumers only need to depend on the `vivado_project` target â never on its individual inputs.�
block_designs�list[VivadoBlockDesignInfo]: typed access to the block-design providers folded into the project via `block_designs = [...]`. Enables downstream rules (e.g. `vivado_bd_wrapper`, project-walking aspects) to reason about BDs by provider rather than reparsing the project script or re-reading rule attrs.�

hook_tools�list: File / FilesToRunProvider entries for `pre_hooks_early` / `pre_hooks` / `post_hooks` targets. Consumers pass this list to `ctx.actions.run_shell(tools=...)` so hook runfiles trees (needed by `tcl_binary`-based hooks) materialize in the sandbox.�
input_files�depset[File]: transitive files the emitted script references by exec-root path (HDL sources, IP repos, BD directories, constraint files, hook files). Any consumer that SOURCES `project_tcl` must pass `input_files.to_list()` as action inputs, or the sandbox won't stage what the script tries to open â `vivado_synthesis`, `vivado_project_export`, and the `export_simulation` rules all do. Consumers that only read a downstream checkpoint do NOT need it; see `_CHECKPOINT_COMMON_FIELDS.input_files` below.�
	ip_blocks�list[VivadoIPBlockInfo]: typed access to the IP providers folded into the project via `ip_blocks = [...]`. Symmetric with `block_designs`.I

module_top;str: top-module name (matches `vivado_project.module_top`).N
part_number?str: Xilinx part string (matches `vivado_project.part_number`).�
project_tcl�File: the emitted `.project.tcl` script. Sourcing this file inside a Vivado process does `create_project` + contributed `project_hooks` + `pre_hooks_early` + `read_verilog` / `read_vhdl` / `add_files` + `read_xdc` + `set_property top` + `pre_hooks`. It has no `post_hooks` and runs no `generate_target` â the consumer issues that with the intent it needs. Reads `PROJECT_MODE` / `PROJECT_DIR` from pre-set Tcl variables or the `VIVADO_PROJECT_MODE` / `VIVADO_PROJECT_DIR` env vars (default: `project` mode in `.`).�
xdc�depset[File]: transitive `.xdc` / `.sdc` / `.tcl` constraint files contributed via `vivado_project.data`, in the exact order the emitted script's `$PROJECT_DATA_FILES` loop reads them: plain files at their listed position, `xdc_library` targets expanded in place with their dep-first transitive closure. Empty when the project has no `data` entries. Enables aspects and future constraint-linting rules to walk the constraint set without reparsing the emitted TCL."4
VivadoProjectInfo@@rules_vivado//vivado:defs.bzl
�
�
block_designs�list[VivadoBlockDesignInfo]: typed access to the block-design providers folded into the project via `block_designs = [...]`. Enables downstream rules (e.g. `vivado_bd_wrapper`, project-walking aspects) to reason about BDs by provider rather than reparsing the project script or re-reading rule attrs.�
�

hook_tools�list: File / FilesToRunProvider entries for `pre_hooks_early` / `pre_hooks` / `post_hooks` targets. Consumers pass this list to `ctx.actions.run_shell(tools=...)` so hook runfiles trees (needed by `tcl_binary`-based hooks) materialize in the sandbox.�
�
input_files�depset[File]: transitive files the emitted script references by exec-root path (HDL sources, IP repos, BD directories, constraint files, hook files). Any consumer that SOURCES `project_tcl` must pass `input_files.to_list()` as action inputs, or the sandbox won't stage what the script tries to open â `vivado_synthesis`, `vivado_project_export`, and the `export_simulation` rules all do. Consumers that only read a downstream checkpoint do NOT need it; see `_CHECKPOINT_COMMON_FIELDS.input_files` below.�
�
	ip_blocks�list[VivadoIPBlockInfo]: typed access to the IP providers folded into the project via `ip_blocks = [...]`. Symmetric with `block_designs`.K
I

module_top;str: top-module name (matches `vivado_project.module_top`).P
N
part_number?str: Xilinx part string (matches `vivado_project.part_number`).�
�
project_tcl�File: the emitted `.project.tcl` script. Sourcing this file inside a Vivado process does `create_project` + contributed `project_hooks` + `pre_hooks_early` + `read_verilog` / `read_vhdl` / `add_files` + `read_xdc` + `set_property top` + `pre_hooks`. It has no `post_hooks` and runs no `generate_target` â the consumer issues that with the intent it needs. Reads `PROJECT_MODE` / `PROJECT_DIR` from pre-set Tcl variables or the `VIVADO_PROJECT_MODE` / `VIVADO_PROJECT_DIR` env vars (default: `project` mode in `.`).�
�
xdc�depset[File]: transitive `.xdc` / `.sdc` / `.tcl` constraint files contributed via `vivado_project.data`, in the exact order the emitted script's `$PROJECT_DATA_FILES` loop reads them: plain files at their listed position, `xdc_library` targets expanded in place with their dep-first transitive closure. Empty when the project has no `data` entries. Enables aspects and future constraint-linting rules to walk the constraint set without reparsing the emitted TCL.�VivadoReportsInfoRMaps the `reports` attr's caller-chosen output names to the declared File objects.2�
�
VivadoReportsInfoRMaps the `reports` attr's caller-chosen output names to the declared File objects.K
reports@dict[str, File]: caller-chosen output filename -> declared File."4
VivadoReportsInfo@@rules_vivado//vivado:defs.bzl
��M
K
reports@dict[str, File]: caller-chosen output filename -> declared File.�VivadoRoutingCheckpointInfo/Output of the routing phase (`vivado_routing`).2�
�
VivadoRoutingCheckpointInfo/Output of the routing phase (`vivado_routing`).D

checkpoint6File: the Vivado checkpoint (.dcp) this phase emitted.�
input_files�depset[File]: transitive files needed to re-open the checkpoint with `read_checkpoint` + `link_design`. Includes the upstream project's `input_files`, the upstream checkpoint file itself, and any impl-XDC bundle.

Most consumers do NOT need this. A `.dcp` is self-contained, so every in-tree phase rule that only `open_checkpoint`s (`vivado_placement`, `vivado_place_optimize`, `vivado_routing`, `vivado_synthesis_optimize`, `vivado_bitstream`, `vivado_device_image`, `vivado_hw_platform`, `vivado_debug_probes`) stages just the `.dcp` and keeps the action's input set small. Pass `input_files.to_list()` only when an action re-links the design against its original sources or re-sources the project script.�

module_top�str: top-module name (propagated from the originating `vivado_project.module_top`). May be `""` if the upstream provider carried no top.�
part_number�str: Xilinx part string (propagated from the originating `vivado_project.part_number`). Consumers use this to open the checkpoint on the correct part.�
project_info�VivadoProjectInfo: typed back-reference to the originating project. Enables consumers to trace a checkpoint back to design intent (module tops, block designs, constraints) without needing a separate `project = ...` attr on every downstream rule.�
tcl�File: the fully-substituted TCL script the action sourced. Useful for debugging (`bazel build //foo:x` produces this) and for reproducing the phase outside Bazel (`vivado -source <this-file>`).">
VivadoRoutingCheckpointInfo@@rules_vivado//vivado:defs.bzl
�'�'F
D

checkpoint6File: the Vivado checkpoint (.dcp) this phase emitted.�
�
input_files�depset[File]: transitive files needed to re-open the checkpoint with `read_checkpoint` + `link_design`. Includes the upstream project's `input_files`, the upstream checkpoint file itself, and any impl-XDC bundle.

Most consumers do NOT need this. A `.dcp` is self-contained, so every in-tree phase rule that only `open_checkpoint`s (`vivado_placement`, `vivado_place_optimize`, `vivado_routing`, `vivado_synthesis_optimize`, `vivado_bitstream`, `vivado_device_image`, `vivado_hw_platform`, `vivado_debug_probes`) stages just the `.dcp` and keeps the action's input set small. Pass `input_files.to_list()` only when an action re-links the design against its original sources or re-sources the project script.�
�

module_top�str: top-module name (propagated from the originating `vivado_project.module_top`). May be `""` if the upstream provider carried no top.�
�
part_number�str: Xilinx part string (propagated from the originating `vivado_project.part_number`). Consumers use this to open the checkpoint on the correct part.�
�
project_info�VivadoProjectInfo: typed back-reference to the originating project. Enables consumers to trace a checkpoint back to design intent (module tops, block designs, constraints) without needing a separate `project = ...` attr on every downstream rule.�
�
tcl�File: the fully-substituted TCL script the action sourced. Useful for debugging (`bazel build //foo:x` produces this) and for reproducing the phase outside Bazel (`vivado -source <this-file>`).�!VivadoSynthCheckpointInfoQOutput of the synthesis phase (`vivado_synthesis` / `vivado_synthesis_optimize`).2� 
�
VivadoSynthCheckpointInfoQOutput of the synthesis phase (`vivado_synthesis` / `vivado_synthesis_optimize`).D

checkpoint6File: the Vivado checkpoint (.dcp) this phase emitted.�
input_files�depset[File]: transitive files needed to re-open the checkpoint with `read_checkpoint` + `link_design`. Includes the upstream project's `input_files`, the upstream checkpoint file itself, and any impl-XDC bundle.

Most consumers do NOT need this. A `.dcp` is self-contained, so every in-tree phase rule that only `open_checkpoint`s (`vivado_placement`, `vivado_place_optimize`, `vivado_routing`, `vivado_synthesis_optimize`, `vivado_bitstream`, `vivado_device_image`, `vivado_hw_platform`, `vivado_debug_probes`) stages just the `.dcp` and keeps the action's input set small. Pass `input_files.to_list()` only when an action re-links the design against its original sources or re-sources the project script.�

module_top�str: top-module name (propagated from the originating `vivado_project.module_top`). May be `""` if the upstream provider carried no top.�
part_number�str: Xilinx part string (propagated from the originating `vivado_project.part_number`). Consumers use this to open the checkpoint on the correct part.�
project_info�VivadoProjectInfo: typed back-reference to the originating project. Enables consumers to trace a checkpoint back to design intent (module tops, block designs, constraints) without needing a separate `project = ...` attr on every downstream rule.�
tcl�File: the fully-substituted TCL script the action sourced. Useful for debugging (`bazel build //foo:x` produces this) and for reproducing the phase outside Bazel (`vivado -source <this-file>`).�
impl_xdc�Optional[File]: Bundle of XDC content from source files marked `USED_IN_IMPLEMENTATION == True`. `synth_design` doesn't apply these and `write_checkpoint` only persists applied constraints, so downstream phases must `read_xdc <bundle>` before `opt_design` / `place_design` or the constraints are lost. May be `None`; consumers must tolerate that case."<
VivadoSynthCheckpointInfo@@rules_vivado//vivado:defs.bzl
w%w%F
D

checkpoint6File: the Vivado checkpoint (.dcp) this phase emitted.�
�
input_files�depset[File]: transitive files needed to re-open the checkpoint with `read_checkpoint` + `link_design`. Includes the upstream project's `input_files`, the upstream checkpoint file itself, and any impl-XDC bundle.

Most consumers do NOT need this. A `.dcp` is self-contained, so every in-tree phase rule that only `open_checkpoint`s (`vivado_placement`, `vivado_place_optimize`, `vivado_routing`, `vivado_synthesis_optimize`, `vivado_bitstream`, `vivado_device_image`, `vivado_hw_platform`, `vivado_debug_probes`) stages just the `.dcp` and keeps the action's input set small. Pass `input_files.to_list()` only when an action re-links the design against its original sources or re-sources the project script.�
�

module_top�str: top-module name (propagated from the originating `vivado_project.module_top`). May be `""` if the upstream provider carried no top.�
�
part_number�str: Xilinx part string (propagated from the originating `vivado_project.part_number`). Consumers use this to open the checkpoint on the correct part.�
�
project_info�VivadoProjectInfo: typed back-reference to the originating project. Enables consumers to trace a checkpoint back to design intent (module tops, block designs, constraints) without needing a separate `project = ...` attr on every downstream rule.�
�
tcl�File: the fully-substituted TCL script the action sourced. Useful for debugging (`bazel build //foo:x` produces this) and for reproducing the phase outside Bazel (`vivado -source <this-file>`).�
�
impl_xdc�Optional[File]: Bundle of XDC content from source files marked `USED_IN_IMPLEMENTATION == True`. `synth_design` doesn't apply these and `write_checkpoint` only persists applied constraints, so downstream phases must `read_xdc <bundle>` before `opt_design` / `place_design` or the constraints are lost. May be `None`; consumers must tolerate that case.�VivadoToolchainInfo�Toolchain info for the Xilinx Vivado tool. Only `vivado` is required; every other field has a default so toolchain rules outside this repo keep working when fields are added.2�
�
VivadoToolchainInfo�Toolchain info for the Xilinx Vivado tool. Only `vivado` is required; every other field has a default so toolchain rules outside this repo keep working when fields are added.Y
envRdict[str, str]: environment variables passed to every Vivado action. Default `{}`.~
requires_networkjbool: whether Vivado actions need network access (typically for a network license server). Default `True`.�
	resources�dict[str, str]: optional `--local_resources` slots every Vivado action claims (values are counts as strings). Each entry becomes an `execution_requirements["resources:<name>"] = <count>` on every action, so users can serialize Vivado runs against arbitrary budgets they've declared via `--local_resources=<name>=<total>` (e.g. license seats, container concurrency). Empty by default â actions schedule freely against `cpu` / `memory` only.�
	sanitizer�FilesToRunProvider or None: executable invoked from every Vivado action's EXIT trap to rewrite the sandbox-root prefix in declared outputs. `vivado_toolchain` wires in the bundled default; `None` (the constructor default) leaves outputs unsanitized, which still builds but caches less well across hosts.S
versionHstr: The version of Vivado associated with this toolchain. Default `""`.�
vivado�FilesToRunProvider: executable Bazel invokes for every Vivado action. Typically a shim that `exec`s the real `vivado` binary. Required.�

xilinx_env�File or None: optional shell script sourced immediately before `vivado` runs, for shell-side env composition `env` cannot express. Default `None`."6
VivadoToolchainInfo@@rules_vivado//vivado:defs.bzl
;;[
Y
envRdict[str, str]: environment variables passed to every Vivado action. Default `{}`.�
~
requires_networkjbool: whether Vivado actions need network access (typically for a network license server). Default `True`.�
�
	resources�dict[str, str]: optional `--local_resources` slots every Vivado action claims (values are counts as strings). Each entry becomes an `execution_requirements["resources:<name>"] = <count>` on every action, so users can serialize Vivado runs against arbitrary budgets they've declared via `--local_resources=<name>=<total>` (e.g. license seats, container concurrency). Empty by default â actions schedule freely against `cpu` / `memory` only.�
�
	sanitizer�FilesToRunProvider or None: executable invoked from every Vivado action's EXIT trap to rewrite the sandbox-root prefix in declared outputs. `vivado_toolchain` wires in the bundled default; `None` (the constructor default) leaves outputs unsanitized, which still builds but caches less well across hosts.U
S
versionHstr: The version of Vivado associated with this toolchain. Default `""`.�
�
vivado�FilesToRunProvider: executable Bazel invokes for every Vivado action. Typically a shim that `exec`s the real `vivado` binary. Required.�
�

xilinx_env�File or None: optional shell script sourced immediately before `vivado` runs, for shell-side env composition `env` cannot express. Default `None`.�XdcInfo�Marker provider on `xdc_library` targets. Carries the transitive closure of the `.xdc` / `.sdc` files a downstream consumer should `read_xdc` in topological order (deps' srcs before the target's own srcs). Independent of any HDL info â `xdc_library` deliberately doesn't re-export VerilogInfo / VhdlInfo. Exists as a first-class provider so aspects can walk arbitrary dep graphs and pick out XDC-file contributors by filtering for this marker.2�	
�
XdcInfo�Marker provider on `xdc_library` targets. Carries the transitive closure of the `.xdc` / `.sdc` files a downstream consumer should `read_xdc` in topological order (deps' srcs before the target's own srcs). Independent of any HDL info â `xdc_library` deliberately doesn't re-export VerilogInfo / VhdlInfo. Exists as a first-class provider so aspects can walk arbitrary dep graphs and pick out XDC-file contributors by filtering for this marker.�
srcs�depset[File]: transitive `.xdc`/`.sdc` files, deep-deps first (topological order). The rule's `DefaultInfo.files` is the same depset so this target also drops into `vivado_project.data` â the flattened order Bazel derives from `ctx.files.data` on a topological depset is what the emitted TCL's `$PROJECT_DATA_FILES` loop iterates."*
XdcInfo@@rules_vivado//vivado:defs.bzl
���
�
srcs�depset[File]: transitive `.xdc`/`.sdc` files, deep-deps first (topological order). The rule's `DefaultInfo.files` is the same depset so this target also drops into `vivado_project.data` â the flattened order Bazel derives from `ctx.files.data` on a topological depset is what the emitted TCL's `$PROJECT_DATA_FILES` loop iterates.�
//vivado:bitstream.bzlr�
%
rules_vivadovivadobitstream.bzl3
vivado_bitstream_vivado_bitstream
9
vivado_device_image_vivado_device_image

�
//vivado:block_design.bzlrs
(
rules_vivadovivadoblock_design.bzl9
vivado_block_design_vivado_block_design
0D
]�
//vivado:debug_probes.bzlrs
(
rules_vivadovivadodebug_probes.bzl9
vivado_debug_probes_vivado_debug_probes
0D
]�
//vivado:hw_platform.bzlrp
'
rules_vivadovivadohw_platform.bzl7
vivado_hw_platform_vivado_hw_platform
/B
Z�
//vivado:implementation.bzlr�
*
rules_vivadovivadoimplementation.bzl=
vivado_place_optimize_vivado_place_optimize
3
vivado_placement_vivado_placement
/
vivado_routing_vivado_routing

�
//vivado:ip.bzlr�

rules_vivadovivadoip.bzlI
vivado_interface_definition_vivado_interface_definition
!9
vivado_interface_ip_vivado_interface_ip
/
vivado_ip_core_vivado_ip_core
  '

vivado_xci_vivado_xci
!!
"�
//vivado:packaged_ip.bzlrp
'
rules_vivadovivadopackaged_ip.bzl7
vivado_packaged_ip_vivado_packaged_ip
#/#B
##Z~
//vivado:project.bzlrd
#
rules_vivadovivadoproject.bzl/
vivado_project_vivado_project
$+$:
$$N�
//vivado:project_export.bzlry
*
rules_vivadovivadoproject_export.bzl=
vivado_project_export_vivado_project_export
%2%H
%%c�
//vivado:providers.bzlr�
%
rules_vivadovivadoproviders.bzl=
VivadoBlockDesignInfo_VivadoBlockDesignInfo
((C
VivadoCompiledSimlibInfo_VivadoCompiledSimlibInfo
))=
VivadoDebugProbesInfo_VivadoDebugProbesInfo
**G
VivadoExportSimulationInfo_VivadoExportSimulationInfo
++ ;
VivadoHwPlatformInfo_VivadoHwPlatformInfo
,,5
VivadoIPBlockInfo_VivadoIPBlockInfo
--9
VivadoInterfaceInfo_VivadoInterfaceInfo
..-
VivadoLogInfo_VivadoLogInfo
//M
VivadoPlacementCheckpointInfo_VivadoPlacementCheckpointInfo
00#5
VivadoProjectInfo_VivadoProjectInfo
115
VivadoReportsInfo_VivadoReportsInfo
22I
VivadoRoutingCheckpointInfo_VivadoRoutingCheckpointInfo
33!E
VivadoSynthCheckpointInfo_VivadoSynthCheckpointInfo
44!
XdcInfo_XdcInfo
55
&6�
//vivado:simulation.bzlr�
&
rules_vivadovivadosimulation.bzl=
vivado_compile_simlib_vivado_compile_simlib
99C
vivado_export_simulation_vivado_export_simulation
::3
vivado_xsim_test_vivado_xsim_test
;;
7<�
//vivado:synthesis.bzlr�
%
rules_vivadovivadosynthesis.bzl3
vivado_synthesis_vivado_synthesis
??E
vivado_synthesis_optimize_vivado_synthesis_optimize
@@
=A�
//vivado:toolchain.bzlr�
%
rules_vivadovivadotoolchain.bzl9
VivadoToolchainInfo_VivadoToolchainInfo
B-BA3
vivado_toolchain_vivado_toolchain
B[Bl
BB��
//vivado:xdc_library.bzlrb
'
rules_vivadovivadoxdc_library.bzl)
xdc_library_xdc_library
C/C;
CCL�# Public entrypoint for rules_vivado.

Re-exports every rule, macro and provider from the phase-grouped files under
`//vivado` and the toolchain rule. Users who only need a subset can load
directly from the phase files (e.g. `load("//vivado:synthesis.bzl", ...)`)
or from `//vivado:providers.bzl` instead of going through this aggregator.

The providers are part of the public API: a rule outside this repo that
wants to consume a checkpoint, feed a `vivado_project`, or wrap a phase
needs them to declare `providers = [...]` on its attrs and to read the
fields off its deps.
�&
'
rules_vivadovivadohw_platform.bzl� vivado_hw_platform�Write a Xilinx `.xsa` hardware-platform archive from a routed checkpoint via `write_hw_platform`.

The `.xsa` is the handoff artifact for Vitis, PetaLinux, and the rest of
the Xilinx SDK tooling. Compose this directly on `vivado_routing` (or
any `VivadoRoutingCheckpointInfo` provider) so `.xsa` production is its
own target, independent of whether a bitstream or device image is also
being built.

Provides `VivadoHwPlatformInfo`.
"�
�
vivado_hw_platform�Write a Xilinx `.xsa` hardware-platform archive from a routed checkpoint via `write_hw_platform`.

The `.xsa` is the handoff artifact for Vitis, PetaLinux, and the rest of
the Xilinx SDK tooling. Compose this directly on `vivado_routing` (or
any `VivadoRoutingCheckpointInfo` provider) so `.xsa` production is its
own target, independent of whether a bitstream or device image is also
being built.

Provides `VivadoHwPlatformInfo`.
*
nameA unique name for this target. `

checkpoint/Routed checkpoint the platform is written from. *
VivadoRoutingCheckpointInfo�
hw_only�Pass `-hw_only` to `write_hw_platform`. When True, produces a hardware-only platform (no bitstream embedded); overrides `include_bit`.2False�
include_bit�Embed a bitstream in the `.xsa` (`-include_bit`). `write_hw_platform` can only embed a bitstream written in the same Vivado session, so the action first runs `write_bitstream` on the opened checkpoint â a full bitstream generation, with no `timing_check` gate â and then packs the result. Set False to skip that cost when the `.xsa` only needs the hardware description, or `hw_only = True` for an explicitly hardware-only platform (which overrides this). Default True matches the historical `with_xsa` bolt-on behavior.2Truet

post_hooks``.tcl` files OR `tcl_binary` targets sourced after `write_hw_platform` completes, in list order.2[]�
	pre_hooksu`.tcl` files OR `tcl_binary` targets sourced on the opened checkpoint before `write_hw_platform` runs, in list order.2[]7
threads'Threads passed to `general.maxThreads`.28�

write_args�Extra flags passed through to `write_hw_platform`. Cannot contain `-file` (the rule's declared `.xsa` path is the argument), `-force` (always emitted), `-fixed` (always emitted for single-image platforms), `-hw_only` / `-include_bit` (use dedicated attrs).2[]t
write_hw_platform_template#The write_hw_platform tcl template.2///vivado/private:write_hw_platform.tcl.template"<
vivado_hw_platform&@@rules_vivado//vivado:hw_platform.bzl
VV,
*
nameA unique name for this target. b
`

checkpoint/Routed checkpoint the platform is written from. *
VivadoRoutingCheckpointInfo�
�
hw_only�Pass `-hw_only` to `write_hw_platform`. When True, produces a hardware-only platform (no bitstream embedded); overrides `include_bit`.2False�
�
include_bit�Embed a bitstream in the `.xsa` (`-include_bit`). `write_hw_platform` can only embed a bitstream written in the same Vivado session, so the action first runs `write_bitstream` on the opened checkpoint â a full bitstream generation, with no `timing_check` gate â and then packs the result. Set False to skip that cost when the `.xsa` only needs the hardware description, or `hw_only = True` for an explicitly hardware-only platform (which overrides this). Default True matches the historical `with_xsa` bolt-on behavior.2Truev
t

post_hooks``.tcl` files OR `tcl_binary` targets sourced after `write_hw_platform` completes, in list order.2[]�
�
	pre_hooksu`.tcl` files OR `tcl_binary` targets sourced on the opened checkpoint before `write_hw_platform` runs, in list order.2[]9
7
threads'Threads passed to `general.maxThreads`.28�
�

write_args�Extra flags passed through to `write_hw_platform`. Cannot contain `-file` (the rule's declared `.xsa` path is the argument), `-force` (always emitted), `-fixed` (always emitted for single-image platforms), `-hw_only` / `-include_bit` (use dedicated attrs).2[]v
t
write_hw_platform_template#The write_hw_platform tcl template.2///vivado/private:write_hw_platform.tcl.template�
//vivado:providers.bzlr�
%
rules_vivadovivadoproviders.bzl:
VivadoHwPlatformInfoVivadoHwPlatformInfo
,
VivadoLogInfoVivadoLogInfo
H
VivadoRoutingCheckpointInfoVivadoRoutingCheckpointInfo
!
�
//vivado/private:common.bzlr�
*
rules_vivadovivado/private
common.bzl.
TOOLCHAIN_TYPETOOLCHAIN_TYPE
:
get_vivado_toolchainget_vivado_toolchain
&

hook_attrs
hook_attrs
0
hook_invocationhook_invocation
2
run_tcl_templaterun_tcl_template
"
tcl_argstcl_args
,
validate_argsvalidate_args

	# vivado_hw_platform rule.�1
*
rules_vivadovivadoimplementation.bzl�vivado_place_optimize)Run post-placement physical optimization."�
�
vivado_place_optimize)Run post-placement physical optimization.*
nameA unique name for this target. H

checkpointPlacement checkpoint. *
VivadoPlacementCheckpointInfoG
phys_opt_args0Extra flags passed through to `phys_opt_design`.2[]e
place_optimize_templateThe placement tcl template2,//vivado/private:place_optimize.tcl.templatev

post_hooksb`.tcl`/`.xdc`/`.sdc` files OR `tcl_binary` targets sourced after `phys_opt_design`, in list order.2[]�
	pre_hooksm`.tcl`/`.xdc`/`.sdc` files OR `tcl_binary` targets sourced on the opened checkpoint before `phys_opt_design`.2[]�
reportskReport types to run after the phase's main transformation. See `vivado_synthesis.reports` for the full API.2!["timing_summary", "utilization"]R
threadsBThreads to pass to vivado which defines the amount of parallelism.28"B
vivado_place_optimize)@@rules_vivado//vivado:implementation.bzl
��,
*
nameA unique name for this target. J
H

checkpointPlacement checkpoint. *
VivadoPlacementCheckpointInfoI
G
phys_opt_args0Extra flags passed through to `phys_opt_design`.2[]g
e
place_optimize_templateThe placement tcl template2,//vivado/private:place_optimize.tcl.templatex
v

post_hooksb`.tcl`/`.xdc`/`.sdc` files OR `tcl_binary` targets sourced after `phys_opt_design`, in list order.2[]�
�
	pre_hooksm`.tcl`/`.xdc`/`.sdc` files OR `tcl_binary` targets sourced on the opened checkpoint before `phys_opt_design`.2[]�
�
reportskReport types to run after the phase's main transformation. See `vivado_synthesis.reports` for the full API.2!["timing_summary", "utilization"]T
R
threadsBThreads to pass to vivado which defines the amount of parallelism.28�vivado_placement4Run placement on a (synthesis-optimized) checkpoint."�
�
vivado_placement4Run placement on a (synthesis-optimized) checkpoint.*
nameA unique name for this target. D

checkpointSynthesis checkpoint. *
VivadoSynthCheckpointInfoA

place_args-Extra flags passed through to `place_design`.2[][
placement_templateThe placement tcl template2'//vivado/private:placement.tcl.templates

post_hooks_`.tcl`/`.xdc`/`.sdc` files OR `tcl_binary` targets sourced after `place_design`, in list order.2[]}
	pre_hooksj`.tcl`/`.xdc`/`.sdc` files OR `tcl_binary` targets sourced on the opened checkpoint before `place_design`.2[]�
reportskReport types to run after the phase's main transformation. See `vivado_synthesis.reports` for the full API.2!["timing_summary", "utilization"]R
threadsBThreads to pass to vivado which defines the amount of parallelism.28"=
vivado_placement)@@rules_vivado//vivado:implementation.bzl
nn,
*
nameA unique name for this target. F
D

checkpointSynthesis checkpoint. *
VivadoSynthCheckpointInfoC
A

place_args-Extra flags passed through to `place_design`.2[]]
[
placement_templateThe placement tcl template2'//vivado/private:placement.tcl.templateu
s

post_hooks_`.tcl`/`.xdc`/`.sdc` files OR `tcl_binary` targets sourced after `place_design`, in list order.2[]
}
	pre_hooksj`.tcl`/`.xdc`/`.sdc` files OR `tcl_binary` targets sourced on the opened checkpoint before `place_design`.2[]�
�
reportskReport types to run after the phase's main transformation. See `vivado_synthesis.reports` for the full API.2!["timing_summary", "utilization"]T
R
threadsBThreads to pass to vivado which defines the amount of parallelism.28�vivado_routing&Run routing on a placement checkpoint."�
�
vivado_routing&Run routing on a placement checkpoint.*
nameA unique name for this target. H

checkpointPlacement checkpoint. *
VivadoPlacementCheckpointInfos

post_hooks_`.tcl`/`.xdc`/`.sdc` files OR `tcl_binary` targets sourced after `route_design`, in list order.2[]}
	pre_hooksj`.tcl`/`.xdc`/`.sdc` files OR `tcl_binary` targets sourced on the opened checkpoint before `route_design`.2[]�
reportskReport types to run after the phase's main transformation. See `vivado_synthesis.reports` for the full API.2@["io", "power", "route_status", "timing_summary", "utilization"]A

route_args-Extra flags passed through to `route_design`.2[]Q
route_templateThe routing tcl template2#//vivado/private:route.tcl.templateR
threadsBThreads to pass to vivado which defines the amount of parallelism.28";
vivado_routing)@@rules_vivado//vivado:implementation.bzl
��,
*
nameA unique name for this target. J
H

checkpointPlacement checkpoint. *
VivadoPlacementCheckpointInfou
s

post_hooks_`.tcl`/`.xdc`/`.sdc` files OR `tcl_binary` targets sourced after `route_design`, in list order.2[]
}
	pre_hooksj`.tcl`/`.xdc`/`.sdc` files OR `tcl_binary` targets sourced on the opened checkpoint before `route_design`.2[]�
�
reportskReport types to run after the phase's main transformation. See `vivado_synthesis.reports` for the full API.2@["io", "power", "route_status", "timing_summary", "utilization"]C
A

route_args-Extra flags passed through to `route_design`.2[]S
Q
route_templateThe routing tcl template2#//vivado/private:route.tcl.templateT
R
threadsBThreads to pass to vivado which defines the amount of parallelism.28�
//vivado:providers.bzlr�
%
rules_vivadovivadoproviders.bzl,
VivadoLogInfoVivadoLogInfo
L
VivadoPlacementCheckpointInfoVivadoPlacementCheckpointInfo
#4
VivadoReportsInfoVivadoReportsInfo
H
VivadoRoutingCheckpointInfoVivadoRoutingCheckpointInfo
!D
VivadoSynthCheckpointInfoVivadoSynthCheckpointInfo
		

�
//vivado/private:common.bzlr�
*
rules_vivadovivado/private
common.bzl.
TOOLCHAIN_TYPETOOLCHAIN_TYPE
:
get_vivado_toolchainget_vivado_toolchain
&

hook_attrs
hook_attrs
0
hook_invocationhook_invocation
*
reports_datareports_data
2
run_tcl_templaterun_tcl_template
"
tcl_argstcl_args
,
validate_argsvalidate_args

H# Implementation-phase rules: placement, physical optimization, routing.�

rules_vivadovivadoip.bzl�vivado_interface_definitioncGenerate Vivado IP-XACT interface definition files (bus definition and abstraction definition XML)."�
�

vivado_interface_definitioncGenerate Vivado IP-XACT interface definition files (bus definition and abstraction definition XML).*
nameA unique name for this target. �
abstraction_definition_template(The abstraction definition XML template.24//vivado/private:abstraction_definition.xml.templatek
bus_definition_template The bus definition XML template.2,//vivado/private:bus_definition.xml.template3
descriptionDescription for the interface.2""D
direct_connection'Whether direct connections are allowed.2TrueE
interface_name/The name of the interface (e.g., 'hbm_reader'). n
interface_setup_template!The interface setup TCL template.2-//vivado/private:interface_setup.tcl.template?
is_addressable%Whether the interface is addressable.2TrueI
library/The library VLNV component (e.g., 'interface').2"interface".
max_mastersMaximum number of masters.21,

max_slavesMaximum number of slaves.21u
parserDPython parser script (SV -> JSON). Override to customize SV parsing.2#//vivado/private:parse_sv_interface<
src1The SystemVerilog interface source file to parse. @
vendor2The vendor VLNV component (e.g., 'mycompany.com'). =
version)The version VLNV component (e.g., '1.0').2"1.0""<
vivado_interface_definition@@rules_vivado//vivado:ip.bzl
�#�#,
*
nameA unique name for this target. �
�
abstraction_definition_template(The abstraction definition XML template.24//vivado/private:abstraction_definition.xml.templatem
k
bus_definition_template The bus definition XML template.2,//vivado/private:bus_definition.xml.template5
3
descriptionDescription for the interface.2""F
D
direct_connection'Whether direct connections are allowed.2TrueG
E
interface_name/The name of the interface (e.g., 'hbm_reader'). p
n
interface_setup_template!The interface setup TCL template.2-//vivado/private:interface_setup.tcl.templateA
?
is_addressable%Whether the interface is addressable.2TrueK
I
library/The library VLNV component (e.g., 'interface').2"interface"0
.
max_mastersMaximum number of masters.21.
,

max_slavesMaximum number of slaves.21w
u
parserDPython parser script (SV -> JSON). Override to customize SV parsing.2#//vivado/private:parse_sv_interface>
<
src1The SystemVerilog interface source file to parse. B
@
vendor2The vendor VLNV component (e.g., 'mycompany.com'). ?
=
version)The version VLNV component (e.g., '1.0').2"1.0"�vivado_interface_ippPackage a Vivado interface definition as an IP block. Unlike vivado_ip_core, this does not require a top module."�
�
vivado_interface_ippPackage a Vivado interface definition as an IP block. Unlike vivado_ip_core, this does not require a top module.*
nameA unique name for this target. �
create_interface_ip_template+The TCL template for creating interface IP.21//vivado/private:create_interface_ip.tcl.templateL
	interface$The interface definition to package. *
VivadoInterfaceInfo�
module�The `verilog_library` / `vhdl_library` containing the interface source file(s). Optional. The default template doesn't read these â Vivado discovers bus and abstraction definitions from the repo path alone â but the transitive sources are staged into the action sandbox so a caller-supplied `create_interface_ip_template` can, and so the interface's HDL shows up in coverage instrumentation.*
VerilogInfo*

VhdlInfo2None"4
vivado_interface_ip@@rules_vivado//vivado:ip.bzl
��,
*
nameA unique name for this target. �
�
create_interface_ip_template+The TCL template for creating interface IP.21//vivado/private:create_interface_ip.tcl.templateN
L
	interface$The interface definition to package. *
VivadoInterfaceInfo�
�
module�The `verilog_library` / `vhdl_library` containing the interface source file(s). Optional. The default template doesn't read these â Vivado discovers bus and abstraction definitions from the repo path alone â but the transitive sources are staged into the action sandbox so a caller-supplied `create_interface_ip_template` can, and so the interface's HDL shows up in coverage instrumentation.*
VerilogInfo*

VhdlInfo2None� vivado_ip_core.Use vivado to package a module into an IP core"�
�
vivado_ip_core.Use vivado to package a module into an IP core*
nameA unique name for this target. l
create_ip_block_templateThe create project tcl template2-//vivado/private:create_ip_block.tcl.template�
encryptrEncrypt the sources. Note: This requires a license. See: https://support.xilinx.com/s/article/68071?language=en_US2FalseL
	ip_blocks$Ip blocks to include in this design.*
VivadoIPBlockInfo2[].

ip_libraryThe version of this ip core. -
	ip_vendorThe version of this ip core. .

ip_versionThe version of this ip core. L
jobs?Jobs to pass to vivado which defines the amount of parallelism.24_
keyfile-The keyfile to use when optionally encrypting2#//vivado/private:xilinx_keyfile.txt=
moduleThe top level build. *
VerilogInfo*

VhdlInfo;

module_top)The name of the top level verilog module. ,
part_numberThe targeted xilinx part. �
project_hooks�`.tcl`/`.xdc`/`.sdc` files OR `tcl_binary` targets sourced INSIDE any downstream `vivado_project` action that folds this target in via `ip_blocks` / `block_designs`. Fires right after `create_project` + `source_mgmt_mode`, before any `add_files`. Home for setup the target needs to work in context (`board_part`, `set_msg_config`, TCL procs). Does NOT run in this target's own action â for that use `pre_hooks` / `post_hooks`. Sourced in list order; multiple targets' contributions concat in project-attr dep order; the project's own `pre_hooks_early` fires last so it wins on override.2[]�
supported_families�Xilinx device families this IP can be consumed by (e.g. `["zynq", "zynquplus", "versal"]`). Each entry is registered at `Production` lifecycle. Leave empty to keep whatever `ipx::package_project` inferred from `part_number` â which restricts downstream consumers to the same family and produces `[Coretcl 2-1132] No IP matching VLNV ... is accessible for the current part '<other-family-part>'` when the consumer sits on a different family.2[]"/
vivado_ip_core@@rules_vivado//vivado:ip.bzl
jj,
*
nameA unique name for this target. n
l
create_ip_block_templateThe create project tcl template2-//vivado/private:create_ip_block.tcl.template�
�
encryptrEncrypt the sources. Note: This requires a license. See: https://support.xilinx.com/s/article/68071?language=en_US2FalseN
L
	ip_blocks$Ip blocks to include in this design.*
VivadoIPBlockInfo2[]0
.

ip_libraryThe version of this ip core. /
-
	ip_vendorThe version of this ip core. 0
.

ip_versionThe version of this ip core. N
L
jobs?Jobs to pass to vivado which defines the amount of parallelism.24a
_
keyfile-The keyfile to use when optionally encrypting2#//vivado/private:xilinx_keyfile.txt?
=
moduleThe top level build. *
VerilogInfo*

VhdlInfo=
;

module_top)The name of the top level verilog module. .
,
part_numberThe targeted xilinx part. �
�
project_hooks�`.tcl`/`.xdc`/`.sdc` files OR `tcl_binary` targets sourced INSIDE any downstream `vivado_project` action that folds this target in via `ip_blocks` / `block_designs`. Fires right after `create_project` + `source_mgmt_mode`, before any `add_files`. Home for setup the target needs to work in context (`board_part`, `set_msg_config`, TCL procs). Does NOT run in this target's own action â for that use `pre_hooks` / `post_hooks`. Sourced in list order; multiple targets' contributions concat in project-attr dep order; the project's own `pre_hooks_early` fires last so it wins on override.2[]�
�
supported_families�Xilinx device families this IP can be consumed by (e.g. `["zynq", "zynquplus", "versal"]`). Each entry is registered at `Production` lifecycle. Leave empty to keep whatever `ipx::package_project` inferred from `part_number` â which restricts downstream consumers to the same family and produces `[Coretcl 2-1132] No IP matching VLNV ... is accessible for the current part '<other-family-part>'` when the consumer sits on a different family.2[]�D
vivado_xci�Package a Xilinx-catalog IP from a configuration TCL into a consumable IP repo.

`script` is the configuration script sourced inside a fresh Vivado
project. It must call
`create_ip -name <ip> -vendor xilinx.com -library ip -version <ver> \
    -module_name <module_top> -dir . -force` and (optionally) configure
the IP via `set_property -dict {...} [get_ips <module_top>]`. The attr
takes an executable target â in practice a `tcl_binary`, which is what
carries the `deps` a script needs to `package require` shared
`tcl_library` helpers. An extra-toolchains transition routes it through
the Vivado tcl toolchain, so its wrapper comes out as a `.vhook.tcl`
Vivado can source directly and its deps land on `auto_path`.

The resulting `.xci` plus generated HDL/sim files are captured into a
TreeArtifact directory and exposed via `VivadoIPBlockInfo` so the IP
repo is auto-added to the consumer's `ip_repo_paths`.

Alongside `VivadoIPBlockInfo`, the rule also exposes `VerilogInfo` and
`VhdlInfo` so the target is `deps`-interchangeable with `verilog_library`
and `vhdl_library`. Generated files are split by extension into four
sibling TreeArtifacts â `<name>.verilog` (`.v` / `.sv`), `<name>.vhdl`
(`.vhd` / `.vhdl`), `<name>.verilog_header` (`.vh` / `.svh`), and
`<name>.data` (everything else) â which are placed on the appropriate
`srcs` / `hdrs` / `data` fields of the two providers. Consuming rules
add each directory via `add_files`; Vivado auto-classifies files
inside by extension. The split carries the IP's `sim/` behavioural model
and `hdl/` sources; the `synth/` wrapper (a second definition of the same
module) and copies of upstream `ip_blocks` are left out, so a
`verilog_library`-shaped consumer sees each module exactly once. Vivado
flows should consume the IP through `ip_blocks` (the `.xci`) rather than
through these directories.

Use the `ip_blocks` attribute on `vivado_project`, `vivado_block_design`,
or `vivado_ip_core` to make this IP available to that consumer. BD
cells that reference the IP's VLNV (e.g.
`create_bd_cell -vlnv xilinx.com:ip:axi_dma:7.1`) will then resolve via
the catalog.

For your own HDL packaged as a new reusable IP, use `vivado_ip_core`
instead.
"�2
�"

vivado_xci�Package a Xilinx-catalog IP from a configuration TCL into a consumable IP repo.

`script` is the configuration script sourced inside a fresh Vivado
project. It must call
`create_ip -name <ip> -vendor xilinx.com -library ip -version <ver> \
    -module_name <module_top> -dir . -force` and (optionally) configure
the IP via `set_property -dict {...} [get_ips <module_top>]`. The attr
takes an executable target â in practice a `tcl_binary`, which is what
carries the `deps` a script needs to `package require` shared
`tcl_library` helpers. An extra-toolchains transition routes it through
the Vivado tcl toolchain, so its wrapper comes out as a `.vhook.tcl`
Vivado can source directly and its deps land on `auto_path`.

The resulting `.xci` plus generated HDL/sim files are captured into a
TreeArtifact directory and exposed via `VivadoIPBlockInfo` so the IP
repo is auto-added to the consumer's `ip_repo_paths`.

Alongside `VivadoIPBlockInfo`, the rule also exposes `VerilogInfo` and
`VhdlInfo` so the target is `deps`-interchangeable with `verilog_library`
and `vhdl_library`. Generated files are split by extension into four
sibling TreeArtifacts â `<name>.verilog` (`.v` / `.sv`), `<name>.vhdl`
(`.vhd` / `.vhdl`), `<name>.verilog_header` (`.vh` / `.svh`), and
`<name>.data` (everything else) â which are placed on the appropriate
`srcs` / `hdrs` / `data` fields of the two providers. Consuming rules
add each directory via `add_files`; Vivado auto-classifies files
inside by extension. The split carries the IP's `sim/` behavioural model
and `hdl/` sources; the `synth/` wrapper (a second definition of the same
module) and copies of upstream `ip_blocks` are left out, so a
`verilog_library`-shaped consumer sees each module exactly once. Vivado
flows should consume the IP through `ip_blocks` (the `.xci`) rather than
through these directories.

Use the `ip_blocks` attribute on `vivado_project`, `vivado_block_design`,
or `vivado_ip_core` to make this IP available to that consumer. BD
cells that reference the IP's VLNV (e.g.
`create_bd_cell -vlnv xilinx.com:ip:axi_dma:7.1`) will then resolve via
the catalog.

For your own HDL packaged as a new reusable IP, use `vivado_ip_core`
instead.
*
nameA unique name for this target. �
data�Additional files the IP-config TCL needs available in the action's sandbox. Each file is materialized at its workspace-relative path; the TCL can reference it via that path (e.g., to `exec patch -i ...` against the generated HDL, or to `read` a side data file). Same semantics as `cc_library.data`, `py_test.data`, etc.2[]n
	ip_blocksFOther IP blocks the configuration TCL depends on (rare; mostly empty).*
VivadoIPBlockInfo2[]I
jobs<Jobs to pass to vivado (resource hint to Bazel's scheduler).21j

module_topXThe `module_name` passed to `create_ip` in `script`. Used to locate the produced `.xci`. ?
part_number,Xilinx part number the IP is configured for. �

post_hooks�`.tcl`/`.xdc`/`.sdc` files OR `tcl_binary` targets sourced after `generate_target`, before the project closes. Sourced in list order.2[]�
	pre_hooks�`.tcl`/`.xdc`/`.sdc` files OR `tcl_binary` targets sourced after project + IP-block setup, before sourcing the user IP TCL. Sourced in list order.2[]�
project_hooks�`.tcl`/`.xdc`/`.sdc` files OR `tcl_binary` targets sourced INSIDE any downstream `vivado_project` action that folds this target in via `ip_blocks` / `block_designs`. Fires right after `create_project` + `source_mgmt_mode`, before any `add_files`. Home for setup the target needs to work in context (`board_part`, `set_msg_config`, TCL procs). Does NOT run in this target's own action â for that use `pre_hooks` / `post_hooks`. Sourced in list order; multiple targets' contributions concat in project-attr dep order; the project's own `pre_hooks_early` fires last so it wins on override.2[]�
script�Executable target (a `tcl_binary`) whose script is sourced inside a fresh Vivado project to configure the IP. Must call `create_ip ... -module_name <module_top>`. Its `tcl_library` deps are staged as runfiles and reached with `package require`. A bare `.tcl` file is not accepted; wrap it in a `tcl_binary`. Q
xci_templateThe XCI tcl template.2(//vivado/private:create_xci.tcl.template"+

vivado_xci@@rules_vivado//vivado:ip.bzl
��,
*
nameA unique name for this target. �
�
data�Additional files the IP-config TCL needs available in the action's sandbox. Each file is materialized at its workspace-relative path; the TCL can reference it via that path (e.g., to `exec patch -i ...` against the generated HDL, or to `read` a side data file). Same semantics as `cc_library.data`, `py_test.data`, etc.2[]p
n
	ip_blocksFOther IP blocks the configuration TCL depends on (rare; mostly empty).*
VivadoIPBlockInfo2[]K
I
jobs<Jobs to pass to vivado (resource hint to Bazel's scheduler).21l
j

module_topXThe `module_name` passed to `create_ip` in `script`. Used to locate the produced `.xci`. A
?
part_number,Xilinx part number the IP is configured for. �
�

post_hooks�`.tcl`/`.xdc`/`.sdc` files OR `tcl_binary` targets sourced after `generate_target`, before the project closes. Sourced in list order.2[]�
�
	pre_hooks�`.tcl`/`.xdc`/`.sdc` files OR `tcl_binary` targets sourced after project + IP-block setup, before sourcing the user IP TCL. Sourced in list order.2[]�
�
project_hooks�`.tcl`/`.xdc`/`.sdc` files OR `tcl_binary` targets sourced INSIDE any downstream `vivado_project` action that folds this target in via `ip_blocks` / `block_designs`. Fires right after `create_project` + `source_mgmt_mode`, before any `add_files`. Home for setup the target needs to work in context (`board_part`, `set_msg_config`, TCL procs). Does NOT run in this target's own action â for that use `pre_hooks` / `post_hooks`. Sourced in list order; multiple targets' contributions concat in project-attr dep order; the project's own `pre_hooks_early` fires last so it wins on override.2[]�
�
script�Executable target (a `tcl_binary`) whose script is sourced inside a fresh Vivado project to configure the IP. Must call `create_ip ... -module_name <module_top>`. Its `tcl_library` deps are staged as runfiles and reached with `package require`. A bare `.tcl` file is not accepted; wrap it in a `tcl_binary`. S
Q
xci_templateThe XCI tcl template.2(//vivado/private:create_xci.tcl.templatet
//verilog:defs.bzlr\
"
rules_verilogverilogdefs.bzl(
VerilogInfoVerilogInfo
+6
8e
//vhdl:defs.bzlrP


rules_vhdlvhdldefs.bzl"
VhdlInfoVhdlInfo
%-
/�
//vivado:providers.bzlr�
%
rules_vivadovivadoproviders.bzl4
VivadoIPBlockInfoVivadoIPBlockInfo
8
VivadoInterfaceInfoVivadoInterfaceInfo

	�
//vivado/private:common.bzlr�
*
rules_vivadovivado/private
common.bzl.
TOOLCHAIN_TYPETOOLCHAIN_TYPE
*
encrypt_dataencrypt_data
:
get_vivado_toolchainget_vivado_toolchain
2
hdl_sources_datahdl_sources_data
&

hook_attrs
hook_attrs
0
hook_invocationhook_invocation
.
ip_blocks_dataip_blocks_data
6
project_hooks_attrproject_hooks_attr
2
run_tcl_templaterun_tcl_template
0
tcl_script_attrtcl_script_attr
0
tcl_script_datatcl_script_data


# IP packaging rules�"
'
rules_vivadovivadopackaged_ip.bzl�vivado_packaged_ip�Wrap a pre-packaged Vivado IP directory as a consumable IP repo.

For third-party / vendor-supplied IPs â a tree rooted at one or more
`component.xml` files. For Xilinx-catalog IPs configured via a
`create_ip` Tcl use `vivado_xci`; for your own HDL packaged as new IP
use `vivado_ip_core`.

Stages each file in `srcs` into a TreeArtifact, preserving its path
relative to the rule's package (with optional `strip_prefix` applied), and
exposes the staged directory via `VivadoIPBlockInfo.repo`. Consumers list
the target in their `ip_blocks` attr; the existing IP-block plumbing adds
the directory to `ip_repo_paths` in the consumer's project so any
`create_ip` calls referencing the IP's VLNV resolve via the catalog.

The rule is repository-agnostic: it works identically in the main repo,
inside an `http_archive`-fetched external repo, or in any custom
repository rule's generated BUILD file.
"�
�
vivado_packaged_ip�Wrap a pre-packaged Vivado IP directory as a consumable IP repo.

For third-party / vendor-supplied IPs â a tree rooted at one or more
`component.xml` files. For Xilinx-catalog IPs configured via a
`create_ip` Tcl use `vivado_xci`; for your own HDL packaged as new IP
use `vivado_ip_core`.

Stages each file in `srcs` into a TreeArtifact, preserving its path
relative to the rule's package (with optional `strip_prefix` applied), and
exposes the staged directory via `VivadoIPBlockInfo.repo`. Consumers list
the target in their `ip_blocks` attr; the existing IP-block plumbing adds
the directory to `ip_repo_paths` in the consumer's project so any
`create_ip` calls referencing the IP's VLNV resolve via the catalog.

The rule is repository-agnostic: it works identically in the main repo,
inside an `http_archive`-fetched external repo, or in any custom
repository rule's generated BUILD file.
*
nameA unique name for this target. �
hdl_libraries�HDL libraries whose transitive sources contribute to the staged IP tree. Walks `VhdlInfo` / `VerilogInfo` providers and stages each `File` at its package-relative path under the staged root (same path computation as `srcs`).*
VerilogInfo*

VhdlInfo2[]�
srcsrFiles under the IP repo root â typically the non-HDL portion: `component.xml`, `xgui/**`, vendor TCL scripts.2[]�
strip_prefix�Optional package-relative prefix to strip from each src's staging path. Mirrors `http_archive.strip_prefix` semantics. Use when the BUILD file is at a higher level than the IP repo root and you want a flatter staged tree. Vivado walks `ip_repo_paths` recursively for `component.xml`, so this is hygiene/predictability only â leaving it empty doesn't affect correctness.2"""<
vivado_packaged_ip&@@rules_vivado//vivado:packaged_ip.bzl
^^,
*
nameA unique name for this target. �
�
hdl_libraries�HDL libraries whose transitive sources contribute to the staged IP tree. Walks `VhdlInfo` / `VerilogInfo` providers and stages each `File` at its package-relative path under the staged root (same path computation as `srcs`).*
VerilogInfo*

VhdlInfo2[]�
�
srcsrFiles under the IP repo root â typically the non-HDL portion: `component.xml`, `xgui/**`, vendor TCL scripts.2[]�
�
strip_prefix�Optional package-relative prefix to strip from each src's staging path. Mirrors `http_archive.strip_prefix` semantics. Use when the BUILD file is at a higher level than the IP repo root and you want a flatter staged tree. Vivado walks `ip_repo_paths` recursively for `component.xml`, so this is hygiene/predictability only â leaving it empty doesn't affect correctness.2""t
//verilog:defs.bzlr\
"
rules_verilogverilogdefs.bzl(
VerilogInfoVerilogInfo
+6
8e
//vhdl:defs.bzlrP


rules_vhdlvhdldefs.bzl"
VhdlInfoVhdlInfo
%-
/�
//vivado:providers.bzlrk
%
rules_vivadovivadoproviders.bzl4
VivadoIPBlockInfoVivadoIPBlockInfo
.?
A�
//vivado:toolchain.bzlre
%
rules_vivadovivadotoolchain.bzl.
TOOLCHAIN_TYPETOOLCHAIN_TYPE
.<
>�
//vivado/private:common.bzlrn
*
rules_vivadovivado/private
common.bzl2
hdl_sources_datahdl_sources_data
3C
E)Pre-packaged IP rule: vivado_packaged_ip.�F
#
rules_vivadovivadoproject.bzl�<vivado_project�Emit a TCL project-creation script. Does NOT invoke Vivado.

A spec-carrying rule: its sole build-time action is a template expansion
producing `<name>.project.tcl`, which â sourced inside a Vivado process
â runs `create_project`, source ingest, constraints, and hooks. It stops
short of `generate_target`, because the right intent (`{synthesis
implementation}` vs `simulation`) depends on the consumer; each consumer
issues its own after sourcing.

Two ways to consume it:

- `vivado_synthesis` (and the other phase rules) take
  `project = <label>` and source the emitted script inside their Vivado
  action before doing their own work.
- A GUI launcher can `vivado -source <name>.project.tcl` directly. The
  script's `PROJECT_MODE` / `PROJECT_DIR` variables default to `project`
  mode in `.`; override them with `VIVADO_PROJECT_MODE` /
  `VIVADO_PROJECT_DIR`, or by pre-setting the Tcl variables before
  sourcing.

Provides `VivadoProjectInfo`.
"�4
�
vivado_project�Emit a TCL project-creation script. Does NOT invoke Vivado.

A spec-carrying rule: its sole build-time action is a template expansion
producing `<name>.project.tcl`, which â sourced inside a Vivado process
â runs `create_project`, source ingest, constraints, and hooks. It stops
short of `generate_target`, because the right intent (`{synthesis
implementation}` vs `simulation`) depends on the consumer; each consumer
issues its own after sourcing.

Two ways to consume it:

- `vivado_synthesis` (and the other phase rules) take
  `project = <label>` and source the emitted script inside their Vivado
  action before doing their own work.
- A GUI launcher can `vivado -source <name>.project.tcl` directly. The
  script's `PROJECT_MODE` / `PROJECT_DIR` variables default to `project`
  mode in `.`; override them with `VIVADO_PROJECT_MODE` /
  `VIVADO_PROJECT_DIR`, or by pre-setting the Tcl variables before
  sourcing.

Provides `VivadoProjectInfo`.
*
nameA unique name for this target. �
block_designs�Block designs (`vivado_block_design` targets) to fold into the project. Copied under `$PROJECT_DIR/imported_bds/<name>/` and `add_files`d. The consumer (`vivado_synthesis` / `vivado_xsim_test`) picks the appropriate `generate_target` intent (`{synthesis implementation}` vs `simulation`).*
VivadoBlockDesignInfo2[]�
data�Constraint / setup files (`.xdc`, `.sdc`, `.tcl`) loaded in EXACT list order â the escape hatch for files whose relative ordering matters (e.g. a `set_clock_groups.xdc` that references clocks defined in a `create_clock.xdc` sourced earlier). Loaded AFTER the HDL-walk-swept `.xdc` files from `verilog_library.data` / `vhdl_library.data`, so project-scope constraints layer on top of per-library foundations. `.xdc`/`.sdc` â `read_xdc`, `.tcl` â `source`. Files whose order doesn't matter should live on the HDL library's `.data` instead and ride the HDL dep graph.

Put a `# do not sort` comment above an order-sensitive list. buildifier sorts `data` lists by default, so without it a routine format pass silently rewrites the constraint load order â nothing fails until Vivado applies the wrong constraints.2[]L
	ip_blocks$IP blocks to include in this design.*
VivadoIPBlockInfo2[]�
module�Top-level HDL library. Optional â omit for IP-only projects (e.g. `vivado_export_simulation` in sim-from-packaged-IPs mode). When set, its transitive sources are `read_verilog` / `read_vhdl`d and its `.xdc` / `.tcl` files are added; when unset, only `ip_blocks` / `block_designs` contribute sources.*
VerilogInfo*

VhdlInfo2None;

module_top)The name of the top level verilog module. ,
part_numberThe targeted xilinx part. �
	pre_hooks�`.tcl`/`.xdc`/`.sdc` files OR `tcl_binary` targets sourced AFTER all `add_files` but BEFORE the emitted script returns control to its caller. Home for hooks that need sources loaded but must run before any `generate_target` â e.g. `fixup_constraints.tcl` calling `get_files -of [get_ips]`. For post-elaboration hooks, use the consumer's `pre_hooks` (`vivado_synthesis.pre_hooks`, `vivado_xsim_test.pre_hooks`). For hooks that set project properties (`board_part`) or define TCL procs used by BD sources, use `pre_hooks_early`. Sourced in list order.2[]�
pre_hooks_early�`.tcl`/`.xdc`/`.sdc` files OR `tcl_binary` targets sourced AFTER `create_project` but BEFORE any `add_files`. Home for hooks that set project-scope properties (`board_part`, `set_msg_config`) or define TCL procs consumed by BD `.tcl` scripts loaded during add_files (e.g. `amba::add_associated_busif`, `noc::*`). Sourced in list order.2[]j
project_tcl_template)Template driving the emitted project TCL.2%//vivado/private:project.tcl.template"4
vivado_project"@@rules_vivado//vivado:project.bzl
��,
*
nameA unique name for this target. �
�
block_designs�Block designs (`vivado_block_design` targets) to fold into the project. Copied under `$PROJECT_DIR/imported_bds/<name>/` and `add_files`d. The consumer (`vivado_synthesis` / `vivado_xsim_test`) picks the appropriate `generate_target` intent (`{synthesis implementation}` vs `simulation`).*
VivadoBlockDesignInfo2[]�
�
data�Constraint / setup files (`.xdc`, `.sdc`, `.tcl`) loaded in EXACT list order â the escape hatch for files whose relative ordering matters (e.g. a `set_clock_groups.xdc` that references clocks defined in a `create_clock.xdc` sourced earlier). Loaded AFTER the HDL-walk-swept `.xdc` files from `verilog_library.data` / `vhdl_library.data`, so project-scope constraints layer on top of per-library foundations. `.xdc`/`.sdc` â `read_xdc`, `.tcl` â `source`. Files whose order doesn't matter should live on the HDL library's `.data` instead and ride the HDL dep graph.

Put a `# do not sort` comment above an order-sensitive list. buildifier sorts `data` lists by default, so without it a routine format pass silently rewrites the constraint load order â nothing fails until Vivado applies the wrong constraints.2[]N
L
	ip_blocks$IP blocks to include in this design.*
VivadoIPBlockInfo2[]�
�
module�Top-level HDL library. Optional â omit for IP-only projects (e.g. `vivado_export_simulation` in sim-from-packaged-IPs mode). When set, its transitive sources are `read_verilog` / `read_vhdl`d and its `.xdc` / `.tcl` files are added; when unset, only `ip_blocks` / `block_designs` contribute sources.*
VerilogInfo*

VhdlInfo2None=
;

module_top)The name of the top level verilog module. .
,
part_numberThe targeted xilinx part. �
�
	pre_hooks�`.tcl`/`.xdc`/`.sdc` files OR `tcl_binary` targets sourced AFTER all `add_files` but BEFORE the emitted script returns control to its caller. Home for hooks that need sources loaded but must run before any `generate_target` â e.g. `fixup_constraints.tcl` calling `get_files -of [get_ips]`. For post-elaboration hooks, use the consumer's `pre_hooks` (`vivado_synthesis.pre_hooks`, `vivado_xsim_test.pre_hooks`). For hooks that set project properties (`board_part`) or define TCL procs used by BD sources, use `pre_hooks_early`. Sourced in list order.2[]�
�
pre_hooks_early�`.tcl`/`.xdc`/`.sdc` files OR `tcl_binary` targets sourced AFTER `create_project` but BEFORE any `add_files`. Home for hooks that set project-scope properties (`board_part`, `set_msg_config`) or define TCL procs consumed by BD `.tcl` scripts loaded during add_files (e.g. `amba::add_associated_busif`, `noc::*`). Sourced in list order.2[]l
j
project_tcl_template)Template driving the emitted project TCL.2%//vivado/private:project.tcl.templatet
//verilog:defs.bzlr\
"
rules_verilogverilogdefs.bzl(
VerilogInfoVerilogInfo
+6
8e
//vhdl:defs.bzlrP


rules_vhdlvhdldefs.bzl"
VhdlInfoVhdlInfo
%-
/�
//vivado:providers.bzlr�
%
rules_vivadovivadoproviders.bzl<
VivadoBlockDesignInfoVivadoBlockDesignInfo
4
VivadoIPBlockInfoVivadoIPBlockInfo
4
VivadoProjectInfoVivadoProjectInfo
		

�
//vivado/private:common.bzlr�
*
rules_vivadovivado/private
common.bzl4
DEFAULT_HOOK_EXTSDEFAULT_HOOK_EXTS
.
TOOLCHAIN_TYPETOOLCHAIN_TYPE
6
block_designs_datablock_designs_data
2
hdl_sources_datahdl_sources_data
0
hook_invocationhook_invocation
.
ip_blocks_dataip_blocks_data
R
 merge_project_hook_contributions merge_project_hook_contributions
&8
tcl_hook_flag_attrstcl_hook_flag_attrs
2
tcl_list_literaltcl_list_literal

�
 //vivado/private:transitions.bzlrq
/
rules_vivadovivado/privatetransitions.bzl0
hook_transitionhook_transition
8G
I# vivado_project rule.�+
*
rules_vivadovivadoproject_export.bzl�%vivado_project_export�Run a user-provided Tcl script against a `vivado_project`, declaring the file and directory outputs the script produces.

Shaped like a `genrule`: you supply the Tcl and declare what it writes;
the rule sources the project's emitted TCL, sources your script, then
verifies every declared output exists. `script` takes an executable
target â in practice a `tcl_binary` â so the script can `package
require` shared `tcl_library` helpers.

Prefer a typed rule (`vivado_synthesis`, `vivado_export_simulation`,
`vivado_hw_platform`, â¦) whenever your workflow maps to one â this is
the escape hatch for workflows that map to none and don't justify a new
rule. Two consumers writing the same invocation with the same Tcl body
is the signal to promote it to a typed rule.

Project-input only: phases whose input is a checkpoint (`write_edif`,
`write_verilog`, `write_hw_platform`, â¦) do not fit this shape.

Provides only `DefaultInfo`, by design â escape-hatch consumers work off
file paths, not typed contracts.
"�
�
vivado_project_export�Run a user-provided Tcl script against a `vivado_project`, declaring the file and directory outputs the script produces.

Shaped like a `genrule`: you supply the Tcl and declare what it writes;
the rule sources the project's emitted TCL, sources your script, then
verifies every declared output exists. `script` takes an executable
target â in practice a `tcl_binary` â so the script can `package
require` shared `tcl_library` helpers.

Prefer a typed rule (`vivado_synthesis`, `vivado_export_simulation`,
`vivado_hw_platform`, â¦) whenever your workflow maps to one â this is
the escape hatch for workflows that map to none and don't justify a new
rule. Two consumers writing the same invocation with the same Tcl body
is the signal to promote it to a typed rule.

Project-input only: phases whose input is a checkpoint (`write_edif`,
`write_verilog`, `write_hw_platform`, â¦) do not fit this shape.

Provides only `DefaultInfo`, by design â escape-hatch consumers work off
file paths, not typed contracts.
*
nameA unique name for this target. ,
jobsJobs hint to Bazel's scheduler.21�
out_dirs�Declared TreeArtifact outputs. Each becomes a `ctx.actions.declare_directory`; paths land in `$OUT_DIRS` (Tcl list, in declared order). User's Tcl must ensure each directory exists at action completion.2[]�
outs�Declared File outputs. Each becomes a `ctx.actions.declare_file`; paths land in `$OUTS` (Tcl list, in declared order). User's Tcl must ensure each file exists at action completion or Bazel fails the action.w

post_hooksc`.tcl` files OR `tcl_binary` targets sourced after the user's Tcl completes. Sourced in list order.2[]�
	pre_hooksv`.tcl` files OR `tcl_binary` targets sourced after the project loads but BEFORE the user's Tcl. Sourced in list order.2[]�
project�`vivado_project` target. The emitted project TCL is sourced BEFORE the user's Tcl, so the user script runs against a fully-loaded project. *
VivadoProjectInfo�
script�Executable target (a `tcl_binary`) whose script is sourced after `vivado_project`'s TCL loads. Sees `$OUTS`, `$OUT_DIRS`, and `$PROJECT_DIR` as pre-set variables. Its `tcl_library` deps are staged as runfiles and reached with `package require`. A bare `.tcl` file is not accepted; wrap it in a `tcl_binary`. "B
vivado_project_export)@@rules_vivado//vivado:project_export.bzl
>>,
*
nameA unique name for this target. .
,
jobsJobs hint to Bazel's scheduler.21�
�
out_dirs�Declared TreeArtifact outputs. Each becomes a `ctx.actions.declare_directory`; paths land in `$OUT_DIRS` (Tcl list, in declared order). User's Tcl must ensure each directory exists at action completion.2[]�
�
outs�Declared File outputs. Each becomes a `ctx.actions.declare_file`; paths land in `$OUTS` (Tcl list, in declared order). User's Tcl must ensure each file exists at action completion or Bazel fails the action.y
w

post_hooksc`.tcl` files OR `tcl_binary` targets sourced after the user's Tcl completes. Sourced in list order.2[]�
�
	pre_hooksv`.tcl` files OR `tcl_binary` targets sourced after the project loads but BEFORE the user's Tcl. Sourced in list order.2[]�
�
project�`vivado_project` target. The emitted project TCL is sourced BEFORE the user's Tcl, so the user script runs against a fully-loaded project. *
VivadoProjectInfo�
�
script�Executable target (a `tcl_binary`) whose script is sourced after `vivado_project`'s TCL loads. Sees `$OUTS`, `$OUT_DIRS`, and `$PROJECT_DIR` as pre-set variables. Its `tcl_library` deps are staged as runfiles and reached with `package require`. A bare `.tcl` file is not accepted; wrap it in a `tcl_binary`. �
//vivado:providers.bzlrk
%
rules_vivadovivadoproviders.bzl4
VivadoProjectInfoVivadoProjectInfo
.?
A�
//vivado/private:common.bzlr�
*
rules_vivadovivado/private
common.bzl.
TOOLCHAIN_TYPETOOLCHAIN_TYPE
:
get_vivado_toolchainget_vivado_toolchain
&

hook_attrs
hook_attrs
0
hook_invocationhook_invocation
		2
run_tcl_templaterun_tcl_template


2
tcl_list_literaltcl_list_literal
0
tcl_script_attrtcl_script_attr
0
tcl_script_datatcl_script_data

# vivado_project_export rule.��
%
rules_vivadovivadoproviders.bzl�VivadoBlockDesignInfoGInfo for a Vivado block design (.bd) produced by `vivado_block_design`.2�
�	
VivadoBlockDesignInfoGInfo for a Vivado block design (.bd) produced by `vivado_block_design`.�
bd_dir�File: tree-artifact directory containing the generated `.bd` and its supporting files. The `.bd` itself is normalized to `<bd_dir>/<module_top>.bd` by the rule.�
ip_block_repos�list[File]: IP repo directories from `ip_blocks` deps that must be added to the consuming project's `ip_repo_paths` for the BD to resolve.�

module_top�string: The block-design name (the argument to `create_bd_design` in the source TCL). Consumers use `<bd_dir>/<module_top>.bd` to find the file.�
project_hooks�list[Target]: hook Targets this target contributes as `project_hooks` to any downstream `vivado_project` that lists it in `ip_blocks` / `block_designs`. The consumer passes the merged Target list through `hook_invocation` to derive both the sourceable paths (for the emitted TCL) and the tools list (for `run_shell(tools = ...)` staging). Sourced right after `create_project` + `source_mgmt_mode` and before the project's own `pre_hooks_early`. Empty when the target declares no `project_hooks`."=
VivadoBlockDesignInfo$@@rules_vivado//vivado:providers.bzl
�!�!�
�
bd_dir�File: tree-artifact directory containing the generated `.bd` and its supporting files. The `.bd` itself is normalized to `<bd_dir>/<module_top>.bd` by the rule.�
�
ip_block_repos�list[File]: IP repo directories from `ip_blocks` deps that must be added to the consuming project's `ip_repo_paths` for the BD to resolve.�
�

module_top�string: The block-design name (the argument to `create_bd_design` in the source TCL). Consumers use `<bd_dir>/<module_top>.bd` to find the file.�
�
project_hooks�list[Target]: hook Targets this target contributes as `project_hooks` to any downstream `vivado_project` that lists it in `ip_blocks` / `block_designs`. The consumer passes the merged Target list through `hook_invocation` to derive both the sourceable paths (for the emitted TCL) and the tools list (for `run_shell(tools = ...)` staging). Sourced right after `create_project` + `source_mgmt_mode` and before the project's own `pre_hooks_early`. Empty when the target declares no `project_hooks`.�	VivadoCompiledSimlibInfo�Output of `vivado_compile_simlib`. Layout matches `compile_simlib -directory <dir>`: `<simlib_dir>/<simulator>/` contains the simulator's link-config file plus per-library compiled artifacts.2�
�
VivadoCompiledSimlibInfo�Output of `vivado_compile_simlib`. Layout matches `compile_simlib -directory <dir>`: `<simlib_dir>/<simulator>/` contains the simulator's link-config file plus per-library compiled artifacts.�

simlib_dir�File: TreeArtifact directory containing the compiled simlib. The link-config file lives at `<simlib_dir>/<simulator>/<link_config_basename>` (e.g. `<simlib_dir>/riviera/library.cfg`).k
	simulator^string: The simulator the simlib targets. One of Vivado's `compile_simlib -simulator` choices."@
VivadoCompiledSimlibInfo$@@rules_vivado//vivado:providers.bzl
�$�$�
�

simlib_dir�File: TreeArtifact directory containing the compiled simlib. The link-config file lives at `<simlib_dir>/<simulator>/<link_config_basename>` (e.g. `<simlib_dir>/riviera/library.cfg`).m
k
	simulator^string: The simulator the simlib targets. One of Vivado's `compile_simlib -simulator` choices.�VivadoDebugProbesInfo�Output of `vivado_debug_probes`. Wraps `write_debug_probes`; produces the `.ltx` probe file consumed by Vivado's Hardware Manager during ILA bring-up.2�
�
VivadoDebugProbesInfo�Output of `vivado_debug_probes`. Wraps `write_debug_probes`; produces the `.ltx` probe file consumed by Vivado's Hardware Manager during ILA bring-up.2
ltx+File: the emitted `.ltx` debug-probes file.r
project_infobVivadoProjectInfo: typed back-reference to the originating project (through the checkpoint chain).A
tcl:File: the fully-substituted TCL script the action sourced."=
VivadoDebugProbesInfo$@@rules_vivado//vivado:providers.bzl
�!�!4
2
ltx+File: the emitted `.ltx` debug-probes file.t
r
project_infobVivadoProjectInfo: typed back-reference to the originating project (through the checkpoint chain).C
A
tcl:File: the fully-substituted TCL script the action sourced.�
VivadoExportSimulationInfo�Output of `vivado_export_simulation` â the directory Vivado writes when invoked with `export_simulation -directory <dir>`. Contents follow Vivado's contract for the chosen simulator (see UG835).2�
�
VivadoExportSimulationInfo�Output of `vivado_export_simulation` â the directory Vivado writes when invoked with `export_simulation -directory <dir>`. Contents follow Vivado's contract for the chosen simulator (see UG835).A

export_dir3File: TreeArtifact directory containing the export.|
project_infolVivadoProjectInfo: typed back-reference to the originating project. Same purpose as on checkpoint providers.@
	simulator3string: The `-simulator` argument passed to Vivado.f
tcl_File: the fully-substituted TCL script the action sourced. See `VivadoSynthCheckpointInfo.tcl`."B
VivadoExportSimulationInfo$@@rules_vivado//vivado:providers.bzl
�&�&C
A

export_dir3File: TreeArtifact directory containing the export.~
|
project_infolVivadoProjectInfo: typed back-reference to the originating project. Same purpose as on checkpoint providers.B
@
	simulator3string: The `-simulator` argument passed to Vivado.h
f
tcl_File: the fully-substituted TCL script the action sourced. See `VivadoSynthCheckpointInfo.tcl`.�VivadoHwPlatformInfo�Output of `vivado_hw_platform`. Wraps `write_hw_platform`; produces the `.xsa` handoff artifact consumed by Vitis, PetaLinux, and other Xilinx SDK tooling.2�
�
VivadoHwPlatformInfo�Output of `vivado_hw_platform`. Wraps `write_hw_platform`; produces the `.xsa` handoff artifact consumed by Vitis, PetaLinux, and other Xilinx SDK tooling.r
project_infobVivadoProjectInfo: typed back-reference to the originating project (through the checkpoint chain).A
tcl:File: the fully-substituted TCL script the action sourced.:
xsa3File: the emitted `.xsa` hardware platform archive."<
VivadoHwPlatformInfo$@@rules_vivado//vivado:providers.bzl
� � t
r
project_infobVivadoProjectInfo: typed back-reference to the originating project (through the checkpoint chain).C
A
tcl:File: the fully-substituted TCL script the action sourced.<
:
xsa3File: the emitted `.xsa` hardware platform archive.�VivadoIPBlockInfo�Describes the contents of a Vivado IP artifact. Consumers read the fields to decide whether to call `create_ip`, `add_files` a configured `.xci`, or just expose the repo on `ip_repo_paths`.2�
�
VivadoIPBlockInfo�Describes the contents of a Vivado IP artifact. Consumers read the fields to decide whether to call `create_ip`, `add_files` a configured `.xci`, or just expose the repo on `ip_repo_paths`.�
configured_instance�Optional[struct(repo_dir: File, xci_relpath: str, module_top: str)]: Set when the artifact contains a pre-configured IP instance. Consumers add `<repo_dir>/<xci_relpath>` to their source set. None when there is no configured instance.�
instantiable�Optional[struct(vendor: str, library: str, name: str, version: str, module_name: str)]: Set when consumers are expected to `create_ip` with these VLNV identifiers and `-module_name <module_name>`. None otherwise.�
project_hooks�list[Target]: hook Targets this target contributes as `project_hooks` to any downstream `vivado_project` that lists it in `ip_blocks` / `block_designs`. The consumer passes the merged Target list through `hook_invocation` to derive both the sourceable paths (for the emitted TCL) and the tools list (for `run_shell(tools = ...)` staging). Sourced right after `create_project` + `source_mgmt_mode` and before the project's own `pre_hooks_early`. Empty when the target declares no `project_hooks`.�
repo�list[File]: Directory artifacts forming an IP repository (`component.xml`-rooted tree). Added to the consuming project's `ip_repo_paths`."9
VivadoIPBlockInfo$@@rules_vivado//vivado:providers.bzl
���
�
configured_instance�Optional[struct(repo_dir: File, xci_relpath: str, module_top: str)]: Set when the artifact contains a pre-configured IP instance. Consumers add `<repo_dir>/<xci_relpath>` to their source set. None when there is no configured instance.�
�
instantiable�Optional[struct(vendor: str, library: str, name: str, version: str, module_name: str)]: Set when consumers are expected to `create_ip` with these VLNV identifiers and `-module_name <module_name>`. None otherwise.�
�
project_hooks�list[Target]: hook Targets this target contributes as `project_hooks` to any downstream `vivado_project` that lists it in `ip_blocks` / `block_designs`. The consumer passes the merged Target list through `hook_invocation` to derive both the sourceable paths (for the emitted TCL) and the tools list (for `run_shell(tools = ...)` staging). Sourced right after `create_project` + `source_mgmt_mode` and before the project's own `pre_hooks_early`. Empty when the target declares no `project_hooks`.�
�
repo�list[File]: Directory artifacts forming an IP repository (`component.xml`-rooted tree). Added to the consuming project's `ip_repo_paths`.�VivadoInterfaceInfo.Info for a Vivado IP-XACT interface definition2�
�
VivadoInterfaceInfo.Info for a Vivado IP-XACT interface definitionD
abstraction_definition*File: The abstraction definition XML file.4
bus_definition"File: The bus definition XML file..
library#string: The library VLNV component.#
namestring: The interface name.7
	setup_tcl*File: The TCL setup file for IP packaging.,
vendor"string: The vendor VLNV component..
version#string: The version VLNV component.";
VivadoInterfaceInfo$@@rules_vivado//vivado:providers.bzl
��F
D
abstraction_definition*File: The abstraction definition XML file.6
4
bus_definition"File: The bus definition XML file.0
.
library#string: The library VLNV component.%
#
namestring: The interface name.9
7
	setup_tcl*File: The TCL setup file for IP packaging..
,
vendor"string: The vendor VLNV component.0
.
version#string: The version VLNV component.�VivadoLogInfo�Aggregated Vivado `.log` and `.jou` files for a phase target and all its transitive upstream phases. Keys are short phase names (`synth`, `synth_opt`, `place`, `place_opt`, `route`, `write_bitstream`, `write_device_image`).2�
�
VivadoLogInfo�Aggregated Vivado `.log` and `.jou` files for a phase target and all its transitive upstream phases. Keys are short phase names (`synth`, `synth_opt`, `place`, `place_opt`, `route`, `write_bitstream`, `write_device_image`).8
journals,dict[str, File]: phase name -> journal File.0
logs(dict[str, File]: phase name -> log File."5
VivadoLogInfo$@@rules_vivado//vivado:providers.bzl
��:
8
journals,dict[str, File]: phase name -> journal File.2
0
logs(dict[str, File]: phase name -> log File.�VivadoPlacementCheckpointInfoMOutput of the placement phase (`vivado_placement` / `vivado_place_optimize`).2�
�
VivadoPlacementCheckpointInfoMOutput of the placement phase (`vivado_placement` / `vivado_place_optimize`).D

checkpoint6File: the Vivado checkpoint (.dcp) this phase emitted.�
input_files�depset[File]: transitive files needed to re-open the checkpoint with `read_checkpoint` + `link_design`. Includes the upstream project's `input_files`, the upstream checkpoint file itself, and any impl-XDC bundle.

Most consumers do NOT need this. A `.dcp` is self-contained, so every in-tree phase rule that only `open_checkpoint`s (`vivado_placement`, `vivado_place_optimize`, `vivado_routing`, `vivado_synthesis_optimize`, `vivado_bitstream`, `vivado_device_image`, `vivado_hw_platform`, `vivado_debug_probes`) stages just the `.dcp` and keeps the action's input set small. Pass `input_files.to_list()` only when an action re-links the design against its original sources or re-sources the project script.�

module_top�str: top-module name (propagated from the originating `vivado_project.module_top`). May be `""` if the upstream provider carried no top.�
part_number�str: Xilinx part string (propagated from the originating `vivado_project.part_number`). Consumers use this to open the checkpoint on the correct part.�
project_info�VivadoProjectInfo: typed back-reference to the originating project. Enables consumers to trace a checkpoint back to design intent (module tops, block designs, constraints) without needing a separate `project = ...` attr on every downstream rule.�
tcl�File: the fully-substituted TCL script the action sourced. Useful for debugging (`bazel build //foo:x` produces this) and for reproducing the phase outside Bazel (`vivado -source <this-file>`)."E
VivadoPlacementCheckpointInfo$@@rules_vivado//vivado:providers.bzl
�)�)F
D

checkpoint6File: the Vivado checkpoint (.dcp) this phase emitted.�
�
input_files�depset[File]: transitive files needed to re-open the checkpoint with `read_checkpoint` + `link_design`. Includes the upstream project's `input_files`, the upstream checkpoint file itself, and any impl-XDC bundle.

Most consumers do NOT need this. A `.dcp` is self-contained, so every in-tree phase rule that only `open_checkpoint`s (`vivado_placement`, `vivado_place_optimize`, `vivado_routing`, `vivado_synthesis_optimize`, `vivado_bitstream`, `vivado_device_image`, `vivado_hw_platform`, `vivado_debug_probes`) stages just the `.dcp` and keeps the action's input set small. Pass `input_files.to_list()` only when an action re-links the design against its original sources or re-sources the project script.�
�

module_top�str: top-module name (propagated from the originating `vivado_project.module_top`). May be `""` if the upstream provider carried no top.�
�
part_number�str: Xilinx part string (propagated from the originating `vivado_project.part_number`). Consumers use this to open the checkpoint on the correct part.�
�
project_info�VivadoProjectInfo: typed back-reference to the originating project. Enables consumers to trace a checkpoint back to design intent (module tops, block designs, constraints) without needing a separate `project = ...` attr on every downstream rule.�
�
tcl�File: the fully-substituted TCL script the action sourced. Useful for debugging (`bazel build //foo:x` produces this) and for reproducing the phase outside Bazel (`vivado -source <this-file>`).�2VivadoProjectInfo�Output of `vivado_project`. Carries a self-contained TCL script (produced by Starlark template expansion, no Vivado invocation) that, when sourced inside a Vivado process, does `create_project` + source ingest + constraints + hooks (but NOT `generate_target` â the consumer picks that intent). Downstream consumers (`vivado_synthesis`, `vivado_export_simulation`, GUI launchers, `vivado_project_export`) source this script in their own Vivado action. The provider also carries the transitive input closure the script references, plus typed access to the sub-providers folded into the project, so consumers only need to depend on the `vivado_project` target â never on its individual inputs.2�,
�
VivadoProjectInfo�Output of `vivado_project`. Carries a self-contained TCL script (produced by Starlark template expansion, no Vivado invocation) that, when sourced inside a Vivado process, does `create_project` + source ingest + constraints + hooks (but NOT `generate_target` â the consumer picks that intent). Downstream consumers (`vivado_synthesis`, `vivado_export_simulation`, GUI launchers, `vivado_project_export`) source this script in their own Vivado action. The provider also carries the transitive input closure the script references, plus typed access to the sub-providers folded into the project, so consumers only need to depend on the `vivado_project` target â never on its individual inputs.�
block_designs�list[VivadoBlockDesignInfo]: typed access to the block-design providers folded into the project via `block_designs = [...]`. Enables downstream rules (e.g. `vivado_bd_wrapper`, project-walking aspects) to reason about BDs by provider rather than reparsing the project script or re-reading rule attrs.�

hook_tools�list: File / FilesToRunProvider entries for `pre_hooks_early` / `pre_hooks` / `post_hooks` targets. Consumers pass this list to `ctx.actions.run_shell(tools=...)` so hook runfiles trees (needed by `tcl_binary`-based hooks) materialize in the sandbox.�
input_files�depset[File]: transitive files the emitted script references by exec-root path (HDL sources, IP repos, BD directories, constraint files, hook files). Any consumer that SOURCES `project_tcl` must pass `input_files.to_list()` as action inputs, or the sandbox won't stage what the script tries to open â `vivado_synthesis`, `vivado_project_export`, and the `export_simulation` rules all do. Consumers that only read a downstream checkpoint do NOT need it; see `_CHECKPOINT_COMMON_FIELDS.input_files` below.�
	ip_blocks�list[VivadoIPBlockInfo]: typed access to the IP providers folded into the project via `ip_blocks = [...]`. Symmetric with `block_designs`.I

module_top;str: top-module name (matches `vivado_project.module_top`).N
part_number?str: Xilinx part string (matches `vivado_project.part_number`).�
project_tcl�File: the emitted `.project.tcl` script. Sourcing this file inside a Vivado process does `create_project` + contributed `project_hooks` + `pre_hooks_early` + `read_verilog` / `read_vhdl` / `add_files` + `read_xdc` + `set_property top` + `pre_hooks`. It has no `post_hooks` and runs no `generate_target` â the consumer issues that with the intent it needs. Reads `PROJECT_MODE` / `PROJECT_DIR` from pre-set Tcl variables or the `VIVADO_PROJECT_MODE` / `VIVADO_PROJECT_DIR` env vars (default: `project` mode in `.`).�
xdc�depset[File]: transitive `.xdc` / `.sdc` / `.tcl` constraint files contributed via `vivado_project.data`, in the exact order the emitted script's `$PROJECT_DATA_FILES` loop reads them: plain files at their listed position, `xdc_library` targets expanded in place with their dep-first transitive closure. Empty when the project has no `data` entries. Enables aspects and future constraint-linting rules to walk the constraint set without reparsing the emitted TCL."9
VivadoProjectInfo$@@rules_vivado//vivado:providers.bzl
�
�
block_designs�list[VivadoBlockDesignInfo]: typed access to the block-design providers folded into the project via `block_designs = [...]`. Enables downstream rules (e.g. `vivado_bd_wrapper`, project-walking aspects) to reason about BDs by provider rather than reparsing the project script or re-reading rule attrs.�
�

hook_tools�list: File / FilesToRunProvider entries for `pre_hooks_early` / `pre_hooks` / `post_hooks` targets. Consumers pass this list to `ctx.actions.run_shell(tools=...)` so hook runfiles trees (needed by `tcl_binary`-based hooks) materialize in the sandbox.�
�
input_files�depset[File]: transitive files the emitted script references by exec-root path (HDL sources, IP repos, BD directories, constraint files, hook files). Any consumer that SOURCES `project_tcl` must pass `input_files.to_list()` as action inputs, or the sandbox won't stage what the script tries to open â `vivado_synthesis`, `vivado_project_export`, and the `export_simulation` rules all do. Consumers that only read a downstream checkpoint do NOT need it; see `_CHECKPOINT_COMMON_FIELDS.input_files` below.�
�
	ip_blocks�list[VivadoIPBlockInfo]: typed access to the IP providers folded into the project via `ip_blocks = [...]`. Symmetric with `block_designs`.K
I

module_top;str: top-module name (matches `vivado_project.module_top`).P
N
part_number?str: Xilinx part string (matches `vivado_project.part_number`).�
�
project_tcl�File: the emitted `.project.tcl` script. Sourcing this file inside a Vivado process does `create_project` + contributed `project_hooks` + `pre_hooks_early` + `read_verilog` / `read_vhdl` / `add_files` + `read_xdc` + `set_property top` + `pre_hooks`. It has no `post_hooks` and runs no `generate_target` â the consumer issues that with the intent it needs. Reads `PROJECT_MODE` / `PROJECT_DIR` from pre-set Tcl variables or the `VIVADO_PROJECT_MODE` / `VIVADO_PROJECT_DIR` env vars (default: `project` mode in `.`).�
�
xdc�depset[File]: transitive `.xdc` / `.sdc` / `.tcl` constraint files contributed via `vivado_project.data`, in the exact order the emitted script's `$PROJECT_DATA_FILES` loop reads them: plain files at their listed position, `xdc_library` targets expanded in place with their dep-first transitive closure. Empty when the project has no `data` entries. Enables aspects and future constraint-linting rules to walk the constraint set without reparsing the emitted TCL.�VivadoReportsInfoRMaps the `reports` attr's caller-chosen output names to the declared File objects.2�
�
VivadoReportsInfoRMaps the `reports` attr's caller-chosen output names to the declared File objects.K
reports@dict[str, File]: caller-chosen output filename -> declared File."9
VivadoReportsInfo$@@rules_vivado//vivado:providers.bzl
��M
K
reports@dict[str, File]: caller-chosen output filename -> declared File.�VivadoRoutingCheckpointInfo/Output of the routing phase (`vivado_routing`).2�
�
VivadoRoutingCheckpointInfo/Output of the routing phase (`vivado_routing`).D

checkpoint6File: the Vivado checkpoint (.dcp) this phase emitted.�
input_files�depset[File]: transitive files needed to re-open the checkpoint with `read_checkpoint` + `link_design`. Includes the upstream project's `input_files`, the upstream checkpoint file itself, and any impl-XDC bundle.

Most consumers do NOT need this. A `.dcp` is self-contained, so every in-tree phase rule that only `open_checkpoint`s (`vivado_placement`, `vivado_place_optimize`, `vivado_routing`, `vivado_synthesis_optimize`, `vivado_bitstream`, `vivado_device_image`, `vivado_hw_platform`, `vivado_debug_probes`) stages just the `.dcp` and keeps the action's input set small. Pass `input_files.to_list()` only when an action re-links the design against its original sources or re-sources the project script.�

module_top�str: top-module name (propagated from the originating `vivado_project.module_top`). May be `""` if the upstream provider carried no top.�
part_number�str: Xilinx part string (propagated from the originating `vivado_project.part_number`). Consumers use this to open the checkpoint on the correct part.�
project_info�VivadoProjectInfo: typed back-reference to the originating project. Enables consumers to trace a checkpoint back to design intent (module tops, block designs, constraints) without needing a separate `project = ...` attr on every downstream rule.�
tcl�File: the fully-substituted TCL script the action sourced. Useful for debugging (`bazel build //foo:x` produces this) and for reproducing the phase outside Bazel (`vivado -source <this-file>`)."C
VivadoRoutingCheckpointInfo$@@rules_vivado//vivado:providers.bzl
�'�'F
D

checkpoint6File: the Vivado checkpoint (.dcp) this phase emitted.�
�
input_files�depset[File]: transitive files needed to re-open the checkpoint with `read_checkpoint` + `link_design`. Includes the upstream project's `input_files`, the upstream checkpoint file itself, and any impl-XDC bundle.

Most consumers do NOT need this. A `.dcp` is self-contained, so every in-tree phase rule that only `open_checkpoint`s (`vivado_placement`, `vivado_place_optimize`, `vivado_routing`, `vivado_synthesis_optimize`, `vivado_bitstream`, `vivado_device_image`, `vivado_hw_platform`, `vivado_debug_probes`) stages just the `.dcp` and keeps the action's input set small. Pass `input_files.to_list()` only when an action re-links the design against its original sources or re-sources the project script.�
�

module_top�str: top-module name (propagated from the originating `vivado_project.module_top`). May be `""` if the upstream provider carried no top.�
�
part_number�str: Xilinx part string (propagated from the originating `vivado_project.part_number`). Consumers use this to open the checkpoint on the correct part.�
�
project_info�VivadoProjectInfo: typed back-reference to the originating project. Enables consumers to trace a checkpoint back to design intent (module tops, block designs, constraints) without needing a separate `project = ...` attr on every downstream rule.�
�
tcl�File: the fully-substituted TCL script the action sourced. Useful for debugging (`bazel build //foo:x` produces this) and for reproducing the phase outside Bazel (`vivado -source <this-file>`).�!VivadoSynthCheckpointInfoQOutput of the synthesis phase (`vivado_synthesis` / `vivado_synthesis_optimize`).2� 
�
VivadoSynthCheckpointInfoQOutput of the synthesis phase (`vivado_synthesis` / `vivado_synthesis_optimize`).D

checkpoint6File: the Vivado checkpoint (.dcp) this phase emitted.�
input_files�depset[File]: transitive files needed to re-open the checkpoint with `read_checkpoint` + `link_design`. Includes the upstream project's `input_files`, the upstream checkpoint file itself, and any impl-XDC bundle.

Most consumers do NOT need this. A `.dcp` is self-contained, so every in-tree phase rule that only `open_checkpoint`s (`vivado_placement`, `vivado_place_optimize`, `vivado_routing`, `vivado_synthesis_optimize`, `vivado_bitstream`, `vivado_device_image`, `vivado_hw_platform`, `vivado_debug_probes`) stages just the `.dcp` and keeps the action's input set small. Pass `input_files.to_list()` only when an action re-links the design against its original sources or re-sources the project script.�

module_top�str: top-module name (propagated from the originating `vivado_project.module_top`). May be `""` if the upstream provider carried no top.�
part_number�str: Xilinx part string (propagated from the originating `vivado_project.part_number`). Consumers use this to open the checkpoint on the correct part.�
project_info�VivadoProjectInfo: typed back-reference to the originating project. Enables consumers to trace a checkpoint back to design intent (module tops, block designs, constraints) without needing a separate `project = ...` attr on every downstream rule.�
tcl�File: the fully-substituted TCL script the action sourced. Useful for debugging (`bazel build //foo:x` produces this) and for reproducing the phase outside Bazel (`vivado -source <this-file>`).�
impl_xdc�Optional[File]: Bundle of XDC content from source files marked `USED_IN_IMPLEMENTATION == True`. `synth_design` doesn't apply these and `write_checkpoint` only persists applied constraints, so downstream phases must `read_xdc <bundle>` before `opt_design` / `place_design` or the constraints are lost. May be `None`; consumers must tolerate that case."A
VivadoSynthCheckpointInfo$@@rules_vivado//vivado:providers.bzl
w%w%F
D

checkpoint6File: the Vivado checkpoint (.dcp) this phase emitted.�
�
input_files�depset[File]: transitive files needed to re-open the checkpoint with `read_checkpoint` + `link_design`. Includes the upstream project's `input_files`, the upstream checkpoint file itself, and any impl-XDC bundle.

Most consumers do NOT need this. A `.dcp` is self-contained, so every in-tree phase rule that only `open_checkpoint`s (`vivado_placement`, `vivado_place_optimize`, `vivado_routing`, `vivado_synthesis_optimize`, `vivado_bitstream`, `vivado_device_image`, `vivado_hw_platform`, `vivado_debug_probes`) stages just the `.dcp` and keeps the action's input set small. Pass `input_files.to_list()` only when an action re-links the design against its original sources or re-sources the project script.�
�

module_top�str: top-module name (propagated from the originating `vivado_project.module_top`). May be `""` if the upstream provider carried no top.�
�
part_number�str: Xilinx part string (propagated from the originating `vivado_project.part_number`). Consumers use this to open the checkpoint on the correct part.�
�
project_info�VivadoProjectInfo: typed back-reference to the originating project. Enables consumers to trace a checkpoint back to design intent (module tops, block designs, constraints) without needing a separate `project = ...` attr on every downstream rule.�
�
tcl�File: the fully-substituted TCL script the action sourced. Useful for debugging (`bazel build //foo:x` produces this) and for reproducing the phase outside Bazel (`vivado -source <this-file>`).�
�
impl_xdc�Optional[File]: Bundle of XDC content from source files marked `USED_IN_IMPLEMENTATION == True`. `synth_design` doesn't apply these and `write_checkpoint` only persists applied constraints, so downstream phases must `read_xdc <bundle>` before `opt_design` / `place_design` or the constraints are lost. May be `None`; consumers must tolerate that case.�XdcInfo�Marker provider on `xdc_library` targets. Carries the transitive closure of the `.xdc` / `.sdc` files a downstream consumer should `read_xdc` in topological order (deps' srcs before the target's own srcs). Independent of any HDL info â `xdc_library` deliberately doesn't re-export VerilogInfo / VhdlInfo. Exists as a first-class provider so aspects can walk arbitrary dep graphs and pick out XDC-file contributors by filtering for this marker.2�	
�
XdcInfo�Marker provider on `xdc_library` targets. Carries the transitive closure of the `.xdc` / `.sdc` files a downstream consumer should `read_xdc` in topological order (deps' srcs before the target's own srcs). Independent of any HDL info â `xdc_library` deliberately doesn't re-export VerilogInfo / VhdlInfo. Exists as a first-class provider so aspects can walk arbitrary dep graphs and pick out XDC-file contributors by filtering for this marker.�
srcs�depset[File]: transitive `.xdc`/`.sdc` files, deep-deps first (topological order). The rule's `DefaultInfo.files` is the same depset so this target also drops into `vivado_project.data` â the flattened order Bazel derives from `ctx.files.data` on a topological depset is what the emitted TCL's `$PROJECT_DATA_FILES` loop iterates."/
XdcInfo$@@rules_vivado//vivado:providers.bzl
���
�
srcs�depset[File]: transitive `.xdc`/`.sdc` files, deep-deps first (topological order). The rule's `DefaultInfo.files` is the same depset so this target also drops into `vivado_project.data` â the flattened order Bazel derives from `ctx.files.data` on a topological depset is what the emitted TCL's `$PROJECT_DATA_FILES` loop iterates.# Vivado providers.�w
&
rules_vivadovivadosimulation.bzl�"vivado_compile_simlib�Pre-compile the Xilinx baseline simulation libraries (`unisim`,
`unimacro`, `secureip`, `unifast`, ...) for a third-party simulator. Output is
a TreeArtifact at the layout `compile_simlib -directory <dir>` produces.

`compile_simlib` is hours of work for `-family all`; pass a specific silicon
family to bound the scope. The simulator install is located via an env-var
lookup on the exec platform (`$RIVIERA_HOME` for riviera, etc.) because
`compile_simlib` shells out to vsimsa AND its peer tools.
"�
�
vivado_compile_simlib�Pre-compile the Xilinx baseline simulation libraries (`unisim`,
`unimacro`, `secureip`, `unifast`, ...) for a third-party simulator. Output is
a TreeArtifact at the layout `compile_simlib -directory <dir>` produces.

`compile_simlib` is hours of work for `-family all`; pass a specific silicon
family to bound the scope. The simulator install is located via an env-var
lookup on the exec platform (`$RIVIERA_HOME` for riviera, etc.) because
`compile_simlib` shells out to vsimsa AND its peer tools.
*
nameA unique name for this target. y
compile_simlib_template.The tcl template that drives `compile_simlib`.2,//vivado/private:compile_simlib.tcl.template�
family�Xilinx silicon family, passed to `compile_simlib -family <X>`. Common values: `all` (hours), `versal`, `kintexuplus`, `zynquplus`. L
language7HDL language, passed to `compile_simlib -language <X>`.2"all"�
library�Simulation library set, passed to `compile_simlib -library <X>`. For families whose `all` set omits a needed library, compile that library in a second target with `no_ip_compile = True` and chain via `vmap -link` at consume time.2"all"�
license_resource_countiNumber of `license_resource_name` units to claim. Values <= 0 fall back to 1 when a resource name is set.20�
license_resource_name�FlexLM feature name to claim from Bazel's local resource pool. Callers wire the pool via `--local_extra_resources=<name>=N`. Overrides the built-in default map (activehdl, riviera). Empty falls back to that map.2""�
no_ip_compile�Pass `-no_ip_compile`. Required on chained follow-up targets: Vivado rewrites `library.cfg` on each `compile_simlib`, so a later call's IP compile pass errors with `Library "<baseline>" not found` because the fresh `library.cfg` lacks the baseline mappings the IPs reference.2False�
no_systemc_compile�Pass `-no_systemc_compile` (default true). The SystemC libs require a working SystemC install reachable by the simulator's C++ toolchain, which often isn't present in CI images.2True[
	simulatorJTarget simulator. `xsim` is built into Vivado and doesn't need precompile. ">
vivado_compile_simlib%@@rules_vivado//vivado:simulation.bzl
��,
*
nameA unique name for this target. {
y
compile_simlib_template.The tcl template that drives `compile_simlib`.2,//vivado/private:compile_simlib.tcl.template�
�
family�Xilinx silicon family, passed to `compile_simlib -family <X>`. Common values: `all` (hours), `versal`, `kintexuplus`, `zynquplus`. N
L
language7HDL language, passed to `compile_simlib -language <X>`.2"all"�
�
library�Simulation library set, passed to `compile_simlib -library <X>`. For families whose `all` set omits a needed library, compile that library in a second target with `no_ip_compile = True` and chain via `vmap -link` at consume time.2"all"�
�
license_resource_countiNumber of `license_resource_name` units to claim. Values <= 0 fall back to 1 when a resource name is set.20�
�
license_resource_name�FlexLM feature name to claim from Bazel's local resource pool. Callers wire the pool via `--local_extra_resources=<name>=N`. Overrides the built-in default map (activehdl, riviera). Empty falls back to that map.2""�
�
no_ip_compile�Pass `-no_ip_compile`. Required on chained follow-up targets: Vivado rewrites `library.cfg` on each `compile_simlib`, so a later call's IP compile pass errors with `Library "<baseline>" not found` because the fresh `library.cfg` lacks the baseline mappings the IPs reference.2False�
�
no_systemc_compile�Pass `-no_systemc_compile` (default true). The SystemC libs require a working SystemC install reachable by the simulator's C++ toolchain, which often isn't present in CI images.2True]
[
	simulatorJTarget simulator. `xsim` is built into Vivado and doesn't need precompile. �vivado_export_simulation�Run Vivado's `export_simulation` over a `vivado_project` and
stage the resulting directory as a TreeArtifact. The downstream
simulator is not run; consumers compose against `VivadoExportSimulationInfo`.

The exported `compile.sh` / `elaborate.sh` / `simulate.sh` scripts are
path-sanitized like every other output: absolute paths become
`<execroot>/` so the tree stays cacheable across hosts and RBE workers.
The bundle is therefore not runnable straight out of `bazel-bin` â a
consumer re-points the marker at its own root first (`sed -i
"s|<execroot>/|$PWD/|g"`). See `vivado_toolchain(sanitizer = ...)`.
"�
�
vivado_export_simulation�Run Vivado's `export_simulation` over a `vivado_project` and
stage the resulting directory as a TreeArtifact. The downstream
simulator is not run; consumers compose against `VivadoExportSimulationInfo`.

The exported `compile.sh` / `elaborate.sh` / `simulate.sh` scripts are
path-sanitized like every other output: absolute paths become
`<execroot>/` so the tree stays cacheable across hosts and RBE workers.
The bundle is therefore not runnable straight out of `bazel-bin` â a
consumer re-points the marker at its own root first (`sed -i
"s|<execroot>/|$PWD/|g"`). See `vivado_toolchain(sanitizer = ...)`.
*
nameA unique name for this target. �
export_simulation_template1The tcl template that drives `export_simulation`.2///vivado/private:export_simulation.tcl.templates

module_topaSimulation-fileset top module. Typically the testbench name, or `<bd>_wrapper` for a BD-only sim. �
post_hook_tools�Executable targets invoked in the same Bazel action AFTER Vivado exits. Each receives `--project-dir <path> --export-dir <path>` and the same paths via `VIVADO_PROJECT_DIR` / `VIVADO_EXPORT_DIR` env vars. Order is preserved; first non-zero exit fails the action.2[]�

post_hooks�`.tcl` files OR `tcl_binary` targets sourced inside Vivado at the end of the export body, with the project still open. Sourced in list order.2[]_
pre_hook_toolsGExecutable targets invoked BEFORE Vivado starts; see `post_hook_tools`.2[]�
	pre_hooks�`.tcl` files OR `tcl_binary` targets sourced after the project script + sim elaboration, before `export_simulation` runs. Sourced in list order.2[]�
project�`vivado_project` target carrying the emitted project TCL script + its transitive input closure. All project-shape attrs (module, part_number, block_designs, ip_blocks, pre_hooks_early, etc.) live on that target. *
VivadoProjectInfo1
	simulator Target simulator for the export. "A
vivado_export_simulation%@@rules_vivado//vivado:simulation.bzl
� � ,
*
nameA unique name for this target. �
�
export_simulation_template1The tcl template that drives `export_simulation`.2///vivado/private:export_simulation.tcl.templateu
s

module_topaSimulation-fileset top module. Typically the testbench name, or `<bd>_wrapper` for a BD-only sim. �
�
post_hook_tools�Executable targets invoked in the same Bazel action AFTER Vivado exits. Each receives `--project-dir <path> --export-dir <path>` and the same paths via `VIVADO_PROJECT_DIR` / `VIVADO_EXPORT_DIR` env vars. Order is preserved; first non-zero exit fails the action.2[]�
�

post_hooks�`.tcl` files OR `tcl_binary` targets sourced inside Vivado at the end of the export body, with the project still open. Sourced in list order.2[]a
_
pre_hook_toolsGExecutable targets invoked BEFORE Vivado starts; see `post_hook_tools`.2[]�
�
	pre_hooks�`.tcl` files OR `tcl_binary` targets sourced after the project script + sim elaboration, before `export_simulation` runs. Sourced in list order.2[]�
�
project�`vivado_project` target carrying the emitted project TCL script + its transitive input closure. All project-shape attrs (module, part_number, block_designs, ip_blocks, pre_hooks_early, etc.) live on that target. *
VivadoProjectInfo3
1
	simulator Target simulator for the export. �.vivado_xsim_test�Run a Vivado xsim simulation as a Bazel test.

A build action sources the `vivado_project`-emitted project TCL,
generates simulation targets on any BDs, and calls `export_simulation`
to produce a self-contained xsim script bundle; the test binary runs
`simulate.sh` at test time. Log-scan patterns catch `$error` output,
which xsim prints but doesn't exit nonzero for. The wrapper writes a
JUnit XML at `$XML_OUTPUT_FILE` and copies the sim log, per-tool logs,
and any `.wdb` waveform into `$TEST_UNDECLARED_OUTPUTS_DIR`.

At test time the wrapper re-points the bundle's sanitized `<execroot>/`
paths at its runfiles, then needs `xvlog` / `xelab` / `xsim` on `PATH`.
Bazel hands tests a minimal `PATH`, so supply them through the
toolchain's `xilinx_env` script (sourced by the wrapper) or an
`env = {"PATH": ...}` entry; failing both, the wrapper boots the
toolchain's `vivado` shim once to discover the install's `bin` dir.
"�'
�
vivado_xsim_test�Run a Vivado xsim simulation as a Bazel test.

A build action sources the `vivado_project`-emitted project TCL,
generates simulation targets on any BDs, and calls `export_simulation`
to produce a self-contained xsim script bundle; the test binary runs
`simulate.sh` at test time. Log-scan patterns catch `$error` output,
which xsim prints but doesn't exit nonzero for. The wrapper writes a
JUnit XML at `$XML_OUTPUT_FILE` and copies the sim log, per-tool logs,
and any `.wdb` waveform into `$TEST_UNDECLARED_OUTPUTS_DIR`.

At test time the wrapper re-points the bundle's sanitized `<execroot>/`
paths at its runfiles, then needs `xvlog` / `xelab` / `xsim` on `PATH`.
Bazel hands tests a minimal `PATH`, so supply them through the
toolchain's `xilinx_env` script (sourced by the wrapper) or an
`env = {"PATH": ...}` entry; failing both, the wrapper boots the
toolchain's `vivado` shim once to discover the install's `bin` dir.
*
nameA unique name for this target. �
completion_pattern�ERE pattern the simulation log must match for the test to pass. Set to `""` to disable. Only consulted when the driver script exited 0.2
"\$finish"�
error_patterns�ERE patterns that mark the simulation log as failed. Joined with `|` and passed to `grep -E`. Pass `[]` to disable log scanning.22["^Error: ", "^ERROR:", "FATAL_ERROR", "\\$fatal"]�
export_simulation_template1The tcl template that drives `export_simulation`.2///vivado/private:export_simulation.tcl.templates

module_topaSimulation-fileset top module. Typically the testbench name, or `<bd>_wrapper` for a BD-only sim. �
post_hook_tools�Executable targets invoked in the same Bazel action AFTER Vivado exits. Each receives `--project-dir <path> --export-dir <path>` and the same paths via `VIVADO_PROJECT_DIR` / `VIVADO_EXPORT_DIR` env vars. Order is preserved; first non-zero exit fails the action.2[]�

post_hooks�`.tcl` files OR `tcl_binary` targets sourced after `export_simulation` completes, with the project still open. Sourced in list order.2[]_
pre_hook_toolsGExecutable targets invoked BEFORE Vivado starts; see `post_hook_tools`.2[]�
	pre_hooks�`.tcl` files OR `tcl_binary` targets sourced after the project script + sim elaboration, before `export_simulation` runs. Sourced in list order.2[]�
project�`vivado_project` target carrying the emitted project TCL script + its transitive input closure. All project-shape attrs (module, part_number, block_designs, ip_blocks, pre_hooks_early, etc.) live on that target. *
VivadoProjectInfo�
with_waveform�Only `False` is accepted; `True` fails at analysis. To capture waveforms, add a `pre_hooks` Tcl script that sets `xsim.simulate.log_all_signals` on the sim fileset.2False�
xsim_test_wrapper_template>Bash template driving the exported `simulate.sh` at test time.2.//vivado/private:xsim_test_wrapper.sh.template"9
vivado_xsim_test%@@rules_vivado//vivado:simulation.bzl
��,
*
nameA unique name for this target. �
�
completion_pattern�ERE pattern the simulation log must match for the test to pass. Set to `""` to disable. Only consulted when the driver script exited 0.2
"\$finish"�
�
error_patterns�ERE patterns that mark the simulation log as failed. Joined with `|` and passed to `grep -E`. Pass `[]` to disable log scanning.22["^Error: ", "^ERROR:", "FATAL_ERROR", "\\$fatal"]�
�
export_simulation_template1The tcl template that drives `export_simulation`.2///vivado/private:export_simulation.tcl.templateu
s

module_topaSimulation-fileset top module. Typically the testbench name, or `<bd>_wrapper` for a BD-only sim. �
�
post_hook_tools�Executable targets invoked in the same Bazel action AFTER Vivado exits. Each receives `--project-dir <path> --export-dir <path>` and the same paths via `VIVADO_PROJECT_DIR` / `VIVADO_EXPORT_DIR` env vars. Order is preserved; first non-zero exit fails the action.2[]�
�

post_hooks�`.tcl` files OR `tcl_binary` targets sourced after `export_simulation` completes, with the project still open. Sourced in list order.2[]a
_
pre_hook_toolsGExecutable targets invoked BEFORE Vivado starts; see `post_hook_tools`.2[]�
�
	pre_hooks�`.tcl` files OR `tcl_binary` targets sourced after the project script + sim elaboration, before `export_simulation` runs. Sourced in list order.2[]�
�
project�`vivado_project` target carrying the emitted project TCL script + its transitive input closure. All project-shape attrs (module, part_number, block_designs, ip_blocks, pre_hooks_early, etc.) live on that target. *
VivadoProjectInfo�
�
with_waveform�Only `False` is accepted; `True` fails at analysis. To capture waveforms, add a `pre_hooks` Tcl script that sets `xsim.simulate.log_all_signals` on the sim fileset.2False�
�
xsim_test_wrapper_template>Bash template driving the exported `simulate.sh` at test time.2.//vivado/private:xsim_test_wrapper.sh.templatea
//lib:shell.bzlrL

bazel_skyliblib	shell.bzl
shellshell
',
.�
//vivado:providers.bzlr�
%
rules_vivadovivadoproviders.bzlB
VivadoCompiledSimlibInfoVivadoCompiledSimlibInfo
F
VivadoExportSimulationInfoVivadoExportSimulationInfo
 4
VivadoProjectInfoVivadoProjectInfo

	�
//vivado/private:common.bzlr�
*
rules_vivadovivado/private
common.bzl0
EXECROOT_MARKEREXECROOT_MARKER
.
TOOLCHAIN_TYPETOOLCHAIN_TYPE
0
exec_hooks_dataexec_hooks_data
:
get_vivado_toolchainget_vivado_toolchain
&

hook_attrs
hook_attrs
0
hook_invocationhook_invocation
2
run_tcl_templaterun_tcl_template


# Simulation rules�E
%
rules_vivadovivadosynthesis.bzl�/vivado_synthesis�Run synthesis on a `vivado_project`. Sources the project's emitted TCL script inside a single Vivado action, generates IP / BD targets (global synthesis â no OOC runs), runs the top synth (`launch_runs` or `synth_design`), and writes a `.dcp` checkpoint + impl-XDC bundle for downstream implementation phases."�,
�
vivado_synthesis�Run synthesis on a `vivado_project`. Sources the project's emitted TCL script inside a single Vivado action, generates IP / BD targets (global synthesis â no OOC runs), runs the top synth (`launch_runs` or `synth_design`), and writes a `.dcp` checkpoint + impl-XDC bundle for downstream implementation phases.*
nameA unique name for this target. L
jobs?Jobs to pass to vivado which defines the amount of parallelism.24�

post_hooks�`.tcl`/`.xdc`/`.sdc` files OR `tcl_binary` targets sourced on the open synthesized design (after `open_run "synth_1"`), before checkpoint write and reports. Sourced in list order.2[]�
	pre_hooks�`.tcl`/`.xdc`/`.sdc` files OR `tcl_binary` targets sourced after the project script finishes (post `generate_target`) but before synth runs are launched. Sourced in list order.2[]�
project�`vivado_project` target carrying the emitted project TCL script + its transitive input closure. All project-shape attrs (module, module_top, part_number, block_designs, ip_blocks, pre_hooks_early, etc.) live on that target, not here. *
VivadoProjectInfo�
project_mode�How Vivado stores project state. `project` creates a named on-disk project so managed-run infrastructure (`launch_runs`, `synth_1`) is available. `in_memory` calls `create_project -in_memory`; managed runs are unavailable, so `synth_invocation = launch_runs` requires `project`. The two modes can produce different netlist hierarchies for block-design-instantiated IPs, affecting downstream physical constraints that target IP-internal cells/nets.2	"project"�
reports�Report types to run after `synth_design`, before checkpoint write. Each entry must be a key in `REPORT_TYPES` (`vivado/private/common.bzl`). Reports live at `<target>.reports/<filename>` and are wrapped in `catch` so a single failure writes an empty file rather than aborting. Pass `reports = []` to disable.2!["timing_summary", "utilization"]�

synth_args�Extra flags for `synth_design` in the `synth_design` invocation path. Cannot contain `-top` (the rule emits that from the project's `module_top`). Not consulted on the `launch_runs` path; there, set `STEPS.SYNTH_DESIGN.ARGS.*` run properties from a `pre_hooks` script.2[]�
synth_invocation�How `synth_design` is invoked. `launch_runs` wraps it in a managed `synth_1` design-run (fresh Vivado process re-loads project state from disk). `synth_design` invokes it in the same process. Multi-config XCI consumer instantiations require `synth_design`: in `launch_runs` the re-loading process binds consumer wrappers to the IP's project-managed synth wrapper (which doesn't propagate consumer-side generics), so wrappers passing distinct generic combinations surface as `__parameterized<N>` black boxes.2"launch_runs"O
synth_strategyThe synthesis strategy to use.2"Vivado Synthesis Defaults"`
synthesis_tcl_templateThe synthesis tcl template.2'//vivado/private:synthesis.tcl.template"8
vivado_synthesis$@@rules_vivado//vivado:synthesis.bzl
��,
*
nameA unique name for this target. N
L
jobs?Jobs to pass to vivado which defines the amount of parallelism.24�
�

post_hooks�`.tcl`/`.xdc`/`.sdc` files OR `tcl_binary` targets sourced on the open synthesized design (after `open_run "synth_1"`), before checkpoint write and reports. Sourced in list order.2[]�
�
	pre_hooks�`.tcl`/`.xdc`/`.sdc` files OR `tcl_binary` targets sourced after the project script finishes (post `generate_target`) but before synth runs are launched. Sourced in list order.2[]�
�
project�`vivado_project` target carrying the emitted project TCL script + its transitive input closure. All project-shape attrs (module, module_top, part_number, block_designs, ip_blocks, pre_hooks_early, etc.) live on that target, not here. *
VivadoProjectInfo�
�
project_mode�How Vivado stores project state. `project` creates a named on-disk project so managed-run infrastructure (`launch_runs`, `synth_1`) is available. `in_memory` calls `create_project -in_memory`; managed runs are unavailable, so `synth_invocation = launch_runs` requires `project`. The two modes can produce different netlist hierarchies for block-design-instantiated IPs, affecting downstream physical constraints that target IP-internal cells/nets.2	"project"�
�
reports�Report types to run after `synth_design`, before checkpoint write. Each entry must be a key in `REPORT_TYPES` (`vivado/private/common.bzl`). Reports live at `<target>.reports/<filename>` and are wrapped in `catch` so a single failure writes an empty file rather than aborting. Pass `reports = []` to disable.2!["timing_summary", "utilization"]�
�

synth_args�Extra flags for `synth_design` in the `synth_design` invocation path. Cannot contain `-top` (the rule emits that from the project's `module_top`). Not consulted on the `launch_runs` path; there, set `STEPS.SYNTH_DESIGN.ARGS.*` run properties from a `pre_hooks` script.2[]�
�
synth_invocation�How `synth_design` is invoked. `launch_runs` wraps it in a managed `synth_1` design-run (fresh Vivado process re-loads project state from disk). `synth_design` invokes it in the same process. Multi-config XCI consumer instantiations require `synth_design`: in `launch_runs` the re-loading process binds consumer wrappers to the IP's project-managed synth wrapper (which doesn't propagate consumer-side generics), so wrappers passing distinct generic combinations surface as `__parameterized<N>` black boxes.2"launch_runs"Q
O
synth_strategyThe synthesis strategy to use.2"Vivado Synthesis Defaults"b
`
synthesis_tcl_templateThe synthesis tcl template.2'//vivado/private:synthesis.tcl.template�vivado_synthesis_optimize:Run post-synthesis optimization on a synthesis checkpoint."�
�
vivado_synthesis_optimize:Run post-synthesis optimization on a synthesis checkpoint.*
nameA unique name for this target. D

checkpointSynthesis checkpoint. *
VivadoSynthCheckpointInfo=
opt_args+Extra flags passed through to `opt_design`.2[]�

post_hooks�`.tcl`/`.xdc`/`.sdc` files OR `tcl_binary` targets sourced after `opt_design`, before reports and checkpoint write. Sourced in list order.2[]�
	pre_hooks�`.tcl`/`.xdc`/`.sdc` files OR `tcl_binary` targets sourced on the opened synth checkpoint, before `opt_design`. Sourced in list order.2[]~
reportsGReport types to run after `opt_design`; see `vivado_synthesis.reports`.2(["drc", "timing_summary", "utilization"]v
synthesis_optimize_template'The synthesis optimization tcl template2,//vivado/private:synth_optimize.tcl.templateR
threadsBThreads to pass to vivado which defines the amount of parallelism.28"A
vivado_synthesis_optimize$@@rules_vivado//vivado:synthesis.bzl
�!�!,
*
nameA unique name for this target. F
D

checkpointSynthesis checkpoint. *
VivadoSynthCheckpointInfo?
=
opt_args+Extra flags passed through to `opt_design`.2[]�
�

post_hooks�`.tcl`/`.xdc`/`.sdc` files OR `tcl_binary` targets sourced after `opt_design`, before reports and checkpoint write. Sourced in list order.2[]�
�
	pre_hooks�`.tcl`/`.xdc`/`.sdc` files OR `tcl_binary` targets sourced on the opened synth checkpoint, before `opt_design`. Sourced in list order.2[]�
~
reportsGReport types to run after `opt_design`; see `vivado_synthesis.reports`.2(["drc", "timing_summary", "utilization"]x
v
synthesis_optimize_template'The synthesis optimization tcl template2,//vivado/private:synth_optimize.tcl.templateT
R
threadsBThreads to pass to vivado which defines the amount of parallelism.28�
//vivado:providers.bzlr�
%
rules_vivadovivadoproviders.bzl,
VivadoLogInfoVivadoLogInfo
4
VivadoProjectInfoVivadoProjectInfo
4
VivadoReportsInfoVivadoReportsInfo
D
VivadoSynthCheckpointInfoVivadoSynthCheckpointInfo

	�
//vivado/private:common.bzlr�
*
rules_vivadovivado/private
common.bzl.
TOOLCHAIN_TYPETOOLCHAIN_TYPE
:
get_vivado_toolchainget_vivado_toolchain
&

hook_attrs
hook_attrs
0
hook_invocationhook_invocation
*
reports_datareports_data
2
run_tcl_templaterun_tcl_template
"
tcl_argstcl_args
,
validate_argsvalidate_args


H# Synthesis-phase rules: vivado_synthesis and vivado_synthesis_optimize.�M
%
rules_vivadovivadotoolchain.bzl�2vivado_toolchain�Declares a Vivado toolchain.

Wrap it with `toolchain(...)` and register that via
`register_toolchains(...)` in MODULE.bazel; every `vivado_*` rule then
resolves the Xilinx environment automatically, with no per-target
`xilinx_env` to thread through. Registering one is required.

Multiple instances can be registered side-by-side and selected via
`target_settings` (flag-driven) or `exec_compatible_with`
(platform-driven) â the latter against the per-version `constraint_value`s
in `//vivado/constraints/version`.

Emits `VivadoToolchainInfo` on `ToolchainInfo.vivado_info`.
"�-
�
vivado_toolchain�Declares a Vivado toolchain.

Wrap it with `toolchain(...)` and register that via
`register_toolchains(...)` in MODULE.bazel; every `vivado_*` rule then
resolves the Xilinx environment automatically, with no per-target
`xilinx_env` to thread through. Registering one is required.

Multiple instances can be registered side-by-side and selected via
`target_settings` (flag-driven) or `exec_compatible_with`
(platform-driven) â the latter against the per-version `constraint_value`s
in `//vivado/constraints/version`.

Emits `VivadoToolchainInfo` on `ToolchainInfo.vivado_info`.
*
nameA unique name for this target. A
env4Environment variables passed to every Vivado action.
2{}�
requires_network�Sets the `requires-network` execution requirement on every `vivado_*` action. True (the default) is correct for a floating license server (`XILINXD_LICENSE_FILE=PORT@HOST`); set it False for license-free editions (Vivado ML Standard / WebPACK) or node-locked `.lic` files read from disk.2True�
	resources�`--local_resources` slots every Vivado action claims: resource name -> per-action count (as a string). Each entry becomes `execution_requirements["resources:<name>"] = <count>`, letting you serialize Vivado runs against a budget declared with `--local_resources=<name>=<total>` â license seats, container concurrency, whatever. `{"vivado_license": "1"}` is the common case. Every name used here needs a matching `--local_resources` registration or actions fail to schedule. Empty by default, so actions schedule freely.
2{}�
	sanitizer�Executable called from every Vivado action's EXIT trap to rewrite the sandbox-root prefix baked into declared outputs with the fixed marker `<execroot>/`. That makes outputs byte-identical across hosts, sandbox strategies, and RBE-worker sandbox UUIDs, so caches hit and shipped artifacts don't leak a worker's path.

Invoked as `<sanitizer> <sandbox_root> <marker> <path>...`, where each path is a declared output â a file, or a TreeArtifact directory to walk. Its exit status is ignored: sanitization must never fail an otherwise-successful Vivado run.

Built for the exec platform and staged with its runfiles, so any `*_binary` works; the default is a `sh_binary` doing a `sed` sweep that skips known binary formats. Override only for custom semantics.2//vivado/private:sanitize_pathsF
version5The version of Vivado associated with this toolchain.2""�
vivado�The Vivado executable. Typically a small bash shim that `exec`s the real `vivado` out of a known install path (e.g. baked into a container image), but any `*_binary` rule works too â runfiles travel along. Defaults to a stock shim that calls `vivado` from the exec platform's `PATH` as a migration aid; production toolchains should pin the install path with their own shim.2//vivado/private:vivado.sh�

xilinx_env�Optional escape hatch â a shell script sourced inside the action shell immediately before `vivado` runs, for shell-side env composition `env` cannot express. Prefer `env`. `vivado_xsim_test` also sources it at test time to put `xvlog` / `xelab` / `xsim` on `PATH`.2None"8
vivado_toolchain$@@rules_vivado//vivado:toolchain.bzl
==,
*
nameA unique name for this target. C
A
env4Environment variables passed to every Vivado action.
2{}�
�
requires_network�Sets the `requires-network` execution requirement on every `vivado_*` action. True (the default) is correct for a floating license server (`XILINXD_LICENSE_FILE=PORT@HOST`); set it False for license-free editions (Vivado ML Standard / WebPACK) or node-locked `.lic` files read from disk.2True�
�
	resources�`--local_resources` slots every Vivado action claims: resource name -> per-action count (as a string). Each entry becomes `execution_requirements["resources:<name>"] = <count>`, letting you serialize Vivado runs against a budget declared with `--local_resources=<name>=<total>` â license seats, container concurrency, whatever. `{"vivado_license": "1"}` is the common case. Every name used here needs a matching `--local_resources` registration or actions fail to schedule. Empty by default, so actions schedule freely.
2{}�
�
	sanitizer�Executable called from every Vivado action's EXIT trap to rewrite the sandbox-root prefix baked into declared outputs with the fixed marker `<execroot>/`. That makes outputs byte-identical across hosts, sandbox strategies, and RBE-worker sandbox UUIDs, so caches hit and shipped artifacts don't leak a worker's path.

Invoked as `<sanitizer> <sandbox_root> <marker> <path>...`, where each path is a declared output â a file, or a TreeArtifact directory to walk. Its exit status is ignored: sanitization must never fail an otherwise-successful Vivado run.

Built for the exec platform and staged with its runfiles, so any `*_binary` works; the default is a `sh_binary` doing a `sed` sweep that skips known binary formats. Override only for custom semantics.2//vivado/private:sanitize_pathsH
F
version5The version of Vivado associated with this toolchain.2""�
�
vivado�The Vivado executable. Typically a small bash shim that `exec`s the real `vivado` out of a known install path (e.g. baked into a container image), but any `*_binary` rule works too â runfiles travel along. Defaults to a stock shim that calls `vivado` from the exec platform's `PATH` as a migration aid; production toolchains should pin the install path with their own shim.2//vivado/private:vivado.sh�
�

xilinx_env�Optional escape hatch â a shell script sourced inside the action shell immediately before `vivado` runs, for shell-side env composition `env` cannot express. Prefer `env`. `vivado_xsim_test` also sources it at test time to put `xvlog` / `xelab` / `xsim` on `PATH`.2None�VivadoToolchainInfo�Toolchain info for the Xilinx Vivado tool. Only `vivado` is required; every other field has a default so toolchain rules outside this repo keep working when fields are added.2�
�
VivadoToolchainInfo�Toolchain info for the Xilinx Vivado tool. Only `vivado` is required; every other field has a default so toolchain rules outside this repo keep working when fields are added.Y
envRdict[str, str]: environment variables passed to every Vivado action. Default `{}`.~
requires_networkjbool: whether Vivado actions need network access (typically for a network license server). Default `True`.�
	resources�dict[str, str]: optional `--local_resources` slots every Vivado action claims (values are counts as strings). Each entry becomes an `execution_requirements["resources:<name>"] = <count>` on every action, so users can serialize Vivado runs against arbitrary budgets they've declared via `--local_resources=<name>=<total>` (e.g. license seats, container concurrency). Empty by default â actions schedule freely against `cpu` / `memory` only.�
	sanitizer�FilesToRunProvider or None: executable invoked from every Vivado action's EXIT trap to rewrite the sandbox-root prefix in declared outputs. `vivado_toolchain` wires in the bundled default; `None` (the constructor default) leaves outputs unsanitized, which still builds but caches less well across hosts.S
versionHstr: The version of Vivado associated with this toolchain. Default `""`.�
vivado�FilesToRunProvider: executable Bazel invokes for every Vivado action. Typically a shim that `exec`s the real `vivado` binary. Required.�

xilinx_env�File or None: optional shell script sourced immediately before `vivado` runs, for shell-side env composition `env` cannot express. Default `None`.";
VivadoToolchainInfo$@@rules_vivado//vivado:toolchain.bzl
;;[
Y
envRdict[str, str]: environment variables passed to every Vivado action. Default `{}`.�
~
requires_networkjbool: whether Vivado actions need network access (typically for a network license server). Default `True`.�
�
	resources�dict[str, str]: optional `--local_resources` slots every Vivado action claims (values are counts as strings). Each entry becomes an `execution_requirements["resources:<name>"] = <count>` on every action, so users can serialize Vivado runs against arbitrary budgets they've declared via `--local_resources=<name>=<total>` (e.g. license seats, container concurrency). Empty by default â actions schedule freely against `cpu` / `memory` only.�
�
	sanitizer�FilesToRunProvider or None: executable invoked from every Vivado action's EXIT trap to rewrite the sandbox-root prefix in declared outputs. `vivado_toolchain` wires in the bundled default; `None` (the constructor default) leaves outputs unsanitized, which still builds but caches less well across hosts.U
S
versionHstr: The version of Vivado associated with this toolchain. Default `""`.�
�
vivado�FilesToRunProvider: executable Bazel invokes for every Vivado action. Typically a shim that `exec`s the real `vivado` binary. Required.�
�

xilinx_env�File or None: optional shell script sourced immediately before `vivado` runs, for shell-side env composition `env` cannot express. Default `None`.J	TOOLCHAIN_TYPE@@//vivado:toolchain_typej@@//vivado:toolchain_type'# Toolchain for the Xilinx Vivado tool.�
'
rules_vivadovivadoxdc_library.bzl�xdc_library�Bundle a set of Xilinx constraint files with other constraint files they must run after.

The only relationship this rule expresses is between XDC files â
`create_clock` before `set_clock_groups`, primary constraints before
secondary. It is deliberately independent of HDL: no `hdl_deps` attr, no
HDL provider re-export.

The transitive XDC set is exposed in `deps`-first (topological) order,
so consumers `read_xdc` files in the sequence inter-XDC ordering
requires. Two ways to consume it:

- **Direct.** List the target in `vivado_project.data`; Bazel walks the
  ordered `DefaultInfo.files` depset into the project's
  `$PROJECT_DATA_FILES` foreach in dep-first order.
- **Aspect.** `XdcInfo` is a first-class marker, so an aspect walking
  any dep graph can filter on `XdcInfo in target` and collect the
  constraint contributions.

Provides `XdcInfo`.
"�
�	
xdc_library�Bundle a set of Xilinx constraint files with other constraint files they must run after.

The only relationship this rule expresses is between XDC files â
`create_clock` before `set_clock_groups`, primary constraints before
secondary. It is deliberately independent of HDL: no `hdl_deps` attr, no
HDL provider re-export.

The transitive XDC set is exposed in `deps`-first (topological) order,
so consumers `read_xdc` files in the sequence inter-XDC ordering
requires. Two ways to consume it:

- **Direct.** List the target in `vivado_project.data`; Bazel walks the
  ordered `DefaultInfo.files` depset into the project's
  `$PROJECT_DATA_FILES` foreach in dep-first order.
- **Aspect.** `XdcInfo` is a first-class marker, so an aspect walking
  any dep graph can filter on `XdcInfo in target` and collect the
  constraint contributions.

Provides `XdcInfo`.
*
nameA unique name for this target. �
depsgOther `xdc_library` targets whose constraint files must be `read_xdc`d BEFORE this target's own `srcs`.*	
XdcInfo2[]I
srcs;Xilinx constraint files (`.xdc` / `.sdc`) this target owns.2[]"5
xdc_library&@@rules_vivado//vivado:xdc_library.bzl
,
*
nameA unique name for this target. �
�
depsgOther `xdc_library` targets whose constraint files must be `read_xdc`d BEFORE this target's own `srcs`.*	
XdcInfo2[]K
I
srcs;Xilinx constraint files (`.xdc` / `.sdc`) this target owns.2[]s
//vivado:providers.bzlrW
%
rules_vivadovivadoproviders.bzl 
XdcInfoXdcInfo
.5
7# xdc_library rule.P

rules_vivadoversion.bzl	VERSION0.5.0j0.5.0rules_vivado version 