�
*
rules_vulkanvulkan/private
common.bzl�resolve_includes@Resolves include search paths from hdrs and includes attributes.*�
�
resolve_includesf
ctx[Rule context. The rule must define hdrs (label_list) and includes (string_list) attributes. (@Resolves include search paths from hdrs and includes attributes."$
"A list of include directory paths.2=
resolve_includes)@@rules_vulkan//vulkan/private:common.bzl
"Common utilities for shader rules.�,
(
rules_vulkanvulkan/privateglsl.bzl�(glsl_shader
Rule to compile GLSL shader.
"�(
�
glsl_shader
Rule to compile GLSL shader.
*
nameA unique name for this target. &
definesList of macro defines2[]�
hdrs�List of header file dependencies for shader compilation.

Each unique directory containing a header file automatically generates a `-I` flag, so the compiler can
find headers included by filename (e.g. `#include "common.h"`). These files are also added as action
inputs so that Bazel tracks them as dependencies and triggers rebuilds when they change.
2[]�	
includes�	List of include search directories, resolved relative to the package.

Each entry produces two `-I` flags:

- Source tree path (e.g. `foo/bar/common`) â for headers checked into the repository, when the include
  path you need differs from the directory that `hdrs` would auto-derive. For example, with a header at
  `pkg/common/nested/helper.h` and `#include "nested/helper.h"`, `hdrs` auto-derives
  `-I pkg/common/nested` but you actually need `-I pkg/common`. Adding `includes = ["common"]` provides
  that.
- Bin directory path (e.g. `bazel-out/.../bin/foo/bar/common`) â same as above, but for headers generated
  by other rules (e.g. `genrule`), which are placed under the output directory rather than the source
  tree.

Paths are constructed by joining the package path with the entry value (e.g. an entry `"common"` in
package `foo/bar` resolves to `foo/bar/common`).

Use this when the auto-derived paths from `hdrs` are not sufficient â for example, when the `#include`
directive uses a path prefix that differs from the header file's immediate directory
(e.g. `#include "subdir/header.h"` where the header is at `pkg/subdir/header.h` and `-I pkg` is needed).
2[]�
opts�Additional arguments to pass to the compiler.

Flags from `//vulkan/settings:glslc_opts` are appended after these, so the global build setting takes
precedence on conflicting flags.
2[].
src#Input GLSL shader source to compile =
stage0Shader stage (vertex, vert, fragment, frag, etc) �
std�
Version and profile for GLSL input files.

Possible values are concatenations of version and profile, e.g. `310es`, `450core`, etc.
2""�

target_env�
Set the target client environment, and the semantics of warnings and errors.

An optional suffix can specify the client version.
2""�

target_spv�
Set the SPIR-V version to be used for the generated SPIR-V module.

The default is the highest version of SPIR-V required to be supported for the target environment.
For example, default for `vulkan1.0` is `spv1.0`.
2"""6
glsl_shader'@@rules_vulkan//vulkan/private:glsl.bzl
NN,
*
nameA unique name for this target. (
&
definesList of macro defines2[]�
�
hdrs�List of header file dependencies for shader compilation.

Each unique directory containing a header file automatically generates a `-I` flag, so the compiler can
find headers included by filename (e.g. `#include "common.h"`). These files are also added as action
inputs so that Bazel tracks them as dependencies and triggers rebuilds when they change.
2[]�	
�	
includes�	List of include search directories, resolved relative to the package.

Each entry produces two `-I` flags:

- Source tree path (e.g. `foo/bar/common`) â for headers checked into the repository, when the include
  path you need differs from the directory that `hdrs` would auto-derive. For example, with a header at
  `pkg/common/nested/helper.h` and `#include "nested/helper.h"`, `hdrs` auto-derives
  `-I pkg/common/nested` but you actually need `-I pkg/common`. Adding `includes = ["common"]` provides
  that.
- Bin directory path (e.g. `bazel-out/.../bin/foo/bar/common`) â same as above, but for headers generated
  by other rules (e.g. `genrule`), which are placed under the output directory rather than the source
  tree.

Paths are constructed by joining the package path with the entry value (e.g. an entry `"common"` in
package `foo/bar` resolves to `foo/bar/common`).

Use this when the auto-derived paths from `hdrs` are not sufficient â for example, when the `#include`
directive uses a path prefix that differs from the header file's immediate directory
(e.g. `#include "subdir/header.h"` where the header is at `pkg/subdir/header.h` and `-I pkg` is needed).
2[]�
�
opts�Additional arguments to pass to the compiler.

Flags from `//vulkan/settings:glslc_opts` are appended after these, so the global build setting takes
precedence on conflicting flags.
2[]0
.
src#Input GLSL shader source to compile ?
=
stage0Shader stage (vertex, vert, fragment, frag, etc) �
�
std�
Version and profile for GLSL input files.

Possible values are concatenations of version and profile, e.g. `310es`, `450core`, etc.
2""�
�

target_env�
Set the target client environment, and the semantics of warnings and errors.

An optional suffix can specify the client version.
2""�
�

target_spv�
Set the SPIR-V version to be used for the generated SPIR-V module.

The default is the highest version of SPIR-V required to be supported for the target environment.
For example, default for `vulkan1.0` is `spv1.0`.
2""�
//rules:common_settings.bzlrn
*
bazel_skylibrulescommon_settings.bzl2
BuildSettingInfoBuildSettingInfo
3C
Ey
//vulkan:providers.bzlr]
%
rules_vulkanvulkanproviders.bzl&

ShaderInfo
ShaderInfo
.8
:�
//vulkan/private:common.bzlrn
*
rules_vulkanvulkan/private
common.bzl2
resolve_includesresolve_includes
3C
E!
A rule to compile GLSL shaders.
�1
(
rules_vulkanvulkan/privatehlsl.bzl�-hlsl_shader�
Rule to compile HLSL shaders using DirectXShaderCompiler.

The target outputs `<name>.cso` by default, or `<name>.spv` when `-spirv` is passed via `opts` or the global
`//vulkan/settings:dxc_opts` build setting. Pass other DXC flags the same way â e.g. `-HV 2021` for HLSL version,
`-enable-16bit-types`, etc.
"�*
�
hlsl_shader�
Rule to compile HLSL shaders using DirectXShaderCompiler.

The target outputs `<name>.cso` by default, or `<name>.spv` when `-spirv` is passed via `opts` or the global
`//vulkan/settings:dxc_opts` build setting. Pass other DXC flags the same way â e.g. `-HV 2021` for HLSL version,
`-enable-16bit-types`, etc.
*
nameA unique name for this target. Q
asmDOutput assembly code listing file to the specified path (-Fc <file>)2""R
def_root_sig<Read root signature from a #define (-rootsig-define <value>)2""&
definesList of macro defines2[]#
entryEntry point name2"main"D
hash6Output shader hash to the specified file (-Fsh <file>)2""�
hdrs�List of header file dependencies for shader compilation.

Each unique directory containing a header file automatically generates a `-I` flag, so the compiler can
find headers included by filename (e.g. `#include "common.h"`). These files are also added as action
inputs so that Bazel tracks them as dependencies and triggers rebuilds when they change.
2[]�	
includes�	List of include search directories, resolved relative to the package.

Each entry produces two `-I` flags:

- Source tree path (e.g. `foo/bar/common`) â for headers checked into the repository, when the include
  path you need differs from the directory that `hdrs` would auto-derive. For example, with a header at
  `pkg/common/nested/helper.h` and `#include "nested/helper.h"`, `hdrs` auto-derives
  `-I pkg/common/nested` but you actually need `-I pkg/common`. Adding `includes = ["common"]` provides
  that.
- Bin directory path (e.g. `bazel-out/.../bin/foo/bar/common`) â same as above, but for headers generated
  by other rules (e.g. `genrule`), which are placed under the output directory rather than the source
  tree.

Paths are constructed by joining the package path with the entry value (e.g. an entry `"common"` in
package `foo/bar` resolves to `foo/bar/common`).

Use this when the auto-derived paths from `hdrs` are not sufficient â for example, when the `#include`
directive uses a path prefix that differs from the header file's immediate directory
(e.g. `#include "subdir/header.h"` where the header is at `pkg/subdir/header.h` and `-I pkg` is needed).
2[]�
opts�Additional arguments to pass to the DXC compiler.

Pass `-spirv` here (or globally via `//vulkan/settings:dxc_opts`) to emit SPIR-V; the rule detects the
flag and selects the `.spv` output extension accordingly. Otherwise the rule emits `.cso` (DXIL).

Flags from `//vulkan/settings:dxc_opts` are appended after these, so the global build setting takes
precedence on conflicting flags.
2[]F
reflect5Output reflection to the specified file (-Fre <file>)2""(
srcInput HLSL shader source file 9
target+Target profile (e.g., cs_6_0, ps_6_0, etc.) "6
hlsl_shader'@@rules_vulkan//vulkan/private:hlsl.bzl
{{,
*
nameA unique name for this target. S
Q
asmDOutput assembly code listing file to the specified path (-Fc <file>)2""T
R
def_root_sig<Read root signature from a #define (-rootsig-define <value>)2""(
&
definesList of macro defines2[]%
#
entryEntry point name2"main"F
D
hash6Output shader hash to the specified file (-Fsh <file>)2""�
�
hdrs�List of header file dependencies for shader compilation.

Each unique directory containing a header file automatically generates a `-I` flag, so the compiler can
find headers included by filename (e.g. `#include "common.h"`). These files are also added as action
inputs so that Bazel tracks them as dependencies and triggers rebuilds when they change.
2[]�	
�	
includes�	List of include search directories, resolved relative to the package.

Each entry produces two `-I` flags:

- Source tree path (e.g. `foo/bar/common`) â for headers checked into the repository, when the include
  path you need differs from the directory that `hdrs` would auto-derive. For example, with a header at
  `pkg/common/nested/helper.h` and `#include "nested/helper.h"`, `hdrs` auto-derives
  `-I pkg/common/nested` but you actually need `-I pkg/common`. Adding `includes = ["common"]` provides
  that.
- Bin directory path (e.g. `bazel-out/.../bin/foo/bar/common`) â same as above, but for headers generated
  by other rules (e.g. `genrule`), which are placed under the output directory rather than the source
  tree.

Paths are constructed by joining the package path with the entry value (e.g. an entry `"common"` in
package `foo/bar` resolves to `foo/bar/common`).

Use this when the auto-derived paths from `hdrs` are not sufficient â for example, when the `#include`
directive uses a path prefix that differs from the header file's immediate directory
(e.g. `#include "subdir/header.h"` where the header is at `pkg/subdir/header.h` and `-I pkg` is needed).
2[]�
�
opts�Additional arguments to pass to the DXC compiler.

Pass `-spirv` here (or globally via `//vulkan/settings:dxc_opts`) to emit SPIR-V; the rule detects the
flag and selects the `.spv` output extension accordingly. Otherwise the rule emits `.cso` (DXIL).

Flags from `//vulkan/settings:dxc_opts` are appended after these, so the global build setting takes
precedence on conflicting flags.
2[]H
F
reflect5Output reflection to the specified file (-Fre <file>)2""*
(
srcInput HLSL shader source file ;
9
target+Target profile (e.g., cs_6_0, ps_6_0, etc.) �
//rules:common_settings.bzlrn
*
bazel_skylibrulescommon_settings.bzl2
BuildSettingInfoBuildSettingInfo
3C
Ey
//vulkan:providers.bzlr]
%
rules_vulkanvulkanproviders.bzl&

ShaderInfo
ShaderInfo
.8
:�
//vulkan/private:common.bzlrn
*
rules_vulkanvulkan/private
common.bzl2
resolve_includesresolve_includes
3C
EC
A rule to compile HLSL shaders using DirectXShaderCompiler (dxc).
�B
+
rules_vulkanvulkan/privateinstall.bzl�?install_sdk�
Downloads and installs the Vulkan SDK for the current platform (Windows, Linux, macOS).

These rely on command line installation described in "Getting started" docs on LunarG.
- https://vulkan.lunarg.com/doc/view/1.3.283.0/mac/getting_started.html
R�=
�
install_sdk�
Downloads and installs the Vulkan SDK for the current platform (Windows, Linux, macOS).

These rely on command line installation described in "Getting started" docs on LunarG.
- https://vulkan.lunarg.com/doc/view/1.3.283.0/mac/getting_started.html
.
name"A unique name for this repository. /

build_file2//vulkan/private:template.BUILD�
macos_components�
Optional Vulkan SDK components to install on macOS.

These are passed to the installer after `--confirm-command install`.

Known components: `com.lunarg.vulkan.usr`, `com.lunarg.vulkan.sdl2`, `com.lunarg.vulkan.glm`,
`com.lunarg.vulkan.volk`, `com.lunarg.vulkan.vma`, `com.lunarg.vulkan.ios`,
`com.lunarg.vulkan.kosmic`.
2[]�
repo_mapping�A dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.<p>For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).
 �
urls�
Custom URLs and SHA256 checksums for the Vulkan SDK.

This allows using a custom mirror for Vulkan SDKs instead of LunarG. When not specified, the SDK
is downloaded from the default LunarG mirrors using the bundled `versions.json`.

A separate download URL and SHA256 checksum is required for each platform. LunarG currently uses
the following platform keys:
- `windows` - Windows x86-64
- `warm` - Windows ARM64
- `mac` - macOS
- `linux` - Linux

Each entry must provide `url` and `sha` fields. On Windows platforms, `runtime_url` and
`runtime_sha` can be used to provide URLs for the Vulkan runtime package.

Example:
```bazel
custom_urls = {
    "linux": {
        "url": "https://sdk.lunarg.com/sdk/download/1.4.313.0/linux/vulkansdk-linux-x86_64-1.4.313.0.tar.xz",
        "sha": "4e957b66ade85eeaee95932aa7e3b45aea64db373c58a5eaefc8228cc71445c2",
    },
    "mac": {
        "url": "https://sdk.lunarg.com/sdk/download/1.4.313.0/mac/vulkansdk-macos-1.4.313.0.zip",
        "sha": "782a966ef4d5d68acaa933ff45215df2e34f286df8f6077270202f218110dc20",
    },
    "windows": {
        "url": "https://sdk.lunarg.com/sdk/download/1.4.313.0/windows/vulkansdk-windows-X64-1.4.313.0.exe",
        "sha": "b643ca8ab4aea5c47b9c4e021a0b33b3a13871bf1d8131e162a9e48c257c4694",
        "runtime_url": "https://sdk.lunarg.com/sdk/download/1.4.313.0/windows/VulkanRT-X64-1.4.313.0-Components.zip",
        "runtime_sha": "e8d37913185142270a2bc1b3e1f8f498a4edf47405fddda666f2f38b30ca944b",
    },
    "warm": {
        "url": "https://sdk.lunarg.com/sdk/download/1.4.313.0/warm/vulkansdk-windows-ARM64-1.4.313.0.exe",
        "sha": "b19a8683df982d302fec07c110962153f02a2e5cf1e5118ff72d8532aa5fc567",
        "runtime_url": "https://sdk.lunarg.com/sdk/download/1.4.313.0/warm/VulkanRT-ARM64-1.4.313.0-Components.zip",
        "runtime_sha": "6335a8d6b7ab85861025c2546f5f52384ff18a6d9346d350c2a0bf3b7524829a",
    },
}
```

2{}�
version�
Vulkan SDK version to download and install.

This expects a version in the format of `1.4.313.0` or `1.4.313`.
When 3 components are provided, `.0` will be appended automatically to make it 4 components.
 �
windows_components�
Optional Vulkan SDK components to install on Windows.

These are passed to the installer between `--confirm-command install` and `copy_only=1`.

Known components: `com.lunarg.vulkan.sdl2`, `com.lunarg.vulkan.glm`, `com.lunarg.vulkan.volk`,
`com.lunarg.vulkan.vma`, `com.lunarg.vulkan.debug`.
2[]�
windows_skip_runtime�
Do not download and install Vulkan runtime package (e.g. `vulkan-1.dll` dependency) on Windows.

When `True`, the downloader will not put `vulkan-1.dll` into the repository root directory.

This is useful if there is a system-wide Vulkan runtime already installed, otherwise this
might lead to link/runtime issues when building CC targets.
2False*9
install_sdk*@@rules_vulkan//vulkan/private:install.bzl
��0
.
name"A unique name for this repository. 1
/

build_file2//vulkan/private:template.BUILD�
�
macos_components�
Optional Vulkan SDK components to install on macOS.

These are passed to the installer after `--confirm-command install`.

Known components: `com.lunarg.vulkan.usr`, `com.lunarg.vulkan.sdl2`, `com.lunarg.vulkan.glm`,
`com.lunarg.vulkan.volk`, `com.lunarg.vulkan.vma`, `com.lunarg.vulkan.ios`,
`com.lunarg.vulkan.kosmic`.
2[]�
�
repo_mapping�A dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.<p>For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).
 �
�
urls�
Custom URLs and SHA256 checksums for the Vulkan SDK.

This allows using a custom mirror for Vulkan SDKs instead of LunarG. When not specified, the SDK
is downloaded from the default LunarG mirrors using the bundled `versions.json`.

A separate download URL and SHA256 checksum is required for each platform. LunarG currently uses
the following platform keys:
- `windows` - Windows x86-64
- `warm` - Windows ARM64
- `mac` - macOS
- `linux` - Linux

Each entry must provide `url` and `sha` fields. On Windows platforms, `runtime_url` and
`runtime_sha` can be used to provide URLs for the Vulkan runtime package.

Example:
```bazel
custom_urls = {
    "linux": {
        "url": "https://sdk.lunarg.com/sdk/download/1.4.313.0/linux/vulkansdk-linux-x86_64-1.4.313.0.tar.xz",
        "sha": "4e957b66ade85eeaee95932aa7e3b45aea64db373c58a5eaefc8228cc71445c2",
    },
    "mac": {
        "url": "https://sdk.lunarg.com/sdk/download/1.4.313.0/mac/vulkansdk-macos-1.4.313.0.zip",
        "sha": "782a966ef4d5d68acaa933ff45215df2e34f286df8f6077270202f218110dc20",
    },
    "windows": {
        "url": "https://sdk.lunarg.com/sdk/download/1.4.313.0/windows/vulkansdk-windows-X64-1.4.313.0.exe",
        "sha": "b643ca8ab4aea5c47b9c4e021a0b33b3a13871bf1d8131e162a9e48c257c4694",
        "runtime_url": "https://sdk.lunarg.com/sdk/download/1.4.313.0/windows/VulkanRT-X64-1.4.313.0-Components.zip",
        "runtime_sha": "e8d37913185142270a2bc1b3e1f8f498a4edf47405fddda666f2f38b30ca944b",
    },
    "warm": {
        "url": "https://sdk.lunarg.com/sdk/download/1.4.313.0/warm/vulkansdk-windows-ARM64-1.4.313.0.exe",
        "sha": "b19a8683df982d302fec07c110962153f02a2e5cf1e5118ff72d8532aa5fc567",
        "runtime_url": "https://sdk.lunarg.com/sdk/download/1.4.313.0/warm/VulkanRT-ARM64-1.4.313.0-Components.zip",
        "runtime_sha": "6335a8d6b7ab85861025c2546f5f52384ff18a6d9346d350c2a0bf3b7524829a",
    },
}
```

2{}�
�
version�
Vulkan SDK version to download and install.

This expects a version in the format of `1.4.313.0` or `1.4.313`.
When 3 components are provided, `.0` will be appended automatically to make it 4 components.
 �
�
windows_components�
Optional Vulkan SDK components to install on Windows.

These are passed to the installer between `--confirm-command install` and `copy_only=1`.

Known components: `com.lunarg.vulkan.sdl2`, `com.lunarg.vulkan.glm`, `com.lunarg.vulkan.volk`,
`com.lunarg.vulkan.vma`, `com.lunarg.vulkan.debug`.
2[]�
�
windows_skip_runtime�
Do not download and install Vulkan runtime package (e.g. `vulkan-1.dll` dependency) on Windows.

When `True`, the downloader will not put `vulkan-1.dll` into the repository root directory.

This is useful if there is a system-wide Vulkan runtime already installed, otherwise this
might lead to link/runtime issues when building CC targets.
2Falsey
//lib:repo_utils.bzlr_
'
aspect_bazel_liblibrepo_utils.bzl&

repo_utils
repo_utils
0:
<�
//vulkan/private:resolve.bzlr�
+
rules_vulkanvulkan/privateresolve.bzl&

find_exact
find_exact
4>*
normalize_osnormalize_os
BN4
normalize_versionnormalize_version
Rc
e
Vulkan SDK installer.
�
+
rules_vulkanvulkan/privateresolve.bzl�
find_exactfFind exact record in the VERSIONS table from the provided version and OS/arch retrieved from the `ctx`*�
�

find_exact
ctxRepository context. (2
version#exact version string to fetch info. (fFind exact record in the VERSIONS table from the provided version and OS/arch retrieved from the `ctx`"�
�A dictionary with URLs for each supported platform.
Note: LunarG may release patch releases for certain platforms, so some platform entries might be missing.28

find_exact*@@rules_vulkan//vulkan/private:resolve.bzl
CC�load_versions|Load versions from versions.json file.

This function reads and parses the versions.json file using the repository context.
*�
�
load_versionsC
ctx8Repository context (only available in repository rules). (|Load versions from versions.json file.

This function reads and parses the versions.json file using the repository context.
"F
DA dictionary of SDK versions with their download URLs and checksums.2;
load_versions*@@rules_vulkan//vulkan/private:resolve.bzl
�normalize_osDConvert repository context to LunarG platform name using repo_utils.*�
�
normalize_os
ctxRepository context. (DConvert repository context to LunarG platform name using repo_utils."
Platform name2:
normalize_os*@@rules_vulkan//vulkan/private:resolve.bzl
�normalize_version;Normalize SDK version string to ensure it has 4 components.*�
�
normalize_version@
version1Version string in the format 'X.Y.Z' or 'X.Y.Z.W' (;Normalize SDK version string to ensure it has 4 components."D
BVersion as 'X.Y.Z.0' if only three components, else returns as-is.2?
normalize_version*@@rules_vulkan//vulkan/private:resolve.bzl
55y
//lib:repo_utils.bzlr_
'
aspect_bazel_liblibrepo_utils.bzl&

repo_utils
repo_utils
0:
<L
Module to resolve download URL and checksum from the provided SDK version.
�+
0
rules_vulkanvulkan/privateshader_group.bzl�'shader_group�
`shader_group` is a rule to group multiple shaders together.

Similar to `filegroup`, but forwards providers to enable building shader libraries and databases. The motivation
for this rule is described in this [issue](https://github.com/bazelbuild/bazel/issues/8904).

The rule expects dependencies from shader compiler targets such as `hlsl_shader`, `glsl_shader`, `slang_shader`,
and `spirv_cross`. Shader groups can also depend on other shader groups, creating hierarchical structures. Each
`shader_group` accumulates ShaderInfo structures from all its dependencies and returns a ShaderGroupInfo provider
containing the collected shader information.

Common use cases include:
- Grouping related shaders together (e.g. vertex + fragment shader pair).
- Building large shader libraries or databases. See the `e2e/smoke` example for implementation details.

**Example:**

```starlark
load("@rules_vulkan//vulkan:defs.bzl", "hlsl_shader", "glsl_shader", "shader_group")

hlsl_shader(
    name = "vertex_shader",
    src = "vertex.hlsl",
    entry = "VSMain",
    target = "vs_6_0",
)

glsl_shader(
    name = "fragment_shader",
    src = "fragment.glsl",
    stage = "frag",
)

shader_group(
    name = "graphics_shaders",
    deps = [
        ":vertex_shader",
        ":fragment_shader",
    ],
    pkg_prefix = "shaders/",
)
```

**Rules_pkg Integration:**

The `shader_group` rule integrates seamlessly with `rules_pkg` for creating shader archives. When `pkg_prefix` is
specified, the rule provides `PackageFilesInfo` that can be consumed directly by `pkg_zip` and other packaging
rules.

The shader group acts as a replacement for `pkg_files`, automatically bundling all shader outputs (compiled
binaries, reflection data, assembly files, etc.) into the specified archive subdirectory. This eliminates the
need to manually specify each shader output file when creating packages.

```starlark
load("@rules_pkg//:pkg.bzl", "pkg_zip")

pkg_zip(
    name = "shader_database",
    srcs = [":graphics_shaders"],  # All shaders will be placed in shaders/ subdirectory
    out = "shaders.zip",
)
```
"�
�
shader_group�
`shader_group` is a rule to group multiple shaders together.

Similar to `filegroup`, but forwards providers to enable building shader libraries and databases. The motivation
for this rule is described in this [issue](https://github.com/bazelbuild/bazel/issues/8904).

The rule expects dependencies from shader compiler targets such as `hlsl_shader`, `glsl_shader`, `slang_shader`,
and `spirv_cross`. Shader groups can also depend on other shader groups, creating hierarchical structures. Each
`shader_group` accumulates ShaderInfo structures from all its dependencies and returns a ShaderGroupInfo provider
containing the collected shader information.

Common use cases include:
- Grouping related shaders together (e.g. vertex + fragment shader pair).
- Building large shader libraries or databases. See the `e2e/smoke` example for implementation details.

**Example:**

```starlark
load("@rules_vulkan//vulkan:defs.bzl", "hlsl_shader", "glsl_shader", "shader_group")

hlsl_shader(
    name = "vertex_shader",
    src = "vertex.hlsl",
    entry = "VSMain",
    target = "vs_6_0",
)

glsl_shader(
    name = "fragment_shader",
    src = "fragment.glsl",
    stage = "frag",
)

shader_group(
    name = "graphics_shaders",
    deps = [
        ":vertex_shader",
        ":fragment_shader",
    ],
    pkg_prefix = "shaders/",
)
```

**Rules_pkg Integration:**

The `shader_group` rule integrates seamlessly with `rules_pkg` for creating shader archives. When `pkg_prefix` is
specified, the rule provides `PackageFilesInfo` that can be consumed directly by `pkg_zip` and other packaging
rules.

The shader group acts as a replacement for `pkg_files`, automatically bundling all shader outputs (compiled
binaries, reflection data, assembly files, etc.) into the specified archive subdirectory. This eliminates the
need to manually specify each shader output file when creating packages.

```starlark
load("@rules_pkg//:pkg.bzl", "pkg_zip")

pkg_zip(
    name = "shader_database",
    srcs = [":graphics_shaders"],  # All shaders will be placed in shaders/ subdirectory
    out = "shaders.zip",
)
```
*
nameA unique name for this target. �
deps�
List of shader targets to group together.

Accepts individual shader targets (HLSL, GLSL, Slang, or spirv_cross) and other `shader_group` targets for
hierarchical grouping.
*

ShaderInfo*
ShaderGroupInfo2[]W

pkg_prefixCIf using with `rules_pkg`, sub-directory in the destination archive2"""?
shader_group/@@rules_vulkan//vulkan/private:shader_group.bzl
,,,
*
nameA unique name for this target. �
�
deps�
List of shader targets to group together.

Accepts individual shader targets (HLSL, GLSL, Slang, or spirv_cross) and other `shader_group` targets for
hierarchical grouping.
*

ShaderInfo*
ShaderGroupInfo2[]Y
W

pkg_prefixCIf using with `rules_pkg`, sub-directory in the destination archive2""a
//lib:paths.bzlrL

bazel_skyliblib	paths.bzl
pathspaths
',
.|
//pkg:providers.bzlrc

	rules_pkgpkgproviders.bzl2
PackageFilesInfoPackageFilesInfo
(8
:�
//vulkan:providers.bzlr�
%
rules_vulkanvulkanproviders.bzl0
ShaderGroupInfoShaderGroupInfo
.=&

ShaderInfo
ShaderInfo
AK
M
Common Vulkan rules.
�/
)
rules_vulkanvulkan/private	slang.bzl�+slang_shader 
Rule to compile Slang shaders.
"�+
�
slang_shader 
Rule to compile Slang shaders.
*
nameA unique name for this target. ,
definesInsert a preprocessor macro2[]U
depfileDSave the source file dependency list in a file (-depfile <name>.dep)2""
entryEntry point name2""�
hdrs�List of header file dependencies for shader compilation.

Each unique directory containing a header file automatically generates a `-I` flag, so the compiler can
find headers included by filename (e.g. `#include "common.h"`). These files are also added as action
inputs so that Bazel tracks them as dependencies and triggers rebuilds when they change.
2[]�	
includes�	List of include search directories, resolved relative to the package.

Each entry produces two `-I` flags:

- Source tree path (e.g. `foo/bar/common`) â for headers checked into the repository, when the include
  path you need differs from the directory that `hdrs` would auto-derive. For example, with a header at
  `pkg/common/nested/helper.h` and `#include "nested/helper.h"`, `hdrs` auto-derives
  `-I pkg/common/nested` but you actually need `-I pkg/common`. Adding `includes = ["common"]` provides
  that.
- Bin directory path (e.g. `bazel-out/.../bin/foo/bar/common`) â same as above, but for headers generated
  by other rules (e.g. `genrule`), which are placed under the output directory rather than the source
  tree.

Paths are constructed by joining the package path with the entry value (e.g. an entry `"common"` in
package `foo/bar` resolves to `foo/bar/common`).

Use this when the auto-derived paths from `hdrs` are not sufficient â for example, when the `#include`
directive uses a path prefix that differs from the header file's immediate directory
(e.g. `#include "subdir/header.h"` where the header is at `pkg/subdir/header.h` and `-I pkg` is needed).
2[]N
lang@Set source language for the shader (slang, hlsl, glsl, cpp, etc)2""�
opts�Additional arguments to pass to the compiler.

Flags from `//vulkan/settings:slangc_opts` are appended after these, so the global build setting takes
precedence on conflicting flags.
2[]P
outCSpecify a path where generated output should be written (-o <path>)2""S
profileBShader profile for code generation (sm_6_6, vs_6_6, glsl_460, etc)2"">
reflect-Emit reflection data in JSON format to a file2""$
srcsSlang input shader files M
stage>Stage of an entry point function (vertex, pixel, compute, etc)2""�
target�Format in which code should be generated (hlsl, dxil, dxil-asm, glsl, spirv, metal, metallib, etc).
This field is optional when compiling to a Slang IR module with `-emit-ir`. When omitted, the `target`
field in `ShaderInfo` will be `None`.2"""8
slang_shader(@@rules_vulkan//vulkan/private:slang.bzl
\\,
*
nameA unique name for this target. .
,
definesInsert a preprocessor macro2[]W
U
depfileDSave the source file dependency list in a file (-depfile <name>.dep)2""!

entryEntry point name2""�
�
hdrs�List of header file dependencies for shader compilation.

Each unique directory containing a header file automatically generates a `-I` flag, so the compiler can
find headers included by filename (e.g. `#include "common.h"`). These files are also added as action
inputs so that Bazel tracks them as dependencies and triggers rebuilds when they change.
2[]�	
�	
includes�	List of include search directories, resolved relative to the package.

Each entry produces two `-I` flags:

- Source tree path (e.g. `foo/bar/common`) â for headers checked into the repository, when the include
  path you need differs from the directory that `hdrs` would auto-derive. For example, with a header at
  `pkg/common/nested/helper.h` and `#include "nested/helper.h"`, `hdrs` auto-derives
  `-I pkg/common/nested` but you actually need `-I pkg/common`. Adding `includes = ["common"]` provides
  that.
- Bin directory path (e.g. `bazel-out/.../bin/foo/bar/common`) â same as above, but for headers generated
  by other rules (e.g. `genrule`), which are placed under the output directory rather than the source
  tree.

Paths are constructed by joining the package path with the entry value (e.g. an entry `"common"` in
package `foo/bar` resolves to `foo/bar/common`).

Use this when the auto-derived paths from `hdrs` are not sufficient â for example, when the `#include`
directive uses a path prefix that differs from the header file's immediate directory
(e.g. `#include "subdir/header.h"` where the header is at `pkg/subdir/header.h` and `-I pkg` is needed).
2[]P
N
lang@Set source language for the shader (slang, hlsl, glsl, cpp, etc)2""�
�
opts�Additional arguments to pass to the compiler.

Flags from `//vulkan/settings:slangc_opts` are appended after these, so the global build setting takes
precedence on conflicting flags.
2[]R
P
outCSpecify a path where generated output should be written (-o <path>)2""U
S
profileBShader profile for code generation (sm_6_6, vs_6_6, glsl_460, etc)2""@
>
reflect-Emit reflection data in JSON format to a file2""&
$
srcsSlang input shader files O
M
stage>Stage of an entry point function (vertex, pixel, compute, etc)2""�
�
target�Format in which code should be generated (hlsl, dxil, dxil-asm, glsl, spirv, metal, metallib, etc).
This field is optional when compiling to a Slang IR module with `-emit-ir`. When omitted, the `target`
field in `ShaderInfo` will be `None`.2""�
//rules:common_settings.bzlrn
*
bazel_skylibrulescommon_settings.bzl2
BuildSettingInfoBuildSettingInfo
3C
Ey
//vulkan:providers.bzlr]
%
rules_vulkanvulkanproviders.bzl&

ShaderInfo
ShaderInfo
.8
:�
//vulkan/private:common.bzlrn
*
rules_vulkanvulkan/private
common.bzl2
resolve_includesresolve_includes
3C
E"
A rule to compile Slang shaders.
�
/
rules_vulkanvulkan/privatespirv_cross.bzl�
spirv_cross�
spirv-cross build target.

This rule allows invoking spirv-cross binary bundled with Vulkan SDK.

Additionally, it integrates with compiler rules (hlsl_shader, glsl_shader, etc) and can inherit entry point
and stages from `CompilerInfo`.
"�
�
spirv_cross�
spirv-cross build target.

This rule allows invoking spirv-cross binary bundled with Vulkan SDK.

Additionally, it integrates with compiler rules (hlsl_shader, glsl_shader, etc) and can inherit entry point
and stages from `CompilerInfo`.
*
nameA unique name for this target. /
backendSelect backend for spirv-cross2"")
entryUse a specific entry point2""D
opts6Additional arguments to pass to the spirv-cross binary2[]O
outBOutput artifact name. If not specified, will default to <name>.out2""
src
Input file 3
stage$Forces use of a certain shader stage2"""=
spirv_cross.@@rules_vulkan//vulkan/private:spirv_cross.bzl
FF,
*
nameA unique name for this target. 1
/
backendSelect backend for spirv-cross2""+
)
entryUse a specific entry point2""F
D
opts6Additional arguments to pass to the spirv-cross binary2[]Q
O
outBOutput artifact name. If not specified, will default to <name>.out2""

src
Input file 5
3
stage$Forces use of a certain shader stage2""y
//vulkan:providers.bzlr]
%
rules_vulkanvulkanproviders.bzl&

ShaderInfo
ShaderInfo
.8
:
spirv-cross wrapper
��
 
rules_vulkanvulkandefs.bzl�(glsl_shader
Rule to compile GLSL shader.
"�(
�
glsl_shader
Rule to compile GLSL shader.
*
nameA unique name for this target. &
definesList of macro defines2[]�
hdrs�List of header file dependencies for shader compilation.

Each unique directory containing a header file automatically generates a `-I` flag, so the compiler can
find headers included by filename (e.g. `#include "common.h"`). These files are also added as action
inputs so that Bazel tracks them as dependencies and triggers rebuilds when they change.
2[]�	
includes�	List of include search directories, resolved relative to the package.

Each entry produces two `-I` flags:

- Source tree path (e.g. `foo/bar/common`) â for headers checked into the repository, when the include
  path you need differs from the directory that `hdrs` would auto-derive. For example, with a header at
  `pkg/common/nested/helper.h` and `#include "nested/helper.h"`, `hdrs` auto-derives
  `-I pkg/common/nested` but you actually need `-I pkg/common`. Adding `includes = ["common"]` provides
  that.
- Bin directory path (e.g. `bazel-out/.../bin/foo/bar/common`) â same as above, but for headers generated
  by other rules (e.g. `genrule`), which are placed under the output directory rather than the source
  tree.

Paths are constructed by joining the package path with the entry value (e.g. an entry `"common"` in
package `foo/bar` resolves to `foo/bar/common`).

Use this when the auto-derived paths from `hdrs` are not sufficient â for example, when the `#include`
directive uses a path prefix that differs from the header file's immediate directory
(e.g. `#include "subdir/header.h"` where the header is at `pkg/subdir/header.h` and `-I pkg` is needed).
2[]�
opts�Additional arguments to pass to the compiler.

Flags from `//vulkan/settings:glslc_opts` are appended after these, so the global build setting takes
precedence on conflicting flags.
2[].
src#Input GLSL shader source to compile =
stage0Shader stage (vertex, vert, fragment, frag, etc) �
std�
Version and profile for GLSL input files.

Possible values are concatenations of version and profile, e.g. `310es`, `450core`, etc.
2""�

target_env�
Set the target client environment, and the semantics of warnings and errors.

An optional suffix can specify the client version.
2""�

target_spv�
Set the SPIR-V version to be used for the generated SPIR-V module.

The default is the highest version of SPIR-V required to be supported for the target environment.
For example, default for `vulkan1.0` is `spv1.0`.
2""".
glsl_shader@@rules_vulkan//vulkan:defs.bzl
NN,
*
nameA unique name for this target. (
&
definesList of macro defines2[]�
�
hdrs�List of header file dependencies for shader compilation.

Each unique directory containing a header file automatically generates a `-I` flag, so the compiler can
find headers included by filename (e.g. `#include "common.h"`). These files are also added as action
inputs so that Bazel tracks them as dependencies and triggers rebuilds when they change.
2[]�	
�	
includes�	List of include search directories, resolved relative to the package.

Each entry produces two `-I` flags:

- Source tree path (e.g. `foo/bar/common`) â for headers checked into the repository, when the include
  path you need differs from the directory that `hdrs` would auto-derive. For example, with a header at
  `pkg/common/nested/helper.h` and `#include "nested/helper.h"`, `hdrs` auto-derives
  `-I pkg/common/nested` but you actually need `-I pkg/common`. Adding `includes = ["common"]` provides
  that.
- Bin directory path (e.g. `bazel-out/.../bin/foo/bar/common`) â same as above, but for headers generated
  by other rules (e.g. `genrule`), which are placed under the output directory rather than the source
  tree.

Paths are constructed by joining the package path with the entry value (e.g. an entry `"common"` in
package `foo/bar` resolves to `foo/bar/common`).

Use this when the auto-derived paths from `hdrs` are not sufficient â for example, when the `#include`
directive uses a path prefix that differs from the header file's immediate directory
(e.g. `#include "subdir/header.h"` where the header is at `pkg/subdir/header.h` and `-I pkg` is needed).
2[]�
�
opts�Additional arguments to pass to the compiler.

Flags from `//vulkan/settings:glslc_opts` are appended after these, so the global build setting takes
precedence on conflicting flags.
2[]0
.
src#Input GLSL shader source to compile ?
=
stage0Shader stage (vertex, vert, fragment, frag, etc) �
�
std�
Version and profile for GLSL input files.

Possible values are concatenations of version and profile, e.g. `310es`, `450core`, etc.
2""�
�

target_env�
Set the target client environment, and the semantics of warnings and errors.

An optional suffix can specify the client version.
2""�
�

target_spv�
Set the SPIR-V version to be used for the generated SPIR-V module.

The default is the highest version of SPIR-V required to be supported for the target environment.
For example, default for `vulkan1.0` is `spv1.0`.
2""�-hlsl_shader�
Rule to compile HLSL shaders using DirectXShaderCompiler.

The target outputs `<name>.cso` by default, or `<name>.spv` when `-spirv` is passed via `opts` or the global
`//vulkan/settings:dxc_opts` build setting. Pass other DXC flags the same way â e.g. `-HV 2021` for HLSL version,
`-enable-16bit-types`, etc.
"�*
�
hlsl_shader�
Rule to compile HLSL shaders using DirectXShaderCompiler.

The target outputs `<name>.cso` by default, or `<name>.spv` when `-spirv` is passed via `opts` or the global
`//vulkan/settings:dxc_opts` build setting. Pass other DXC flags the same way â e.g. `-HV 2021` for HLSL version,
`-enable-16bit-types`, etc.
*
nameA unique name for this target. Q
asmDOutput assembly code listing file to the specified path (-Fc <file>)2""R
def_root_sig<Read root signature from a #define (-rootsig-define <value>)2""&
definesList of macro defines2[]#
entryEntry point name2"main"D
hash6Output shader hash to the specified file (-Fsh <file>)2""�
hdrs�List of header file dependencies for shader compilation.

Each unique directory containing a header file automatically generates a `-I` flag, so the compiler can
find headers included by filename (e.g. `#include "common.h"`). These files are also added as action
inputs so that Bazel tracks them as dependencies and triggers rebuilds when they change.
2[]�	
includes�	List of include search directories, resolved relative to the package.

Each entry produces two `-I` flags:

- Source tree path (e.g. `foo/bar/common`) â for headers checked into the repository, when the include
  path you need differs from the directory that `hdrs` would auto-derive. For example, with a header at
  `pkg/common/nested/helper.h` and `#include "nested/helper.h"`, `hdrs` auto-derives
  `-I pkg/common/nested` but you actually need `-I pkg/common`. Adding `includes = ["common"]` provides
  that.
- Bin directory path (e.g. `bazel-out/.../bin/foo/bar/common`) â same as above, but for headers generated
  by other rules (e.g. `genrule`), which are placed under the output directory rather than the source
  tree.

Paths are constructed by joining the package path with the entry value (e.g. an entry `"common"` in
package `foo/bar` resolves to `foo/bar/common`).

Use this when the auto-derived paths from `hdrs` are not sufficient â for example, when the `#include`
directive uses a path prefix that differs from the header file's immediate directory
(e.g. `#include "subdir/header.h"` where the header is at `pkg/subdir/header.h` and `-I pkg` is needed).
2[]�
opts�Additional arguments to pass to the DXC compiler.

Pass `-spirv` here (or globally via `//vulkan/settings:dxc_opts`) to emit SPIR-V; the rule detects the
flag and selects the `.spv` output extension accordingly. Otherwise the rule emits `.cso` (DXIL).

Flags from `//vulkan/settings:dxc_opts` are appended after these, so the global build setting takes
precedence on conflicting flags.
2[]F
reflect5Output reflection to the specified file (-Fre <file>)2""(
srcInput HLSL shader source file 9
target+Target profile (e.g., cs_6_0, ps_6_0, etc.) ".
hlsl_shader@@rules_vulkan//vulkan:defs.bzl
{{,
*
nameA unique name for this target. S
Q
asmDOutput assembly code listing file to the specified path (-Fc <file>)2""T
R
def_root_sig<Read root signature from a #define (-rootsig-define <value>)2""(
&
definesList of macro defines2[]%
#
entryEntry point name2"main"F
D
hash6Output shader hash to the specified file (-Fsh <file>)2""�
�
hdrs�List of header file dependencies for shader compilation.

Each unique directory containing a header file automatically generates a `-I` flag, so the compiler can
find headers included by filename (e.g. `#include "common.h"`). These files are also added as action
inputs so that Bazel tracks them as dependencies and triggers rebuilds when they change.
2[]�	
�	
includes�	List of include search directories, resolved relative to the package.

Each entry produces two `-I` flags:

- Source tree path (e.g. `foo/bar/common`) â for headers checked into the repository, when the include
  path you need differs from the directory that `hdrs` would auto-derive. For example, with a header at
  `pkg/common/nested/helper.h` and `#include "nested/helper.h"`, `hdrs` auto-derives
  `-I pkg/common/nested` but you actually need `-I pkg/common`. Adding `includes = ["common"]` provides
  that.
- Bin directory path (e.g. `bazel-out/.../bin/foo/bar/common`) â same as above, but for headers generated
  by other rules (e.g. `genrule`), which are placed under the output directory rather than the source
  tree.

Paths are constructed by joining the package path with the entry value (e.g. an entry `"common"` in
package `foo/bar` resolves to `foo/bar/common`).

Use this when the auto-derived paths from `hdrs` are not sufficient â for example, when the `#include`
directive uses a path prefix that differs from the header file's immediate directory
(e.g. `#include "subdir/header.h"` where the header is at `pkg/subdir/header.h` and `-I pkg` is needed).
2[]�
�
opts�Additional arguments to pass to the DXC compiler.

Pass `-spirv` here (or globally via `//vulkan/settings:dxc_opts`) to emit SPIR-V; the rule detects the
flag and selects the `.spv` output extension accordingly. Otherwise the rule emits `.cso` (DXIL).

Flags from `//vulkan/settings:dxc_opts` are appended after these, so the global build setting takes
precedence on conflicting flags.
2[]H
F
reflect5Output reflection to the specified file (-Fre <file>)2""*
(
srcInput HLSL shader source file ;
9
target+Target profile (e.g., cs_6_0, ps_6_0, etc.) �'shader_group�
`shader_group` is a rule to group multiple shaders together.

Similar to `filegroup`, but forwards providers to enable building shader libraries and databases. The motivation
for this rule is described in this [issue](https://github.com/bazelbuild/bazel/issues/8904).

The rule expects dependencies from shader compiler targets such as `hlsl_shader`, `glsl_shader`, `slang_shader`,
and `spirv_cross`. Shader groups can also depend on other shader groups, creating hierarchical structures. Each
`shader_group` accumulates ShaderInfo structures from all its dependencies and returns a ShaderGroupInfo provider
containing the collected shader information.

Common use cases include:
- Grouping related shaders together (e.g. vertex + fragment shader pair).
- Building large shader libraries or databases. See the `e2e/smoke` example for implementation details.

**Example:**

```starlark
load("@rules_vulkan//vulkan:defs.bzl", "hlsl_shader", "glsl_shader", "shader_group")

hlsl_shader(
    name = "vertex_shader",
    src = "vertex.hlsl",
    entry = "VSMain",
    target = "vs_6_0",
)

glsl_shader(
    name = "fragment_shader",
    src = "fragment.glsl",
    stage = "frag",
)

shader_group(
    name = "graphics_shaders",
    deps = [
        ":vertex_shader",
        ":fragment_shader",
    ],
    pkg_prefix = "shaders/",
)
```

**Rules_pkg Integration:**

The `shader_group` rule integrates seamlessly with `rules_pkg` for creating shader archives. When `pkg_prefix` is
specified, the rule provides `PackageFilesInfo` that can be consumed directly by `pkg_zip` and other packaging
rules.

The shader group acts as a replacement for `pkg_files`, automatically bundling all shader outputs (compiled
binaries, reflection data, assembly files, etc.) into the specified archive subdirectory. This eliminates the
need to manually specify each shader output file when creating packages.

```starlark
load("@rules_pkg//:pkg.bzl", "pkg_zip")

pkg_zip(
    name = "shader_database",
    srcs = [":graphics_shaders"],  # All shaders will be placed in shaders/ subdirectory
    out = "shaders.zip",
)
```
"�
�
shader_group�
`shader_group` is a rule to group multiple shaders together.

Similar to `filegroup`, but forwards providers to enable building shader libraries and databases. The motivation
for this rule is described in this [issue](https://github.com/bazelbuild/bazel/issues/8904).

The rule expects dependencies from shader compiler targets such as `hlsl_shader`, `glsl_shader`, `slang_shader`,
and `spirv_cross`. Shader groups can also depend on other shader groups, creating hierarchical structures. Each
`shader_group` accumulates ShaderInfo structures from all its dependencies and returns a ShaderGroupInfo provider
containing the collected shader information.

Common use cases include:
- Grouping related shaders together (e.g. vertex + fragment shader pair).
- Building large shader libraries or databases. See the `e2e/smoke` example for implementation details.

**Example:**

```starlark
load("@rules_vulkan//vulkan:defs.bzl", "hlsl_shader", "glsl_shader", "shader_group")

hlsl_shader(
    name = "vertex_shader",
    src = "vertex.hlsl",
    entry = "VSMain",
    target = "vs_6_0",
)

glsl_shader(
    name = "fragment_shader",
    src = "fragment.glsl",
    stage = "frag",
)

shader_group(
    name = "graphics_shaders",
    deps = [
        ":vertex_shader",
        ":fragment_shader",
    ],
    pkg_prefix = "shaders/",
)
```

**Rules_pkg Integration:**

The `shader_group` rule integrates seamlessly with `rules_pkg` for creating shader archives. When `pkg_prefix` is
specified, the rule provides `PackageFilesInfo` that can be consumed directly by `pkg_zip` and other packaging
rules.

The shader group acts as a replacement for `pkg_files`, automatically bundling all shader outputs (compiled
binaries, reflection data, assembly files, etc.) into the specified archive subdirectory. This eliminates the
need to manually specify each shader output file when creating packages.

```starlark
load("@rules_pkg//:pkg.bzl", "pkg_zip")

pkg_zip(
    name = "shader_database",
    srcs = [":graphics_shaders"],  # All shaders will be placed in shaders/ subdirectory
    out = "shaders.zip",
)
```
*
nameA unique name for this target. �
deps�
List of shader targets to group together.

Accepts individual shader targets (HLSL, GLSL, Slang, or spirv_cross) and other `shader_group` targets for
hierarchical grouping.
*

ShaderInfo*
ShaderGroupInfo2[]W

pkg_prefixCIf using with `rules_pkg`, sub-directory in the destination archive2"""/
shader_group@@rules_vulkan//vulkan:defs.bzl
,,,
*
nameA unique name for this target. �
�
deps�
List of shader targets to group together.

Accepts individual shader targets (HLSL, GLSL, Slang, or spirv_cross) and other `shader_group` targets for
hierarchical grouping.
*

ShaderInfo*
ShaderGroupInfo2[]Y
W

pkg_prefixCIf using with `rules_pkg`, sub-directory in the destination archive2""�+slang_shader 
Rule to compile Slang shaders.
"�*
�
slang_shader 
Rule to compile Slang shaders.
*
nameA unique name for this target. ,
definesInsert a preprocessor macro2[]U
depfileDSave the source file dependency list in a file (-depfile <name>.dep)2""
entryEntry point name2""�
hdrs�List of header file dependencies for shader compilation.

Each unique directory containing a header file automatically generates a `-I` flag, so the compiler can
find headers included by filename (e.g. `#include "common.h"`). These files are also added as action
inputs so that Bazel tracks them as dependencies and triggers rebuilds when they change.
2[]�	
includes�	List of include search directories, resolved relative to the package.

Each entry produces two `-I` flags:

- Source tree path (e.g. `foo/bar/common`) â for headers checked into the repository, when the include
  path you need differs from the directory that `hdrs` would auto-derive. For example, with a header at
  `pkg/common/nested/helper.h` and `#include "nested/helper.h"`, `hdrs` auto-derives
  `-I pkg/common/nested` but you actually need `-I pkg/common`. Adding `includes = ["common"]` provides
  that.
- Bin directory path (e.g. `bazel-out/.../bin/foo/bar/common`) â same as above, but for headers generated
  by other rules (e.g. `genrule`), which are placed under the output directory rather than the source
  tree.

Paths are constructed by joining the package path with the entry value (e.g. an entry `"common"` in
package `foo/bar` resolves to `foo/bar/common`).

Use this when the auto-derived paths from `hdrs` are not sufficient â for example, when the `#include`
directive uses a path prefix that differs from the header file's immediate directory
(e.g. `#include "subdir/header.h"` where the header is at `pkg/subdir/header.h` and `-I pkg` is needed).
2[]N
lang@Set source language for the shader (slang, hlsl, glsl, cpp, etc)2""�
opts�Additional arguments to pass to the compiler.

Flags from `//vulkan/settings:slangc_opts` are appended after these, so the global build setting takes
precedence on conflicting flags.
2[]P
outCSpecify a path where generated output should be written (-o <path>)2""S
profileBShader profile for code generation (sm_6_6, vs_6_6, glsl_460, etc)2"">
reflect-Emit reflection data in JSON format to a file2""$
srcsSlang input shader files M
stage>Stage of an entry point function (vertex, pixel, compute, etc)2""�
target�Format in which code should be generated (hlsl, dxil, dxil-asm, glsl, spirv, metal, metallib, etc).
This field is optional when compiling to a Slang IR module with `-emit-ir`. When omitted, the `target`
field in `ShaderInfo` will be `None`.2"""/
slang_shader@@rules_vulkan//vulkan:defs.bzl
\\,
*
nameA unique name for this target. .
,
definesInsert a preprocessor macro2[]W
U
depfileDSave the source file dependency list in a file (-depfile <name>.dep)2""!

entryEntry point name2""�
�
hdrs�List of header file dependencies for shader compilation.

Each unique directory containing a header file automatically generates a `-I` flag, so the compiler can
find headers included by filename (e.g. `#include "common.h"`). These files are also added as action
inputs so that Bazel tracks them as dependencies and triggers rebuilds when they change.
2[]�	
�	
includes�	List of include search directories, resolved relative to the package.

Each entry produces two `-I` flags:

- Source tree path (e.g. `foo/bar/common`) â for headers checked into the repository, when the include
  path you need differs from the directory that `hdrs` would auto-derive. For example, with a header at
  `pkg/common/nested/helper.h` and `#include "nested/helper.h"`, `hdrs` auto-derives
  `-I pkg/common/nested` but you actually need `-I pkg/common`. Adding `includes = ["common"]` provides
  that.
- Bin directory path (e.g. `bazel-out/.../bin/foo/bar/common`) â same as above, but for headers generated
  by other rules (e.g. `genrule`), which are placed under the output directory rather than the source
  tree.

Paths are constructed by joining the package path with the entry value (e.g. an entry `"common"` in
package `foo/bar` resolves to `foo/bar/common`).

Use this when the auto-derived paths from `hdrs` are not sufficient â for example, when the `#include`
directive uses a path prefix that differs from the header file's immediate directory
(e.g. `#include "subdir/header.h"` where the header is at `pkg/subdir/header.h` and `-I pkg` is needed).
2[]P
N
lang@Set source language for the shader (slang, hlsl, glsl, cpp, etc)2""�
�
opts�Additional arguments to pass to the compiler.

Flags from `//vulkan/settings:slangc_opts` are appended after these, so the global build setting takes
precedence on conflicting flags.
2[]R
P
outCSpecify a path where generated output should be written (-o <path>)2""U
S
profileBShader profile for code generation (sm_6_6, vs_6_6, glsl_460, etc)2""@
>
reflect-Emit reflection data in JSON format to a file2""&
$
srcsSlang input shader files O
M
stage>Stage of an entry point function (vertex, pixel, compute, etc)2""�
�
target�Format in which code should be generated (hlsl, dxil, dxil-asm, glsl, spirv, metal, metallib, etc).
This field is optional when compiling to a Slang IR module with `-emit-ir`. When omitted, the `target`
field in `ShaderInfo` will be `None`.2""�
spirv_cross�
spirv-cross build target.

This rule allows invoking spirv-cross binary bundled with Vulkan SDK.

Additionally, it integrates with compiler rules (hlsl_shader, glsl_shader, etc) and can inherit entry point
and stages from `CompilerInfo`.
"�
�
spirv_cross�
spirv-cross build target.

This rule allows invoking spirv-cross binary bundled with Vulkan SDK.

Additionally, it integrates with compiler rules (hlsl_shader, glsl_shader, etc) and can inherit entry point
and stages from `CompilerInfo`.
*
nameA unique name for this target. /
backendSelect backend for spirv-cross2"")
entryUse a specific entry point2""D
opts6Additional arguments to pass to the spirv-cross binary2[]O
outBOutput artifact name. If not specified, will default to <name>.out2""
src
Input file 3
stage$Forces use of a certain shader stage2""".
spirv_cross@@rules_vulkan//vulkan:defs.bzl
FF,
*
nameA unique name for this target. 1
/
backendSelect backend for spirv-cross2""+
)
entryUse a specific entry point2""F
D
opts6Additional arguments to pass to the spirv-cross binary2[]Q
O
outBOutput artifact name. If not specified, will default to <name>.out2""

src
Input file 5
3
stage$Forces use of a certain shader stage2""�vulkan_toolchain"�
�
vulkan_toolchain*
nameA unique name for this target. 
dxcPath to dxc 7
env*
Environment to be passed to executables.

2{}
glslcPath to glslc 
slangcPath to slangc &
spirv_crossPath to spirv_cross "3
vulkan_toolchain@@rules_vulkan//vulkan:defs.bzl
,
*
nameA unique name for this target. 

dxcPath to dxc 9
7
env*
Environment to be passed to executables.

2{}

glslcPath to glslc 

slangcPath to slangc (
&
spirv_crossPath to spirv_cross �ShaderGroupInfo
A collection of shader infos.
2�
�
ShaderGroupInfo
A collection of shader infos.
%
listList of ShaderInfo structures"2
ShaderGroupInfo@@rules_vulkan//vulkan:defs.bzl
'
%
listList of ShaderInfo structures�

ShaderInfo
Shader metadata returned by the shader targets during compilation.

This is useful for building all kind of shader databases.
2�	
�

ShaderInfo
Shader metadata returned by the shader targets during compilation.

This is useful for building all kind of shader databases.
D
binary:Binary output file containing the compiled shader bytecode>
assembly2Assembly output file (if generated, HLSL-specific)3

reflection%Reflection output file (if generated)6
hash.Hash output file (if generated, HLSL-specific)@
depfile5Dependency output file (if generated, Slang-specific))
entry Shader entry point function name
stageShader stage9
defines.List of shader defines used during compilationB
target8Compilation target (note: this depends on compiler used)"-

ShaderInfo@@rules_vulkan//vulkan:defs.bzl
F
D
binary:Binary output file containing the compiled shader bytecode@
>
assembly2Assembly output file (if generated, HLSL-specific)5
3

reflection%Reflection output file (if generated)8
6
hash.Hash output file (if generated, HLSL-specific)B
@
depfile5Dependency output file (if generated, Slang-specific)+
)
entry Shader entry point function name

stageShader stage;
9
defines.List of shader defines used during compilationD
B
target8Compilation target (note: this depends on compiler used)�?download_sdk�
Downloads and installs the Vulkan SDK for the current platform (Windows, Linux, macOS).

These rely on command line installation described in "Getting started" docs on LunarG.
- https://vulkan.lunarg.com/doc/view/1.3.283.0/mac/getting_started.html
R�=
�
download_sdk�
Downloads and installs the Vulkan SDK for the current platform (Windows, Linux, macOS).

These rely on command line installation described in "Getting started" docs on LunarG.
- https://vulkan.lunarg.com/doc/view/1.3.283.0/mac/getting_started.html
.
name"A unique name for this repository. /

build_file2//vulkan/private:template.BUILD�
macos_components�
Optional Vulkan SDK components to install on macOS.

These are passed to the installer after `--confirm-command install`.

Known components: `com.lunarg.vulkan.usr`, `com.lunarg.vulkan.sdl2`, `com.lunarg.vulkan.glm`,
`com.lunarg.vulkan.volk`, `com.lunarg.vulkan.vma`, `com.lunarg.vulkan.ios`,
`com.lunarg.vulkan.kosmic`.
2[]�
repo_mapping�A dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.<p>For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).
 �
urls�
Custom URLs and SHA256 checksums for the Vulkan SDK.

This allows using a custom mirror for Vulkan SDKs instead of LunarG. When not specified, the SDK
is downloaded from the default LunarG mirrors using the bundled `versions.json`.

A separate download URL and SHA256 checksum is required for each platform. LunarG currently uses
the following platform keys:
- `windows` - Windows x86-64
- `warm` - Windows ARM64
- `mac` - macOS
- `linux` - Linux

Each entry must provide `url` and `sha` fields. On Windows platforms, `runtime_url` and
`runtime_sha` can be used to provide URLs for the Vulkan runtime package.

Example:
```bazel
custom_urls = {
    "linux": {
        "url": "https://sdk.lunarg.com/sdk/download/1.4.313.0/linux/vulkansdk-linux-x86_64-1.4.313.0.tar.xz",
        "sha": "4e957b66ade85eeaee95932aa7e3b45aea64db373c58a5eaefc8228cc71445c2",
    },
    "mac": {
        "url": "https://sdk.lunarg.com/sdk/download/1.4.313.0/mac/vulkansdk-macos-1.4.313.0.zip",
        "sha": "782a966ef4d5d68acaa933ff45215df2e34f286df8f6077270202f218110dc20",
    },
    "windows": {
        "url": "https://sdk.lunarg.com/sdk/download/1.4.313.0/windows/vulkansdk-windows-X64-1.4.313.0.exe",
        "sha": "b643ca8ab4aea5c47b9c4e021a0b33b3a13871bf1d8131e162a9e48c257c4694",
        "runtime_url": "https://sdk.lunarg.com/sdk/download/1.4.313.0/windows/VulkanRT-X64-1.4.313.0-Components.zip",
        "runtime_sha": "e8d37913185142270a2bc1b3e1f8f498a4edf47405fddda666f2f38b30ca944b",
    },
    "warm": {
        "url": "https://sdk.lunarg.com/sdk/download/1.4.313.0/warm/vulkansdk-windows-ARM64-1.4.313.0.exe",
        "sha": "b19a8683df982d302fec07c110962153f02a2e5cf1e5118ff72d8532aa5fc567",
        "runtime_url": "https://sdk.lunarg.com/sdk/download/1.4.313.0/warm/VulkanRT-ARM64-1.4.313.0-Components.zip",
        "runtime_sha": "6335a8d6b7ab85861025c2546f5f52384ff18a6d9346d350c2a0bf3b7524829a",
    },
}
```

2{}�
version�
Vulkan SDK version to download and install.

This expects a version in the format of `1.4.313.0` or `1.4.313`.
When 3 components are provided, `.0` will be appended automatically to make it 4 components.
 �
windows_components�
Optional Vulkan SDK components to install on Windows.

These are passed to the installer between `--confirm-command install` and `copy_only=1`.

Known components: `com.lunarg.vulkan.sdl2`, `com.lunarg.vulkan.glm`, `com.lunarg.vulkan.volk`,
`com.lunarg.vulkan.vma`, `com.lunarg.vulkan.debug`.
2[]�
windows_skip_runtime�
Do not download and install Vulkan runtime package (e.g. `vulkan-1.dll` dependency) on Windows.

When `True`, the downloader will not put `vulkan-1.dll` into the repository root directory.

This is useful if there is a system-wide Vulkan runtime already installed, otherwise this
might lead to link/runtime issues when building CC targets.
2False*/
download_sdk@@rules_vulkan//vulkan:defs.bzl
��0
.
name"A unique name for this repository. 1
/

build_file2//vulkan/private:template.BUILD�
�
macos_components�
Optional Vulkan SDK components to install on macOS.

These are passed to the installer after `--confirm-command install`.

Known components: `com.lunarg.vulkan.usr`, `com.lunarg.vulkan.sdl2`, `com.lunarg.vulkan.glm`,
`com.lunarg.vulkan.volk`, `com.lunarg.vulkan.vma`, `com.lunarg.vulkan.ios`,
`com.lunarg.vulkan.kosmic`.
2[]�
�
repo_mapping�A dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.<p>For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).
 �
�
urls�
Custom URLs and SHA256 checksums for the Vulkan SDK.

This allows using a custom mirror for Vulkan SDKs instead of LunarG. When not specified, the SDK
is downloaded from the default LunarG mirrors using the bundled `versions.json`.

A separate download URL and SHA256 checksum is required for each platform. LunarG currently uses
the following platform keys:
- `windows` - Windows x86-64
- `warm` - Windows ARM64
- `mac` - macOS
- `linux` - Linux

Each entry must provide `url` and `sha` fields. On Windows platforms, `runtime_url` and
`runtime_sha` can be used to provide URLs for the Vulkan runtime package.

Example:
```bazel
custom_urls = {
    "linux": {
        "url": "https://sdk.lunarg.com/sdk/download/1.4.313.0/linux/vulkansdk-linux-x86_64-1.4.313.0.tar.xz",
        "sha": "4e957b66ade85eeaee95932aa7e3b45aea64db373c58a5eaefc8228cc71445c2",
    },
    "mac": {
        "url": "https://sdk.lunarg.com/sdk/download/1.4.313.0/mac/vulkansdk-macos-1.4.313.0.zip",
        "sha": "782a966ef4d5d68acaa933ff45215df2e34f286df8f6077270202f218110dc20",
    },
    "windows": {
        "url": "https://sdk.lunarg.com/sdk/download/1.4.313.0/windows/vulkansdk-windows-X64-1.4.313.0.exe",
        "sha": "b643ca8ab4aea5c47b9c4e021a0b33b3a13871bf1d8131e162a9e48c257c4694",
        "runtime_url": "https://sdk.lunarg.com/sdk/download/1.4.313.0/windows/VulkanRT-X64-1.4.313.0-Components.zip",
        "runtime_sha": "e8d37913185142270a2bc1b3e1f8f498a4edf47405fddda666f2f38b30ca944b",
    },
    "warm": {
        "url": "https://sdk.lunarg.com/sdk/download/1.4.313.0/warm/vulkansdk-windows-ARM64-1.4.313.0.exe",
        "sha": "b19a8683df982d302fec07c110962153f02a2e5cf1e5118ff72d8532aa5fc567",
        "runtime_url": "https://sdk.lunarg.com/sdk/download/1.4.313.0/warm/VulkanRT-ARM64-1.4.313.0-Components.zip",
        "runtime_sha": "6335a8d6b7ab85861025c2546f5f52384ff18a6d9346d350c2a0bf3b7524829a",
    },
}
```

2{}�
�
version�
Vulkan SDK version to download and install.

This expects a version in the format of `1.4.313.0` or `1.4.313`.
When 3 components are provided, `.0` will be appended automatically to make it 4 components.
 �
�
windows_components�
Optional Vulkan SDK components to install on Windows.

These are passed to the installer between `--confirm-command install` and `copy_only=1`.

Known components: `com.lunarg.vulkan.sdl2`, `com.lunarg.vulkan.glm`, `com.lunarg.vulkan.volk`,
`com.lunarg.vulkan.vma`, `com.lunarg.vulkan.debug`.
2[]�
�
windows_skip_runtime�
Do not download and install Vulkan runtime package (e.g. `vulkan-1.dll` dependency) on Windows.

When `True`, the downloader will not put `vulkan-1.dll` into the repository root directory.

This is useful if there is a system-wide Vulkan runtime already installed, otherwise this
might lead to link/runtime issues when building CC targets.
2False�?install_sdk�
Downloads and installs the Vulkan SDK for the current platform (Windows, Linux, macOS).

These rely on command line installation described in "Getting started" docs on LunarG.
- https://vulkan.lunarg.com/doc/view/1.3.283.0/mac/getting_started.html
R�=
�
install_sdk�
Downloads and installs the Vulkan SDK for the current platform (Windows, Linux, macOS).

These rely on command line installation described in "Getting started" docs on LunarG.
- https://vulkan.lunarg.com/doc/view/1.3.283.0/mac/getting_started.html
.
name"A unique name for this repository. /

build_file2//vulkan/private:template.BUILD�
macos_components�
Optional Vulkan SDK components to install on macOS.

These are passed to the installer after `--confirm-command install`.

Known components: `com.lunarg.vulkan.usr`, `com.lunarg.vulkan.sdl2`, `com.lunarg.vulkan.glm`,
`com.lunarg.vulkan.volk`, `com.lunarg.vulkan.vma`, `com.lunarg.vulkan.ios`,
`com.lunarg.vulkan.kosmic`.
2[]�
repo_mapping�A dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.<p>For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).
 �
urls�
Custom URLs and SHA256 checksums for the Vulkan SDK.

This allows using a custom mirror for Vulkan SDKs instead of LunarG. When not specified, the SDK
is downloaded from the default LunarG mirrors using the bundled `versions.json`.

A separate download URL and SHA256 checksum is required for each platform. LunarG currently uses
the following platform keys:
- `windows` - Windows x86-64
- `warm` - Windows ARM64
- `mac` - macOS
- `linux` - Linux

Each entry must provide `url` and `sha` fields. On Windows platforms, `runtime_url` and
`runtime_sha` can be used to provide URLs for the Vulkan runtime package.

Example:
```bazel
custom_urls = {
    "linux": {
        "url": "https://sdk.lunarg.com/sdk/download/1.4.313.0/linux/vulkansdk-linux-x86_64-1.4.313.0.tar.xz",
        "sha": "4e957b66ade85eeaee95932aa7e3b45aea64db373c58a5eaefc8228cc71445c2",
    },
    "mac": {
        "url": "https://sdk.lunarg.com/sdk/download/1.4.313.0/mac/vulkansdk-macos-1.4.313.0.zip",
        "sha": "782a966ef4d5d68acaa933ff45215df2e34f286df8f6077270202f218110dc20",
    },
    "windows": {
        "url": "https://sdk.lunarg.com/sdk/download/1.4.313.0/windows/vulkansdk-windows-X64-1.4.313.0.exe",
        "sha": "b643ca8ab4aea5c47b9c4e021a0b33b3a13871bf1d8131e162a9e48c257c4694",
        "runtime_url": "https://sdk.lunarg.com/sdk/download/1.4.313.0/windows/VulkanRT-X64-1.4.313.0-Components.zip",
        "runtime_sha": "e8d37913185142270a2bc1b3e1f8f498a4edf47405fddda666f2f38b30ca944b",
    },
    "warm": {
        "url": "https://sdk.lunarg.com/sdk/download/1.4.313.0/warm/vulkansdk-windows-ARM64-1.4.313.0.exe",
        "sha": "b19a8683df982d302fec07c110962153f02a2e5cf1e5118ff72d8532aa5fc567",
        "runtime_url": "https://sdk.lunarg.com/sdk/download/1.4.313.0/warm/VulkanRT-ARM64-1.4.313.0-Components.zip",
        "runtime_sha": "6335a8d6b7ab85861025c2546f5f52384ff18a6d9346d350c2a0bf3b7524829a",
    },
}
```

2{}�
version�
Vulkan SDK version to download and install.

This expects a version in the format of `1.4.313.0` or `1.4.313`.
When 3 components are provided, `.0` will be appended automatically to make it 4 components.
 �
windows_components�
Optional Vulkan SDK components to install on Windows.

These are passed to the installer between `--confirm-command install` and `copy_only=1`.

Known components: `com.lunarg.vulkan.sdl2`, `com.lunarg.vulkan.glm`, `com.lunarg.vulkan.volk`,
`com.lunarg.vulkan.vma`, `com.lunarg.vulkan.debug`.
2[]�
windows_skip_runtime�
Do not download and install Vulkan runtime package (e.g. `vulkan-1.dll` dependency) on Windows.

When `True`, the downloader will not put `vulkan-1.dll` into the repository root directory.

This is useful if there is a system-wide Vulkan runtime already installed, otherwise this
might lead to link/runtime issues when building CC targets.
2False*.
install_sdk@@rules_vulkan//vulkan:defs.bzl
��0
.
name"A unique name for this repository. 1
/

build_file2//vulkan/private:template.BUILD�
�
macos_components�
Optional Vulkan SDK components to install on macOS.

These are passed to the installer after `--confirm-command install`.

Known components: `com.lunarg.vulkan.usr`, `com.lunarg.vulkan.sdl2`, `com.lunarg.vulkan.glm`,
`com.lunarg.vulkan.volk`, `com.lunarg.vulkan.vma`, `com.lunarg.vulkan.ios`,
`com.lunarg.vulkan.kosmic`.
2[]�
�
repo_mapping�A dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.<p>For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).
 �
�
urls�
Custom URLs and SHA256 checksums for the Vulkan SDK.

This allows using a custom mirror for Vulkan SDKs instead of LunarG. When not specified, the SDK
is downloaded from the default LunarG mirrors using the bundled `versions.json`.

A separate download URL and SHA256 checksum is required for each platform. LunarG currently uses
the following platform keys:
- `windows` - Windows x86-64
- `warm` - Windows ARM64
- `mac` - macOS
- `linux` - Linux

Each entry must provide `url` and `sha` fields. On Windows platforms, `runtime_url` and
`runtime_sha` can be used to provide URLs for the Vulkan runtime package.

Example:
```bazel
custom_urls = {
    "linux": {
        "url": "https://sdk.lunarg.com/sdk/download/1.4.313.0/linux/vulkansdk-linux-x86_64-1.4.313.0.tar.xz",
        "sha": "4e957b66ade85eeaee95932aa7e3b45aea64db373c58a5eaefc8228cc71445c2",
    },
    "mac": {
        "url": "https://sdk.lunarg.com/sdk/download/1.4.313.0/mac/vulkansdk-macos-1.4.313.0.zip",
        "sha": "782a966ef4d5d68acaa933ff45215df2e34f286df8f6077270202f218110dc20",
    },
    "windows": {
        "url": "https://sdk.lunarg.com/sdk/download/1.4.313.0/windows/vulkansdk-windows-X64-1.4.313.0.exe",
        "sha": "b643ca8ab4aea5c47b9c4e021a0b33b3a13871bf1d8131e162a9e48c257c4694",
        "runtime_url": "https://sdk.lunarg.com/sdk/download/1.4.313.0/windows/VulkanRT-X64-1.4.313.0-Components.zip",
        "runtime_sha": "e8d37913185142270a2bc1b3e1f8f498a4edf47405fddda666f2f38b30ca944b",
    },
    "warm": {
        "url": "https://sdk.lunarg.com/sdk/download/1.4.313.0/warm/vulkansdk-windows-ARM64-1.4.313.0.exe",
        "sha": "b19a8683df982d302fec07c110962153f02a2e5cf1e5118ff72d8532aa5fc567",
        "runtime_url": "https://sdk.lunarg.com/sdk/download/1.4.313.0/warm/VulkanRT-ARM64-1.4.313.0-Components.zip",
        "runtime_sha": "6335a8d6b7ab85861025c2546f5f52384ff18a6d9346d350c2a0bf3b7524829a",
    },
}
```

2{}�
�
version�
Vulkan SDK version to download and install.

This expects a version in the format of `1.4.313.0` or `1.4.313`.
When 3 components are provided, `.0` will be appended automatically to make it 4 components.
 �
�
windows_components�
Optional Vulkan SDK components to install on Windows.

These are passed to the installer between `--confirm-command install` and `copy_only=1`.

Known components: `com.lunarg.vulkan.sdl2`, `com.lunarg.vulkan.glm`, `com.lunarg.vulkan.volk`,
`com.lunarg.vulkan.vma`, `com.lunarg.vulkan.debug`.
2[]�
�
windows_skip_runtime�
Do not download and install Vulkan runtime package (e.g. `vulkan-1.dll` dependency) on Windows.

When `True`, the downloader will not put `vulkan-1.dll` into the repository root directory.

This is useful if there is a system-wide Vulkan runtime already installed, otherwise this
might lead to link/runtime issues when building CC targets.
2False�
//vulkan:providers.bzlr�
%
rules_vulkanvulkanproviders.bzl1
ShaderGroupInfo_ShaderGroupInfo
-='

ShaderInfo_ShaderInfo
S^
n�
//vulkan:toolchains.bzlrk
&
rules_vulkanvulkantoolchains.bzl3
vulkan_toolchain_vulkan_toolchain
.?
U�
//vulkan/private:glsl.bzlrc
(
rules_vulkanvulkan/privateglsl.bzl)
glsl_shader_glsl_shader
0<
M�
//vulkan/private:hlsl.bzlrc
(
rules_vulkanvulkan/privatehlsl.bzl)
hlsl_shader_hlsl_shader
0<
M�
//vulkan/private:install.bzlr�
+
rules_vulkanvulkan/privateinstall.bzl-
INSTALL_ATTRS_INSTALL_ATTRS
	3	A)
install_sdk_install_sdk
	U	a
		r�
!//vulkan/private:shader_group.bzlrm
0
rules_vulkanvulkan/privateshader_group.bzl+
shader_group_shader_group

8
E


W�
//vulkan/private:slang.bzlrf
)
rules_vulkanvulkan/private	slang.bzl+
slang_shader_slang_shader
1>
P�
 //vulkan/private:spirv_cross.bzlrj
/
rules_vulkanvulkan/privatespirv_cross.bzl)
spirv_cross_spirv_cross
7C
T-
Definitions for the Vulkan SDK Bazel rules.
�V
&
rules_vulkanvulkanextensions.bzl�U
vulkan_sdk)
Module extension to manage Vulkan SDKs.
J�T
� 

vulkan_sdk)
Module extension to manage Vulkan SDKs.
�
	toolchain�
namey
            Optional repository name alias.

            If not specified, will use "vulkan_sdk_{version}".
            2""�
macos_components�
            Optional Vulkan SDK components to install on macOS.

            These are passed to the installer after `--confirm-command install`.

            Known components: `com.lunarg.vulkan.usr`, `com.lunarg.vulkan.sdl2`, `com.lunarg.vulkan.glm`,
            `com.lunarg.vulkan.volk`, `com.lunarg.vulkan.vma`, `com.lunarg.vulkan.ios`,
            `com.lunarg.vulkan.kosmic`.
            2[]�
urls�
            Custom URLs and SHA256 checksums for the Vulkan SDK.

            This allows using a custom mirror for Vulkan SDKs instead of LunarG. When not specified, the SDK
            is downloaded from the default LunarG mirrors using the bundled `versions.json`.

            A separate download URL and SHA256 checksum is required for each platform. LunarG currently uses
            the following platform keys:
            - `windows` - Windows x86-64
            - `warm` - Windows ARM64
            - `mac` - macOS
            - `linux` - Linux

            Each entry must provide `url` and `sha` fields. On Windows platforms, `runtime_url` and
            `runtime_sha` can be used to provide URLs for the Vulkan runtime package.

            Example:
            ```bazel
            custom_urls = {
                "linux": {
                    "url": "https://sdk.lunarg.com/sdk/download/1.4.313.0/linux/vulkansdk-linux-x86_64-1.4.313.0.tar.xz",
                    "sha": "4e957b66ade85eeaee95932aa7e3b45aea64db373c58a5eaefc8228cc71445c2",
                },
                "mac": {
                    "url": "https://sdk.lunarg.com/sdk/download/1.4.313.0/mac/vulkansdk-macos-1.4.313.0.zip",
                    "sha": "782a966ef4d5d68acaa933ff45215df2e34f286df8f6077270202f218110dc20",
                },
                "windows": {
                    "url": "https://sdk.lunarg.com/sdk/download/1.4.313.0/windows/vulkansdk-windows-X64-1.4.313.0.exe",
                    "sha": "b643ca8ab4aea5c47b9c4e021a0b33b3a13871bf1d8131e162a9e48c257c4694",
                    "runtime_url": "https://sdk.lunarg.com/sdk/download/1.4.313.0/windows/VulkanRT-X64-1.4.313.0-Components.zip",
                    "runtime_sha": "e8d37913185142270a2bc1b3e1f8f498a4edf47405fddda666f2f38b30ca944b",
                },
                "warm": {
                    "url": "https://sdk.lunarg.com/sdk/download/1.4.313.0/warm/vulkansdk-windows-ARM64-1.4.313.0.exe",
                    "sha": "b19a8683df982d302fec07c110962153f02a2e5cf1e5118ff72d8532aa5fc567",
                    "runtime_url": "https://sdk.lunarg.com/sdk/download/1.4.313.0/warm/VulkanRT-ARM64-1.4.313.0-Components.zip",
                    "runtime_sha": "6335a8d6b7ab85861025c2546f5f52384ff18a6d9346d350c2a0bf3b7524829a",
                },
            }
            ```
            
2{}�
version�
            Vulkan SDK version to download and install.

            This expects a version in the format of `1.4.313.0` or `1.4.313`.
            When 3 components are provided, `.0` will be appended automatically to make it 4 components.
             �
windows_components�
            Optional Vulkan SDK components to install on Windows.

            These are passed to the installer between `--confirm-command install` and `copy_only=1`.

            Known components: `com.lunarg.vulkan.sdl2`, `com.lunarg.vulkan.glm`, `com.lunarg.vulkan.volk`,
            `com.lunarg.vulkan.vma`, `com.lunarg.vulkan.debug`.
            2[]�
windows_skip_runtime�
            Do not download and install Vulkan runtime package (e.g. `vulkan-1.dll` dependency) on Windows.

            When `True`, the downloader will not put `vulkan-1.dll` into the repository root directory.

            This is useful if there is a system-wide Vulkan runtime already installed, otherwise this
            might lead to link/runtime issues when building CC targets.
            2False"3

vulkan_sdk%@@rules_vulkan//vulkan:extensions.bzl
!!�3
�
	toolchainc
nameU
Optional repository name alias.

If not specified, will use "vulkan_sdk_{version}".
2""�
macos_components�
Optional Vulkan SDK components to install on macOS.

These are passed to the installer after `--confirm-command install`.

Known components: `com.lunarg.vulkan.usr`, `com.lunarg.vulkan.sdl2`, `com.lunarg.vulkan.glm`,
`com.lunarg.vulkan.volk`, `com.lunarg.vulkan.vma`, `com.lunarg.vulkan.ios`,
`com.lunarg.vulkan.kosmic`.
2[]�
urls�
Custom URLs and SHA256 checksums for the Vulkan SDK.

This allows using a custom mirror for Vulkan SDKs instead of LunarG. When not specified, the SDK
is downloaded from the default LunarG mirrors using the bundled `versions.json`.

A separate download URL and SHA256 checksum is required for each platform. LunarG currently uses
the following platform keys:
- `windows` - Windows x86-64
- `warm` - Windows ARM64
- `mac` - macOS
- `linux` - Linux

Each entry must provide `url` and `sha` fields. On Windows platforms, `runtime_url` and
`runtime_sha` can be used to provide URLs for the Vulkan runtime package.

Example:
```bazel
custom_urls = {
    "linux": {
        "url": "https://sdk.lunarg.com/sdk/download/1.4.313.0/linux/vulkansdk-linux-x86_64-1.4.313.0.tar.xz",
        "sha": "4e957b66ade85eeaee95932aa7e3b45aea64db373c58a5eaefc8228cc71445c2",
    },
    "mac": {
        "url": "https://sdk.lunarg.com/sdk/download/1.4.313.0/mac/vulkansdk-macos-1.4.313.0.zip",
        "sha": "782a966ef4d5d68acaa933ff45215df2e34f286df8f6077270202f218110dc20",
    },
    "windows": {
        "url": "https://sdk.lunarg.com/sdk/download/1.4.313.0/windows/vulkansdk-windows-X64-1.4.313.0.exe",
        "sha": "b643ca8ab4aea5c47b9c4e021a0b33b3a13871bf1d8131e162a9e48c257c4694",
        "runtime_url": "https://sdk.lunarg.com/sdk/download/1.4.313.0/windows/VulkanRT-X64-1.4.313.0-Components.zip",
        "runtime_sha": "e8d37913185142270a2bc1b3e1f8f498a4edf47405fddda666f2f38b30ca944b",
    },
    "warm": {
        "url": "https://sdk.lunarg.com/sdk/download/1.4.313.0/warm/vulkansdk-windows-ARM64-1.4.313.0.exe",
        "sha": "b19a8683df982d302fec07c110962153f02a2e5cf1e5118ff72d8532aa5fc567",
        "runtime_url": "https://sdk.lunarg.com/sdk/download/1.4.313.0/warm/VulkanRT-ARM64-1.4.313.0-Components.zip",
        "runtime_sha": "6335a8d6b7ab85861025c2546f5f52384ff18a6d9346d350c2a0bf3b7524829a",
    },
}
```

2{}�
version�
Vulkan SDK version to download and install.

This expects a version in the format of `1.4.313.0` or `1.4.313`.
When 3 components are provided, `.0` will be appended automatically to make it 4 components.
 �
windows_components�
Optional Vulkan SDK components to install on Windows.

These are passed to the installer between `--confirm-command install` and `copy_only=1`.

Known components: `com.lunarg.vulkan.sdl2`, `com.lunarg.vulkan.glm`, `com.lunarg.vulkan.volk`,
`com.lunarg.vulkan.vma`, `com.lunarg.vulkan.debug`.
2[]�
windows_skip_runtime�
Do not download and install Vulkan runtime package (e.g. `vulkan-1.dll` dependency) on Windows.

When `True`, the downloader will not put `vulkan-1.dll` into the repository root directory.

This is useful if there is a system-wide Vulkan runtime already installed, otherwise this
might lead to link/runtime issues when building CC targets.
2Falsee
c
nameU
Optional repository name alias.

If not specified, will use "vulkan_sdk_{version}".
2""�
�
macos_components�
Optional Vulkan SDK components to install on macOS.

These are passed to the installer after `--confirm-command install`.

Known components: `com.lunarg.vulkan.usr`, `com.lunarg.vulkan.sdl2`, `com.lunarg.vulkan.glm`,
`com.lunarg.vulkan.volk`, `com.lunarg.vulkan.vma`, `com.lunarg.vulkan.ios`,
`com.lunarg.vulkan.kosmic`.
2[]�
�
urls�
Custom URLs and SHA256 checksums for the Vulkan SDK.

This allows using a custom mirror for Vulkan SDKs instead of LunarG. When not specified, the SDK
is downloaded from the default LunarG mirrors using the bundled `versions.json`.

A separate download URL and SHA256 checksum is required for each platform. LunarG currently uses
the following platform keys:
- `windows` - Windows x86-64
- `warm` - Windows ARM64
- `mac` - macOS
- `linux` - Linux

Each entry must provide `url` and `sha` fields. On Windows platforms, `runtime_url` and
`runtime_sha` can be used to provide URLs for the Vulkan runtime package.

Example:
```bazel
custom_urls = {
    "linux": {
        "url": "https://sdk.lunarg.com/sdk/download/1.4.313.0/linux/vulkansdk-linux-x86_64-1.4.313.0.tar.xz",
        "sha": "4e957b66ade85eeaee95932aa7e3b45aea64db373c58a5eaefc8228cc71445c2",
    },
    "mac": {
        "url": "https://sdk.lunarg.com/sdk/download/1.4.313.0/mac/vulkansdk-macos-1.4.313.0.zip",
        "sha": "782a966ef4d5d68acaa933ff45215df2e34f286df8f6077270202f218110dc20",
    },
    "windows": {
        "url": "https://sdk.lunarg.com/sdk/download/1.4.313.0/windows/vulkansdk-windows-X64-1.4.313.0.exe",
        "sha": "b643ca8ab4aea5c47b9c4e021a0b33b3a13871bf1d8131e162a9e48c257c4694",
        "runtime_url": "https://sdk.lunarg.com/sdk/download/1.4.313.0/windows/VulkanRT-X64-1.4.313.0-Components.zip",
        "runtime_sha": "e8d37913185142270a2bc1b3e1f8f498a4edf47405fddda666f2f38b30ca944b",
    },
    "warm": {
        "url": "https://sdk.lunarg.com/sdk/download/1.4.313.0/warm/vulkansdk-windows-ARM64-1.4.313.0.exe",
        "sha": "b19a8683df982d302fec07c110962153f02a2e5cf1e5118ff72d8532aa5fc567",
        "runtime_url": "https://sdk.lunarg.com/sdk/download/1.4.313.0/warm/VulkanRT-ARM64-1.4.313.0-Components.zip",
        "runtime_sha": "6335a8d6b7ab85861025c2546f5f52384ff18a6d9346d350c2a0bf3b7524829a",
    },
}
```

2{}�
�
version�
Vulkan SDK version to download and install.

This expects a version in the format of `1.4.313.0` or `1.4.313`.
When 3 components are provided, `.0` will be appended automatically to make it 4 components.
 �
�
windows_components�
Optional Vulkan SDK components to install on Windows.

These are passed to the installer between `--confirm-command install` and `copy_only=1`.

Known components: `com.lunarg.vulkan.sdl2`, `com.lunarg.vulkan.glm`, `com.lunarg.vulkan.volk`,
`com.lunarg.vulkan.vma`, `com.lunarg.vulkan.debug`.
2[]�
�
windows_skip_runtime�
Do not download and install Vulkan runtime package (e.g. `vulkan-1.dll` dependency) on Windows.

When `True`, the downloader will not put `vulkan-1.dll` into the repository root directory.

This is useful if there is a system-wide Vulkan runtime already installed, otherwise this
might lead to link/runtime issues when building CC targets.
2False�
//vulkan:defs.bzlr�
 
rules_vulkanvulkandefs.bzl,
INSTALL_ATTRSINSTALL_ATTRS
)6(
install_sdkinstall_sdk
:E
G)
Module extension to manage Vulkan SDKs.
�
%
rules_vulkanvulkanproviders.bzl�ShaderGroupInfo
A collection of shader infos.
2�
�
ShaderGroupInfo
A collection of shader infos.
%
listList of ShaderInfo structures"7
ShaderGroupInfo$@@rules_vulkan//vulkan:providers.bzl
'
%
listList of ShaderInfo structures�

ShaderInfo
Shader metadata returned by the shader targets during compilation.

This is useful for building all kind of shader databases.
2�	
�

ShaderInfo
Shader metadata returned by the shader targets during compilation.

This is useful for building all kind of shader databases.
D
binary:Binary output file containing the compiled shader bytecode>
assembly2Assembly output file (if generated, HLSL-specific)3

reflection%Reflection output file (if generated)6
hash.Hash output file (if generated, HLSL-specific)@
depfile5Dependency output file (if generated, Slang-specific))
entry Shader entry point function name
stageShader stage9
defines.List of shader defines used during compilationB
target8Compilation target (note: this depends on compiler used)"2

ShaderInfo$@@rules_vulkan//vulkan:providers.bzl
F
D
binary:Binary output file containing the compiled shader bytecode@
>
assembly2Assembly output file (if generated, HLSL-specific)5
3

reflection%Reflection output file (if generated)8
6
hash.Hash output file (if generated, HLSL-specific)B
@
depfile5Dependency output file (if generated, Slang-specific)+
)
entry Shader entry point function name

stageShader stage;
9
defines.List of shader defines used during compilationD
B
target8Compilation target (note: this depends on compiler used)
Vulkan providers.
�
&
rules_vulkanvulkantoolchains.bzl�vulkan_toolchain"�
�
vulkan_toolchain*
nameA unique name for this target. 
dxcPath to dxc 7
env*
Environment to be passed to executables.

2{}
glslcPath to glslc 
slangcPath to slangc &
spirv_crossPath to spirv_cross "9
vulkan_toolchain%@@rules_vulkan//vulkan:toolchains.bzl
,
*
nameA unique name for this target. 

dxcPath to dxc 9
7
env*
Environment to be passed to executables.

2{}

glslcPath to glslc 

slangcPath to slangc (
&
spirv_crossPath to spirv_cross �
VulkanInfoInformation about Vulkan SDK2�
�

VulkanInfoInformation about Vulkan SDK
dxc(Undocumented)
slangc(Undocumented)
glslc(Undocumented)
spirv_cross(Undocumented)
env(Undocumented)"3

VulkanInfo%@@rules_vulkan//vulkan:toolchains.bzl


dxc(Undocumented)

slangc(Undocumented)

glslc(Undocumented)

spirv_cross(Undocumented)

env(Undocumented)
Vulkan SDK toolchains
 