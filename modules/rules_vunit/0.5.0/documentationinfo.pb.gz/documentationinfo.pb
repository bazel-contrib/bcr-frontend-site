�
<
rules_vunitvunit/private/simulatorsvunit_activehdl.bzl�vunit_activehdl_sim�A simulator configuration for running [Aldec
Active-HDL](https://www.aldec.com/en/products/fpga_simulation/active-hdl)
under VUnit.

### Status

Infrastructure only. Active-HDL is commercial, with no BCR module and
no redistributable binary; `rules_vunit` cannot validate this rule in
CI.

### Notes

Active-HDL accepts both Verilog/SystemVerilog (`VerilogInfo`) and VHDL
(`VhdlInfo`) modules. Sets `VUNIT_SIMULATOR=activehdl`.
"�
�
vunit_activehdl_sim�A simulator configuration for running [Aldec
Active-HDL](https://www.aldec.com/en/products/fpga_simulation/active-hdl)
under VUnit.

### Status

Infrastructure only. Active-HDL is commercial, with no BCR module and
no redistributable binary; `rules_vunit` cannot validate this rule in
CI.

### Notes

Active-HDL accepts both Verilog/SystemVerilog (`VerilogInfo`) and VHDL
(`VhdlInfo`) modules. Sets `VUNIT_SIMULATOR=activehdl`.
*
nameA unique name for this target. �
env�Environment variables to set when the vunit runner invokes this simulator at test time (license-server pointers, install root vars, â¦). Precedence: toolchain `env` < sim `env` < rule-level `vunit_test(env = ...)`.
2{},
vcom The `vcom` VHDL compiler binary. .
vlib"The `vlib` library manager binary. =
vlog1The `vlog` Verilog/SystemVerilog compiler binary. (
vsimThe `vsim` simulator binary. "R
vunit_activehdl_sim;@@rules_vunit//vunit/private/simulators:vunit_activehdl.bzl
DD,
*
nameA unique name for this target. �
�
env�Environment variables to set when the vunit runner invokes this simulator at test time (license-server pointers, install root vars, â¦). Precedence: toolchain `env` < sim `env` < rule-level `vunit_test(env = ...)`.
2{}.
,
vcom The `vcom` VHDL compiler binary. 0
.
vlib"The `vlib` library manager binary. ?
=
vlog1The `vlog` Verilog/SystemVerilog compiler binary. *
(
vsimThe `vsim` simulator binary. �activehdl_compile;Stage HDL sources for an Active-HDL simulation under VUnit.*�
�
activehdl_compile%
ctxThe rule's context object. (2
	simulator!The `vunit_activehdl_sim` target. (2
	libraries!List of (lib_name, target) pairs. ()
sim_optsForwarded to VUnit's CLI. (;Stage HDL sources for an Active-HDL simulation under VUnit."I
GVUnitSimOutputInfo: Source runfiles plus the `VUNIT_SIMULATOR` env var.2P
activehdl_compile;@@rules_vunit//vunit/private/simulators:vunit_activehdl.bzl
�VUnitSimActiveHdlInfo0Active-HDL-specific extension of `VUnitSimInfo`.2�
�
VUnitSimActiveHdlInfo0Active-HDL-specific extension of `VUnitSimInfo`.T
	all_filesGdepset[File]: All transitive runfiles required by the Active-HDL tools.2
vcom*File: The `vcom` VHDL compiler executable.4
vlib,File: The `vlib` library manager executable.5
vlog-File: The `vlog` Verilog compiler executable..
vsim&File: The `vsim` simulator executable."T
VUnitSimActiveHdlInfo;@@rules_vunit//vunit/private/simulators:vunit_activehdl.bzl
!!V
T
	all_filesGdepset[File]: All transitive runfiles required by the Active-HDL tools.4
2
vcom*File: The `vcom` VHDL compiler executable.6
4
vlib,File: The `vlib` library manager executable.7
5
vlog-File: The `vlog` Verilog compiler executable.0
.
vsim&File: The `vsim` simulator executable.�
.//vunit/private/simulators:vunit_sim_utils.bzlr�
<
rules_vunitvunit/private/simulatorsvunit_sim_utils.bzl*
SIM_ENV_ATTRSIM_ENV_ATTR
EQ*
VUnitSimInfoVUnitSimInfo
Ua6
VUnitSimOutputInfoVUnitSimOutputInfo
ew?
gather_library_sourcesgather_library_sources
{�
�&VUnit Active-HDL simulator integration�>
7
rules_vunitvunit/private/simulatorsvunit_ghdl.bzl�&vunit_ghdl_sim�	A simulator configuration for running [GHDL](https://ghdl.github.io/ghdl/)
simulations in VUnit tests.

### Status

Working against the BCR `ghdl` module from version `6.0.0.bcr.1` onward.
The backend is selectable with `--@ghdl//:backend={mcode, llvm-jit}`
(default `mcode` on x86_64, `llvm-jit` elsewhere).

### Notes

GHDL only supports VHDL (`VhdlInfo`); pair it with `vhdl_library` targets
in the `libraries` map of `vunit_test`. VUnit drives `ghdl` directly via
its `vu.main()` at test time using sources surfaced through runfiles.

The `vhdl_libs` attribute should point at the pre-compiled IEEE/std
libraries from the BCR `ghdl` module â most projects want
`["@ghdl//:vhdl_libs_v08"]`.

### Coverage

GHDL only emits coverage when built with the `gcc` backend; the BCR
`ghdl` module ships only `mcode` and `llvm-jit`, neither of which
support it. Wiring up coverage flags here would be a no-op (or
runtime error) against a stock BCR build, so this rule omits the
sim-side coverage path. The generic `VUnitSimInfo.coverage` field
remains available for downstream toolchains that point
`vunit_ghdl_sim(ghdl = ...)` at a GHDL+gcc binary and want to thread
gcov output through `bazel coverage`.
"�
�
vunit_ghdl_sim�	A simulator configuration for running [GHDL](https://ghdl.github.io/ghdl/)
simulations in VUnit tests.

### Status

Working against the BCR `ghdl` module from version `6.0.0.bcr.1` onward.
The backend is selectable with `--@ghdl//:backend={mcode, llvm-jit}`
(default `mcode` on x86_64, `llvm-jit` elsewhere).

### Notes

GHDL only supports VHDL (`VhdlInfo`); pair it with `vhdl_library` targets
in the `libraries` map of `vunit_test`. VUnit drives `ghdl` directly via
its `vu.main()` at test time using sources surfaced through runfiles.

The `vhdl_libs` attribute should point at the pre-compiled IEEE/std
libraries from the BCR `ghdl` module â most projects want
`["@ghdl//:vhdl_libs_v08"]`.

### Coverage

GHDL only emits coverage when built with the `gcc` backend; the BCR
`ghdl` module ships only `mcode` and `llvm-jit`, neither of which
support it. Wiring up coverage flags here would be a no-op (or
runtime error) against a stock BCR build, so this rule omits the
sim-side coverage path. The generic `VUnitSimInfo.coverage` field
remains available for downstream toolchains that point
`vunit_ghdl_sim(ghdl = ...)` at a GHDL+gcc binary and want to thread
gcov output through `bazel coverage`.
*
nameA unique name for this target. �
env�Environment variables to set when the vunit runner invokes this simulator at test time (license-server pointers, install root vars, â¦). Precedence: toolchain `env` < sim `env` < rule-level `vunit_test(env = ...)`.
2{}
ghdlThe `ghdl` binary. �
ghdl_prefix�Literal value to set as `GHDL_PREFIX` at simulation time. Use this for
ghdl installs where the prefix is a stable absolute path on disk â
typically a system/`.deb`/Homebrew install (e.g. `"/usr/lib/ghdl"`).

When unset (default), `GHDL_PREFIX` is auto-derived from `vhdl_libs` if
it's populated (BCR-shaped layout), otherwise left unset so ghdl falls
back to its own compiled-in search paths.
2""�
	vhdl_libs�Pre-compiled VHDL standard libraries (e.g. `@ghdl//:vhdl_libs_v08`).
**Assumes the BCR `ghdl` module's layout** â
`<root>/{std,ieee}/v<XX>/<name>-objXX.cf` â from which `GHDL_PREFIX`
is derived. If you ship ghdl differently and the IEEE/std libs are
already discoverable by the binary, leave this empty and (optionally)
set `ghdl_prefix` to a literal path, or skip both for a system install
that uses its compiled-in defaults.
2[]"H
vunit_ghdl_sim6@@rules_vunit//vunit/private/simulators:vunit_ghdl.bzl
ss,
*
nameA unique name for this target. �
�
env�Environment variables to set when the vunit runner invokes this simulator at test time (license-server pointers, install root vars, â¦). Precedence: toolchain `env` < sim `env` < rule-level `vunit_test(env = ...)`.
2{} 

ghdlThe `ghdl` binary. �
�
ghdl_prefix�Literal value to set as `GHDL_PREFIX` at simulation time. Use this for
ghdl installs where the prefix is a stable absolute path on disk â
typically a system/`.deb`/Homebrew install (e.g. `"/usr/lib/ghdl"`).

When unset (default), `GHDL_PREFIX` is auto-derived from `vhdl_libs` if
it's populated (BCR-shaped layout), otherwise left unset so ghdl falls
back to its own compiled-in search paths.
2""�
�
	vhdl_libs�Pre-compiled VHDL standard libraries (e.g. `@ghdl//:vhdl_libs_v08`).
**Assumes the BCR `ghdl` module's layout** â
`<root>/{std,ieee}/v<XX>/<name>-objXX.cf` â from which `GHDL_PREFIX`
is derived. If you ship ghdl differently and the IEEE/std libs are
already discoverable by the binary, leave this empty and (optionally)
set `ghdl_prefix` to a literal path, or skip both for a system install
that uses its compiled-in defaults.
2[]�ghdl_compile�Stage VHDL sources and GHDL standard libraries for a VUnit run.

VUnit drives GHDL through `vu.main()` at test time — no Bazel-time
`ghdl -a` runs. The JIT backends (`mcode`, `llvm-jit`) bake absolute
paths into `.cf` metadata, so any sandbox-time work directory wouldn't
be relocatable to the test sandbox. Instead this function gathers the
sources from each library target and rolls them into the runfiles;
`vunit_test` writes them into `libraries.json` and the toolchain's
`run.py` adds them via `lib.add_source_file(...)`.
*�
�
ghdl_compile%
ctxThe rule's context object. (-
	simulatorThe `vunit_ghdl_sim` target. (~
	librariesmList of (lib_name, target) pairs. Each target
must provide `VhdlInfo` (Verilog inputs aren't valid for GHDL). ()
sim_optsForwarded to VUnit's CLI. (�Stage VHDL sources and GHDL standard libraries for a VUnit run.

VUnit drives GHDL through `vu.main()` at test time — no Bazel-time
`ghdl -a` runs. The JIT backends (`mcode`, `llvm-jit`) bake absolute
paths into `.cf` metadata, so any sandbox-time work directory wouldn't
be relocatable to the test sandbox. Instead this function gathers the
sources from each library target and rolls them into the runfiles;
`vunit_test` writes them into `libraries.json` and the toolchain's
`run.py` adds them via `lib.add_source_file(...)`.
"R
PVUnitSimOutputInfo: Provider carrying source runfiles, env vars,
and CLI extras.2F
ghdl_compile6@@rules_vunit//vunit/private/simulators:vunit_ghdl.bzl
##�VUnitSimGhdlInfo*GHDL-specific extension of `VUnitSimInfo`.2�
�
VUnitSimGhdlInfo*GHDL-specific extension of `VUnitSimInfo`.N
	all_filesAdepset[File]: All transitive runfiles required by the GHDL tools.$
ghdlFile: The `ghdl` executable.�
ghdl_prefix�str: Literal value to set as `GHDL_PREFIX` at sim time. Empty falls back to deriving from `vhdl_libs` (BCR layout) or to ghdl's compiled-in defaults.h
	vhdl_libs[depset[File]: Pre-compiled VHDL standard library files for GHDL_PREFIX (BCR-shaped layout)."J
VUnitSimGhdlInfo6@@rules_vunit//vunit/private/simulators:vunit_ghdl.bzl
P
N
	all_filesAdepset[File]: All transitive runfiles required by the GHDL tools.&
$
ghdlFile: The `ghdl` executable.�
�
ghdl_prefix�str: Literal value to set as `GHDL_PREFIX` at sim time. Empty falls back to deriving from `vhdl_libs` (BCR layout) or to ghdl's compiled-in defaults.j
h
	vhdl_libs[depset[File]: Pre-compiled VHDL standard library files for GHDL_PREFIX (BCR-shaped layout).e
//vhdl:defs.bzlrP


rules_vhdlvhdldefs.bzl"
VhdlInfoVhdlInfo
%-
/�
.//vunit/private/simulators:vunit_sim_utils.bzlr�
<
rules_vunitvunit/private/simulatorsvunit_sim_utils.bzl*
SIM_ENV_ATTRSIM_ENV_ATTR
EQ*
VUnitSimInfoVUnitSimInfo
Ua6
VUnitSimOutputInfoVUnitSimOutputInfo
ew
y VUnit GHDL simulator integration�$
;
rules_vunitvunit/private/simulatorsvunit_modelsim.bzl�vunit_modelsim_sim�A simulator configuration for running [Mentor/Siemens EDA
ModelSim](https://eda.sw.siemens.com/en-US/ic/modelsim/) under VUnit.

VUnit shares the `modelsim` backend for both ModelSim and Questa; use
`vunit_questa_sim` if you prefer that terminology â they wire up the
same VUnit backend.

### Status

Infrastructure only. ModelSim is commercial, with no BCR module and no
redistributable binary; `rules_vunit` cannot validate this rule in CI.
Wire it up downstream by pointing the binary attrs at your own install
and registering a `vunit_toolchain` that routes `sim = "modelsim"`
through this rule.

### Notes

ModelSim accepts both Verilog/SystemVerilog (`VerilogInfo`) and VHDL
(`VhdlInfo`) modules. VUnit drives `vlib` / `vlog` / `vcom` / `vsim` via
its own runner â the rule just stages sources and surfaces the
binaries on PATH.
"�
�
vunit_modelsim_sim�A simulator configuration for running [Mentor/Siemens EDA
ModelSim](https://eda.sw.siemens.com/en-US/ic/modelsim/) under VUnit.

VUnit shares the `modelsim` backend for both ModelSim and Questa; use
`vunit_questa_sim` if you prefer that terminology â they wire up the
same VUnit backend.

### Status

Infrastructure only. ModelSim is commercial, with no BCR module and no
redistributable binary; `rules_vunit` cannot validate this rule in CI.
Wire it up downstream by pointing the binary attrs at your own install
and registering a `vunit_toolchain` that routes `sim = "modelsim"`
through this rule.

### Notes

ModelSim accepts both Verilog/SystemVerilog (`VerilogInfo`) and VHDL
(`VhdlInfo`) modules. VUnit drives `vlib` / `vlog` / `vcom` / `vsim` via
its own runner â the rule just stages sources and surfaces the
binaries on PATH.
*
nameA unique name for this target. �
env�Environment variables to set when the vunit runner invokes this simulator at test time (license-server pointers, install root vars, â¦). Precedence: toolchain `env` < sim `env` < rule-level `vunit_test(env = ...)`.
2{},
vcom The `vcom` VHDL compiler binary. .
vlib"The `vlib` library manager binary. =
vlog1The `vlog` Verilog/SystemVerilog compiler binary. (
vsimThe `vsim` simulator binary. "P
vunit_modelsim_sim:@@rules_vunit//vunit/private/simulators:vunit_modelsim.bzl
DD,
*
nameA unique name for this target. �
�
env�Environment variables to set when the vunit runner invokes this simulator at test time (license-server pointers, install root vars, â¦). Precedence: toolchain `env` < sim `env` < rule-level `vunit_test(env = ...)`.
2{}.
,
vcom The `vcom` VHDL compiler binary. 0
.
vlib"The `vlib` library manager binary. ?
=
vlog1The `vlog` Verilog/SystemVerilog compiler binary. *
(
vsimThe `vsim` simulator binary. �modelsim_compile?Stage HDL sources for a ModelSim/Questa simulation under VUnit.*�
�
modelsim_compile%
ctxThe rule's context object. (1
	simulator The `vunit_modelsim_sim` target. (2
	libraries!List of (lib_name, target) pairs. ()
sim_optsForwarded to VUnit's CLI. (?Stage HDL sources for a ModelSim/Questa simulation under VUnit."I
GVUnitSimOutputInfo: Source runfiles plus the `VUNIT_SIMULATOR` env var.2N
modelsim_compile:@@rules_vunit//vunit/private/simulators:vunit_modelsim.bzl
�VUnitSimModelsimInfo.ModelSim-specific extension of `VUnitSimInfo`.2�
�
VUnitSimModelsimInfo.ModelSim-specific extension of `VUnitSimInfo`.R
	all_filesEdepset[File]: All transitive runfiles required by the ModelSim tools.2
vcom*File: The `vcom` VHDL compiler executable.4
vlib,File: The `vlib` library manager executable.5
vlog-File: The `vlog` Verilog compiler executable..
vsim&File: The `vsim` simulator executable."R
VUnitSimModelsimInfo:@@rules_vunit//vunit/private/simulators:vunit_modelsim.bzl
  T
R
	all_filesEdepset[File]: All transitive runfiles required by the ModelSim tools.4
2
vcom*File: The `vcom` VHDL compiler executable.6
4
vlib,File: The `vlib` library manager executable.7
5
vlog-File: The `vlog` Verilog compiler executable.0
.
vsim&File: The `vsim` simulator executable.�
.//vunit/private/simulators:vunit_sim_utils.bzlr�
<
rules_vunitvunit/private/simulatorsvunit_sim_utils.bzl*
SIM_ENV_ATTRSIM_ENV_ATTR
EQ*
VUnitSimInfoVUnitSimInfo
Ua6
VUnitSimOutputInfoVUnitSimOutputInfo
ew?
gather_library_sourcesgather_library_sources
{�
�$VUnit ModelSim simulator integration�;
6
rules_vunitvunit/private/simulatorsvunit_nvc.bzl�'vunit_nvc_sim�
A simulator configuration for running [NVC](https://www.nickg.me.uk/nvc/)
(open-source VHDL simulator) under VUnit.

### Status

Working against the BCR `nvc` module from version `1.21.0` onward.

### Notes

NVC only supports VHDL (`VhdlInfo`); pair it with `vhdl_library` targets
in the `libraries` map of `vunit_test`. VUnit drives `nvc` directly via
its `vu.main()` at test time using sources surfaced through runfiles.

`vhdl_libs` accepts a list of per-library TreeArtifact targets â
typically `["@nvc//:vhdl_libs"]`, the BCR `nvc` module's filegroup of
per-library directories laid out exactly like a system install under
`<prefix>/lib/nvc/<library>/`. The rule's implementation stages those
TreeArtifacts side-by-side under a single root and points
`NVC_LIBPATH` at it so nvc finds every shipped library (STD, IEEE,
NVC, plus the SYNOPSYS / VITAL extras inside IEEE) at simulation
time.

### Coverage

VUnit has no NVC coverage integration upstream â `vu.set_sim_option`
exposes `nvc.elab_flags`/`nvc.sim_flags`/`nvc.a_flags`, but there's
no shipped recipe for routing NVC's `--cover` instrumentation through
those, and `nvc --cover-export` only emits Cobertura. Rather than
invent a sim-side path here, this rule omits coverage. The generic
`VUnitSimInfo.coverage` field stays available for the commercial
simulators (Mentor UCDB, Aldec ACDB) where a real bridge exists.
"�
�
vunit_nvc_sim�
A simulator configuration for running [NVC](https://www.nickg.me.uk/nvc/)
(open-source VHDL simulator) under VUnit.

### Status

Working against the BCR `nvc` module from version `1.21.0` onward.

### Notes

NVC only supports VHDL (`VhdlInfo`); pair it with `vhdl_library` targets
in the `libraries` map of `vunit_test`. VUnit drives `nvc` directly via
its `vu.main()` at test time using sources surfaced through runfiles.

`vhdl_libs` accepts a list of per-library TreeArtifact targets â
typically `["@nvc//:vhdl_libs"]`, the BCR `nvc` module's filegroup of
per-library directories laid out exactly like a system install under
`<prefix>/lib/nvc/<library>/`. The rule's implementation stages those
TreeArtifacts side-by-side under a single root and points
`NVC_LIBPATH` at it so nvc finds every shipped library (STD, IEEE,
NVC, plus the SYNOPSYS / VITAL extras inside IEEE) at simulation
time.

### Coverage

VUnit has no NVC coverage integration upstream â `vu.set_sim_option`
exposes `nvc.elab_flags`/`nvc.sim_flags`/`nvc.a_flags`, but there's
no shipped recipe for routing NVC's `--cover` instrumentation through
those, and `nvc --cover-export` only emits Cobertura. Rather than
invent a sim-side path here, this rule omits coverage. The generic
`VUnitSimInfo.coverage` field stays available for the commercial
simulators (Mentor UCDB, Aldec ACDB) where a real bridge exists.
*
nameA unique name for this target. �
env�Environment variables to set when the vunit runner invokes this simulator at test time (license-server pointers, install root vars, â¦). Precedence: toolchain `env` < sim `env` < rule-level `vunit_test(env = ...)`.
2{}&
nvcThe `nvc` simulator binary. �
nvc_libpath�Literal value to set as `NVC_LIBPATH` at simulation time. Use this
for nvc installs where the prefix is a stable absolute path on disk â
typically a system / `.deb` / Homebrew install
(e.g. `"/usr/local/lib/nvc"`).

When unset (default), `NVC_LIBPATH` is auto-derived from `vhdl_libs`
if it's populated (per-library TreeArtifacts staged into one root by
this rule), otherwise left unset so nvc falls back to its own
compiled-in search paths.
2""�
	vhdl_libs�Per-library TreeArtifact targets to stage side-by-side under a
single `NVC_LIBPATH` root. Typically `["@nvc//:vhdl_libs"]` â the
BCR `nvc` module's filegroup of per-library directories. Empty (the
default) leaves `NVC_LIBPATH` unset.
2[]"F
vunit_nvc_sim5@@rules_vunit//vunit/private/simulators:vunit_nvc.bzl
��,
*
nameA unique name for this target. �
�
env�Environment variables to set when the vunit runner invokes this simulator at test time (license-server pointers, install root vars, â¦). Precedence: toolchain `env` < sim `env` < rule-level `vunit_test(env = ...)`.
2{}(
&
nvcThe `nvc` simulator binary. �
�
nvc_libpath�Literal value to set as `NVC_LIBPATH` at simulation time. Use this
for nvc installs where the prefix is a stable absolute path on disk â
typically a system / `.deb` / Homebrew install
(e.g. `"/usr/local/lib/nvc"`).

When unset (default), `NVC_LIBPATH` is auto-derived from `vhdl_libs`
if it's populated (per-library TreeArtifacts staged into one root by
this rule), otherwise left unset so nvc falls back to its own
compiled-in search paths.
2""�
�
	vhdl_libs�Per-library TreeArtifact targets to stage side-by-side under a
single `NVC_LIBPATH` root. Typically `["@nvc//:vhdl_libs"]` â the
BCR `nvc` module's filegroup of per-library directories. Empty (the
default) leaves `NVC_LIBPATH` unset.
2[]�	nvc_compile�Stage VHDL sources and the consolidated NVC library root for a VUnit run.

VUnit drives `nvc` through `vu.main()` at test time — no Bazel-time
`nvc -a` runs. The consolidated library root we point
`NVC_LIBPATH` at is read-only, and nvc creates its own writable
work library inside the test sandbox and finds STD/IEEE/NVC inside
the staged libroot.
*�
�
nvc_compile%
ctxThe rule's context object. (,
	simulatorThe `vunit_nvc_sim` target. (}
	librarieslList of (lib_name, target) pairs. Each target
must provide `VhdlInfo` (Verilog inputs aren't valid for NVC). ()
sim_optsForwarded to VUnit's CLI. (�Stage VHDL sources and the consolidated NVC library root for a VUnit run.

VUnit drives `nvc` through `vu.main()` at test time — no Bazel-time
`nvc -a` runs. The consolidated library root we point
`NVC_LIBPATH` at is read-only, and nvc creates its own writable
work library inside the test sandbox and finds STD/IEEE/NVC inside
the staged libroot.
"R
PVUnitSimOutputInfo: Provider carrying source runfiles, env vars,
and CLI extras.2D
nvc_compile5@@rules_vunit//vunit/private/simulators:vunit_nvc.bzl
FF�VUnitSimNvcInfo)NVC-specific extension of `VUnitSimInfo`.2�
�
VUnitSimNvcInfo)NVC-specific extension of `VUnitSimInfo`.M
	all_files@depset[File]: All transitive runfiles required by the NVC tools.j
lib_root^File-or-None: Consolidated NVC library root TreeArtifact (or None when `vhdl_libs` was empty).,
nvc%File: The `nvc` simulator executable.�
nvc_libpath�str: Literal value to set as `NVC_LIBPATH` at sim time. Empty falls back to deriving from `lib_root`, or to nvc's compiled-in defaults."H
VUnitSimNvcInfo5@@rules_vunit//vunit/private/simulators:vunit_nvc.bzl
<<O
M
	all_files@depset[File]: All transitive runfiles required by the NVC tools.l
j
lib_root^File-or-None: Consolidated NVC library root TreeArtifact (or None when `vhdl_libs` was empty)..
,
nvc%File: The `nvc` simulator executable.�
�
nvc_libpath�str: Literal value to set as `NVC_LIBPATH` at sim time. Empty falls back to deriving from `lib_root`, or to nvc's compiled-in defaults.e
//vhdl:defs.bzlrP


rules_vhdlvhdldefs.bzl"
VhdlInfoVhdlInfo
%-
/�
.//vunit/private/simulators:vunit_sim_utils.bzlr�
<
rules_vunitvunit/private/simulatorsvunit_sim_utils.bzl*
SIM_ENV_ATTRSIM_ENV_ATTR
EQ*
VUnitSimInfoVUnitSimInfo
Ua6
VUnitSimOutputInfoVUnitSimOutputInfo
ew
yVUnit NVC simulator integration�
9
rules_vunitvunit/private/simulatorsvunit_questa.bzl�vunit_questa_sim�A simulator configuration for running [Mentor/Siemens EDA
Questa](https://eda.sw.siemens.com/en-US/ic/questa/) under VUnit.

Functionally identical to `vunit_modelsim_sim` â VUnit shares one
backend for both products. Use whichever name suits your team's
terminology.

### Status

Infrastructure only. Questa is commercial, with no BCR module and no
redistributable binary; `rules_vunit` cannot validate this rule in CI.
"�
�
vunit_questa_sim�A simulator configuration for running [Mentor/Siemens EDA
Questa](https://eda.sw.siemens.com/en-US/ic/questa/) under VUnit.

Functionally identical to `vunit_modelsim_sim` â VUnit shares one
backend for both products. Use whichever name suits your team's
terminology.

### Status

Infrastructure only. Questa is commercial, with no BCR module and no
redistributable binary; `rules_vunit` cannot validate this rule in CI.
*
nameA unique name for this target. �
env�Environment variables to set when the vunit runner invokes this simulator at test time (license-server pointers, install root vars, â¦). Precedence: toolchain `env` < sim `env` < rule-level `vunit_test(env = ...)`.
2{},
vcom The `vcom` VHDL compiler binary. .
vlib"The `vlib` library manager binary. =
vlog1The `vlog` Verilog/SystemVerilog compiler binary. (
vsimThe `vsim` simulator binary. "L
vunit_questa_sim8@@rules_vunit//vunit/private/simulators:vunit_questa.bzl
EE,
*
nameA unique name for this target. �
�
env�Environment variables to set when the vunit runner invokes this simulator at test time (license-server pointers, install root vars, â¦). Precedence: toolchain `env` < sim `env` < rule-level `vunit_test(env = ...)`.
2{}.
,
vcom The `vcom` VHDL compiler binary. 0
.
vlib"The `vlib` library manager binary. ?
=
vlog1The `vlog` Verilog/SystemVerilog compiler binary. *
(
vsimThe `vsim` simulator binary. �questa_compile6Stage HDL sources for a Questa simulation under VUnit.*�
�
questa_compile%
ctxThe rule's context object. (/
	simulatorThe `vunit_questa_sim` target. (2
	libraries!List of (lib_name, target) pairs. ()
sim_optsForwarded to VUnit's CLI. (6Stage HDL sources for a Questa simulation under VUnit."I
GVUnitSimOutputInfo: Source runfiles plus the `VUNIT_SIMULATOR` env var.2J
questa_compile8@@rules_vunit//vunit/private/simulators:vunit_questa.bzl
�VUnitSimQuestaInfo,Questa-specific extension of `VUnitSimInfo`.2�
�
VUnitSimQuestaInfo,Questa-specific extension of `VUnitSimInfo`.P
	all_filesCdepset[File]: All transitive runfiles required by the Questa tools.2
vcom*File: The `vcom` VHDL compiler executable.4
vlib,File: The `vlib` library manager executable.5
vlog-File: The `vlog` Verilog compiler executable..
vsim&File: The `vsim` simulator executable."N
VUnitSimQuestaInfo8@@rules_vunit//vunit/private/simulators:vunit_questa.bzl
R
P
	all_filesCdepset[File]: All transitive runfiles required by the Questa tools.4
2
vcom*File: The `vcom` VHDL compiler executable.6
4
vlib,File: The `vlib` library manager executable.7
5
vlog-File: The `vlog` Verilog compiler executable.0
.
vsim&File: The `vsim` simulator executable.�
.//vunit/private/simulators:vunit_sim_utils.bzlr�
<
rules_vunitvunit/private/simulatorsvunit_sim_utils.bzl*
SIM_ENV_ATTRSIM_ENV_ATTR
EQ*
VUnitSimInfoVUnitSimInfo
Ua6
VUnitSimOutputInfoVUnitSimOutputInfo
ew?
gather_library_sourcesgather_library_sources
{�
�"VUnit Questa simulator integration�;
:
rules_vunitvunit/private/simulatorsvunit_riviera.bzl�(vunit_riviera_sim�A simulator configuration for running [Aldec
Riviera-PRO](https://www.aldec.com/en/products/functional_verification/riviera-pro)
under VUnit.

### Status

Infrastructure only. Riviera-PRO is commercial, with no BCR module and
no redistributable binary; `rules_vunit` cannot validate this rule in
CI.

### Notes

Riviera-PRO accepts both Verilog/SystemVerilog (`VerilogInfo`) and VHDL
(`VhdlInfo`) modules. Sets `VUNIT_SIMULATOR=rivierapro`.
"�%
�
vunit_riviera_sim�A simulator configuration for running [Aldec
Riviera-PRO](https://www.aldec.com/en/products/functional_verification/riviera-pro)
under VUnit.

### Status

Infrastructure only. Riviera-PRO is commercial, with no BCR module and
no redistributable binary; `rules_vunit` cannot validate this rule in
CI.

### Notes

Riviera-PRO accepts both Verilog/SystemVerilog (`VerilogInfo`) and VHDL
(`VhdlInfo`) modules. Sets `VUNIT_SIMULATOR=rivierapro`.
*
nameA unique name for this target. �
coverage_args�Template fragments forwarded to `coverage_tool` after the test runs under `bazel coverage`. `{output}` is substituted with `$COVERAGE_OUTPUT_FILE`; `{data_files}` is expanded into one positional arg per file matched by `coverage_data_glob`. Only meaningful when `coverage_tool` is set.2[]�
coverage_data_glob�Shell glob (relative to the VUnit output dir) selecting the raw coverage data files `coverage_tool` consumes. For Riviera-PRO, `**/coverage.acdb` matches every per-testcase ACDB the run produces. Only meaningful when `coverage_tool` is set.2""�
coverage_tool�Optional Riviera coverage post-processor. When set AND the test runs under `bazel coverage` (Bazel populates `$COVERAGE_OUTPUT_FILE`), the rules_vunit process wrapper invokes this binary after the sim exits with the `coverage_args` template (substituting `{output}` and `{data_files}`) so it can translate the merged ACDB into lcov at `$COVERAGE_OUTPUT_FILE`. Leave unset to ship raw ACDBs under the test outputs dir without an lcov roll-up.2None�
env�Environment variables to set when the vunit runner invokes this simulator at test time (license-server pointers, install root vars, â¦). Precedence: toolchain `env` < sim `env` < rule-level `vunit_test(env = ...)`.
2{},
vcom The `vcom` VHDL compiler binary. .
vlib"The `vlib` library manager binary. v
vlistiThe `vlist` library lister binary. Invoked by `vu.main()` to enumerate compiled units in the library.cfg. =
vlog1The `vlog` Verilog/SystemVerilog compiler binary. �
vmapxThe `vmap` library-mapping binary. Invoked when external (precompiled) libraries are linked into the test's library.cfg. (
vsimThe `vsim` simulator binary. �
vsimsa�The `vsimsa` batch-shell binary. **Required**: VUnit's `RivieraProInterface.find_prefix_from_path()` rejects a toolchain directory unless BOTH `vsim` AND `vsimsa` resolve in the same dir on PATH. Omitting `vsimsa` produces a confusing `No available simulator detected` error at test time. "N
vunit_riviera_sim9@@rules_vunit//vunit/private/simulators:vunit_riviera.bzl
bb,
*
nameA unique name for this target. �
�
coverage_args�Template fragments forwarded to `coverage_tool` after the test runs under `bazel coverage`. `{output}` is substituted with `$COVERAGE_OUTPUT_FILE`; `{data_files}` is expanded into one positional arg per file matched by `coverage_data_glob`. Only meaningful when `coverage_tool` is set.2[]�
�
coverage_data_glob�Shell glob (relative to the VUnit output dir) selecting the raw coverage data files `coverage_tool` consumes. For Riviera-PRO, `**/coverage.acdb` matches every per-testcase ACDB the run produces. Only meaningful when `coverage_tool` is set.2""�
�
coverage_tool�Optional Riviera coverage post-processor. When set AND the test runs under `bazel coverage` (Bazel populates `$COVERAGE_OUTPUT_FILE`), the rules_vunit process wrapper invokes this binary after the sim exits with the `coverage_args` template (substituting `{output}` and `{data_files}`) so it can translate the merged ACDB into lcov at `$COVERAGE_OUTPUT_FILE`. Leave unset to ship raw ACDBs under the test outputs dir without an lcov roll-up.2None�
�
env�Environment variables to set when the vunit runner invokes this simulator at test time (license-server pointers, install root vars, â¦). Precedence: toolchain `env` < sim `env` < rule-level `vunit_test(env = ...)`.
2{}.
,
vcom The `vcom` VHDL compiler binary. 0
.
vlib"The `vlib` library manager binary. x
v
vlistiThe `vlist` library lister binary. Invoked by `vu.main()` to enumerate compiled units in the library.cfg. ?
=
vlog1The `vlog` Verilog/SystemVerilog compiler binary. �
�
vmapxThe `vmap` library-mapping binary. Invoked when external (precompiled) libraries are linked into the test's library.cfg. *
(
vsimThe `vsim` simulator binary. �
�
vsimsa�The `vsimsa` batch-shell binary. **Required**: VUnit's `RivieraProInterface.find_prefix_from_path()` rejects a toolchain directory unless BOTH `vsim` AND `vsimsa` resolve in the same dir on PATH. Omitting `vsimsa` produces a confusing `No available simulator detected` error at test time. �riviera_compile;Stage HDL sources for a Riviera-PRO simulation under VUnit.*�
�
riviera_compile%
ctxThe rule's context object. (0
	simulatorThe `vunit_riviera_sim` target. (2
	libraries!List of (lib_name, target) pairs. ()
sim_optsForwarded to VUnit's CLI. (;Stage HDL sources for a Riviera-PRO simulation under VUnit."I
GVUnitSimOutputInfo: Source runfiles plus the `VUNIT_SIMULATOR` env var.2L
riviera_compile9@@rules_vunit//vunit/private/simulators:vunit_riviera.bzl
�
VUnitSimRivieraInfo1Riviera-PRO-specific extension of `VUnitSimInfo`.2�

�
VUnitSimRivieraInfo1Riviera-PRO-specific extension of `VUnitSimInfo`.Q
	all_filesDdepset[File]: All transitive runfiles required by the Riviera tools.2
vcom*File: The `vcom` VHDL compiler executable.4
vlib,File: The `vlib` library manager executable.5
vlist,File: The `vlist` library lister executable.5
vlog-File: The `vlog` Verilog compiler executable.4
vmap,File: The `vmap` library-mapping executable..
vsim&File: The `vsim` simulator executable.�
vsimsa�File: The `vsimsa` batch-shell executable (required at PATH alongside `vsim` for VUnit's RivieraProInterface to detect this toolchain)."P
VUnitSimRivieraInfo9@@rules_vunit//vunit/private/simulators:vunit_riviera.bzl
S
Q
	all_filesDdepset[File]: All transitive runfiles required by the Riviera tools.4
2
vcom*File: The `vcom` VHDL compiler executable.6
4
vlib,File: The `vlib` library manager executable.7
5
vlist,File: The `vlist` library lister executable.7
5
vlog-File: The `vlog` Verilog compiler executable.6
4
vmap,File: The `vmap` library-mapping executable.0
.
vsim&File: The `vsim` simulator executable.�
�
vsimsa�File: The `vsimsa` batch-shell executable (required at PATH alongside `vsim` for VUnit's RivieraProInterface to detect this toolchain).�
.//vunit/private/simulators:vunit_sim_utils.bzlr�
<
rules_vunitvunit/private/simulatorsvunit_sim_utils.bzl*
SIM_ENV_ATTRSIM_ENV_ATTR
EQ*
VUnitSimInfoVUnitSimInfo
Ua6
VUnitSimOutputInfoVUnitSimOutputInfo
ew?
gather_library_sourcesgather_library_sources
{�
�'VUnit Riviera-PRO simulator integration�N
<
rules_vunitvunit/private/simulatorsvunit_sim_utils.bzl�
gather_library_sources�Collect transitive HDL source / data / hdr files from library targets.

Mixed-language commercial sims (Aldec Active-HDL, ModelSim,
Questa, Riviera) all need the same shape: VHDL srcs+data, or
Verilog srcs+data+hdrs (hdrs are textually included by the SV
preprocessor — they don't compile separately, but must be staged
so `\`include "foo.svh"` resolves against the include search
path threaded through the manifest by `_build_libraries_from_module`).
*�
�
gather_library_sourcesq
	libraries`list of `(lib_name, target)` pairs; each target must
provide either `VhdlInfo` or `VerilogInfo`. (�Collect transitive HDL source / data / hdr files from library targets.

Mixed-language commercial sims (Aldec Active-HDL, ModelSim,
Questa, Riviera) all need the same shape: VHDL srcs+data, or
Verilog srcs+data+hdrs (hdrs are textually included by the SV
preprocessor — they don't compile separately, but must be staged
so `\`include "foo.svh"` resolves against the include search
path threaded through the manifest by `_build_libraries_from_module`).
"g
eA `depset[File]` of all transitive sources, data files, and SV
headers reached through the libraries.2U
gather_library_sources;@@rules_vunit//vunit/private/simulators:vunit_sim_utils.bzl
�1VUnitSimInfo�Common simulator interface required by the vunit toolchain.

`VUnitSimInfo` is the *only* contract `vunit_test` and `vunit_toolchain`
depend on â any target that returns it can plug into the toolchain's
`simulators` dict. The shipped `vunit_*_sim` rules each return one (plus
their own per-simulator extension provider, e.g. `VUnitSimGhdlInfo`), but
they aren't privileged in any way.

This is the public extension point for shipping a simulator the bundled
rules don't cover, or wrapping an install shape they don't fit (vendored
tarball, system `.deb`, internal corp build, ...). Write a Starlark rule
whose impl returns `VUnitSimInfo`, drop it into a `vunit_toolchain`
under the simulator name of your choice, and `vunit_test(sim = ...)`
resolves through it.

Simulator-specific providers (`VUnitSimGhdlInfo`, `VUnitSimNvcInfo`,
etc.) are only consumed by the corresponding shipped `compile` function â
custom rules don't need to return them unless they want to reuse a
shipped `compile`.
2�)
�
VUnitSimInfo�Common simulator interface required by the vunit toolchain.

`VUnitSimInfo` is the *only* contract `vunit_test` and `vunit_toolchain`
depend on â any target that returns it can plug into the toolchain's
`simulators` dict. The shipped `vunit_*_sim` rules each return one (plus
their own per-simulator extension provider, e.g. `VUnitSimGhdlInfo`), but
they aren't privileged in any way.

This is the public extension point for shipping a simulator the bundled
rules don't cover, or wrapping an install shape they don't fit (vendored
tarball, system `.deb`, internal corp build, ...). Write a Starlark rule
whose impl returns `VUnitSimInfo`, drop it into a `vunit_toolchain`
under the simulator name of your choice, and `vunit_test(sim = ...)`
resolves through it.

Simulator-specific providers (`VUnitSimGhdlInfo`, `VUnitSimNvcInfo`,
etc.) are only consumed by the corresponding shipped `compile` function â
custom rules don't need to return them unless they want to reuse a
shipped `compile`.
M
	all_files@depset[File]: All transitive runfiles required by the simulator.�
bins�dict[str, File]: Simulator binaries to place on PATH at test time. Keys are the expected binary names (e.g. {'ghdl': <File>} or {'vsim': <File>, 'vlog': <File>, 'vcom': <File>, 'vlib': <File>}).�
compile�callable: A function with signature `compile(ctx, simulator, libraries, sim_opts) -> VUnitSimOutputInfo` that gathers and stages HDL sources for VUnit. `libraries` is a list of `(lib_name, target)` pairs.�
coverage�struct-or-None: Per-sim bridge from raw simulator coverage output to lcov for `bazel coverage`. When set AND the test is launched under `bazel coverage` (`ctx.configuration.coverage_enabled`), the process wrapper invokes the tool after the sim returns, producing lcov at `$COVERAGE_OUTPUT_FILE`. Sims without coverage support leave this `None`. Fields:
* `tool` (Target): the coverage tool target. `vunit_test` reads `tool[DefaultInfo].files_to_run.executable` for the executable path and `tool[DefaultInfo].default_runfiles` for the tool's runfiles tree â passing the target (not just the executable File) means rules_venv-based binaries get their venv_config + interpreter staged into the test runfiles.
* `args` (list[str]): args template. `{output}` is substituted with `$COVERAGE_OUTPUT_FILE`; `{data_files}` is expanded into one positional arg per file matched by `data_glob`. Other entries pass through verbatim.
* `data_glob` (str): shell glob relative to the VUnit output dir selecting the raw coverage artifacts the tool consumes (e.g. `**/*.covdb` for NVC).�
env�dict[str, str]: Environment variables this simulator needs when the vunit runner invokes it at test time (e.g. license-server pointers, install-root vars). Surfaced from the sim rule's `env` attr; defaults to `{}` when a sim integration omits it. Precedence at test time: toolchain `env` < sim `env` < rule-level `vunit_test(env = ...)`.�
name�str: The VUnit simulator name this integration declares (e.g. "ghdl", "nvc", "modelsim"). Used to populate `VUNIT_SIMULATOR` at test time."K
VUnitSimInfo;@@rules_vunit//vunit/private/simulators:vunit_sim_utils.bzl
PPO
M
	all_files@depset[File]: All transitive runfiles required by the simulator.�
�
bins�dict[str, File]: Simulator binaries to place on PATH at test time. Keys are the expected binary names (e.g. {'ghdl': <File>} or {'vsim': <File>, 'vlog': <File>, 'vcom': <File>, 'vlib': <File>}).�
�
compile�callable: A function with signature `compile(ctx, simulator, libraries, sim_opts) -> VUnitSimOutputInfo` that gathers and stages HDL sources for VUnit. `libraries` is a list of `(lib_name, target)` pairs.�
�
coverage�struct-or-None: Per-sim bridge from raw simulator coverage output to lcov for `bazel coverage`. When set AND the test is launched under `bazel coverage` (`ctx.configuration.coverage_enabled`), the process wrapper invokes the tool after the sim returns, producing lcov at `$COVERAGE_OUTPUT_FILE`. Sims without coverage support leave this `None`. Fields:
* `tool` (Target): the coverage tool target. `vunit_test` reads `tool[DefaultInfo].files_to_run.executable` for the executable path and `tool[DefaultInfo].default_runfiles` for the tool's runfiles tree â passing the target (not just the executable File) means rules_venv-based binaries get their venv_config + interpreter staged into the test runfiles.
* `args` (list[str]): args template. `{output}` is substituted with `$COVERAGE_OUTPUT_FILE`; `{data_files}` is expanded into one positional arg per file matched by `data_glob`. Other entries pass through verbatim.
* `data_glob` (str): shell glob relative to the VUnit output dir selecting the raw coverage artifacts the tool consumes (e.g. `**/*.covdb` for NVC).�
�
env�dict[str, str]: Environment variables this simulator needs when the vunit runner invokes it at test time (e.g. license-server pointers, install-root vars). Surfaced from the sim rule's `env` attr; defaults to `{}` when a sim integration omits it. Precedence at test time: toolchain `env` < sim `env` < rule-level `vunit_test(env = ...)`.�
�
name�str: The VUnit simulator name this integration declares (e.g. "ghdl", "nvc", "modelsim"). Used to populate `VUNIT_SIMULATOR` at test time.�VUnitSimOutputInfo;Per-simulator outputs returned from a `compile()` function.2�
�
VUnitSimOutputInfo;Per-simulator outputs returned from a `compile()` function.�

build_args�list[str]: Optional extra args forwarded as `VUnit.set_compile_option(...)`-style flags. Plumbed but not yet applied by the default `run.py`.�
runfiles|Runfiles: The runfiles object carrying the simulator binaries, HDL sources, and standard libraries VUnit needs at test time.�
sim_env�dict[str, str]: Environment variables to set when invoking the toolchain's
`run.py` at test time. Literal string values are set verbatim; values prefixed
with `abs:[upN:]<rlocationpath>` are resolved by the vunit process wrapper to
an absolute filesystem path, optionally walking N parent directories up (e.g.
`abs:up3:ghdl+/vhdl_libs_v08/ieee/v08/ieee-obj08.cf` resolves to the
`vhdl_libs_v08` root directory).
�
	test_args�list[str]: Optional extra args appended to the `run.py` invocation (forwarded into VUnit's CLI parser, e.g. `--gtkwave-fmt fst`)."Q
VUnitSimOutputInfo;@@rules_vunit//vunit/private/simulators:vunit_sim_utils.bzl
55�
�

build_args�list[str]: Optional extra args forwarded as `VUnit.set_compile_option(...)`-style flags. Plumbed but not yet applied by the default `run.py`.�
�
runfiles|Runfiles: The runfiles object carrying the simulator binaries, HDL sources, and standard libraries VUnit needs at test time.�
�
sim_env�dict[str, str]: Environment variables to set when invoking the toolchain's
`run.py` at test time. Literal string values are set verbatim; values prefixed
with `abs:[upN:]<rlocationpath>` are resolved by the vunit process wrapper to
an absolute filesystem path, optionally walking N parent directories up (e.g.
`abs:up3:ghdl+/vhdl_libs_v08/ieee/v08/ieee-obj08.cf` resolves to the
`vhdl_libs_v08` root directory).
�
�
	test_args�list[str]: Optional extra args appended to the `run.py` invocation (forwarded into VUnit's CLI parser, e.g. `--gtkwave-fmt fst`).t
//verilog:defs.bzlr\
"
rules_verilogverilogdefs.bzl(
VerilogInfoVerilogInfo
+6
8e
//vhdl:defs.bzlrP


rules_vhdlvhdldefs.bzl"
VhdlInfoVhdlInfo
%-
/,Common utilities for vunit simulator actions�+
@
rules_vunitvunit/private"vunit_precompiled_library_info.bzl�$VUnitPrecompiledLibraryInfo�Output of a downstream rule that materialises a simulator vendor's precompiled library set (e.g. Xilinx IP simulation libraries extracted via Vivado `export_simulation` and compiled by the simulator's own driver). The vunit test rule consumes these via its `precompiled_libs` attr; the vunit_process_wrapper patches the per-format runner to emit the vendor's link directive (`vmap -link` for Aldec, `-modelsimini` for Mentor, etc.) before VUnit's own compile step.2� 
�
VUnitPrecompiledLibraryInfo�Output of a downstream rule that materialises a simulator vendor's precompiled library set (e.g. Xilinx IP simulation libraries extracted via Vivado `export_simulation` and compiled by the simulator's own driver). The vunit test rule consumes these via its `precompiled_libs` attr; the vunit_process_wrapper patches the per-format runner to emit the vendor's link directive (`vmap -link` for Aldec, `-modelsimini` for Mentor, etc.) before VUnit's own compile step.�
format�str: precompiled-library format family. Tied to the vendor binary format and link-config syntax, not to an individual simulator. Known values: `aldec` (rivierapro, activehdl), `mentor` (questa, modelsim), `synopsys` (vcs, vcs_mx), `cadence` (xcelium, ies). One bundle works for every simulator in its family.�
library_dir�File: TreeArtifact rooted at the library set. Holds the format's link-config file at a conventional path (aldec: ./library.cfg; mentor: ./modelsim.ini; synopsys: ./synopsys_sim.setup; cadence: ./cds.lib) plus the per-library compiled artifacts the link-config references.�
links_secureip�bool: True when this bundle ships a `secureip` library that encrypted vendor primitives reference at elaboration. When set, the wrapper instructs the toolchain `run.py` to add `-L secureip` (Aldec) / equivalent to the vsim link flags so the encrypted modules resolve. Replaces the legacy `vendor='xilinx'` string check in downstream `run.py`s.�
provides_glbl�bool: True when this bundle ships the Xilinx `glbl` module needed to drive global pseudo-resets (GSR/GTS/PRLD) for Vivado-exported IP. When set, the wrapper instructs the toolchain `run.py` to add `xil_defaultlib.glbl` as a sibling simulation top. Replaces the legacy `vendor='xilinx'` string check; bundles that provide glbl elsewhere (or don't need it) can leave this False even with `vendor='xilinx'`.�
vendor�str: free-form ecosystem identifier, included in the wrapper's runtime descriptor as advisory metadata for the toolchain `run.py` (e.g. logging which vendor's libs were linked). NOT used by the wrapper for any behavioral decision â see `links_secureip` / `provides_glbl` for typed quirks. Conventional values: `xilinx`, `intel`, `microchip`, or empty for non-vendor bundles."^
VUnitPrecompiledLibraryInfo?@@rules_vunit//vunit/private:vunit_precompiled_library_info.bzl
''�
�
format�str: precompiled-library format family. Tied to the vendor binary format and link-config syntax, not to an individual simulator. Known values: `aldec` (rivierapro, activehdl), `mentor` (questa, modelsim), `synopsys` (vcs, vcs_mx), `cadence` (xcelium, ies). One bundle works for every simulator in its family.�
�
library_dir�File: TreeArtifact rooted at the library set. Holds the format's link-config file at a conventional path (aldec: ./library.cfg; mentor: ./modelsim.ini; synopsys: ./synopsys_sim.setup; cadence: ./cds.lib) plus the per-library compiled artifacts the link-config references.�
�
links_secureip�bool: True when this bundle ships a `secureip` library that encrypted vendor primitives reference at elaboration. When set, the wrapper instructs the toolchain `run.py` to add `-L secureip` (Aldec) / equivalent to the vsim link flags so the encrypted modules resolve. Replaces the legacy `vendor='xilinx'` string check in downstream `run.py`s.�
�
provides_glbl�bool: True when this bundle ships the Xilinx `glbl` module needed to drive global pseudo-resets (GSR/GTS/PRLD) for Vivado-exported IP. When set, the wrapper instructs the toolchain `run.py` to add `xil_defaultlib.glbl` as a sibling simulation top. Replaces the legacy `vendor='xilinx'` string check; bundles that provide glbl elsewhere (or don't need it) can leave this False even with `vendor='xilinx'`.�
�
vendor�str: free-form ecosystem identifier, included in the wrapper's runtime descriptor as advisory metadata for the toolchain `run.py` (e.g. logging which vendor's libs were linked). NOT used by the wrapper for any behavioral decision â see `links_secureip` / `provides_glbl` for typed quirks. Conventional values: `xilinx`, `intel`, `microchip`, or empty for non-vendor bundles.�`VUnitPrecompiledLibraryInfo` â provider for downstream-produced library sets.

Cocotb's analog (`CocotbPrecompiledLibraryInfo`) ships with `rules_cocotb`;
the VUnit equivalent serves the same role: a contract between rules_vunit's
`vunit_test` consumer and a downstream producer (e.g. a rule that compiles
Xilinx IP simulation libraries into a Riviera library set). rules_vunit owns
the contract; the producer rules live in downstream orgs because they
typically dispatch over heterogeneous build-system inputs (Vivado exports,
plain HDL libraries, vendor IP catalogs) that this ruleset can't reasonably
model upstream.

Field shapes mirror `CocotbPrecompiledLibraryInfo` exactly so a single
downstream producer rule can return both providers from the same action
(one Bazel target, one compile, two consumers).
��
2
rules_vunitvunit/privatevunit_simulators.bzl�vunit_activehdl_sim�A simulator configuration for running [Aldec
Active-HDL](https://www.aldec.com/en/products/fpga_simulation/active-hdl)
under VUnit.

### Status

Infrastructure only. Active-HDL is commercial, with no BCR module and
no redistributable binary; `rules_vunit` cannot validate this rule in
CI.

### Notes

Active-HDL accepts both Verilog/SystemVerilog (`VerilogInfo`) and VHDL
(`VhdlInfo`) modules. Sets `VUNIT_SIMULATOR=activehdl`.
"�
�
vunit_activehdl_sim�A simulator configuration for running [Aldec
Active-HDL](https://www.aldec.com/en/products/fpga_simulation/active-hdl)
under VUnit.

### Status

Infrastructure only. Active-HDL is commercial, with no BCR module and
no redistributable binary; `rules_vunit` cannot validate this rule in
CI.

### Notes

Active-HDL accepts both Verilog/SystemVerilog (`VerilogInfo`) and VHDL
(`VhdlInfo`) modules. Sets `VUNIT_SIMULATOR=activehdl`.
*
nameA unique name for this target. �
env�Environment variables to set when the vunit runner invokes this simulator at test time (license-server pointers, install root vars, â¦). Precedence: toolchain `env` < sim `env` < rule-level `vunit_test(env = ...)`.
2{},
vcom The `vcom` VHDL compiler binary. .
vlib"The `vlib` library manager binary. =
vlog1The `vlog` Verilog/SystemVerilog compiler binary. (
vsimThe `vsim` simulator binary. "H
vunit_activehdl_sim1@@rules_vunit//vunit/private:vunit_simulators.bzl
DD,
*
nameA unique name for this target. �
�
env�Environment variables to set when the vunit runner invokes this simulator at test time (license-server pointers, install root vars, â¦). Precedence: toolchain `env` < sim `env` < rule-level `vunit_test(env = ...)`.
2{}.
,
vcom The `vcom` VHDL compiler binary. 0
.
vlib"The `vlib` library manager binary. ?
=
vlog1The `vlog` Verilog/SystemVerilog compiler binary. *
(
vsimThe `vsim` simulator binary. �&vunit_ghdl_sim�	A simulator configuration for running [GHDL](https://ghdl.github.io/ghdl/)
simulations in VUnit tests.

### Status

Working against the BCR `ghdl` module from version `6.0.0.bcr.1` onward.
The backend is selectable with `--@ghdl//:backend={mcode, llvm-jit}`
(default `mcode` on x86_64, `llvm-jit` elsewhere).

### Notes

GHDL only supports VHDL (`VhdlInfo`); pair it with `vhdl_library` targets
in the `libraries` map of `vunit_test`. VUnit drives `ghdl` directly via
its `vu.main()` at test time using sources surfaced through runfiles.

The `vhdl_libs` attribute should point at the pre-compiled IEEE/std
libraries from the BCR `ghdl` module â most projects want
`["@ghdl//:vhdl_libs_v08"]`.

### Coverage

GHDL only emits coverage when built with the `gcc` backend; the BCR
`ghdl` module ships only `mcode` and `llvm-jit`, neither of which
support it. Wiring up coverage flags here would be a no-op (or
runtime error) against a stock BCR build, so this rule omits the
sim-side coverage path. The generic `VUnitSimInfo.coverage` field
remains available for downstream toolchains that point
`vunit_ghdl_sim(ghdl = ...)` at a GHDL+gcc binary and want to thread
gcov output through `bazel coverage`.
"�
�
vunit_ghdl_sim�	A simulator configuration for running [GHDL](https://ghdl.github.io/ghdl/)
simulations in VUnit tests.

### Status

Working against the BCR `ghdl` module from version `6.0.0.bcr.1` onward.
The backend is selectable with `--@ghdl//:backend={mcode, llvm-jit}`
(default `mcode` on x86_64, `llvm-jit` elsewhere).

### Notes

GHDL only supports VHDL (`VhdlInfo`); pair it with `vhdl_library` targets
in the `libraries` map of `vunit_test`. VUnit drives `ghdl` directly via
its `vu.main()` at test time using sources surfaced through runfiles.

The `vhdl_libs` attribute should point at the pre-compiled IEEE/std
libraries from the BCR `ghdl` module â most projects want
`["@ghdl//:vhdl_libs_v08"]`.

### Coverage

GHDL only emits coverage when built with the `gcc` backend; the BCR
`ghdl` module ships only `mcode` and `llvm-jit`, neither of which
support it. Wiring up coverage flags here would be a no-op (or
runtime error) against a stock BCR build, so this rule omits the
sim-side coverage path. The generic `VUnitSimInfo.coverage` field
remains available for downstream toolchains that point
`vunit_ghdl_sim(ghdl = ...)` at a GHDL+gcc binary and want to thread
gcov output through `bazel coverage`.
*
nameA unique name for this target. �
env�Environment variables to set when the vunit runner invokes this simulator at test time (license-server pointers, install root vars, â¦). Precedence: toolchain `env` < sim `env` < rule-level `vunit_test(env = ...)`.
2{}
ghdlThe `ghdl` binary. �
ghdl_prefix�Literal value to set as `GHDL_PREFIX` at simulation time. Use this for
ghdl installs where the prefix is a stable absolute path on disk â
typically a system/`.deb`/Homebrew install (e.g. `"/usr/lib/ghdl"`).

When unset (default), `GHDL_PREFIX` is auto-derived from `vhdl_libs` if
it's populated (BCR-shaped layout), otherwise left unset so ghdl falls
back to its own compiled-in search paths.
2""�
	vhdl_libs�Pre-compiled VHDL standard libraries (e.g. `@ghdl//:vhdl_libs_v08`).
**Assumes the BCR `ghdl` module's layout** â
`<root>/{std,ieee}/v<XX>/<name>-objXX.cf` â from which `GHDL_PREFIX`
is derived. If you ship ghdl differently and the IEEE/std libs are
already discoverable by the binary, leave this empty and (optionally)
set `ghdl_prefix` to a literal path, or skip both for a system install
that uses its compiled-in defaults.
2[]"C
vunit_ghdl_sim1@@rules_vunit//vunit/private:vunit_simulators.bzl
ss,
*
nameA unique name for this target. �
�
env�Environment variables to set when the vunit runner invokes this simulator at test time (license-server pointers, install root vars, â¦). Precedence: toolchain `env` < sim `env` < rule-level `vunit_test(env = ...)`.
2{} 

ghdlThe `ghdl` binary. �
�
ghdl_prefix�Literal value to set as `GHDL_PREFIX` at simulation time. Use this for
ghdl installs where the prefix is a stable absolute path on disk â
typically a system/`.deb`/Homebrew install (e.g. `"/usr/lib/ghdl"`).

When unset (default), `GHDL_PREFIX` is auto-derived from `vhdl_libs` if
it's populated (BCR-shaped layout), otherwise left unset so ghdl falls
back to its own compiled-in search paths.
2""�
�
	vhdl_libs�Pre-compiled VHDL standard libraries (e.g. `@ghdl//:vhdl_libs_v08`).
**Assumes the BCR `ghdl` module's layout** â
`<root>/{std,ieee}/v<XX>/<name>-objXX.cf` â from which `GHDL_PREFIX`
is derived. If you ship ghdl differently and the IEEE/std libs are
already discoverable by the binary, leave this empty and (optionally)
set `ghdl_prefix` to a literal path, or skip both for a system install
that uses its compiled-in defaults.
2[]�vunit_modelsim_sim�A simulator configuration for running [Mentor/Siemens EDA
ModelSim](https://eda.sw.siemens.com/en-US/ic/modelsim/) under VUnit.

VUnit shares the `modelsim` backend for both ModelSim and Questa; use
`vunit_questa_sim` if you prefer that terminology â they wire up the
same VUnit backend.

### Status

Infrastructure only. ModelSim is commercial, with no BCR module and no
redistributable binary; `rules_vunit` cannot validate this rule in CI.
Wire it up downstream by pointing the binary attrs at your own install
and registering a `vunit_toolchain` that routes `sim = "modelsim"`
through this rule.

### Notes

ModelSim accepts both Verilog/SystemVerilog (`VerilogInfo`) and VHDL
(`VhdlInfo`) modules. VUnit drives `vlib` / `vlog` / `vcom` / `vsim` via
its own runner â the rule just stages sources and surfaces the
binaries on PATH.
"�
�
vunit_modelsim_sim�A simulator configuration for running [Mentor/Siemens EDA
ModelSim](https://eda.sw.siemens.com/en-US/ic/modelsim/) under VUnit.

VUnit shares the `modelsim` backend for both ModelSim and Questa; use
`vunit_questa_sim` if you prefer that terminology â they wire up the
same VUnit backend.

### Status

Infrastructure only. ModelSim is commercial, with no BCR module and no
redistributable binary; `rules_vunit` cannot validate this rule in CI.
Wire it up downstream by pointing the binary attrs at your own install
and registering a `vunit_toolchain` that routes `sim = "modelsim"`
through this rule.

### Notes

ModelSim accepts both Verilog/SystemVerilog (`VerilogInfo`) and VHDL
(`VhdlInfo`) modules. VUnit drives `vlib` / `vlog` / `vcom` / `vsim` via
its own runner â the rule just stages sources and surfaces the
binaries on PATH.
*
nameA unique name for this target. �
env�Environment variables to set when the vunit runner invokes this simulator at test time (license-server pointers, install root vars, â¦). Precedence: toolchain `env` < sim `env` < rule-level `vunit_test(env = ...)`.
2{},
vcom The `vcom` VHDL compiler binary. .
vlib"The `vlib` library manager binary. =
vlog1The `vlog` Verilog/SystemVerilog compiler binary. (
vsimThe `vsim` simulator binary. "G
vunit_modelsim_sim1@@rules_vunit//vunit/private:vunit_simulators.bzl
DD,
*
nameA unique name for this target. �
�
env�Environment variables to set when the vunit runner invokes this simulator at test time (license-server pointers, install root vars, â¦). Precedence: toolchain `env` < sim `env` < rule-level `vunit_test(env = ...)`.
2{}.
,
vcom The `vcom` VHDL compiler binary. 0
.
vlib"The `vlib` library manager binary. ?
=
vlog1The `vlog` Verilog/SystemVerilog compiler binary. *
(
vsimThe `vsim` simulator binary. �'vunit_nvc_sim�
A simulator configuration for running [NVC](https://www.nickg.me.uk/nvc/)
(open-source VHDL simulator) under VUnit.

### Status

Working against the BCR `nvc` module from version `1.21.0` onward.

### Notes

NVC only supports VHDL (`VhdlInfo`); pair it with `vhdl_library` targets
in the `libraries` map of `vunit_test`. VUnit drives `nvc` directly via
its `vu.main()` at test time using sources surfaced through runfiles.

`vhdl_libs` accepts a list of per-library TreeArtifact targets â
typically `["@nvc//:vhdl_libs"]`, the BCR `nvc` module's filegroup of
per-library directories laid out exactly like a system install under
`<prefix>/lib/nvc/<library>/`. The rule's implementation stages those
TreeArtifacts side-by-side under a single root and points
`NVC_LIBPATH` at it so nvc finds every shipped library (STD, IEEE,
NVC, plus the SYNOPSYS / VITAL extras inside IEEE) at simulation
time.

### Coverage

VUnit has no NVC coverage integration upstream â `vu.set_sim_option`
exposes `nvc.elab_flags`/`nvc.sim_flags`/`nvc.a_flags`, but there's
no shipped recipe for routing NVC's `--cover` instrumentation through
those, and `nvc --cover-export` only emits Cobertura. Rather than
invent a sim-side path here, this rule omits coverage. The generic
`VUnitSimInfo.coverage` field stays available for the commercial
simulators (Mentor UCDB, Aldec ACDB) where a real bridge exists.
"�
�
vunit_nvc_sim�
A simulator configuration for running [NVC](https://www.nickg.me.uk/nvc/)
(open-source VHDL simulator) under VUnit.

### Status

Working against the BCR `nvc` module from version `1.21.0` onward.

### Notes

NVC only supports VHDL (`VhdlInfo`); pair it with `vhdl_library` targets
in the `libraries` map of `vunit_test`. VUnit drives `nvc` directly via
its `vu.main()` at test time using sources surfaced through runfiles.

`vhdl_libs` accepts a list of per-library TreeArtifact targets â
typically `["@nvc//:vhdl_libs"]`, the BCR `nvc` module's filegroup of
per-library directories laid out exactly like a system install under
`<prefix>/lib/nvc/<library>/`. The rule's implementation stages those
TreeArtifacts side-by-side under a single root and points
`NVC_LIBPATH` at it so nvc finds every shipped library (STD, IEEE,
NVC, plus the SYNOPSYS / VITAL extras inside IEEE) at simulation
time.

### Coverage

VUnit has no NVC coverage integration upstream â `vu.set_sim_option`
exposes `nvc.elab_flags`/`nvc.sim_flags`/`nvc.a_flags`, but there's
no shipped recipe for routing NVC's `--cover` instrumentation through
those, and `nvc --cover-export` only emits Cobertura. Rather than
invent a sim-side path here, this rule omits coverage. The generic
`VUnitSimInfo.coverage` field stays available for the commercial
simulators (Mentor UCDB, Aldec ACDB) where a real bridge exists.
*
nameA unique name for this target. �
env�Environment variables to set when the vunit runner invokes this simulator at test time (license-server pointers, install root vars, â¦). Precedence: toolchain `env` < sim `env` < rule-level `vunit_test(env = ...)`.
2{}&
nvcThe `nvc` simulator binary. �
nvc_libpath�Literal value to set as `NVC_LIBPATH` at simulation time. Use this
for nvc installs where the prefix is a stable absolute path on disk â
typically a system / `.deb` / Homebrew install
(e.g. `"/usr/local/lib/nvc"`).

When unset (default), `NVC_LIBPATH` is auto-derived from `vhdl_libs`
if it's populated (per-library TreeArtifacts staged into one root by
this rule), otherwise left unset so nvc falls back to its own
compiled-in search paths.
2""�
	vhdl_libs�Per-library TreeArtifact targets to stage side-by-side under a
single `NVC_LIBPATH` root. Typically `["@nvc//:vhdl_libs"]` â the
BCR `nvc` module's filegroup of per-library directories. Empty (the
default) leaves `NVC_LIBPATH` unset.
2[]"B
vunit_nvc_sim1@@rules_vunit//vunit/private:vunit_simulators.bzl
��,
*
nameA unique name for this target. �
�
env�Environment variables to set when the vunit runner invokes this simulator at test time (license-server pointers, install root vars, â¦). Precedence: toolchain `env` < sim `env` < rule-level `vunit_test(env = ...)`.
2{}(
&
nvcThe `nvc` simulator binary. �
�
nvc_libpath�Literal value to set as `NVC_LIBPATH` at simulation time. Use this
for nvc installs where the prefix is a stable absolute path on disk â
typically a system / `.deb` / Homebrew install
(e.g. `"/usr/local/lib/nvc"`).

When unset (default), `NVC_LIBPATH` is auto-derived from `vhdl_libs`
if it's populated (per-library TreeArtifacts staged into one root by
this rule), otherwise left unset so nvc falls back to its own
compiled-in search paths.
2""�
�
	vhdl_libs�Per-library TreeArtifact targets to stage side-by-side under a
single `NVC_LIBPATH` root. Typically `["@nvc//:vhdl_libs"]` â the
BCR `nvc` module's filegroup of per-library directories. Empty (the
default) leaves `NVC_LIBPATH` unset.
2[]�vunit_questa_sim�A simulator configuration for running [Mentor/Siemens EDA
Questa](https://eda.sw.siemens.com/en-US/ic/questa/) under VUnit.

Functionally identical to `vunit_modelsim_sim` â VUnit shares one
backend for both products. Use whichever name suits your team's
terminology.

### Status

Infrastructure only. Questa is commercial, with no BCR module and no
redistributable binary; `rules_vunit` cannot validate this rule in CI.
"�
�
vunit_questa_sim�A simulator configuration for running [Mentor/Siemens EDA
Questa](https://eda.sw.siemens.com/en-US/ic/questa/) under VUnit.

Functionally identical to `vunit_modelsim_sim` â VUnit shares one
backend for both products. Use whichever name suits your team's
terminology.

### Status

Infrastructure only. Questa is commercial, with no BCR module and no
redistributable binary; `rules_vunit` cannot validate this rule in CI.
*
nameA unique name for this target. �
env�Environment variables to set when the vunit runner invokes this simulator at test time (license-server pointers, install root vars, â¦). Precedence: toolchain `env` < sim `env` < rule-level `vunit_test(env = ...)`.
2{},
vcom The `vcom` VHDL compiler binary. .
vlib"The `vlib` library manager binary. =
vlog1The `vlog` Verilog/SystemVerilog compiler binary. (
vsimThe `vsim` simulator binary. "E
vunit_questa_sim1@@rules_vunit//vunit/private:vunit_simulators.bzl
EE,
*
nameA unique name for this target. �
�
env�Environment variables to set when the vunit runner invokes this simulator at test time (license-server pointers, install root vars, â¦). Precedence: toolchain `env` < sim `env` < rule-level `vunit_test(env = ...)`.
2{}.
,
vcom The `vcom` VHDL compiler binary. 0
.
vlib"The `vlib` library manager binary. ?
=
vlog1The `vlog` Verilog/SystemVerilog compiler binary. *
(
vsimThe `vsim` simulator binary. �(vunit_riviera_sim�A simulator configuration for running [Aldec
Riviera-PRO](https://www.aldec.com/en/products/functional_verification/riviera-pro)
under VUnit.

### Status

Infrastructure only. Riviera-PRO is commercial, with no BCR module and
no redistributable binary; `rules_vunit` cannot validate this rule in
CI.

### Notes

Riviera-PRO accepts both Verilog/SystemVerilog (`VerilogInfo`) and VHDL
(`VhdlInfo`) modules. Sets `VUNIT_SIMULATOR=rivierapro`.
"�%
�
vunit_riviera_sim�A simulator configuration for running [Aldec
Riviera-PRO](https://www.aldec.com/en/products/functional_verification/riviera-pro)
under VUnit.

### Status

Infrastructure only. Riviera-PRO is commercial, with no BCR module and
no redistributable binary; `rules_vunit` cannot validate this rule in
CI.

### Notes

Riviera-PRO accepts both Verilog/SystemVerilog (`VerilogInfo`) and VHDL
(`VhdlInfo`) modules. Sets `VUNIT_SIMULATOR=rivierapro`.
*
nameA unique name for this target. �
coverage_args�Template fragments forwarded to `coverage_tool` after the test runs under `bazel coverage`. `{output}` is substituted with `$COVERAGE_OUTPUT_FILE`; `{data_files}` is expanded into one positional arg per file matched by `coverage_data_glob`. Only meaningful when `coverage_tool` is set.2[]�
coverage_data_glob�Shell glob (relative to the VUnit output dir) selecting the raw coverage data files `coverage_tool` consumes. For Riviera-PRO, `**/coverage.acdb` matches every per-testcase ACDB the run produces. Only meaningful when `coverage_tool` is set.2""�
coverage_tool�Optional Riviera coverage post-processor. When set AND the test runs under `bazel coverage` (Bazel populates `$COVERAGE_OUTPUT_FILE`), the rules_vunit process wrapper invokes this binary after the sim exits with the `coverage_args` template (substituting `{output}` and `{data_files}`) so it can translate the merged ACDB into lcov at `$COVERAGE_OUTPUT_FILE`. Leave unset to ship raw ACDBs under the test outputs dir without an lcov roll-up.2None�
env�Environment variables to set when the vunit runner invokes this simulator at test time (license-server pointers, install root vars, â¦). Precedence: toolchain `env` < sim `env` < rule-level `vunit_test(env = ...)`.
2{},
vcom The `vcom` VHDL compiler binary. .
vlib"The `vlib` library manager binary. v
vlistiThe `vlist` library lister binary. Invoked by `vu.main()` to enumerate compiled units in the library.cfg. =
vlog1The `vlog` Verilog/SystemVerilog compiler binary. �
vmapxThe `vmap` library-mapping binary. Invoked when external (precompiled) libraries are linked into the test's library.cfg. (
vsimThe `vsim` simulator binary. �
vsimsa�The `vsimsa` batch-shell binary. **Required**: VUnit's `RivieraProInterface.find_prefix_from_path()` rejects a toolchain directory unless BOTH `vsim` AND `vsimsa` resolve in the same dir on PATH. Omitting `vsimsa` produces a confusing `No available simulator detected` error at test time. "F
vunit_riviera_sim1@@rules_vunit//vunit/private:vunit_simulators.bzl
bb,
*
nameA unique name for this target. �
�
coverage_args�Template fragments forwarded to `coverage_tool` after the test runs under `bazel coverage`. `{output}` is substituted with `$COVERAGE_OUTPUT_FILE`; `{data_files}` is expanded into one positional arg per file matched by `coverage_data_glob`. Only meaningful when `coverage_tool` is set.2[]�
�
coverage_data_glob�Shell glob (relative to the VUnit output dir) selecting the raw coverage data files `coverage_tool` consumes. For Riviera-PRO, `**/coverage.acdb` matches every per-testcase ACDB the run produces. Only meaningful when `coverage_tool` is set.2""�
�
coverage_tool�Optional Riviera coverage post-processor. When set AND the test runs under `bazel coverage` (Bazel populates `$COVERAGE_OUTPUT_FILE`), the rules_vunit process wrapper invokes this binary after the sim exits with the `coverage_args` template (substituting `{output}` and `{data_files}`) so it can translate the merged ACDB into lcov at `$COVERAGE_OUTPUT_FILE`. Leave unset to ship raw ACDBs under the test outputs dir without an lcov roll-up.2None�
�
env�Environment variables to set when the vunit runner invokes this simulator at test time (license-server pointers, install root vars, â¦). Precedence: toolchain `env` < sim `env` < rule-level `vunit_test(env = ...)`.
2{}.
,
vcom The `vcom` VHDL compiler binary. 0
.
vlib"The `vlib` library manager binary. x
v
vlistiThe `vlist` library lister binary. Invoked by `vu.main()` to enumerate compiled units in the library.cfg. ?
=
vlog1The `vlog` Verilog/SystemVerilog compiler binary. �
�
vmapxThe `vmap` library-mapping binary. Invoked when external (precompiled) libraries are linked into the test's library.cfg. *
(
vsimThe `vsim` simulator binary. �
�
vsimsa�The `vsimsa` batch-shell binary. **Required**: VUnit's `RivieraProInterface.find_prefix_from_path()` rejects a toolchain directory unless BOTH `vsim` AND `vsimsa` resolve in the same dir on PATH. Omitting `vsimsa` produces a confusing `No available simulator detected` error at test time. �vunit_sim_compile�Dispatch source-gathering to the simulator's compile function via its provider.

Each `vunit_*_sim` target carries a `VUnitSimInfo` provider whose `compile`
field references the simulator-specific compile function. This dispatcher
simply calls it, removing the need for a static mapping of simulator names
to functions.
*�
�
vunit_sim_compile%
ctxThe rule's context object. (G
	simulator6The `vunit_*_sim` target that provides `VUnitSimInfo`. (_
kwargsSArguments forwarded to the compile function (typically
`libraries` and `sim_opts`).(�Dispatch source-gathering to the simulator's compile function via its provider.

Each `vunit_*_sim` target carries a `VUnitSimInfo` provider whose `compile`
field references the simulator-specific compile function. This dispatcher
simply calls it, removing the need for a static mapping of simulator names
to functions.
"5
3VUnitSimOutputInfo: The simulator's compile output.2F
vunit_sim_compile1@@rules_vunit//vunit/private:vunit_simulators.bzl
66�VUnitSimActiveHdlInfo0Active-HDL-specific extension of `VUnitSimInfo`.2�
�
VUnitSimActiveHdlInfo0Active-HDL-specific extension of `VUnitSimInfo`.T
	all_filesGdepset[File]: All transitive runfiles required by the Active-HDL tools.2
vcom*File: The `vcom` VHDL compiler executable.4
vlib,File: The `vlib` library manager executable.5
vlog-File: The `vlog` Verilog compiler executable..
vsim&File: The `vsim` simulator executable."J
VUnitSimActiveHdlInfo1@@rules_vunit//vunit/private:vunit_simulators.bzl
!!V
T
	all_filesGdepset[File]: All transitive runfiles required by the Active-HDL tools.4
2
vcom*File: The `vcom` VHDL compiler executable.6
4
vlib,File: The `vlib` library manager executable.7
5
vlog-File: The `vlog` Verilog compiler executable.0
.
vsim&File: The `vsim` simulator executable.�VUnitSimGhdlInfo*GHDL-specific extension of `VUnitSimInfo`.2�
�
VUnitSimGhdlInfo*GHDL-specific extension of `VUnitSimInfo`.N
	all_filesAdepset[File]: All transitive runfiles required by the GHDL tools.$
ghdlFile: The `ghdl` executable.�
ghdl_prefix�str: Literal value to set as `GHDL_PREFIX` at sim time. Empty falls back to deriving from `vhdl_libs` (BCR layout) or to ghdl's compiled-in defaults.h
	vhdl_libs[depset[File]: Pre-compiled VHDL standard library files for GHDL_PREFIX (BCR-shaped layout)."E
VUnitSimGhdlInfo1@@rules_vunit//vunit/private:vunit_simulators.bzl
P
N
	all_filesAdepset[File]: All transitive runfiles required by the GHDL tools.&
$
ghdlFile: The `ghdl` executable.�
�
ghdl_prefix�str: Literal value to set as `GHDL_PREFIX` at sim time. Empty falls back to deriving from `vhdl_libs` (BCR layout) or to ghdl's compiled-in defaults.j
h
	vhdl_libs[depset[File]: Pre-compiled VHDL standard library files for GHDL_PREFIX (BCR-shaped layout).�1VUnitSimInfo�Common simulator interface required by the vunit toolchain.

`VUnitSimInfo` is the *only* contract `vunit_test` and `vunit_toolchain`
depend on â any target that returns it can plug into the toolchain's
`simulators` dict. The shipped `vunit_*_sim` rules each return one (plus
their own per-simulator extension provider, e.g. `VUnitSimGhdlInfo`), but
they aren't privileged in any way.

This is the public extension point for shipping a simulator the bundled
rules don't cover, or wrapping an install shape they don't fit (vendored
tarball, system `.deb`, internal corp build, ...). Write a Starlark rule
whose impl returns `VUnitSimInfo`, drop it into a `vunit_toolchain`
under the simulator name of your choice, and `vunit_test(sim = ...)`
resolves through it.

Simulator-specific providers (`VUnitSimGhdlInfo`, `VUnitSimNvcInfo`,
etc.) are only consumed by the corresponding shipped `compile` function â
custom rules don't need to return them unless they want to reuse a
shipped `compile`.
2�)
�
VUnitSimInfo�Common simulator interface required by the vunit toolchain.

`VUnitSimInfo` is the *only* contract `vunit_test` and `vunit_toolchain`
depend on â any target that returns it can plug into the toolchain's
`simulators` dict. The shipped `vunit_*_sim` rules each return one (plus
their own per-simulator extension provider, e.g. `VUnitSimGhdlInfo`), but
they aren't privileged in any way.

This is the public extension point for shipping a simulator the bundled
rules don't cover, or wrapping an install shape they don't fit (vendored
tarball, system `.deb`, internal corp build, ...). Write a Starlark rule
whose impl returns `VUnitSimInfo`, drop it into a `vunit_toolchain`
under the simulator name of your choice, and `vunit_test(sim = ...)`
resolves through it.

Simulator-specific providers (`VUnitSimGhdlInfo`, `VUnitSimNvcInfo`,
etc.) are only consumed by the corresponding shipped `compile` function â
custom rules don't need to return them unless they want to reuse a
shipped `compile`.
M
	all_files@depset[File]: All transitive runfiles required by the simulator.�
bins�dict[str, File]: Simulator binaries to place on PATH at test time. Keys are the expected binary names (e.g. {'ghdl': <File>} or {'vsim': <File>, 'vlog': <File>, 'vcom': <File>, 'vlib': <File>}).�
compile�callable: A function with signature `compile(ctx, simulator, libraries, sim_opts) -> VUnitSimOutputInfo` that gathers and stages HDL sources for VUnit. `libraries` is a list of `(lib_name, target)` pairs.�
coverage�struct-or-None: Per-sim bridge from raw simulator coverage output to lcov for `bazel coverage`. When set AND the test is launched under `bazel coverage` (`ctx.configuration.coverage_enabled`), the process wrapper invokes the tool after the sim returns, producing lcov at `$COVERAGE_OUTPUT_FILE`. Sims without coverage support leave this `None`. Fields:
* `tool` (Target): the coverage tool target. `vunit_test` reads `tool[DefaultInfo].files_to_run.executable` for the executable path and `tool[DefaultInfo].default_runfiles` for the tool's runfiles tree â passing the target (not just the executable File) means rules_venv-based binaries get their venv_config + interpreter staged into the test runfiles.
* `args` (list[str]): args template. `{output}` is substituted with `$COVERAGE_OUTPUT_FILE`; `{data_files}` is expanded into one positional arg per file matched by `data_glob`. Other entries pass through verbatim.
* `data_glob` (str): shell glob relative to the VUnit output dir selecting the raw coverage artifacts the tool consumes (e.g. `**/*.covdb` for NVC).�
env�dict[str, str]: Environment variables this simulator needs when the vunit runner invokes it at test time (e.g. license-server pointers, install-root vars). Surfaced from the sim rule's `env` attr; defaults to `{}` when a sim integration omits it. Precedence at test time: toolchain `env` < sim `env` < rule-level `vunit_test(env = ...)`.�
name�str: The VUnit simulator name this integration declares (e.g. "ghdl", "nvc", "modelsim"). Used to populate `VUNIT_SIMULATOR` at test time."A
VUnitSimInfo1@@rules_vunit//vunit/private:vunit_simulators.bzl
PPO
M
	all_files@depset[File]: All transitive runfiles required by the simulator.�
�
bins�dict[str, File]: Simulator binaries to place on PATH at test time. Keys are the expected binary names (e.g. {'ghdl': <File>} or {'vsim': <File>, 'vlog': <File>, 'vcom': <File>, 'vlib': <File>}).�
�
compile�callable: A function with signature `compile(ctx, simulator, libraries, sim_opts) -> VUnitSimOutputInfo` that gathers and stages HDL sources for VUnit. `libraries` is a list of `(lib_name, target)` pairs.�
�
coverage�struct-or-None: Per-sim bridge from raw simulator coverage output to lcov for `bazel coverage`. When set AND the test is launched under `bazel coverage` (`ctx.configuration.coverage_enabled`), the process wrapper invokes the tool after the sim returns, producing lcov at `$COVERAGE_OUTPUT_FILE`. Sims without coverage support leave this `None`. Fields:
* `tool` (Target): the coverage tool target. `vunit_test` reads `tool[DefaultInfo].files_to_run.executable` for the executable path and `tool[DefaultInfo].default_runfiles` for the tool's runfiles tree â passing the target (not just the executable File) means rules_venv-based binaries get their venv_config + interpreter staged into the test runfiles.
* `args` (list[str]): args template. `{output}` is substituted with `$COVERAGE_OUTPUT_FILE`; `{data_files}` is expanded into one positional arg per file matched by `data_glob`. Other entries pass through verbatim.
* `data_glob` (str): shell glob relative to the VUnit output dir selecting the raw coverage artifacts the tool consumes (e.g. `**/*.covdb` for NVC).�
�
env�dict[str, str]: Environment variables this simulator needs when the vunit runner invokes it at test time (e.g. license-server pointers, install-root vars). Surfaced from the sim rule's `env` attr; defaults to `{}` when a sim integration omits it. Precedence at test time: toolchain `env` < sim `env` < rule-level `vunit_test(env = ...)`.�
�
name�str: The VUnit simulator name this integration declares (e.g. "ghdl", "nvc", "modelsim"). Used to populate `VUNIT_SIMULATOR` at test time.�VUnitSimModelsimInfo.ModelSim-specific extension of `VUnitSimInfo`.2�
�
VUnitSimModelsimInfo.ModelSim-specific extension of `VUnitSimInfo`.R
	all_filesEdepset[File]: All transitive runfiles required by the ModelSim tools.2
vcom*File: The `vcom` VHDL compiler executable.4
vlib,File: The `vlib` library manager executable.5
vlog-File: The `vlog` Verilog compiler executable..
vsim&File: The `vsim` simulator executable."I
VUnitSimModelsimInfo1@@rules_vunit//vunit/private:vunit_simulators.bzl
  T
R
	all_filesEdepset[File]: All transitive runfiles required by the ModelSim tools.4
2
vcom*File: The `vcom` VHDL compiler executable.6
4
vlib,File: The `vlib` library manager executable.7
5
vlog-File: The `vlog` Verilog compiler executable.0
.
vsim&File: The `vsim` simulator executable.�VUnitSimNvcInfo)NVC-specific extension of `VUnitSimInfo`.2�
�
VUnitSimNvcInfo)NVC-specific extension of `VUnitSimInfo`.M
	all_files@depset[File]: All transitive runfiles required by the NVC tools.j
lib_root^File-or-None: Consolidated NVC library root TreeArtifact (or None when `vhdl_libs` was empty).,
nvc%File: The `nvc` simulator executable.�
nvc_libpath�str: Literal value to set as `NVC_LIBPATH` at sim time. Empty falls back to deriving from `lib_root`, or to nvc's compiled-in defaults."D
VUnitSimNvcInfo1@@rules_vunit//vunit/private:vunit_simulators.bzl
<<O
M
	all_files@depset[File]: All transitive runfiles required by the NVC tools.l
j
lib_root^File-or-None: Consolidated NVC library root TreeArtifact (or None when `vhdl_libs` was empty)..
,
nvc%File: The `nvc` simulator executable.�
�
nvc_libpath�str: Literal value to set as `NVC_LIBPATH` at sim time. Empty falls back to deriving from `lib_root`, or to nvc's compiled-in defaults.�VUnitSimOutputInfo;Per-simulator outputs returned from a `compile()` function.2�
�
VUnitSimOutputInfo;Per-simulator outputs returned from a `compile()` function.�

build_args�list[str]: Optional extra args forwarded as `VUnit.set_compile_option(...)`-style flags. Plumbed but not yet applied by the default `run.py`.�
runfiles|Runfiles: The runfiles object carrying the simulator binaries, HDL sources, and standard libraries VUnit needs at test time.�
sim_env�dict[str, str]: Environment variables to set when invoking the toolchain's
`run.py` at test time. Literal string values are set verbatim; values prefixed
with `abs:[upN:]<rlocationpath>` are resolved by the vunit process wrapper to
an absolute filesystem path, optionally walking N parent directories up (e.g.
`abs:up3:ghdl+/vhdl_libs_v08/ieee/v08/ieee-obj08.cf` resolves to the
`vhdl_libs_v08` root directory).
�
	test_args�list[str]: Optional extra args appended to the `run.py` invocation (forwarded into VUnit's CLI parser, e.g. `--gtkwave-fmt fst`)."G
VUnitSimOutputInfo1@@rules_vunit//vunit/private:vunit_simulators.bzl
55�
�

build_args�list[str]: Optional extra args forwarded as `VUnit.set_compile_option(...)`-style flags. Plumbed but not yet applied by the default `run.py`.�
�
runfiles|Runfiles: The runfiles object carrying the simulator binaries, HDL sources, and standard libraries VUnit needs at test time.�
�
sim_env�dict[str, str]: Environment variables to set when invoking the toolchain's
`run.py` at test time. Literal string values are set verbatim; values prefixed
with `abs:[upN:]<rlocationpath>` are resolved by the vunit process wrapper to
an absolute filesystem path, optionally walking N parent directories up (e.g.
`abs:up3:ghdl+/vhdl_libs_v08/ieee/v08/ieee-obj08.cf` resolves to the
`vhdl_libs_v08` root directory).
�
�
	test_args�list[str]: Optional extra args appended to the `run.py` invocation (forwarded into VUnit's CLI parser, e.g. `--gtkwave-fmt fst`).�VUnitSimQuestaInfo,Questa-specific extension of `VUnitSimInfo`.2�
�
VUnitSimQuestaInfo,Questa-specific extension of `VUnitSimInfo`.P
	all_filesCdepset[File]: All transitive runfiles required by the Questa tools.2
vcom*File: The `vcom` VHDL compiler executable.4
vlib,File: The `vlib` library manager executable.5
vlog-File: The `vlog` Verilog compiler executable..
vsim&File: The `vsim` simulator executable."G
VUnitSimQuestaInfo1@@rules_vunit//vunit/private:vunit_simulators.bzl
R
P
	all_filesCdepset[File]: All transitive runfiles required by the Questa tools.4
2
vcom*File: The `vcom` VHDL compiler executable.6
4
vlib,File: The `vlib` library manager executable.7
5
vlog-File: The `vlog` Verilog compiler executable.0
.
vsim&File: The `vsim` simulator executable.�
VUnitSimRivieraInfo1Riviera-PRO-specific extension of `VUnitSimInfo`.2�

�
VUnitSimRivieraInfo1Riviera-PRO-specific extension of `VUnitSimInfo`.Q
	all_filesDdepset[File]: All transitive runfiles required by the Riviera tools.2
vcom*File: The `vcom` VHDL compiler executable.4
vlib,File: The `vlib` library manager executable.5
vlist,File: The `vlist` library lister executable.5
vlog-File: The `vlog` Verilog compiler executable.4
vmap,File: The `vmap` library-mapping executable..
vsim&File: The `vsim` simulator executable.�
vsimsa�File: The `vsimsa` batch-shell executable (required at PATH alongside `vsim` for VUnit's RivieraProInterface to detect this toolchain)."H
VUnitSimRivieraInfo1@@rules_vunit//vunit/private:vunit_simulators.bzl
S
Q
	all_filesDdepset[File]: All transitive runfiles required by the Riviera tools.4
2
vcom*File: The `vcom` VHDL compiler executable.6
4
vlib,File: The `vlib` library manager executable.7
5
vlist,File: The `vlist` library lister executable.7
5
vlog-File: The `vlog` Verilog compiler executable.6
4
vmap,File: The `vmap` library-mapping executable.0
.
vsim&File: The `vsim` simulator executable.�
�
vsimsa�File: The `vsimsa` batch-shell executable (required at PATH alongside `vsim` for VUnit's RivieraProInterface to detect this toolchain).�
.//vunit/private/simulators:vunit_activehdl.bzlr�
<
rules_vunitvunit/private/simulatorsvunit_activehdl.bzl=
VUnitSimActiveHdlInfo_VUnitSimActiveHdlInfo
9
vunit_activehdl_sim_vunit_activehdl_sim

�
)//vunit/private/simulators:vunit_ghdl.bzlr�
7
rules_vunitvunit/private/simulatorsvunit_ghdl.bzl3
VUnitSimGhdlInfo_VUnitSimGhdlInfo


/
vunit_ghdl_sim_vunit_ghdl_sim

�
-//vunit/private/simulators:vunit_modelsim.bzlr�
;
rules_vunitvunit/private/simulatorsvunit_modelsim.bzl;
VUnitSimModelsimInfo_VUnitSimModelsimInfo
7
vunit_modelsim_sim_vunit_modelsim_sim

�
(//vunit/private/simulators:vunit_nvc.bzlr�
6
rules_vunitvunit/private/simulatorsvunit_nvc.bzl1
VUnitSimNvcInfo_VUnitSimNvcInfo
-
vunit_nvc_sim_vunit_nvc_sim

�
+//vunit/private/simulators:vunit_questa.bzlr�
9
rules_vunitvunit/private/simulatorsvunit_questa.bzl7
VUnitSimQuestaInfo_VUnitSimQuestaInfo
3
vunit_questa_sim_vunit_questa_sim

�
,//vunit/private/simulators:vunit_riviera.bzlr�
:
rules_vunitvunit/private/simulatorsvunit_riviera.bzl9
VUnitSimRivieraInfo_VUnitSimRivieraInfo
5
vunit_riviera_sim_vunit_riviera_sim

 �
.//vunit/private/simulators:vunit_sim_utils.bzlr�
<
rules_vunitvunit/private/simulatorsvunit_sim_utils.bzl+
VUnitSimInfo_VUnitSimInfo
##7
VUnitSimOutputInfo_VUnitSimOutputInfo
$$
!%VUnit simulator dispatch�G
1
rules_vunitvunit/privatevunit_toolchain.bzl�current_vunit_toolchain_libEMatch and expose the `vunit_toolchain` for the current configuration."�
�
current_vunit_toolchain_libEMatch and expose the `vunit_toolchain` for the current configuration.*
nameA unique name for this target. "O
current_vunit_toolchain_lib0@@rules_vunit//vunit/private:vunit_toolchain.bzl
�#�#,
*
nameA unique name for this target. �Avunit_toolchain�Define a toolchain for `vunit_*` rules.

The toolchain bundles a `vunit` Python library, a set of HDL simulators
that `vunit_test` targets can select between via their `sim` attribute,
and the orchestration `run.py` the rule invokes at test time. Register
an instance with the standard `toolchain(...)` wrapper to make it
discoverable.

### Registering simulators

Each entry in `simulators` is a `vunit_*_sim` target keyed by the
*string* name that `vunit_test(sim = ...)` will use to select it.
Names are user-chosen â common conventions are `"ghdl"`, `"nvc"`,
`"modelsim"`, `"questa"`. Each name must be unique within the dict.

```python
load("@rules_vunit//vunit:vunit_ghdl_sim.bzl", "vunit_ghdl_sim")
load("@rules_vunit//vunit:vunit_toolchain.bzl", "vunit_toolchain")

vunit_ghdl_sim(
    name = "vunit_ghdl",
    ghdl = "@ghdl",
    vhdl_libs = ["@ghdl//:vhdl_libs_v08"],
)

vunit_toolchain(
    name = "my_vunit_toolchain",
    vunit = "//path/to:vunit_py_library",
    default_sim = "ghdl",
    simulators = {":vunit_ghdl": "ghdl"},
    # run_py defaults to //tools/rules_vunit_run:rules_vunit_run.py.
)

toolchain(
    name = "my_toolchain",
    toolchain = ":my_vunit_toolchain",
    toolchain_type = "@rules_vunit//vunit:toolchain_type",
)
```

Add `register_toolchains("//path/to:my_toolchain")` to `MODULE.bazel`
ahead of `//vunit/toolchain` to override the default. `default_sim`
chooses which simulator runs when a `vunit_test` omits its own `sim`
attribute; it's optional, but if set must name one of the keys in
`simulators`.

### Customising `run.py`

The default `run.py` (shipped at
`//tools/rules_vunit_run:rules_vunit_run.py`) reads a JSON descriptor
from `VUNIT_LIBRARIES_JSON`, declares each library with
`vu.add_library(...)` / `lib.add_source_file(...)`, and calls
`vu.main()`. Override it via the `run_py` attribute when you need extra
configuration â custom test attributes, `set_sim_option(...)` calls,
`post_run` hooks, etc. The wrapper always sets:

* `VUNIT_LIBRARIES_JSON` â path to the resolved library/sources JSON.
* `VUNIT_OUTPUT_PATH` â sandboxed directory to pass as `-o`.
* `VUNIT_XUNIT_XML` â path to write the xunit XML to (pass as `-x`).

The script runs inside the venv composed by the `vunit_test` rule:
`toolchain.vunit` is on `sys.path`, plus anything the test pulls in via
its own `deps` attribute. So a custom `run.py` just needs to `import
vunit` and any helper packages declared on the test target.

The default driver's plumbing is also exposed as a Python library â
`from rules_vunit_run import load_manifest,
ensure_vunit_verilog_path_is_plus_free, vunit_builtin_verilog_include_dir,
configure_coverage` â so a custom `run.py` can reuse the manifest
loader, the bzlmod `+`-in-path workaround for Aldec, and the coverage
hook instead of vendoring them. Add
`@rules_vunit//tools/rules_vunit_run` to the test target's `deps` to
make the import resolve.

Per-simulator API and wiring details live in the
[Simulators](./simulators.md) section.
"�)
� 
vunit_toolchain�Define a toolchain for `vunit_*` rules.

The toolchain bundles a `vunit` Python library, a set of HDL simulators
that `vunit_test` targets can select between via their `sim` attribute,
and the orchestration `run.py` the rule invokes at test time. Register
an instance with the standard `toolchain(...)` wrapper to make it
discoverable.

### Registering simulators

Each entry in `simulators` is a `vunit_*_sim` target keyed by the
*string* name that `vunit_test(sim = ...)` will use to select it.
Names are user-chosen â common conventions are `"ghdl"`, `"nvc"`,
`"modelsim"`, `"questa"`. Each name must be unique within the dict.

```python
load("@rules_vunit//vunit:vunit_ghdl_sim.bzl", "vunit_ghdl_sim")
load("@rules_vunit//vunit:vunit_toolchain.bzl", "vunit_toolchain")

vunit_ghdl_sim(
    name = "vunit_ghdl",
    ghdl = "@ghdl",
    vhdl_libs = ["@ghdl//:vhdl_libs_v08"],
)

vunit_toolchain(
    name = "my_vunit_toolchain",
    vunit = "//path/to:vunit_py_library",
    default_sim = "ghdl",
    simulators = {":vunit_ghdl": "ghdl"},
    # run_py defaults to //tools/rules_vunit_run:rules_vunit_run.py.
)

toolchain(
    name = "my_toolchain",
    toolchain = ":my_vunit_toolchain",
    toolchain_type = "@rules_vunit//vunit:toolchain_type",
)
```

Add `register_toolchains("//path/to:my_toolchain")` to `MODULE.bazel`
ahead of `//vunit/toolchain` to override the default. `default_sim`
chooses which simulator runs when a `vunit_test` omits its own `sim`
attribute; it's optional, but if set must name one of the keys in
`simulators`.

### Customising `run.py`

The default `run.py` (shipped at
`//tools/rules_vunit_run:rules_vunit_run.py`) reads a JSON descriptor
from `VUNIT_LIBRARIES_JSON`, declares each library with
`vu.add_library(...)` / `lib.add_source_file(...)`, and calls
`vu.main()`. Override it via the `run_py` attribute when you need extra
configuration â custom test attributes, `set_sim_option(...)` calls,
`post_run` hooks, etc. The wrapper always sets:

* `VUNIT_LIBRARIES_JSON` â path to the resolved library/sources JSON.
* `VUNIT_OUTPUT_PATH` â sandboxed directory to pass as `-o`.
* `VUNIT_XUNIT_XML` â path to write the xunit XML to (pass as `-x`).

The script runs inside the venv composed by the `vunit_test` rule:
`toolchain.vunit` is on `sys.path`, plus anything the test pulls in via
its own `deps` attribute. So a custom `run.py` just needs to `import
vunit` and any helper packages declared on the test target.

The default driver's plumbing is also exposed as a Python library â
`from rules_vunit_run import load_manifest,
ensure_vunit_verilog_path_is_plus_free, vunit_builtin_verilog_include_dir,
configure_coverage` â so a custom `run.py` can reuse the manifest
loader, the bzlmod `+`-in-path workaround for Aldec, and the coverage
hook instead of vendoring them. Add
`@rules_vunit//tools/rules_vunit_run` to the test target's `deps` to
make the import resolve.

Per-simulator API and wiring details live in the
[Simulators](./simulators.md) section.
*
nameA unique name for this target. :
default_sim%An optional default simulator to use.2""�
env�Environment variables to set whenever the toolchain invokes a simulator. Applied to every sim registered in `simulators`; for sim-specific vars (license server, install root, etc.) prefer the per-`vunit_*_sim` `env` attr instead. Precedence at test time: toolchain `env` < sim `env` < rule-level `vunit_test(env = ...)`.
2{}�
run_py�The Python orchestration script the `vunit_test` rule invokes. Defaults to a shipped driver that wires VUnit up from a JSON library descriptor; override with your own `.py` when you need custom orchestration (hooks, per-test attributes, etc.). Python deps for the script come from the toolchain's `vunit` py_library plus the test's `deps` â both are stitched into the venv that runs the script.2*//tools/rules_vunit_run:rules_vunit_run.py�

simulatorsoA mapping of `vunit_*_sim` targets to their matching simulator names. Every target must provide `VUnitSimInfo`.	 *
VUnitSimInfo2
vunitThe `vunit` python library. *
PyInfo"C
vunit_toolchain0@@rules_vunit//vunit/private:vunit_toolchain.bzl
,
*
nameA unique name for this target. <
:
default_sim%An optional default simulator to use.2""�
�
env�Environment variables to set whenever the toolchain invokes a simulator. Applied to every sim registered in `simulators`; for sim-specific vars (license server, install root, etc.) prefer the per-`vunit_*_sim` `env` attr instead. Precedence at test time: toolchain `env` < sim `env` < rule-level `vunit_test(env = ...)`.
2{}�
�
run_py�The Python orchestration script the `vunit_test` rule invokes. Defaults to a shipped driver that wires VUnit up from a JSON library descriptor; override with your own `.py` when you need custom orchestration (hooks, per-test attributes, etc.). Python deps for the script come from the toolchain's `vunit` py_library plus the test's `deps` â both are stitched into the venv that runs the script.2*//tools/rules_vunit_run:rules_vunit_run.py�
�

simulatorsoA mapping of `vunit_*_sim` targets to their matching simulator names. Every target must provide `VUnitSimInfo`.	 *
VUnitSimInfo4
2
vunitThe `vunit` python library. *
PyInfok
//python:py_info.bzlrQ
!

rules_venvpythonpy_info.bzl
PyInfoPyInfo
*0
2�
$//vunit/private:vunit_simulators.bzlrn
2
rules_vunitvunit/privatevunit_simulators.bzl*
VUnitSimInfoVUnitSimInfo
;G
Ivunit toolchain rulesٛ

rules_vunitvunitdefs.bzl�vunit_activehdl_sim�A simulator configuration for running [Aldec
Active-HDL](https://www.aldec.com/en/products/fpga_simulation/active-hdl)
under VUnit.

### Status

Infrastructure only. Active-HDL is commercial, with no BCR module and
no redistributable binary; `rules_vunit` cannot validate this rule in
CI.

### Notes

Active-HDL accepts both Verilog/SystemVerilog (`VerilogInfo`) and VHDL
(`VhdlInfo`) modules. Sets `VUNIT_SIMULATOR=activehdl`.
"�
�
vunit_activehdl_sim�A simulator configuration for running [Aldec
Active-HDL](https://www.aldec.com/en/products/fpga_simulation/active-hdl)
under VUnit.

### Status

Infrastructure only. Active-HDL is commercial, with no BCR module and
no redistributable binary; `rules_vunit` cannot validate this rule in
CI.

### Notes

Active-HDL accepts both Verilog/SystemVerilog (`VerilogInfo`) and VHDL
(`VhdlInfo`) modules. Sets `VUNIT_SIMULATOR=activehdl`.
*
nameA unique name for this target. �
env�Environment variables to set when the vunit runner invokes this simulator at test time (license-server pointers, install root vars, â¦). Precedence: toolchain `env` < sim `env` < rule-level `vunit_test(env = ...)`.
2{},
vcom The `vcom` VHDL compiler binary. .
vlib"The `vlib` library manager binary. =
vlog1The `vlog` Verilog/SystemVerilog compiler binary. (
vsimThe `vsim` simulator binary. "4
vunit_activehdl_sim@@rules_vunit//vunit:defs.bzl
DD,
*
nameA unique name for this target. �
�
env�Environment variables to set when the vunit runner invokes this simulator at test time (license-server pointers, install root vars, â¦). Precedence: toolchain `env` < sim `env` < rule-level `vunit_test(env = ...)`.
2{}.
,
vcom The `vcom` VHDL compiler binary. 0
.
vlib"The `vlib` library manager binary. ?
=
vlog1The `vlog` Verilog/SystemVerilog compiler binary. *
(
vsimThe `vsim` simulator binary. �&vunit_ghdl_sim�	A simulator configuration for running [GHDL](https://ghdl.github.io/ghdl/)
simulations in VUnit tests.

### Status

Working against the BCR `ghdl` module from version `6.0.0.bcr.1` onward.
The backend is selectable with `--@ghdl//:backend={mcode, llvm-jit}`
(default `mcode` on x86_64, `llvm-jit` elsewhere).

### Notes

GHDL only supports VHDL (`VhdlInfo`); pair it with `vhdl_library` targets
in the `libraries` map of `vunit_test`. VUnit drives `ghdl` directly via
its `vu.main()` at test time using sources surfaced through runfiles.

The `vhdl_libs` attribute should point at the pre-compiled IEEE/std
libraries from the BCR `ghdl` module â most projects want
`["@ghdl//:vhdl_libs_v08"]`.

### Coverage

GHDL only emits coverage when built with the `gcc` backend; the BCR
`ghdl` module ships only `mcode` and `llvm-jit`, neither of which
support it. Wiring up coverage flags here would be a no-op (or
runtime error) against a stock BCR build, so this rule omits the
sim-side coverage path. The generic `VUnitSimInfo.coverage` field
remains available for downstream toolchains that point
`vunit_ghdl_sim(ghdl = ...)` at a GHDL+gcc binary and want to thread
gcov output through `bazel coverage`.
"�
�
vunit_ghdl_sim�	A simulator configuration for running [GHDL](https://ghdl.github.io/ghdl/)
simulations in VUnit tests.

### Status

Working against the BCR `ghdl` module from version `6.0.0.bcr.1` onward.
The backend is selectable with `--@ghdl//:backend={mcode, llvm-jit}`
(default `mcode` on x86_64, `llvm-jit` elsewhere).

### Notes

GHDL only supports VHDL (`VhdlInfo`); pair it with `vhdl_library` targets
in the `libraries` map of `vunit_test`. VUnit drives `ghdl` directly via
its `vu.main()` at test time using sources surfaced through runfiles.

The `vhdl_libs` attribute should point at the pre-compiled IEEE/std
libraries from the BCR `ghdl` module â most projects want
`["@ghdl//:vhdl_libs_v08"]`.

### Coverage

GHDL only emits coverage when built with the `gcc` backend; the BCR
`ghdl` module ships only `mcode` and `llvm-jit`, neither of which
support it. Wiring up coverage flags here would be a no-op (or
runtime error) against a stock BCR build, so this rule omits the
sim-side coverage path. The generic `VUnitSimInfo.coverage` field
remains available for downstream toolchains that point
`vunit_ghdl_sim(ghdl = ...)` at a GHDL+gcc binary and want to thread
gcov output through `bazel coverage`.
*
nameA unique name for this target. �
env�Environment variables to set when the vunit runner invokes this simulator at test time (license-server pointers, install root vars, â¦). Precedence: toolchain `env` < sim `env` < rule-level `vunit_test(env = ...)`.
2{}
ghdlThe `ghdl` binary. �
ghdl_prefix�Literal value to set as `GHDL_PREFIX` at simulation time. Use this for
ghdl installs where the prefix is a stable absolute path on disk â
typically a system/`.deb`/Homebrew install (e.g. `"/usr/lib/ghdl"`).

When unset (default), `GHDL_PREFIX` is auto-derived from `vhdl_libs` if
it's populated (BCR-shaped layout), otherwise left unset so ghdl falls
back to its own compiled-in search paths.
2""�
	vhdl_libs�Pre-compiled VHDL standard libraries (e.g. `@ghdl//:vhdl_libs_v08`).
**Assumes the BCR `ghdl` module's layout** â
`<root>/{std,ieee}/v<XX>/<name>-objXX.cf` â from which `GHDL_PREFIX`
is derived. If you ship ghdl differently and the IEEE/std libs are
already discoverable by the binary, leave this empty and (optionally)
set `ghdl_prefix` to a literal path, or skip both for a system install
that uses its compiled-in defaults.
2[]"/
vunit_ghdl_sim@@rules_vunit//vunit:defs.bzl
ss,
*
nameA unique name for this target. �
�
env�Environment variables to set when the vunit runner invokes this simulator at test time (license-server pointers, install root vars, â¦). Precedence: toolchain `env` < sim `env` < rule-level `vunit_test(env = ...)`.
2{} 

ghdlThe `ghdl` binary. �
�
ghdl_prefix�Literal value to set as `GHDL_PREFIX` at simulation time. Use this for
ghdl installs where the prefix is a stable absolute path on disk â
typically a system/`.deb`/Homebrew install (e.g. `"/usr/lib/ghdl"`).

When unset (default), `GHDL_PREFIX` is auto-derived from `vhdl_libs` if
it's populated (BCR-shaped layout), otherwise left unset so ghdl falls
back to its own compiled-in search paths.
2""�
�
	vhdl_libs�Pre-compiled VHDL standard libraries (e.g. `@ghdl//:vhdl_libs_v08`).
**Assumes the BCR `ghdl` module's layout** â
`<root>/{std,ieee}/v<XX>/<name>-objXX.cf` â from which `GHDL_PREFIX`
is derived. If you ship ghdl differently and the IEEE/std libs are
already discoverable by the binary, leave this empty and (optionally)
set `ghdl_prefix` to a literal path, or skip both for a system install
that uses its compiled-in defaults.
2[]�vunit_modelsim_sim�A simulator configuration for running [Mentor/Siemens EDA
ModelSim](https://eda.sw.siemens.com/en-US/ic/modelsim/) under VUnit.

VUnit shares the `modelsim` backend for both ModelSim and Questa; use
`vunit_questa_sim` if you prefer that terminology â they wire up the
same VUnit backend.

### Status

Infrastructure only. ModelSim is commercial, with no BCR module and no
redistributable binary; `rules_vunit` cannot validate this rule in CI.
Wire it up downstream by pointing the binary attrs at your own install
and registering a `vunit_toolchain` that routes `sim = "modelsim"`
through this rule.

### Notes

ModelSim accepts both Verilog/SystemVerilog (`VerilogInfo`) and VHDL
(`VhdlInfo`) modules. VUnit drives `vlib` / `vlog` / `vcom` / `vsim` via
its own runner â the rule just stages sources and surfaces the
binaries on PATH.
"�
�

vunit_modelsim_sim�A simulator configuration for running [Mentor/Siemens EDA
ModelSim](https://eda.sw.siemens.com/en-US/ic/modelsim/) under VUnit.

VUnit shares the `modelsim` backend for both ModelSim and Questa; use
`vunit_questa_sim` if you prefer that terminology â they wire up the
same VUnit backend.

### Status

Infrastructure only. ModelSim is commercial, with no BCR module and no
redistributable binary; `rules_vunit` cannot validate this rule in CI.
Wire it up downstream by pointing the binary attrs at your own install
and registering a `vunit_toolchain` that routes `sim = "modelsim"`
through this rule.

### Notes

ModelSim accepts both Verilog/SystemVerilog (`VerilogInfo`) and VHDL
(`VhdlInfo`) modules. VUnit drives `vlib` / `vlog` / `vcom` / `vsim` via
its own runner â the rule just stages sources and surfaces the
binaries on PATH.
*
nameA unique name for this target. �
env�Environment variables to set when the vunit runner invokes this simulator at test time (license-server pointers, install root vars, â¦). Precedence: toolchain `env` < sim `env` < rule-level `vunit_test(env = ...)`.
2{},
vcom The `vcom` VHDL compiler binary. .
vlib"The `vlib` library manager binary. =
vlog1The `vlog` Verilog/SystemVerilog compiler binary. (
vsimThe `vsim` simulator binary. "3
vunit_modelsim_sim@@rules_vunit//vunit:defs.bzl
DD,
*
nameA unique name for this target. �
�
env�Environment variables to set when the vunit runner invokes this simulator at test time (license-server pointers, install root vars, â¦). Precedence: toolchain `env` < sim `env` < rule-level `vunit_test(env = ...)`.
2{}.
,
vcom The `vcom` VHDL compiler binary. 0
.
vlib"The `vlib` library manager binary. ?
=
vlog1The `vlog` Verilog/SystemVerilog compiler binary. *
(
vsimThe `vsim` simulator binary. �'vunit_nvc_sim�
A simulator configuration for running [NVC](https://www.nickg.me.uk/nvc/)
(open-source VHDL simulator) under VUnit.

### Status

Working against the BCR `nvc` module from version `1.21.0` onward.

### Notes

NVC only supports VHDL (`VhdlInfo`); pair it with `vhdl_library` targets
in the `libraries` map of `vunit_test`. VUnit drives `nvc` directly via
its `vu.main()` at test time using sources surfaced through runfiles.

`vhdl_libs` accepts a list of per-library TreeArtifact targets â
typically `["@nvc//:vhdl_libs"]`, the BCR `nvc` module's filegroup of
per-library directories laid out exactly like a system install under
`<prefix>/lib/nvc/<library>/`. The rule's implementation stages those
TreeArtifacts side-by-side under a single root and points
`NVC_LIBPATH` at it so nvc finds every shipped library (STD, IEEE,
NVC, plus the SYNOPSYS / VITAL extras inside IEEE) at simulation
time.

### Coverage

VUnit has no NVC coverage integration upstream â `vu.set_sim_option`
exposes `nvc.elab_flags`/`nvc.sim_flags`/`nvc.a_flags`, but there's
no shipped recipe for routing NVC's `--cover` instrumentation through
those, and `nvc --cover-export` only emits Cobertura. Rather than
invent a sim-side path here, this rule omits coverage. The generic
`VUnitSimInfo.coverage` field stays available for the commercial
simulators (Mentor UCDB, Aldec ACDB) where a real bridge exists.
"�
�
vunit_nvc_sim�
A simulator configuration for running [NVC](https://www.nickg.me.uk/nvc/)
(open-source VHDL simulator) under VUnit.

### Status

Working against the BCR `nvc` module from version `1.21.0` onward.

### Notes

NVC only supports VHDL (`VhdlInfo`); pair it with `vhdl_library` targets
in the `libraries` map of `vunit_test`. VUnit drives `nvc` directly via
its `vu.main()` at test time using sources surfaced through runfiles.

`vhdl_libs` accepts a list of per-library TreeArtifact targets â
typically `["@nvc//:vhdl_libs"]`, the BCR `nvc` module's filegroup of
per-library directories laid out exactly like a system install under
`<prefix>/lib/nvc/<library>/`. The rule's implementation stages those
TreeArtifacts side-by-side under a single root and points
`NVC_LIBPATH` at it so nvc finds every shipped library (STD, IEEE,
NVC, plus the SYNOPSYS / VITAL extras inside IEEE) at simulation
time.

### Coverage

VUnit has no NVC coverage integration upstream â `vu.set_sim_option`
exposes `nvc.elab_flags`/`nvc.sim_flags`/`nvc.a_flags`, but there's
no shipped recipe for routing NVC's `--cover` instrumentation through
those, and `nvc --cover-export` only emits Cobertura. Rather than
invent a sim-side path here, this rule omits coverage. The generic
`VUnitSimInfo.coverage` field stays available for the commercial
simulators (Mentor UCDB, Aldec ACDB) where a real bridge exists.
*
nameA unique name for this target. �
env�Environment variables to set when the vunit runner invokes this simulator at test time (license-server pointers, install root vars, â¦). Precedence: toolchain `env` < sim `env` < rule-level `vunit_test(env = ...)`.
2{}&
nvcThe `nvc` simulator binary. �
nvc_libpath�Literal value to set as `NVC_LIBPATH` at simulation time. Use this
for nvc installs where the prefix is a stable absolute path on disk â
typically a system / `.deb` / Homebrew install
(e.g. `"/usr/local/lib/nvc"`).

When unset (default), `NVC_LIBPATH` is auto-derived from `vhdl_libs`
if it's populated (per-library TreeArtifacts staged into one root by
this rule), otherwise left unset so nvc falls back to its own
compiled-in search paths.
2""�
	vhdl_libs�Per-library TreeArtifact targets to stage side-by-side under a
single `NVC_LIBPATH` root. Typically `["@nvc//:vhdl_libs"]` â the
BCR `nvc` module's filegroup of per-library directories. Empty (the
default) leaves `NVC_LIBPATH` unset.
2[]".
vunit_nvc_sim@@rules_vunit//vunit:defs.bzl
��,
*
nameA unique name for this target. �
�
env�Environment variables to set when the vunit runner invokes this simulator at test time (license-server pointers, install root vars, â¦). Precedence: toolchain `env` < sim `env` < rule-level `vunit_test(env = ...)`.
2{}(
&
nvcThe `nvc` simulator binary. �
�
nvc_libpath�Literal value to set as `NVC_LIBPATH` at simulation time. Use this
for nvc installs where the prefix is a stable absolute path on disk â
typically a system / `.deb` / Homebrew install
(e.g. `"/usr/local/lib/nvc"`).

When unset (default), `NVC_LIBPATH` is auto-derived from `vhdl_libs`
if it's populated (per-library TreeArtifacts staged into one root by
this rule), otherwise left unset so nvc falls back to its own
compiled-in search paths.
2""�
�
	vhdl_libs�Per-library TreeArtifact targets to stage side-by-side under a
single `NVC_LIBPATH` root. Typically `["@nvc//:vhdl_libs"]` â the
BCR `nvc` module's filegroup of per-library directories. Empty (the
default) leaves `NVC_LIBPATH` unset.
2[]�vunit_questa_sim�A simulator configuration for running [Mentor/Siemens EDA
Questa](https://eda.sw.siemens.com/en-US/ic/questa/) under VUnit.

Functionally identical to `vunit_modelsim_sim` â VUnit shares one
backend for both products. Use whichever name suits your team's
terminology.

### Status

Infrastructure only. Questa is commercial, with no BCR module and no
redistributable binary; `rules_vunit` cannot validate this rule in CI.
"�
�
vunit_questa_sim�A simulator configuration for running [Mentor/Siemens EDA
Questa](https://eda.sw.siemens.com/en-US/ic/questa/) under VUnit.

Functionally identical to `vunit_modelsim_sim` â VUnit shares one
backend for both products. Use whichever name suits your team's
terminology.

### Status

Infrastructure only. Questa is commercial, with no BCR module and no
redistributable binary; `rules_vunit` cannot validate this rule in CI.
*
nameA unique name for this target. �
env�Environment variables to set when the vunit runner invokes this simulator at test time (license-server pointers, install root vars, â¦). Precedence: toolchain `env` < sim `env` < rule-level `vunit_test(env = ...)`.
2{},
vcom The `vcom` VHDL compiler binary. .
vlib"The `vlib` library manager binary. =
vlog1The `vlog` Verilog/SystemVerilog compiler binary. (
vsimThe `vsim` simulator binary. "1
vunit_questa_sim@@rules_vunit//vunit:defs.bzl
EE,
*
nameA unique name for this target. �
�
env�Environment variables to set when the vunit runner invokes this simulator at test time (license-server pointers, install root vars, â¦). Precedence: toolchain `env` < sim `env` < rule-level `vunit_test(env = ...)`.
2{}.
,
vcom The `vcom` VHDL compiler binary. 0
.
vlib"The `vlib` library manager binary. ?
=
vlog1The `vlog` Verilog/SystemVerilog compiler binary. *
(
vsimThe `vsim` simulator binary. �(vunit_riviera_sim�A simulator configuration for running [Aldec
Riviera-PRO](https://www.aldec.com/en/products/functional_verification/riviera-pro)
under VUnit.

### Status

Infrastructure only. Riviera-PRO is commercial, with no BCR module and
no redistributable binary; `rules_vunit` cannot validate this rule in
CI.

### Notes

Riviera-PRO accepts both Verilog/SystemVerilog (`VerilogInfo`) and VHDL
(`VhdlInfo`) modules. Sets `VUNIT_SIMULATOR=rivierapro`.
"�%
�
vunit_riviera_sim�A simulator configuration for running [Aldec
Riviera-PRO](https://www.aldec.com/en/products/functional_verification/riviera-pro)
under VUnit.

### Status

Infrastructure only. Riviera-PRO is commercial, with no BCR module and
no redistributable binary; `rules_vunit` cannot validate this rule in
CI.

### Notes

Riviera-PRO accepts both Verilog/SystemVerilog (`VerilogInfo`) and VHDL
(`VhdlInfo`) modules. Sets `VUNIT_SIMULATOR=rivierapro`.
*
nameA unique name for this target. �
coverage_args�Template fragments forwarded to `coverage_tool` after the test runs under `bazel coverage`. `{output}` is substituted with `$COVERAGE_OUTPUT_FILE`; `{data_files}` is expanded into one positional arg per file matched by `coverage_data_glob`. Only meaningful when `coverage_tool` is set.2[]�
coverage_data_glob�Shell glob (relative to the VUnit output dir) selecting the raw coverage data files `coverage_tool` consumes. For Riviera-PRO, `**/coverage.acdb` matches every per-testcase ACDB the run produces. Only meaningful when `coverage_tool` is set.2""�
coverage_tool�Optional Riviera coverage post-processor. When set AND the test runs under `bazel coverage` (Bazel populates `$COVERAGE_OUTPUT_FILE`), the rules_vunit process wrapper invokes this binary after the sim exits with the `coverage_args` template (substituting `{output}` and `{data_files}`) so it can translate the merged ACDB into lcov at `$COVERAGE_OUTPUT_FILE`. Leave unset to ship raw ACDBs under the test outputs dir without an lcov roll-up.2None�
env�Environment variables to set when the vunit runner invokes this simulator at test time (license-server pointers, install root vars, â¦). Precedence: toolchain `env` < sim `env` < rule-level `vunit_test(env = ...)`.
2{},
vcom The `vcom` VHDL compiler binary. .
vlib"The `vlib` library manager binary. v
vlistiThe `vlist` library lister binary. Invoked by `vu.main()` to enumerate compiled units in the library.cfg. =
vlog1The `vlog` Verilog/SystemVerilog compiler binary. �
vmapxThe `vmap` library-mapping binary. Invoked when external (precompiled) libraries are linked into the test's library.cfg. (
vsimThe `vsim` simulator binary. �
vsimsa�The `vsimsa` batch-shell binary. **Required**: VUnit's `RivieraProInterface.find_prefix_from_path()` rejects a toolchain directory unless BOTH `vsim` AND `vsimsa` resolve in the same dir on PATH. Omitting `vsimsa` produces a confusing `No available simulator detected` error at test time. "2
vunit_riviera_sim@@rules_vunit//vunit:defs.bzl
bb,
*
nameA unique name for this target. �
�
coverage_args�Template fragments forwarded to `coverage_tool` after the test runs under `bazel coverage`. `{output}` is substituted with `$COVERAGE_OUTPUT_FILE`; `{data_files}` is expanded into one positional arg per file matched by `coverage_data_glob`. Only meaningful when `coverage_tool` is set.2[]�
�
coverage_data_glob�Shell glob (relative to the VUnit output dir) selecting the raw coverage data files `coverage_tool` consumes. For Riviera-PRO, `**/coverage.acdb` matches every per-testcase ACDB the run produces. Only meaningful when `coverage_tool` is set.2""�
�
coverage_tool�Optional Riviera coverage post-processor. When set AND the test runs under `bazel coverage` (Bazel populates `$COVERAGE_OUTPUT_FILE`), the rules_vunit process wrapper invokes this binary after the sim exits with the `coverage_args` template (substituting `{output}` and `{data_files}`) so it can translate the merged ACDB into lcov at `$COVERAGE_OUTPUT_FILE`. Leave unset to ship raw ACDBs under the test outputs dir without an lcov roll-up.2None�
�
env�Environment variables to set when the vunit runner invokes this simulator at test time (license-server pointers, install root vars, â¦). Precedence: toolchain `env` < sim `env` < rule-level `vunit_test(env = ...)`.
2{}.
,
vcom The `vcom` VHDL compiler binary. 0
.
vlib"The `vlib` library manager binary. x
v
vlistiThe `vlist` library lister binary. Invoked by `vu.main()` to enumerate compiled units in the library.cfg. ?
=
vlog1The `vlog` Verilog/SystemVerilog compiler binary. �
�
vmapxThe `vmap` library-mapping binary. Invoked when external (precompiled) libraries are linked into the test's library.cfg. *
(
vsimThe `vsim` simulator binary. �
�
vsimsa�The `vsimsa` batch-shell binary. **Required**: VUnit's `RivieraProInterface.find_prefix_from_path()` rejects a toolchain directory unless BOTH `vsim` AND `vsimsa` resolve in the same dir on PATH. Omitting `vsimsa` produces a confusing `No available simulator detected` error at test time. �Avunit_toolchain�Define a toolchain for `vunit_*` rules.

The toolchain bundles a `vunit` Python library, a set of HDL simulators
that `vunit_test` targets can select between via their `sim` attribute,
and the orchestration `run.py` the rule invokes at test time. Register
an instance with the standard `toolchain(...)` wrapper to make it
discoverable.

### Registering simulators

Each entry in `simulators` is a `vunit_*_sim` target keyed by the
*string* name that `vunit_test(sim = ...)` will use to select it.
Names are user-chosen â common conventions are `"ghdl"`, `"nvc"`,
`"modelsim"`, `"questa"`. Each name must be unique within the dict.

```python
load("@rules_vunit//vunit:vunit_ghdl_sim.bzl", "vunit_ghdl_sim")
load("@rules_vunit//vunit:vunit_toolchain.bzl", "vunit_toolchain")

vunit_ghdl_sim(
    name = "vunit_ghdl",
    ghdl = "@ghdl",
    vhdl_libs = ["@ghdl//:vhdl_libs_v08"],
)

vunit_toolchain(
    name = "my_vunit_toolchain",
    vunit = "//path/to:vunit_py_library",
    default_sim = "ghdl",
    simulators = {":vunit_ghdl": "ghdl"},
    # run_py defaults to //tools/rules_vunit_run:rules_vunit_run.py.
)

toolchain(
    name = "my_toolchain",
    toolchain = ":my_vunit_toolchain",
    toolchain_type = "@rules_vunit//vunit:toolchain_type",
)
```

Add `register_toolchains("//path/to:my_toolchain")` to `MODULE.bazel`
ahead of `//vunit/toolchain` to override the default. `default_sim`
chooses which simulator runs when a `vunit_test` omits its own `sim`
attribute; it's optional, but if set must name one of the keys in
`simulators`.

### Customising `run.py`

The default `run.py` (shipped at
`//tools/rules_vunit_run:rules_vunit_run.py`) reads a JSON descriptor
from `VUNIT_LIBRARIES_JSON`, declares each library with
`vu.add_library(...)` / `lib.add_source_file(...)`, and calls
`vu.main()`. Override it via the `run_py` attribute when you need extra
configuration â custom test attributes, `set_sim_option(...)` calls,
`post_run` hooks, etc. The wrapper always sets:

* `VUNIT_LIBRARIES_JSON` â path to the resolved library/sources JSON.
* `VUNIT_OUTPUT_PATH` â sandboxed directory to pass as `-o`.
* `VUNIT_XUNIT_XML` â path to write the xunit XML to (pass as `-x`).

The script runs inside the venv composed by the `vunit_test` rule:
`toolchain.vunit` is on `sys.path`, plus anything the test pulls in via
its own `deps` attribute. So a custom `run.py` just needs to `import
vunit` and any helper packages declared on the test target.

The default driver's plumbing is also exposed as a Python library â
`from rules_vunit_run import load_manifest,
ensure_vunit_verilog_path_is_plus_free, vunit_builtin_verilog_include_dir,
configure_coverage` â so a custom `run.py` can reuse the manifest
loader, the bzlmod `+`-in-path workaround for Aldec, and the coverage
hook instead of vendoring them. Add
`@rules_vunit//tools/rules_vunit_run` to the test target's `deps` to
make the import resolve.

Per-simulator API and wiring details live in the
[Simulators](./simulators.md) section.
"�)
� 
vunit_toolchain�Define a toolchain for `vunit_*` rules.

The toolchain bundles a `vunit` Python library, a set of HDL simulators
that `vunit_test` targets can select between via their `sim` attribute,
and the orchestration `run.py` the rule invokes at test time. Register
an instance with the standard `toolchain(...)` wrapper to make it
discoverable.

### Registering simulators

Each entry in `simulators` is a `vunit_*_sim` target keyed by the
*string* name that `vunit_test(sim = ...)` will use to select it.
Names are user-chosen â common conventions are `"ghdl"`, `"nvc"`,
`"modelsim"`, `"questa"`. Each name must be unique within the dict.

```python
load("@rules_vunit//vunit:vunit_ghdl_sim.bzl", "vunit_ghdl_sim")
load("@rules_vunit//vunit:vunit_toolchain.bzl", "vunit_toolchain")

vunit_ghdl_sim(
    name = "vunit_ghdl",
    ghdl = "@ghdl",
    vhdl_libs = ["@ghdl//:vhdl_libs_v08"],
)

vunit_toolchain(
    name = "my_vunit_toolchain",
    vunit = "//path/to:vunit_py_library",
    default_sim = "ghdl",
    simulators = {":vunit_ghdl": "ghdl"},
    # run_py defaults to //tools/rules_vunit_run:rules_vunit_run.py.
)

toolchain(
    name = "my_toolchain",
    toolchain = ":my_vunit_toolchain",
    toolchain_type = "@rules_vunit//vunit:toolchain_type",
)
```

Add `register_toolchains("//path/to:my_toolchain")` to `MODULE.bazel`
ahead of `//vunit/toolchain` to override the default. `default_sim`
chooses which simulator runs when a `vunit_test` omits its own `sim`
attribute; it's optional, but if set must name one of the keys in
`simulators`.

### Customising `run.py`

The default `run.py` (shipped at
`//tools/rules_vunit_run:rules_vunit_run.py`) reads a JSON descriptor
from `VUNIT_LIBRARIES_JSON`, declares each library with
`vu.add_library(...)` / `lib.add_source_file(...)`, and calls
`vu.main()`. Override it via the `run_py` attribute when you need extra
configuration â custom test attributes, `set_sim_option(...)` calls,
`post_run` hooks, etc. The wrapper always sets:

* `VUNIT_LIBRARIES_JSON` â path to the resolved library/sources JSON.
* `VUNIT_OUTPUT_PATH` â sandboxed directory to pass as `-o`.
* `VUNIT_XUNIT_XML` â path to write the xunit XML to (pass as `-x`).

The script runs inside the venv composed by the `vunit_test` rule:
`toolchain.vunit` is on `sys.path`, plus anything the test pulls in via
its own `deps` attribute. So a custom `run.py` just needs to `import
vunit` and any helper packages declared on the test target.

The default driver's plumbing is also exposed as a Python library â
`from rules_vunit_run import load_manifest,
ensure_vunit_verilog_path_is_plus_free, vunit_builtin_verilog_include_dir,
configure_coverage` â so a custom `run.py` can reuse the manifest
loader, the bzlmod `+`-in-path workaround for Aldec, and the coverage
hook instead of vendoring them. Add
`@rules_vunit//tools/rules_vunit_run` to the test target's `deps` to
make the import resolve.

Per-simulator API and wiring details live in the
[Simulators](./simulators.md) section.
*
nameA unique name for this target. :
default_sim%An optional default simulator to use.2""�
env�Environment variables to set whenever the toolchain invokes a simulator. Applied to every sim registered in `simulators`; for sim-specific vars (license server, install root, etc.) prefer the per-`vunit_*_sim` `env` attr instead. Precedence at test time: toolchain `env` < sim `env` < rule-level `vunit_test(env = ...)`.
2{}�
run_py�The Python orchestration script the `vunit_test` rule invokes. Defaults to a shipped driver that wires VUnit up from a JSON library descriptor; override with your own `.py` when you need custom orchestration (hooks, per-test attributes, etc.). Python deps for the script come from the toolchain's `vunit` py_library plus the test's `deps` â both are stitched into the venv that runs the script.2*//tools/rules_vunit_run:rules_vunit_run.py�

simulatorsoA mapping of `vunit_*_sim` targets to their matching simulator names. Every target must provide `VUnitSimInfo`.	 *
VUnitSimInfo2
vunitThe `vunit` python library. *
PyInfo"0
vunit_toolchain@@rules_vunit//vunit:defs.bzl
,
*
nameA unique name for this target. <
:
default_sim%An optional default simulator to use.2""�
�
env�Environment variables to set whenever the toolchain invokes a simulator. Applied to every sim registered in `simulators`; for sim-specific vars (license server, install root, etc.) prefer the per-`vunit_*_sim` `env` attr instead. Precedence at test time: toolchain `env` < sim `env` < rule-level `vunit_test(env = ...)`.
2{}�
�
run_py�The Python orchestration script the `vunit_test` rule invokes. Defaults to a shipped driver that wires VUnit up from a JSON library descriptor; override with your own `.py` when you need custom orchestration (hooks, per-test attributes, etc.). Python deps for the script come from the toolchain's `vunit` py_library plus the test's `deps` â both are stitched into the venv that runs the script.2*//tools/rules_vunit_run:rules_vunit_run.py�
�

simulatorsoA mapping of `vunit_*_sim` targets to their matching simulator names. Every target must provide `VUnitSimInfo`.	 *
VUnitSimInfo4
2
vunitThe `vunit` python library. *
PyInfo�$VUnitPrecompiledLibraryInfo�Output of a downstream rule that materialises a simulator vendor's precompiled library set (e.g. Xilinx IP simulation libraries extracted via Vivado `export_simulation` and compiled by the simulator's own driver). The vunit test rule consumes these via its `precompiled_libs` attr; the vunit_process_wrapper patches the per-format runner to emit the vendor's link directive (`vmap -link` for Aldec, `-modelsimini` for Mentor, etc.) before VUnit's own compile step.2� 
�
VUnitPrecompiledLibraryInfo�Output of a downstream rule that materialises a simulator vendor's precompiled library set (e.g. Xilinx IP simulation libraries extracted via Vivado `export_simulation` and compiled by the simulator's own driver). The vunit test rule consumes these via its `precompiled_libs` attr; the vunit_process_wrapper patches the per-format runner to emit the vendor's link directive (`vmap -link` for Aldec, `-modelsimini` for Mentor, etc.) before VUnit's own compile step.�
format�str: precompiled-library format family. Tied to the vendor binary format and link-config syntax, not to an individual simulator. Known values: `aldec` (rivierapro, activehdl), `mentor` (questa, modelsim), `synopsys` (vcs, vcs_mx), `cadence` (xcelium, ies). One bundle works for every simulator in its family.�
library_dir�File: TreeArtifact rooted at the library set. Holds the format's link-config file at a conventional path (aldec: ./library.cfg; mentor: ./modelsim.ini; synopsys: ./synopsys_sim.setup; cadence: ./cds.lib) plus the per-library compiled artifacts the link-config references.�
links_secureip�bool: True when this bundle ships a `secureip` library that encrypted vendor primitives reference at elaboration. When set, the wrapper instructs the toolchain `run.py` to add `-L secureip` (Aldec) / equivalent to the vsim link flags so the encrypted modules resolve. Replaces the legacy `vendor='xilinx'` string check in downstream `run.py`s.�
provides_glbl�bool: True when this bundle ships the Xilinx `glbl` module needed to drive global pseudo-resets (GSR/GTS/PRLD) for Vivado-exported IP. When set, the wrapper instructs the toolchain `run.py` to add `xil_defaultlib.glbl` as a sibling simulation top. Replaces the legacy `vendor='xilinx'` string check; bundles that provide glbl elsewhere (or don't need it) can leave this False even with `vendor='xilinx'`.�
vendor�str: free-form ecosystem identifier, included in the wrapper's runtime descriptor as advisory metadata for the toolchain `run.py` (e.g. logging which vendor's libs were linked). NOT used by the wrapper for any behavioral decision â see `links_secureip` / `provides_glbl` for typed quirks. Conventional values: `xilinx`, `intel`, `microchip`, or empty for non-vendor bundles."<
VUnitPrecompiledLibraryInfo@@rules_vunit//vunit:defs.bzl
''�
�
format�str: precompiled-library format family. Tied to the vendor binary format and link-config syntax, not to an individual simulator. Known values: `aldec` (rivierapro, activehdl), `mentor` (questa, modelsim), `synopsys` (vcs, vcs_mx), `cadence` (xcelium, ies). One bundle works for every simulator in its family.�
�
library_dir�File: TreeArtifact rooted at the library set. Holds the format's link-config file at a conventional path (aldec: ./library.cfg; mentor: ./modelsim.ini; synopsys: ./synopsys_sim.setup; cadence: ./cds.lib) plus the per-library compiled artifacts the link-config references.�
�
links_secureip�bool: True when this bundle ships a `secureip` library that encrypted vendor primitives reference at elaboration. When set, the wrapper instructs the toolchain `run.py` to add `-L secureip` (Aldec) / equivalent to the vsim link flags so the encrypted modules resolve. Replaces the legacy `vendor='xilinx'` string check in downstream `run.py`s.�
�
provides_glbl�bool: True when this bundle ships the Xilinx `glbl` module needed to drive global pseudo-resets (GSR/GTS/PRLD) for Vivado-exported IP. When set, the wrapper instructs the toolchain `run.py` to add `xil_defaultlib.glbl` as a sibling simulation top. Replaces the legacy `vendor='xilinx'` string check; bundles that provide glbl elsewhere (or don't need it) can leave this False even with `vendor='xilinx'`.�
�
vendor�str: free-form ecosystem identifier, included in the wrapper's runtime descriptor as advisory metadata for the toolchain `run.py` (e.g. logging which vendor's libs were linked). NOT used by the wrapper for any behavioral decision â see `links_secureip` / `provides_glbl` for typed quirks. Conventional values: `xilinx`, `intel`, `microchip`, or empty for non-vendor bundles.�
//vunit:vunit_activehdl_sim.bzlrx
-
rules_vunitvunitvunit_activehdl_sim.bzl9
vunit_activehdl_sim_vunit_activehdl_sim

�
//vunit:vunit_ghdl_sim.bzlri
(
rules_vunitvunitvunit_ghdl_sim.bzl/
vunit_ghdl_sim_vunit_ghdl_sim
		

�
//vunit:vunit_modelsim_sim.bzlru
,
rules_vunitvunitvunit_modelsim_sim.bzl7
vunit_modelsim_sim_vunit_modelsim_sim

�
//vunit:vunit_nvc_sim.bzlrf
'
rules_vunitvunitvunit_nvc_sim.bzl-
vunit_nvc_sim_vunit_nvc_sim

�
//vunit:vunit_questa_sim.bzlro
*
rules_vunitvunitvunit_questa_sim.bzl3
vunit_questa_sim_vunit_questa_sim

�
//vunit:vunit_riviera_sim.bzlrr
+
rules_vunitvunitvunit_riviera_sim.bzl5
vunit_riviera_sim_vunit_riviera_sim

y
//vunit:vunit_test.bzlr]
$
rules_vunitvunitvunit_test.bzl'

vunit_test_vunit_test

�
//vunit:vunit_toolchain.bzlrl
)
rules_vunitvunitvunit_toolchain.bzl1
vunit_toolchain_vunit_toolchain
!!
"�
2//vunit/private:vunit_precompiled_library_info.bzlr�
@
rules_vunitvunit/private"vunit_precompiled_library_info.bzlI
VUnitPrecompiledLibraryInfo_VUnitPrecompiledLibraryInfo
%%!
#&VUnit rules�
-
rules_vunitvunitvunit_activehdl_sim.bzl�vunit_activehdl_sim�A simulator configuration for running [Aldec
Active-HDL](https://www.aldec.com/en/products/fpga_simulation/active-hdl)
under VUnit.

### Status

Infrastructure only. Active-HDL is commercial, with no BCR module and
no redistributable binary; `rules_vunit` cannot validate this rule in
CI.

### Notes

Active-HDL accepts both Verilog/SystemVerilog (`VerilogInfo`) and VHDL
(`VhdlInfo`) modules. Sets `VUNIT_SIMULATOR=activehdl`.
"�
�
vunit_activehdl_sim�A simulator configuration for running [Aldec
Active-HDL](https://www.aldec.com/en/products/fpga_simulation/active-hdl)
under VUnit.

### Status

Infrastructure only. Active-HDL is commercial, with no BCR module and
no redistributable binary; `rules_vunit` cannot validate this rule in
CI.

### Notes

Active-HDL accepts both Verilog/SystemVerilog (`VerilogInfo`) and VHDL
(`VhdlInfo`) modules. Sets `VUNIT_SIMULATOR=activehdl`.
*
nameA unique name for this target. �
env�Environment variables to set when the vunit runner invokes this simulator at test time (license-server pointers, install root vars, â¦). Precedence: toolchain `env` < sim `env` < rule-level `vunit_test(env = ...)`.
2{},
vcom The `vcom` VHDL compiler binary. .
vlib"The `vlib` library manager binary. =
vlog1The `vlog` Verilog/SystemVerilog compiler binary. (
vsimThe `vsim` simulator binary. "C
vunit_activehdl_sim,@@rules_vunit//vunit:vunit_activehdl_sim.bzl
DD,
*
nameA unique name for this target. �
�
env�Environment variables to set when the vunit runner invokes this simulator at test time (license-server pointers, install root vars, â¦). Precedence: toolchain `env` < sim `env` < rule-level `vunit_test(env = ...)`.
2{}.
,
vcom The `vcom` VHDL compiler binary. 0
.
vlib"The `vlib` library manager binary. ?
=
vlog1The `vlog` Verilog/SystemVerilog compiler binary. *
(
vsimThe `vsim` simulator binary. �
$//vunit/private:vunit_simulators.bzlr}
2
rules_vunitvunit/privatevunit_simulators.bzl9
vunit_activehdl_sim_vunit_activehdl_sim

vunit_activehdl_sim�(
(
rules_vunitvunitvunit_ghdl_sim.bzl�&vunit_ghdl_sim�	A simulator configuration for running [GHDL](https://ghdl.github.io/ghdl/)
simulations in VUnit tests.

### Status

Working against the BCR `ghdl` module from version `6.0.0.bcr.1` onward.
The backend is selectable with `--@ghdl//:backend={mcode, llvm-jit}`
(default `mcode` on x86_64, `llvm-jit` elsewhere).

### Notes

GHDL only supports VHDL (`VhdlInfo`); pair it with `vhdl_library` targets
in the `libraries` map of `vunit_test`. VUnit drives `ghdl` directly via
its `vu.main()` at test time using sources surfaced through runfiles.

The `vhdl_libs` attribute should point at the pre-compiled IEEE/std
libraries from the BCR `ghdl` module â most projects want
`["@ghdl//:vhdl_libs_v08"]`.

### Coverage

GHDL only emits coverage when built with the `gcc` backend; the BCR
`ghdl` module ships only `mcode` and `llvm-jit`, neither of which
support it. Wiring up coverage flags here would be a no-op (or
runtime error) against a stock BCR build, so this rule omits the
sim-side coverage path. The generic `VUnitSimInfo.coverage` field
remains available for downstream toolchains that point
`vunit_ghdl_sim(ghdl = ...)` at a GHDL+gcc binary and want to thread
gcov output through `bazel coverage`.
"�
�
vunit_ghdl_sim�	A simulator configuration for running [GHDL](https://ghdl.github.io/ghdl/)
simulations in VUnit tests.

### Status

Working against the BCR `ghdl` module from version `6.0.0.bcr.1` onward.
The backend is selectable with `--@ghdl//:backend={mcode, llvm-jit}`
(default `mcode` on x86_64, `llvm-jit` elsewhere).

### Notes

GHDL only supports VHDL (`VhdlInfo`); pair it with `vhdl_library` targets
in the `libraries` map of `vunit_test`. VUnit drives `ghdl` directly via
its `vu.main()` at test time using sources surfaced through runfiles.

The `vhdl_libs` attribute should point at the pre-compiled IEEE/std
libraries from the BCR `ghdl` module â most projects want
`["@ghdl//:vhdl_libs_v08"]`.

### Coverage

GHDL only emits coverage when built with the `gcc` backend; the BCR
`ghdl` module ships only `mcode` and `llvm-jit`, neither of which
support it. Wiring up coverage flags here would be a no-op (or
runtime error) against a stock BCR build, so this rule omits the
sim-side coverage path. The generic `VUnitSimInfo.coverage` field
remains available for downstream toolchains that point
`vunit_ghdl_sim(ghdl = ...)` at a GHDL+gcc binary and want to thread
gcov output through `bazel coverage`.
*
nameA unique name for this target. �
env�Environment variables to set when the vunit runner invokes this simulator at test time (license-server pointers, install root vars, â¦). Precedence: toolchain `env` < sim `env` < rule-level `vunit_test(env = ...)`.
2{}
ghdlThe `ghdl` binary. �
ghdl_prefix�Literal value to set as `GHDL_PREFIX` at simulation time. Use this for
ghdl installs where the prefix is a stable absolute path on disk â
typically a system/`.deb`/Homebrew install (e.g. `"/usr/lib/ghdl"`).

When unset (default), `GHDL_PREFIX` is auto-derived from `vhdl_libs` if
it's populated (BCR-shaped layout), otherwise left unset so ghdl falls
back to its own compiled-in search paths.
2""�
	vhdl_libs�Pre-compiled VHDL standard libraries (e.g. `@ghdl//:vhdl_libs_v08`).
**Assumes the BCR `ghdl` module's layout** â
`<root>/{std,ieee}/v<XX>/<name>-objXX.cf` â from which `GHDL_PREFIX`
is derived. If you ship ghdl differently and the IEEE/std libs are
already discoverable by the binary, leave this empty and (optionally)
set `ghdl_prefix` to a literal path, or skip both for a system install
that uses its compiled-in defaults.
2[]"9
vunit_ghdl_sim'@@rules_vunit//vunit:vunit_ghdl_sim.bzl
ss,
*
nameA unique name for this target. �
�
env�Environment variables to set when the vunit runner invokes this simulator at test time (license-server pointers, install root vars, â¦). Precedence: toolchain `env` < sim `env` < rule-level `vunit_test(env = ...)`.
2{} 

ghdlThe `ghdl` binary. �
�
ghdl_prefix�Literal value to set as `GHDL_PREFIX` at simulation time. Use this for
ghdl installs where the prefix is a stable absolute path on disk â
typically a system/`.deb`/Homebrew install (e.g. `"/usr/lib/ghdl"`).

When unset (default), `GHDL_PREFIX` is auto-derived from `vhdl_libs` if
it's populated (BCR-shaped layout), otherwise left unset so ghdl falls
back to its own compiled-in search paths.
2""�
�
	vhdl_libs�Pre-compiled VHDL standard libraries (e.g. `@ghdl//:vhdl_libs_v08`).
**Assumes the BCR `ghdl` module's layout** â
`<root>/{std,ieee}/v<XX>/<name>-objXX.cf` â from which `GHDL_PREFIX`
is derived. If you ship ghdl differently and the IEEE/std libs are
already discoverable by the binary, leave this empty and (optionally)
set `ghdl_prefix` to a literal path, or skip both for a system install
that uses its compiled-in defaults.
2[]�
$//vunit/private:vunit_simulators.bzlrs
2
rules_vunitvunit/privatevunit_simulators.bzl/
vunit_ghdl_sim_vunit_ghdl_sim

vunit_ghdl_sim�
,
rules_vunitvunitvunit_modelsim_sim.bzl�vunit_modelsim_sim�A simulator configuration for running [Mentor/Siemens EDA
ModelSim](https://eda.sw.siemens.com/en-US/ic/modelsim/) under VUnit.

VUnit shares the `modelsim` backend for both ModelSim and Questa; use
`vunit_questa_sim` if you prefer that terminology â they wire up the
same VUnit backend.

### Status

Infrastructure only. ModelSim is commercial, with no BCR module and no
redistributable binary; `rules_vunit` cannot validate this rule in CI.
Wire it up downstream by pointing the binary attrs at your own install
and registering a `vunit_toolchain` that routes `sim = "modelsim"`
through this rule.

### Notes

ModelSim accepts both Verilog/SystemVerilog (`VerilogInfo`) and VHDL
(`VhdlInfo`) modules. VUnit drives `vlib` / `vlog` / `vcom` / `vsim` via
its own runner â the rule just stages sources and surfaces the
binaries on PATH.
"�
�
vunit_modelsim_sim�A simulator configuration for running [Mentor/Siemens EDA
ModelSim](https://eda.sw.siemens.com/en-US/ic/modelsim/) under VUnit.

VUnit shares the `modelsim` backend for both ModelSim and Questa; use
`vunit_questa_sim` if you prefer that terminology â they wire up the
same VUnit backend.

### Status

Infrastructure only. ModelSim is commercial, with no BCR module and no
redistributable binary; `rules_vunit` cannot validate this rule in CI.
Wire it up downstream by pointing the binary attrs at your own install
and registering a `vunit_toolchain` that routes `sim = "modelsim"`
through this rule.

### Notes

ModelSim accepts both Verilog/SystemVerilog (`VerilogInfo`) and VHDL
(`VhdlInfo`) modules. VUnit drives `vlib` / `vlog` / `vcom` / `vsim` via
its own runner â the rule just stages sources and surfaces the
binaries on PATH.
*
nameA unique name for this target. �
env�Environment variables to set when the vunit runner invokes this simulator at test time (license-server pointers, install root vars, â¦). Precedence: toolchain `env` < sim `env` < rule-level `vunit_test(env = ...)`.
2{},
vcom The `vcom` VHDL compiler binary. .
vlib"The `vlib` library manager binary. =
vlog1The `vlog` Verilog/SystemVerilog compiler binary. (
vsimThe `vsim` simulator binary. "A
vunit_modelsim_sim+@@rules_vunit//vunit:vunit_modelsim_sim.bzl
DD,
*
nameA unique name for this target. �
�
env�Environment variables to set when the vunit runner invokes this simulator at test time (license-server pointers, install root vars, â¦). Precedence: toolchain `env` < sim `env` < rule-level `vunit_test(env = ...)`.
2{}.
,
vcom The `vcom` VHDL compiler binary. 0
.
vlib"The `vlib` library manager binary. ?
=
vlog1The `vlog` Verilog/SystemVerilog compiler binary. *
(
vsimThe `vsim` simulator binary. �
$//vunit/private:vunit_simulators.bzlr{
2
rules_vunitvunit/privatevunit_simulators.bzl7
vunit_modelsim_sim_vunit_modelsim_sim

vunit_modelsim_sim�(
'
rules_vunitvunitvunit_nvc_sim.bzl�'vunit_nvc_sim�
A simulator configuration for running [NVC](https://www.nickg.me.uk/nvc/)
(open-source VHDL simulator) under VUnit.

### Status

Working against the BCR `nvc` module from version `1.21.0` onward.

### Notes

NVC only supports VHDL (`VhdlInfo`); pair it with `vhdl_library` targets
in the `libraries` map of `vunit_test`. VUnit drives `nvc` directly via
its `vu.main()` at test time using sources surfaced through runfiles.

`vhdl_libs` accepts a list of per-library TreeArtifact targets â
typically `["@nvc//:vhdl_libs"]`, the BCR `nvc` module's filegroup of
per-library directories laid out exactly like a system install under
`<prefix>/lib/nvc/<library>/`. The rule's implementation stages those
TreeArtifacts side-by-side under a single root and points
`NVC_LIBPATH` at it so nvc finds every shipped library (STD, IEEE,
NVC, plus the SYNOPSYS / VITAL extras inside IEEE) at simulation
time.

### Coverage

VUnit has no NVC coverage integration upstream â `vu.set_sim_option`
exposes `nvc.elab_flags`/`nvc.sim_flags`/`nvc.a_flags`, but there's
no shipped recipe for routing NVC's `--cover` instrumentation through
those, and `nvc --cover-export` only emits Cobertura. Rather than
invent a sim-side path here, this rule omits coverage. The generic
`VUnitSimInfo.coverage` field stays available for the commercial
simulators (Mentor UCDB, Aldec ACDB) where a real bridge exists.
"�
�
vunit_nvc_sim�
A simulator configuration for running [NVC](https://www.nickg.me.uk/nvc/)
(open-source VHDL simulator) under VUnit.

### Status

Working against the BCR `nvc` module from version `1.21.0` onward.

### Notes

NVC only supports VHDL (`VhdlInfo`); pair it with `vhdl_library` targets
in the `libraries` map of `vunit_test`. VUnit drives `nvc` directly via
its `vu.main()` at test time using sources surfaced through runfiles.

`vhdl_libs` accepts a list of per-library TreeArtifact targets â
typically `["@nvc//:vhdl_libs"]`, the BCR `nvc` module's filegroup of
per-library directories laid out exactly like a system install under
`<prefix>/lib/nvc/<library>/`. The rule's implementation stages those
TreeArtifacts side-by-side under a single root and points
`NVC_LIBPATH` at it so nvc finds every shipped library (STD, IEEE,
NVC, plus the SYNOPSYS / VITAL extras inside IEEE) at simulation
time.

### Coverage

VUnit has no NVC coverage integration upstream â `vu.set_sim_option`
exposes `nvc.elab_flags`/`nvc.sim_flags`/`nvc.a_flags`, but there's
no shipped recipe for routing NVC's `--cover` instrumentation through
those, and `nvc --cover-export` only emits Cobertura. Rather than
invent a sim-side path here, this rule omits coverage. The generic
`VUnitSimInfo.coverage` field stays available for the commercial
simulators (Mentor UCDB, Aldec ACDB) where a real bridge exists.
*
nameA unique name for this target. �
env�Environment variables to set when the vunit runner invokes this simulator at test time (license-server pointers, install root vars, â¦). Precedence: toolchain `env` < sim `env` < rule-level `vunit_test(env = ...)`.
2{}&
nvcThe `nvc` simulator binary. �
nvc_libpath�Literal value to set as `NVC_LIBPATH` at simulation time. Use this
for nvc installs where the prefix is a stable absolute path on disk â
typically a system / `.deb` / Homebrew install
(e.g. `"/usr/local/lib/nvc"`).

When unset (default), `NVC_LIBPATH` is auto-derived from `vhdl_libs`
if it's populated (per-library TreeArtifacts staged into one root by
this rule), otherwise left unset so nvc falls back to its own
compiled-in search paths.
2""�
	vhdl_libs�Per-library TreeArtifact targets to stage side-by-side under a
single `NVC_LIBPATH` root. Typically `["@nvc//:vhdl_libs"]` â the
BCR `nvc` module's filegroup of per-library directories. Empty (the
default) leaves `NVC_LIBPATH` unset.
2[]"7
vunit_nvc_sim&@@rules_vunit//vunit:vunit_nvc_sim.bzl
��,
*
nameA unique name for this target. �
�
env�Environment variables to set when the vunit runner invokes this simulator at test time (license-server pointers, install root vars, â¦). Precedence: toolchain `env` < sim `env` < rule-level `vunit_test(env = ...)`.
2{}(
&
nvcThe `nvc` simulator binary. �
�
nvc_libpath�Literal value to set as `NVC_LIBPATH` at simulation time. Use this
for nvc installs where the prefix is a stable absolute path on disk â
typically a system / `.deb` / Homebrew install
(e.g. `"/usr/local/lib/nvc"`).

When unset (default), `NVC_LIBPATH` is auto-derived from `vhdl_libs`
if it's populated (per-library TreeArtifacts staged into one root by
this rule), otherwise left unset so nvc falls back to its own
compiled-in search paths.
2""�
�
	vhdl_libs�Per-library TreeArtifact targets to stage side-by-side under a
single `NVC_LIBPATH` root. Typically `["@nvc//:vhdl_libs"]` â the
BCR `nvc` module's filegroup of per-library directories. Empty (the
default) leaves `NVC_LIBPATH` unset.
2[]�
$//vunit/private:vunit_simulators.bzlrq
2
rules_vunitvunit/privatevunit_simulators.bzl-
vunit_nvc_sim_vunit_nvc_sim

vunit_nvc_sim�
*
rules_vunitvunitvunit_questa_sim.bzl�vunit_questa_sim�A simulator configuration for running [Mentor/Siemens EDA
Questa](https://eda.sw.siemens.com/en-US/ic/questa/) under VUnit.

Functionally identical to `vunit_modelsim_sim` â VUnit shares one
backend for both products. Use whichever name suits your team's
terminology.

### Status

Infrastructure only. Questa is commercial, with no BCR module and no
redistributable binary; `rules_vunit` cannot validate this rule in CI.
"�
�
vunit_questa_sim�A simulator configuration for running [Mentor/Siemens EDA
Questa](https://eda.sw.siemens.com/en-US/ic/questa/) under VUnit.

Functionally identical to `vunit_modelsim_sim` â VUnit shares one
backend for both products. Use whichever name suits your team's
terminology.

### Status

Infrastructure only. Questa is commercial, with no BCR module and no
redistributable binary; `rules_vunit` cannot validate this rule in CI.
*
nameA unique name for this target. �
env�Environment variables to set when the vunit runner invokes this simulator at test time (license-server pointers, install root vars, â¦). Precedence: toolchain `env` < sim `env` < rule-level `vunit_test(env = ...)`.
2{},
vcom The `vcom` VHDL compiler binary. .
vlib"The `vlib` library manager binary. =
vlog1The `vlog` Verilog/SystemVerilog compiler binary. (
vsimThe `vsim` simulator binary. "=
vunit_questa_sim)@@rules_vunit//vunit:vunit_questa_sim.bzl
EE,
*
nameA unique name for this target. �
�
env�Environment variables to set when the vunit runner invokes this simulator at test time (license-server pointers, install root vars, â¦). Precedence: toolchain `env` < sim `env` < rule-level `vunit_test(env = ...)`.
2{}.
,
vcom The `vcom` VHDL compiler binary. 0
.
vlib"The `vlib` library manager binary. ?
=
vlog1The `vlog` Verilog/SystemVerilog compiler binary. *
(
vsimThe `vsim` simulator binary. �
$//vunit/private:vunit_simulators.bzlrw
2
rules_vunitvunit/privatevunit_simulators.bzl3
vunit_questa_sim_vunit_questa_sim

vunit_questa_sim�*
+
rules_vunitvunitvunit_riviera_sim.bzl�(vunit_riviera_sim�A simulator configuration for running [Aldec
Riviera-PRO](https://www.aldec.com/en/products/functional_verification/riviera-pro)
under VUnit.

### Status

Infrastructure only. Riviera-PRO is commercial, with no BCR module and
no redistributable binary; `rules_vunit` cannot validate this rule in
CI.

### Notes

Riviera-PRO accepts both Verilog/SystemVerilog (`VerilogInfo`) and VHDL
(`VhdlInfo`) modules. Sets `VUNIT_SIMULATOR=rivierapro`.
"�%
�
vunit_riviera_sim�A simulator configuration for running [Aldec
Riviera-PRO](https://www.aldec.com/en/products/functional_verification/riviera-pro)
under VUnit.

### Status

Infrastructure only. Riviera-PRO is commercial, with no BCR module and
no redistributable binary; `rules_vunit` cannot validate this rule in
CI.

### Notes

Riviera-PRO accepts both Verilog/SystemVerilog (`VerilogInfo`) and VHDL
(`VhdlInfo`) modules. Sets `VUNIT_SIMULATOR=rivierapro`.
*
nameA unique name for this target. �
coverage_args�Template fragments forwarded to `coverage_tool` after the test runs under `bazel coverage`. `{output}` is substituted with `$COVERAGE_OUTPUT_FILE`; `{data_files}` is expanded into one positional arg per file matched by `coverage_data_glob`. Only meaningful when `coverage_tool` is set.2[]�
coverage_data_glob�Shell glob (relative to the VUnit output dir) selecting the raw coverage data files `coverage_tool` consumes. For Riviera-PRO, `**/coverage.acdb` matches every per-testcase ACDB the run produces. Only meaningful when `coverage_tool` is set.2""�
coverage_tool�Optional Riviera coverage post-processor. When set AND the test runs under `bazel coverage` (Bazel populates `$COVERAGE_OUTPUT_FILE`), the rules_vunit process wrapper invokes this binary after the sim exits with the `coverage_args` template (substituting `{output}` and `{data_files}`) so it can translate the merged ACDB into lcov at `$COVERAGE_OUTPUT_FILE`. Leave unset to ship raw ACDBs under the test outputs dir without an lcov roll-up.2None�
env�Environment variables to set when the vunit runner invokes this simulator at test time (license-server pointers, install root vars, â¦). Precedence: toolchain `env` < sim `env` < rule-level `vunit_test(env = ...)`.
2{},
vcom The `vcom` VHDL compiler binary. .
vlib"The `vlib` library manager binary. v
vlistiThe `vlist` library lister binary. Invoked by `vu.main()` to enumerate compiled units in the library.cfg. =
vlog1The `vlog` Verilog/SystemVerilog compiler binary. �
vmapxThe `vmap` library-mapping binary. Invoked when external (precompiled) libraries are linked into the test's library.cfg. (
vsimThe `vsim` simulator binary. �
vsimsa�The `vsimsa` batch-shell binary. **Required**: VUnit's `RivieraProInterface.find_prefix_from_path()` rejects a toolchain directory unless BOTH `vsim` AND `vsimsa` resolve in the same dir on PATH. Omitting `vsimsa` produces a confusing `No available simulator detected` error at test time. "?
vunit_riviera_sim*@@rules_vunit//vunit:vunit_riviera_sim.bzl
bb,
*
nameA unique name for this target. �
�
coverage_args�Template fragments forwarded to `coverage_tool` after the test runs under `bazel coverage`. `{output}` is substituted with `$COVERAGE_OUTPUT_FILE`; `{data_files}` is expanded into one positional arg per file matched by `coverage_data_glob`. Only meaningful when `coverage_tool` is set.2[]�
�
coverage_data_glob�Shell glob (relative to the VUnit output dir) selecting the raw coverage data files `coverage_tool` consumes. For Riviera-PRO, `**/coverage.acdb` matches every per-testcase ACDB the run produces. Only meaningful when `coverage_tool` is set.2""�
�
coverage_tool�Optional Riviera coverage post-processor. When set AND the test runs under `bazel coverage` (Bazel populates `$COVERAGE_OUTPUT_FILE`), the rules_vunit process wrapper invokes this binary after the sim exits with the `coverage_args` template (substituting `{output}` and `{data_files}`) so it can translate the merged ACDB into lcov at `$COVERAGE_OUTPUT_FILE`. Leave unset to ship raw ACDBs under the test outputs dir without an lcov roll-up.2None�
�
env�Environment variables to set when the vunit runner invokes this simulator at test time (license-server pointers, install root vars, â¦). Precedence: toolchain `env` < sim `env` < rule-level `vunit_test(env = ...)`.
2{}.
,
vcom The `vcom` VHDL compiler binary. 0
.
vlib"The `vlib` library manager binary. x
v
vlistiThe `vlist` library lister binary. Invoked by `vu.main()` to enumerate compiled units in the library.cfg. ?
=
vlog1The `vlog` Verilog/SystemVerilog compiler binary. �
�
vmapxThe `vmap` library-mapping binary. Invoked when external (precompiled) libraries are linked into the test's library.cfg. *
(
vsimThe `vsim` simulator binary. �
�
vsimsa�The `vsimsa` batch-shell binary. **Required**: VUnit's `RivieraProInterface.find_prefix_from_path()` rejects a toolchain directory unless BOTH `vsim` AND `vsimsa` resolve in the same dir on PATH. Omitting `vsimsa` produces a confusing `No available simulator detected` error at test time. �
$//vunit/private:vunit_simulators.bzlry
2
rules_vunitvunit/privatevunit_simulators.bzl5
vunit_riviera_sim_vunit_riviera_sim

vunit_riviera_sim�C
)
rules_vunitvunitvunit_toolchain.bzl�Avunit_toolchain�Define a toolchain for `vunit_*` rules.

The toolchain bundles a `vunit` Python library, a set of HDL simulators
that `vunit_test` targets can select between via their `sim` attribute,
and the orchestration `run.py` the rule invokes at test time. Register
an instance with the standard `toolchain(...)` wrapper to make it
discoverable.

### Registering simulators

Each entry in `simulators` is a `vunit_*_sim` target keyed by the
*string* name that `vunit_test(sim = ...)` will use to select it.
Names are user-chosen â common conventions are `"ghdl"`, `"nvc"`,
`"modelsim"`, `"questa"`. Each name must be unique within the dict.

```python
load("@rules_vunit//vunit:vunit_ghdl_sim.bzl", "vunit_ghdl_sim")
load("@rules_vunit//vunit:vunit_toolchain.bzl", "vunit_toolchain")

vunit_ghdl_sim(
    name = "vunit_ghdl",
    ghdl = "@ghdl",
    vhdl_libs = ["@ghdl//:vhdl_libs_v08"],
)

vunit_toolchain(
    name = "my_vunit_toolchain",
    vunit = "//path/to:vunit_py_library",
    default_sim = "ghdl",
    simulators = {":vunit_ghdl": "ghdl"},
    # run_py defaults to //tools/rules_vunit_run:rules_vunit_run.py.
)

toolchain(
    name = "my_toolchain",
    toolchain = ":my_vunit_toolchain",
    toolchain_type = "@rules_vunit//vunit:toolchain_type",
)
```

Add `register_toolchains("//path/to:my_toolchain")` to `MODULE.bazel`
ahead of `//vunit/toolchain` to override the default. `default_sim`
chooses which simulator runs when a `vunit_test` omits its own `sim`
attribute; it's optional, but if set must name one of the keys in
`simulators`.

### Customising `run.py`

The default `run.py` (shipped at
`//tools/rules_vunit_run:rules_vunit_run.py`) reads a JSON descriptor
from `VUNIT_LIBRARIES_JSON`, declares each library with
`vu.add_library(...)` / `lib.add_source_file(...)`, and calls
`vu.main()`. Override it via the `run_py` attribute when you need extra
configuration â custom test attributes, `set_sim_option(...)` calls,
`post_run` hooks, etc. The wrapper always sets:

* `VUNIT_LIBRARIES_JSON` â path to the resolved library/sources JSON.
* `VUNIT_OUTPUT_PATH` â sandboxed directory to pass as `-o`.
* `VUNIT_XUNIT_XML` â path to write the xunit XML to (pass as `-x`).

The script runs inside the venv composed by the `vunit_test` rule:
`toolchain.vunit` is on `sys.path`, plus anything the test pulls in via
its own `deps` attribute. So a custom `run.py` just needs to `import
vunit` and any helper packages declared on the test target.

The default driver's plumbing is also exposed as a Python library â
`from rules_vunit_run import load_manifest,
ensure_vunit_verilog_path_is_plus_free, vunit_builtin_verilog_include_dir,
configure_coverage` â so a custom `run.py` can reuse the manifest
loader, the bzlmod `+`-in-path workaround for Aldec, and the coverage
hook instead of vendoring them. Add
`@rules_vunit//tools/rules_vunit_run` to the test target's `deps` to
make the import resolve.

Per-simulator API and wiring details live in the
[Simulators](./simulators.md) section.
"�)
� 
vunit_toolchain�Define a toolchain for `vunit_*` rules.

The toolchain bundles a `vunit` Python library, a set of HDL simulators
that `vunit_test` targets can select between via their `sim` attribute,
and the orchestration `run.py` the rule invokes at test time. Register
an instance with the standard `toolchain(...)` wrapper to make it
discoverable.

### Registering simulators

Each entry in `simulators` is a `vunit_*_sim` target keyed by the
*string* name that `vunit_test(sim = ...)` will use to select it.
Names are user-chosen â common conventions are `"ghdl"`, `"nvc"`,
`"modelsim"`, `"questa"`. Each name must be unique within the dict.

```python
load("@rules_vunit//vunit:vunit_ghdl_sim.bzl", "vunit_ghdl_sim")
load("@rules_vunit//vunit:vunit_toolchain.bzl", "vunit_toolchain")

vunit_ghdl_sim(
    name = "vunit_ghdl",
    ghdl = "@ghdl",
    vhdl_libs = ["@ghdl//:vhdl_libs_v08"],
)

vunit_toolchain(
    name = "my_vunit_toolchain",
    vunit = "//path/to:vunit_py_library",
    default_sim = "ghdl",
    simulators = {":vunit_ghdl": "ghdl"},
    # run_py defaults to //tools/rules_vunit_run:rules_vunit_run.py.
)

toolchain(
    name = "my_toolchain",
    toolchain = ":my_vunit_toolchain",
    toolchain_type = "@rules_vunit//vunit:toolchain_type",
)
```

Add `register_toolchains("//path/to:my_toolchain")` to `MODULE.bazel`
ahead of `//vunit/toolchain` to override the default. `default_sim`
chooses which simulator runs when a `vunit_test` omits its own `sim`
attribute; it's optional, but if set must name one of the keys in
`simulators`.

### Customising `run.py`

The default `run.py` (shipped at
`//tools/rules_vunit_run:rules_vunit_run.py`) reads a JSON descriptor
from `VUNIT_LIBRARIES_JSON`, declares each library with
`vu.add_library(...)` / `lib.add_source_file(...)`, and calls
`vu.main()`. Override it via the `run_py` attribute when you need extra
configuration â custom test attributes, `set_sim_option(...)` calls,
`post_run` hooks, etc. The wrapper always sets:

* `VUNIT_LIBRARIES_JSON` â path to the resolved library/sources JSON.
* `VUNIT_OUTPUT_PATH` â sandboxed directory to pass as `-o`.
* `VUNIT_XUNIT_XML` â path to write the xunit XML to (pass as `-x`).

The script runs inside the venv composed by the `vunit_test` rule:
`toolchain.vunit` is on `sys.path`, plus anything the test pulls in via
its own `deps` attribute. So a custom `run.py` just needs to `import
vunit` and any helper packages declared on the test target.

The default driver's plumbing is also exposed as a Python library â
`from rules_vunit_run import load_manifest,
ensure_vunit_verilog_path_is_plus_free, vunit_builtin_verilog_include_dir,
configure_coverage` â so a custom `run.py` can reuse the manifest
loader, the bzlmod `+`-in-path workaround for Aldec, and the coverage
hook instead of vendoring them. Add
`@rules_vunit//tools/rules_vunit_run` to the test target's `deps` to
make the import resolve.

Per-simulator API and wiring details live in the
[Simulators](./simulators.md) section.
*
nameA unique name for this target. :
default_sim%An optional default simulator to use.2""�
env�Environment variables to set whenever the toolchain invokes a simulator. Applied to every sim registered in `simulators`; for sim-specific vars (license server, install root, etc.) prefer the per-`vunit_*_sim` `env` attr instead. Precedence at test time: toolchain `env` < sim `env` < rule-level `vunit_test(env = ...)`.
2{}�
run_py�The Python orchestration script the `vunit_test` rule invokes. Defaults to a shipped driver that wires VUnit up from a JSON library descriptor; override with your own `.py` when you need custom orchestration (hooks, per-test attributes, etc.). Python deps for the script come from the toolchain's `vunit` py_library plus the test's `deps` â both are stitched into the venv that runs the script.2*//tools/rules_vunit_run:rules_vunit_run.py�

simulatorsoA mapping of `vunit_*_sim` targets to their matching simulator names. Every target must provide `VUnitSimInfo`.	 *
VUnitSimInfo2
vunitThe `vunit` python library. *
PyInfo";
vunit_toolchain(@@rules_vunit//vunit:vunit_toolchain.bzl
,
*
nameA unique name for this target. <
:
default_sim%An optional default simulator to use.2""�
�
env�Environment variables to set whenever the toolchain invokes a simulator. Applied to every sim registered in `simulators`; for sim-specific vars (license server, install root, etc.) prefer the per-`vunit_*_sim` `env` attr instead. Precedence at test time: toolchain `env` < sim `env` < rule-level `vunit_test(env = ...)`.
2{}�
�
run_py�The Python orchestration script the `vunit_test` rule invokes. Defaults to a shipped driver that wires VUnit up from a JSON library descriptor; override with your own `.py` when you need custom orchestration (hooks, per-test attributes, etc.). Python deps for the script come from the toolchain's `vunit` py_library plus the test's `deps` â both are stitched into the venv that runs the script.2*//tools/rules_vunit_run:rules_vunit_run.py�
�

simulatorsoA mapping of `vunit_*_sim` targets to their matching simulator names. Every target must provide `VUnitSimInfo`.	 *
VUnitSimInfo4
2
vunitThe `vunit` python library. *
PyInfo�
#//vunit/private:vunit_toolchain.bzlrt
1
rules_vunitvunit/privatevunit_toolchain.bzl1
vunit_toolchain_vunit_toolchain

vunit_toolchainN

rules_vunitversion.bzl	VERSION0.5.0j0.5.0rules_vunit version 