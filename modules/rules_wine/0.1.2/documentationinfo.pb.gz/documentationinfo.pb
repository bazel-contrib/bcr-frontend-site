�+
wineactions.bzl�	wine_path�Args.map_each callback for Wine-only executable adapter consumers.

Pass this function to Args.add_all; do not call it during analysis.
For runner-based actions, use windows_actions.add_path instead.
*�
�
	wine_path@
file4File supplied by Args during command-line expansion. (�Args.map_each callback for Wine-only executable adapter consumers.

Pass this function to Args.add_all; do not call it during analysis.
For runner-based actions, use windows_actions.add_path instead.
"D
BA JSON-escaped Wine path marker containing the action-mapped path.2
	wine_path//wine:actions.bzlB
@
file4File supplied by Args during command-line expansion. (�windows_actions.add_path�Append a File path, deferring mapping and Wine encoding until execution.

Use this for command-line arguments, not markers inside payload response
files. Tree artifacts are passed as directory paths rather than expanded.
*�
�
windows_actions.add_path:
runner,Context returned by windows_actions.resolve. (/
args#Args object receiving the argument. (O
fileCFile or tree artifact. Pass ordinary strings with Args.add instead. (:
format(Surrounding option syntax, e.g. /out:%s."%s"(�Append a File path, deferring mapping and Wine encoding until execution.

Use this for command-line arguments, not markers inside payload response
files. Tree artifacts are passed as directory paths rather than expanded.
2
	_add_path//wine:actions.bzl<
:
runner,Context returned by windows_actions.resolve. (1
/
args#Args object receiving the argument. (Q
O
fileCFile or tree artifact. Pass ordinary strings with Args.add instead. (<
:
format(Surrounding option syntax, e.g. /out:%s."%s"(�windows_actions.resolveBBind a runner to the execution group declaring its toolchain type.*�
�
windows_actions.resolve&
ctxThe consuming rule context. (J

exec_group/Group declaring windows_actions.toolchain_type.	"default"(BBind a runner to the execution group declaring its toolchain type."�
�Context for run/add_path, containing WindowsRunnerInfo as windows and the
action's exec_group. windows.arch describes the executor CPU; Wine owns
payload CPU support. Constrain the execution group to require a
particular executor, for example to avoid CPU translation.2
_resolve//wine:actions.bzl(
&
ctxThe consuming rule context. (L
J

exec_group/Group declaring windows_actions.toolchain_type.	"default"(�windows_actions.run�Declare an action running a Windows executable on the resolved executor.

Linux/macOS use Wine with a fresh writable prefix per action. Windows
executes the payload directly. Use add_path for File arguments to preserve
optional Bazel path mapping. The selected runtime owns guest CPU support;
this helper does not inspect the executable's architecture.
*�
�
windows_actions.run&
ctxThe consuming rule context. (\
runnerNContext returned by windows_actions.resolve for this action's
execution group. (�

executable�Windows executable File or FilesToRunProvider. Configure
source-built tools for Windows explicitly; this function does not
transition dependencies. (;
outputs,Output Files declared by the consuming rule. (M
	arguments:List of strings and Args objects passed to the executable.[](F
inputs6List or depset of input Files, as for ctx.actions.run.[](�
env}Environment variables for the Windows process. Runfiles discovery
variables are reserved by the supervisor on Wine executors.{}(Q
runtime_files:Additional Files required by the executable, such as DLLs.[](�
toolsxList of Files/FilesToRunProviders, or depset of Files, as for
ctx.actions.run. The executable is included automatically.[](,
mnemonicAction mnemonic."WindowsRun"(6
progress_messageOptional progress message.None(x
kwargslAdditional ctx.actions.run arguments. Do not supply
exec_group or toolchain; these are determined by runner.(�Declare an action running a Windows executable on the resolved executor.

Linux/macOS use Wine with a fresh writable prefix per action. Windows
executes the payload directly. Use add_path for File arguments to preserve
optional Bazel path mapping. The selected runtime owns guest CPU support;
this helper does not inspect the executable's architecture.
2
_run//wine:actions.bzl(
&
ctxThe consuming rule context. (^
\
runnerNContext returned by windows_actions.resolve for this action's
execution group. (�
�

executable�Windows executable File or FilesToRunProvider. Configure
source-built tools for Windows explicitly; this function does not
transition dependencies. (=
;
outputs,Output Files declared by the consuming rule. (O
M
	arguments:List of strings and Args objects passed to the executable.[](H
F
inputs6List or depset of input Files, as for ctx.actions.run.[](�
�
env}Environment variables for the Windows process. Runfiles discovery
variables are reserved by the supervisor on Wine executors.{}(S
Q
runtime_files:Additional Files required by the executable, such as DLLs.[](�
�
toolsxList of Files/FilesToRunProviders, or depset of Files, as for
ctx.actions.run. The executable is included automatically.[](.
,
mnemonicAction mnemonic."WindowsRun"(8
6
progress_messageOptional progress message.None(z
x
kwargslAdditional ctx.actions.run arguments. Do not supply
exec_group or toolchain; these are determined by runner.(ELow-level Windows actions using one resolved execution-group context.�
wine/extensionwine.bzl�
wine�Provide pinned Wine distributions and default Windows runner toolchains.

Import wine_toolchains with use_repo, then register
@wine_toolchains//:all explicitly. This extension has no configuration tags and
does not register toolchains automatically. Custom distributions use
windows_runner_toolchain and native toolchain declarations instead.

Defaults cover Linux x86_64/ARM64, macOS ARM64 and native Windows x86_64/ARM64.
ARM64 Wine distributions include FEX for x86_64 Windows programs. Linux requires
glibc 2.17 or newer and a UTF-8 locale. The macOS distribution declares a 26.5
deployment minimum; see the runtime guide for tested baselines and limitations.J�
�
wine�Provide pinned Wine distributions and default Windows runner toolchains.

Import wine_toolchains with use_repo, then register
@wine_toolchains//:all explicitly. This extension has no configuration tags and
does not register toolchains automatically. Custom distributions use
windows_runner_toolchain and native toolchain declarations instead.

Defaults cover Linux x86_64/ARM64, macOS ARM64 and native Windows x86_64/ARM64.
ARM64 Wine distributions include FEX for x86_64 Windows programs. Linux requires
glibc 2.17 or newer and a UTF-8 locale. The macOS distribution declares a 26.5
deployment minimum; see the runtime guide for tested baselines and limitations."//wine/extension:wine.bzlKPinned default Wine toolchains; custom runtimes use public toolchain rules.�)
winetoolchain.bzl�windows_runner_toolchain�Define a Windows runner implementation for native execution or Wine.

Wrap this target in native toolchain declarations with constraints matching the
executor OS/CPU. Use runner_toolchain_type for windows_actions and
adapter_toolchain_type for windows_binary. The adapter registration additionally
constrains the target platform to match the executor.

Wine distributions must preserve their installation layout and include all
runtime files. This rule supplies no CPU emulator itself; guest CPU support is
determined by the supplied Wine distribution. Native runners execute payloads
directly and must omit Wine files and launcher."�
�
windows_runner_toolchain�Define a Windows runner implementation for native execution or Wine.

Wrap this target in native toolchain declarations with constraints matching the
executor OS/CPU. Use runner_toolchain_type for windows_actions and
adapter_toolchain_type for windows_binary. The adapter registration additionally
constrains the target platform to match the executor.

Wine distributions must preserve their installation layout and include all
runtime files. This rule supplies no CPU emulator itself; guest CPU support is
determined by the supplied Wine distribution. Native runners execute payloads
directly and must omit Wine files and launcher.*
nameA unique name for this target. {
archZExecutor CPU, matching the registration's platform constraints; not the Windows guest CPU. J"x86_64"J	"aarch64"d
backendCUse native for Windows executors or wine for Linux/macOS executors. J"native"J"wine"�
launchernWine supervisor executable, normally @rules_wine//wine/runtime:supervisor. Required for wine; omit for native.2NoneN
loader<Native Wine loader file. Required for wine; omit for native.2NoneO
server=Matching wineserver file. Required for wine; omit for native.2Noneo
files^Complete Wine installation files, preserving paths relative to loader/server. Omit for native.2NoneS
identityADistribution/version description exposed through WineRuntimeInfo.2""g
requirementsQHost library/OS requirements for consumers to inspect; not enforced by this rule.2""�
env�Wine runtime environment, taking precedence over payload env. {loader_dir} and {server_dir} expand at execution time. Reserved lifecycle variables cannot be set here.
2{}"0
windows_runner_toolchain//wine:toolchain.bzl,
*
nameA unique name for this target. }
{
archZExecutor CPU, matching the registration's platform constraints; not the Windows guest CPU. J"x86_64"J	"aarch64"f
d
backendCUse native for Windows executors or wine for Linux/macOS executors. J"native"J"wine"�
�
launchernWine supervisor executable, normally @rules_wine//wine/runtime:supervisor. Required for wine; omit for native.2NoneP
N
loader<Native Wine loader file. Required for wine; omit for native.2NoneQ
O
server=Matching wineserver file. Required for wine; omit for native.2Noneq
o
files^Complete Wine installation files, preserving paths relative to loader/server. Omit for native.2NoneU
S
identityADistribution/version description exposed through WineRuntimeInfo.2""i
g
requirementsQHost library/OS requirements for consumers to inspect; not enforced by this rule.2""�
�
env�Wine runtime environment, taking precedence over payload env. {loader_dir} and {server_dir} expand at execution time. Reserved lifecycle variables cannot be set here.
2{}�WineRuntimeInfo<Immutable Wine distribution built for the selected executor.2�
�
WineRuntimeInfo<Immutable Wine distribution built for the selected executor.L
loaderBNative Wine ELF/Mach-O loader File; installation layout preserved.#
serverMatching wineserver File.0
files'Complete immutable distribution depset.,
identity Distribution/version provenance.D
requirements4Host library requirements, not inferred hermeticity.S
envLDistribution loader environment; {loader_dir} and {server_dir} placeholders."'
WineRuntimeInfo//wine:toolchain.bzlN
L
loaderBNative Wine ELF/Mach-O loader File; installation layout preserved.%
#
serverMatching wineserver File.2
0
files'Complete immutable distribution depset..
,
identity Distribution/version provenance.F
D
requirements4Host library requirements, not inferred hermeticity.U
S
envLDistribution loader environment; {loader_dir} and {server_dir} placeholders.�WindowsRunnerInfo(Execution contract for Windows payloads.2�
�
WindowsRunnerInfo(Execution contract for Windows payloads.O
archGNative executor architecture; Wine may support additional payload CPUs.
backendwine or native.^
launcherRLinux/macOS Wine supervisor FilesToRunProvider, or None for direct native actions.#
runtimeWineRuntimeInfo or None.7
runfiles+Complete executor-native launcher runfiles.")
WindowsRunnerInfo//wine:toolchain.bzlQ
O
archGNative executor architecture; Wine may support additional payload CPUs.

backendwine or native.`
^
launcherRLinux/macOS Wine supervisor FilesToRunProvider, or None for direct native actions.%
#
runtimeWineRuntimeInfo or None.9
7
runfiles+Complete executor-native launcher runfiles.DWindows runner providers and user-authored toolchain implementation.�
winewindows_binary.bzl�windows_binary�Wrap a Windows executable for use with bazel run or as another rule's tool.

The wrapper runs on Linux/macOS using the Wine toolchain matching its configured
target OS/CPU. As a dependency configured with cfg = "exec", that is the consuming
action's execution platform. Native Windows actions should use windows_actions.run.

The payload's runfiles and RunEnvironmentInfo are preserved. Prebuilt payloads
use the selected Wine runtime's supported guest CPUs. For source-built payloads,
target_platform optionally selects a Windows compilation platform; its CPU must
match the wrapper's CPU. This rule does not register a C++ compiler."�

�
windows_binary�Wrap a Windows executable for use with bazel run or as another rule's tool.

The wrapper runs on Linux/macOS using the Wine toolchain matching its configured
target OS/CPU. As a dependency configured with cfg = "exec", that is the consuming
action's execution platform. Native Windows actions should use windows_actions.run.

The payload's runfiles and RunEnvironmentInfo are preserved. Prebuilt payloads
use the selected Wine runtime's supported guest CPUs. For source-built payloads,
target_platform optionally selects a Windows compilation platform; its CPU must
match the wrapper's CPU. This rule does not register a C++ compiler.*
nameA unique name for this target. e
binaryWWindows executable file or executable target; its runfiles are included in the wrapper. �
target_platformkOptional Windows compilation platform for binary. Its CPU must match the wrapper's CPU; omit for prebuilts.*(
PlatformInfo
PlatformInfo<native>2None"+
windows_binary//wine:windows_binary.bzl8,
*
nameA unique name for this target. g
e
binaryWWindows executable file or executable target; its runfiles are included in the wrapper. �
�
target_platformkOptional Windows compilation platform for binary. Its CPU must match the wrapper's CPU; omit for prebuilts.*(
PlatformInfo
PlatformInfo<native>2NoneERun Windows executables through native Wine on Linux/macOS platforms. 