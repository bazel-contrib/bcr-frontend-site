�+
wineactions.bzl�	wine_path�Args.map_each callback for Wine-only executable adapter consumers.

Pass this function to Args.add_all; do not call it during analysis.
For runner-based actions, use windows_actions.add_path instead.
*�
�
	wine_path@
file4File supplied by Args during command-line expansion. (�Args.map_each callback for Wine-only executable adapter consumers.

Pass this function to Args.add_all; do not call it during analysis.
For runner-based actions, use windows_actions.add_path instead.
"D
BA JSON-escaped Wine path marker containing the action-mapped path.2
	wine_path//wine:actions.bzlB
@
file4File supplied by Args during command-line expansion. (�windows_actions.add_path�Append a File path, deferring mapping and Wine encoding until execution.

Use this for command-line arguments, not markers inside payload response
files. Tree artifacts are passed as directory paths rather than expanded.
*�
�
windows_actions.add_path:
runner,Context returned by windows_actions.resolve. (/
args#Args object receiving the argument. (O
fileCFile or tree artifact. Pass ordinary strings with Args.add instead. (:
format(Surrounding option syntax, e.g. /out:%s."%s"(�Append a File path, deferring mapping and Wine encoding until execution.

Use this for command-line arguments, not markers inside payload response
files. Tree artifacts are passed as directory paths rather than expanded.
2
	_add_path//wine:actions.bzl<
:
runner,Context returned by windows_actions.resolve. (1
/
args#Args object receiving the argument. (Q
O
fileCFile or tree artifact. Pass ordinary strings with Args.add instead. (<
:
format(Surrounding option syntax, e.g. /out:%s."%s"(�windows_actions.resolveBBind a runner to the execution group declaring its toolchain type.*�
�
windows_actions.resolve&
ctxThe consuming rule context. (J

exec_group/Group declaring windows_actions.toolchain_type.	"default"(BBind a runner to the execution group declaring its toolchain type."�
�Context for run/add_path, containing WindowsRunnerInfo as windows and the
action's exec_group. windows.arch describes the executor CPU; Wine owns
payload CPU support. Constrain the execution group to require a
particular executor, for example to avoid CPU translation.2
_resolve//wine:actions.bzl(
&
ctxThe consuming rule context. (L
J

exec_group/Group declaring windows_actions.toolchain_type.	"default"(�windows_actions.run�Declare an action running a Windows executable on the resolved executor.

Linux/macOS use Wine with a fresh writable prefix per action. Windows
executes the payload directly. Use add_path for File arguments to preserve
optional Bazel path mapping. The selected runtime owns guest CPU support;
this helper does not inspect the executable's architecture.
*�
�
windows_actions.run&
ctxThe consuming rule context. (\
runnerNContext returned by windows_actions.resolve for this action's
execution group. (�

executable�Windows executable File or FilesToRunProvider. Configure
source-built tools for Windows explicitly; this function does not
transition dependencies. (;
outputs,Output Files declared by the consuming rule. (M
	arguments:List of strings and Args objects passed to the executable.[](F
inputs6List or depset of input Files, as for ctx.actions.run.[](�
env}Environment variables for the Windows process. Runfiles discovery
variables are reserved by the supervisor on Wine executors.{}(Q
runtime_files:Additional Files required by the executable, such as DLLs.[](�
toolsxList of Files/FilesToRunProviders, or depset of Files, as for
ctx.actions.run. The executable is included automatically.[](,
mnemonicAction mnemonic."WindowsRun"(6
progress_messageOptional progress message.None(x
kwargslAdditional ctx.actions.run arguments. Do not supply
exec_group or toolchain; these are determined by runner.(�Declare an action running a Windows executable on the resolved executor.

Linux/macOS use Wine with a fresh writable prefix per action. Windows
executes the payload directly. Use add_path for File arguments to preserve
optional Bazel path mapping. The selected runtime owns guest CPU support;
this helper does not inspect the executable's architecture.
2
_run//wine:actions.bzl(
&
ctxThe consuming rule context. (^
\
runnerNContext returned by windows_actions.resolve for this action's
execution group. (�
�

executable�Windows executable File or FilesToRunProvider. Configure
source-built tools for Windows explicitly; this function does not
transition dependencies. (=
;
outputs,Output Files declared by the consuming rule. (O
M
	arguments:List of strings and Args objects passed to the executable.[](H
F
inputs6List or depset of input Files, as for ctx.actions.run.[](�
�
env}Environment variables for the Windows process. Runfiles discovery
variables are reserved by the supervisor on Wine executors.{}(S
Q
runtime_files:Additional Files required by the executable, such as DLLs.[](�
�
toolsxList of Files/FilesToRunProviders, or depset of Files, as for
ctx.actions.run. The executable is included automatically.[](.
,
mnemonicAction mnemonic."WindowsRun"(8
6
progress_messageOptional progress message.None(z
x
kwargslAdditional ctx.actions.run arguments. Do not supply
exec_group or toolchain; these are determined by runner.(ELow-level Windows actions using one resolved execution-group context.�
wine/extensionwine.bzl�wine�Provide pinned Wine runtimes and independently registered native developer tools.

Import wine_toolchains with use_repo, then register
@wine_toolchains//:all explicitly. This extension has no configuration tags and
does not register toolchains automatically. Custom distributions use
windows_runner_toolchain and native toolchain declarations instead.

Import wine_tools_toolchains and explicitly register @wine_tools_toolchains//:all
to use native wmc, wrc and widl. This tools-only setup needs no Windows runner,
Wine runtime, FEX, supervisor or C++ compiler. Custom tools distributions use
wine_tools_toolchain and native toolchain declarations.

Defaults cover Linux x86_64/ARM64, macOS ARM64 and native Windows x86_64/ARM64.
ARM64 Wine distributions include FEX for x86_64 Windows programs. Linux requires
glibc 2.17 or newer and a UTF-8 locale. The macOS distribution declares a 26.5
deployment minimum; see the runtime guide for tested baselines and limitations.J�
�
wine�Provide pinned Wine runtimes and independently registered native developer tools.

Import wine_toolchains with use_repo, then register
@wine_toolchains//:all explicitly. This extension has no configuration tags and
does not register toolchains automatically. Custom distributions use
windows_runner_toolchain and native toolchain declarations instead.

Import wine_tools_toolchains and explicitly register @wine_tools_toolchains//:all
to use native wmc, wrc and widl. This tools-only setup needs no Windows runner,
Wine runtime, FEX, supervisor or C++ compiler. Custom tools distributions use
wine_tools_toolchain and native toolchain declarations.

Defaults cover Linux x86_64/ARM64, macOS ARM64 and native Windows x86_64/ARM64.
ARM64 Wine distributions include FEX for x86_64 Windows programs. Linux requires
glibc 2.17 or newer and a UTF-8 locale. The macOS distribution declares a 26.5
deployment minimum; see the runtime guide for tested baselines and limitations."//wine/extension:wine.bzlKPinned default Wine toolchains; custom runtimes use public toolchain rules.�)
winetoolchain.bzl�windows_runner_toolchain�Define a Windows runner implementation for native execution or Wine.

Wrap this target in native toolchain declarations with constraints matching the
executor OS/CPU. Use runner_toolchain_type for windows_actions and
adapter_toolchain_type for windows_binary. The adapter registration additionally
constrains the target platform to match the executor.

Wine distributions must preserve their installation layout and include all
runtime files. This rule supplies no CPU emulator itself; guest CPU support is
determined by the supplied Wine distribution. Native runners execute payloads
directly and must omit Wine files and launcher."�
�
windows_runner_toolchain�Define a Windows runner implementation for native execution or Wine.

Wrap this target in native toolchain declarations with constraints matching the
executor OS/CPU. Use runner_toolchain_type for windows_actions and
adapter_toolchain_type for windows_binary. The adapter registration additionally
constrains the target platform to match the executor.

Wine distributions must preserve their installation layout and include all
runtime files. This rule supplies no CPU emulator itself; guest CPU support is
determined by the supplied Wine distribution. Native runners execute payloads
directly and must omit Wine files and launcher.*
nameA unique name for this target. {
archZExecutor CPU, matching the registration's platform constraints; not the Windows guest CPU. J"x86_64"J	"aarch64"d
backendCUse native for Windows executors or wine for Linux/macOS executors. J"native"J"wine"�
launchernWine supervisor executable, normally @rules_wine//wine/runtime:supervisor. Required for wine; omit for native.2NoneN
loader<Native Wine loader file. Required for wine; omit for native.2NoneO
server=Matching wineserver file. Required for wine; omit for native.2Noneo
files^Complete Wine installation files, preserving paths relative to loader/server. Omit for native.2NoneS
identityADistribution/version description exposed through WineRuntimeInfo.2""g
requirementsQHost library/OS requirements for consumers to inspect; not enforced by this rule.2""�
env�Wine runtime environment, taking precedence over payload env. {loader_dir} and {server_dir} expand at execution time. Reserved lifecycle variables cannot be set here.
2{}"0
windows_runner_toolchain//wine:toolchain.bzl,
*
nameA unique name for this target. }
{
archZExecutor CPU, matching the registration's platform constraints; not the Windows guest CPU. J"x86_64"J	"aarch64"f
d
backendCUse native for Windows executors or wine for Linux/macOS executors. J"native"J"wine"�
�
launchernWine supervisor executable, normally @rules_wine//wine/runtime:supervisor. Required for wine; omit for native.2NoneP
N
loader<Native Wine loader file. Required for wine; omit for native.2NoneQ
O
server=Matching wineserver file. Required for wine; omit for native.2Noneq
o
files^Complete Wine installation files, preserving paths relative to loader/server. Omit for native.2NoneU
S
identityADistribution/version description exposed through WineRuntimeInfo.2""i
g
requirementsQHost library/OS requirements for consumers to inspect; not enforced by this rule.2""�
�
env�Wine runtime environment, taking precedence over payload env. {loader_dir} and {server_dir} expand at execution time. Reserved lifecycle variables cannot be set here.
2{}�WineRuntimeInfo<Immutable Wine distribution built for the selected executor.2�
�
WineRuntimeInfo<Immutable Wine distribution built for the selected executor.L
loaderBNative Wine ELF/Mach-O loader File; installation layout preserved.#
serverMatching wineserver File.0
files'Complete immutable distribution depset.,
identity Distribution/version provenance.D
requirements4Host library requirements, not inferred hermeticity.S
envLDistribution loader environment; {loader_dir} and {server_dir} placeholders."'
WineRuntimeInfo//wine:toolchain.bzlN
L
loaderBNative Wine ELF/Mach-O loader File; installation layout preserved.%
#
serverMatching wineserver File.2
0
files'Complete immutable distribution depset..
,
identity Distribution/version provenance.F
D
requirements4Host library requirements, not inferred hermeticity.U
S
envLDistribution loader environment; {loader_dir} and {server_dir} placeholders.�WindowsRunnerInfo(Execution contract for Windows payloads.2�
�
WindowsRunnerInfo(Execution contract for Windows payloads.O
archGNative executor architecture; Wine may support additional payload CPUs.
backendwine or native.^
launcherRLinux/macOS Wine supervisor FilesToRunProvider, or None for direct native actions.#
runtimeWineRuntimeInfo or None.7
runfiles+Complete executor-native launcher runfiles.")
WindowsRunnerInfo//wine:toolchain.bzlQ
O
archGNative executor architecture; Wine may support additional payload CPUs.

backendwine or native.`
^
launcherRLinux/macOS Wine supervisor FilesToRunProvider, or None for direct native actions.%
#
runtimeWineRuntimeInfo or None.9
7
runfiles+Complete executor-native launcher runfiles.DWindows runner providers and user-authored toolchain implementation.�1
winetools_toolchain.bzl�wine_tools_toolchain�Define a native Wine tools distribution.

Wrap this implementation in a native toolchain declaration using
@rules_wine//wine:tools_toolchain_type and executor OS/CPU constraints. All three
executables must run directly on that executor. No Wine runner is used.
Supply the complete distribution in files, preserving its relative paths.
The headers are compiler inputs, not a C/C++ Windows SDK.

Resolved genrules can use WINE_WMC, WINE_WRC and WINE_WIDL make variables.
Each is a raw executable path without flags; quote it in shell commands.
DefaultInfo supplies the complete distribution. Custom executables that need
runfiles must also appear in genrule.tools to materialize those runfiles."�
�

wine_tools_toolchain�Define a native Wine tools distribution.

Wrap this implementation in a native toolchain declaration using
@rules_wine//wine:tools_toolchain_type and executor OS/CPU constraints. All three
executables must run directly on that executor. No Wine runner is used.
Supply the complete distribution in files, preserving its relative paths.
The headers are compiler inputs, not a C/C++ Windows SDK.

Resolved genrules can use WINE_WMC, WINE_WRC and WINE_WIDL make variables.
Each is a raw executable path without flags; quote it in shell commands.
DefaultInfo supplies the complete distribution. Custom executables that need
runfiles must also appear in genrule.tools to materialize those runfiles.*
nameA unique name for this target. !
wmcNative wmc executable. !
wrcNative wrc executable. #
widlNative widl executable. _
filesRAll tools distribution files, including headers, IDLs, typelibs and Unix NLS data. l
include]Header directly inside the distribution's include/wine/windows directory, normally windows.h. P
nlsABundled share/wine/nls/locale.nls. Omit for native Windows tools.2NoneB
x86_64_typelib,Bundled lib/wine/x86_64-windows/stdole2.tlb. D
aarch64_typelib-Bundled lib/wine/aarch64-windows/stdole2.tlb. "2
wine_tools_toolchain//wine:tools_toolchain.bzl,
*
nameA unique name for this target. #
!
wmcNative wmc executable. #
!
wrcNative wrc executable. %
#
widlNative widl executable. a
_
filesRAll tools distribution files, including headers, IDLs, typelibs and Unix NLS data. n
l
include]Header directly inside the distribution's include/wine/windows directory, normally windows.h. R
P
nlsABundled share/wine/nls/locale.nls. Omit for native Windows tools.2NoneD
B
x86_64_typelib,Bundled lib/wine/x86_64-windows/stdole2.tlb. F
D
aarch64_typelib-Bundled lib/wine/aarch64-windows/stdole2.tlb. �wine_tools_executable_toolchain�Define tools for the wmc, wrc and widl executable labels.

Wrap with a native toolchain declaration using
@rules_wine//wine:tools_executable_toolchain_type and target_compatible_with
constraints describing where these executables run. Dependencies remain in the
configured target platform, which is the consuming action's executor when used
as a tool. Use wine_tools_toolchain separately for generation rules and genrules."�
�
wine_tools_executable_toolchain�Define tools for the wmc, wrc and widl executable labels.

Wrap with a native toolchain declaration using
@rules_wine//wine:tools_executable_toolchain_type and target_compatible_with
constraints describing where these executables run. Dependencies remain in the
configured target platform, which is the consuming action's executor when used
as a tool. Use wine_tools_toolchain separately for generation rules and genrules.*
nameA unique name for this target. !
wmcNative wmc executable. !
wrcNative wrc executable. #
widlNative widl executable. _
filesRAll tools distribution files, including headers, IDLs, typelibs and Unix NLS data. l
include]Header directly inside the distribution's include/wine/windows directory, normally windows.h. P
nlsABundled share/wine/nls/locale.nls. Omit for native Windows tools.2NoneB
x86_64_typelib,Bundled lib/wine/x86_64-windows/stdole2.tlb. D
aarch64_typelib-Bundled lib/wine/aarch64-windows/stdole2.tlb. "=
wine_tools_executable_toolchain//wine:tools_toolchain.bzl,
*
nameA unique name for this target. #
!
wmcNative wmc executable. #
!
wrcNative wrc executable. %
#
widlNative widl executable. a
_
filesRAll tools distribution files, including headers, IDLs, typelibs and Unix NLS data. n
l
include]Header directly inside the distribution's include/wine/windows directory, normally windows.h. R
P
nlsABundled share/wine/nls/locale.nls. Omit for native Windows tools.2NoneD
B
x86_64_typelib,Bundled lib/wine/x86_64-windows/stdole2.tlb. F
D
aarch64_typelib-Bundled lib/wine/aarch64-windows/stdole2.tlb. �
WineToolsInfoANative wmc, wrc and widl with their declared compiler input data.2�

�
WineToolsInfoANative wmc, wrc and widl with their declared compiler input data.R
wmcKNative message compiler FilesToRunProvider, preserving executable runfiles.S
wrcLNative resource compiler FilesToRunProvider, preserving executable runfiles.O
widlGNative IDL compiler FilesToRunProvider, preserving executable runfiles.L
filesCComplete tools distribution depset, preserving installation layout.G
include<A header File whose parent is the bundled include directory.9
nls2locale.nls File, or None for native Windows tools.>
typelibs2Target CPU to bundled stdole2.tlb File dictionary.8
runfiles,Tool name to executable runfiles dictionary."+
WineToolsInfo//wine:tools_toolchain.bzlT
R
wmcKNative message compiler FilesToRunProvider, preserving executable runfiles.U
S
wrcLNative resource compiler FilesToRunProvider, preserving executable runfiles.Q
O
widlGNative IDL compiler FilesToRunProvider, preserving executable runfiles.N
L
filesCComplete tools distribution depset, preserving installation layout.I
G
include<A header File whose parent is the bundled include directory.;
9
nls2locale.nls File, or None for native Windows tools.@
>
typelibs2Target CPU to bundled stdole2.tlb File dictionary.:
8
runfiles,Tool name to executable runfiles dictionary.FNative Wine developer tools, independent of Windows program execution.�
winewindows_binary.bzl�windows_binary�Wrap a Windows executable for use with bazel run or as another rule's tool.

The wrapper runs on Linux/macOS using the Wine toolchain matching its configured
target OS/CPU. As a dependency configured with cfg = "exec", that is the consuming
action's execution platform. Native Windows actions should use windows_actions.run.

The payload's runfiles and RunEnvironmentInfo are preserved. Prebuilt payloads
use the selected Wine runtime's supported guest CPUs. For source-built payloads,
target_platform optionally selects a Windows compilation platform; its CPU must
match the wrapper's CPU. This rule does not register a C++ compiler."�

�
windows_binary�Wrap a Windows executable for use with bazel run or as another rule's tool.

The wrapper runs on Linux/macOS using the Wine toolchain matching its configured
target OS/CPU. As a dependency configured with cfg = "exec", that is the consuming
action's execution platform. Native Windows actions should use windows_actions.run.

The payload's runfiles and RunEnvironmentInfo are preserved. Prebuilt payloads
use the selected Wine runtime's supported guest CPUs. For source-built payloads,
target_platform optionally selects a Windows compilation platform; its CPU must
match the wrapper's CPU. This rule does not register a C++ compiler.*
nameA unique name for this target. e
binaryWWindows executable file or executable target; its runfiles are included in the wrapper. �
target_platformkOptional Windows compilation platform for binary. Its CPU must match the wrapper's CPU; omit for prebuilts.*(
PlatformInfo
PlatformInfo<native>2None"+
windows_binary//wine:windows_binary.bzl8,
*
nameA unique name for this target. g
e
binaryWWindows executable file or executable target; its runfiles are included in the wrapper. �
�
target_platformkOptional Windows compilation platform for binary. Its CPU must match the wrapper's CPU; omit for prebuilts.*(
PlatformInfo
PlatformInfo<native>2NoneERun Windows executables through native Wine on Linux/macOS platforms.�
winewine_idl_files.bzl�wine_idl_files�Generate selected headers, type libraries or C source files from IDL.

The configured target CPU selects the Windows output ABI (x86_64 or aarch64),
independently of the executor CPU. Every output is an explicit output label;
select at least one. Declare imported IDLs, headers and typelibs in imports.
Bundled Wine IDLs and the matching stdole2.tlb are available without a host SDK.
Generated C uses interpreter stubs (-Oif) and includes the selected header's basename, or the input basename.h if
header is omitted. Consumers own include paths, C compilation and linking.
Upstream __DATE__ and __TIME__ expand to wall-clock time; avoid them in cached builds."�
�
wine_idl_files�Generate selected headers, type libraries or C source files from IDL.

The configured target CPU selects the Windows output ABI (x86_64 or aarch64),
independently of the executor CPU. Every output is an explicit output label;
select at least one. Declare imported IDLs, headers and typelibs in imports.
Bundled Wine IDLs and the matching stdole2.tlb are available without a host SDK.
Generated C uses interpreter stubs (-Oif) and includes the selected header's basename, or the input basename.h if
header is omitted. Consumers own include paths, C compilation and linking.
Upstream __DATE__ and __TIME__ expand to wall-clock time; avoid them in cached builds.*
nameA unique name for this target. 
srcIDL source. ^
importsMImported IDLs, headers and type libraries; each parent directory is searched.2[]>
defines-Preprocessor definitions, NAME or NAME=VALUE.2[]�
includes�Additional package-relative include directories, searched in both source and generated output roots. Imported inputs must still be declared in imports.2[]*
headerGenerated header (-h).2None81
typelibGenerated type library (-t).2None81
clientGenerated client C stub (-c).2None81
serverGenerated server C stub (-s).2None81
proxyGenerated proxy C source (-p).2None8?
iid.Generated interface identifiers C source (-u).2None8"+
wine_idl_files//wine:wine_idl_files.bzl,
*
nameA unique name for this target. 

srcIDL source. `
^
importsMImported IDLs, headers and type libraries; each parent directory is searched.2[]@
>
defines-Preprocessor definitions, NAME or NAME=VALUE.2[]�
�
includes�Additional package-relative include directories, searched in both source and generated output roots. Imported inputs must still be declared in imports.2[],
*
headerGenerated header (-h).2None83
1
typelibGenerated type library (-t).2None83
1
clientGenerated client C stub (-c).2None83
1
serverGenerated server C stub (-s).2None83
1
proxyGenerated proxy C source (-p).2None8A
?
iid.Generated interface identifiers C source (-u).2None8:Generate explicitly selected IDL outputs with native widl.�
winewine_message_file.bzl�wine_message_file�Compile a message table to RC plus header, or directly to RES.

The default rc mode emits out and an implicit name.h output label. Message
tables are inline (-i), so no content-dependent .bin files are written. The res
mode emits only out: upstream wmc does not generate a header in that mode.
Message tables use Unicode output (-U). Input defaults to the source codepage;
set unicode for UTF-16 input (-u), not UTF-8."�

�
wine_message_file�Compile a message table to RC plus header, or directly to RES.

The default rc mode emits out and an implicit name.h output label. Message
tables are inline (-i), so no content-dependent .bin files are written. The res
mode emits only out: upstream wmc does not generate a header in that mode.
Message tables use Unicode output (-U). Input defaults to the source codepage;
set unicode for UTF-16 input (-u), not UTF-8.*
nameA unique name for this target. 
srcMessage definitions. ;
out.Output RC or RES file, matching output_format. 8Y
headerERC mode header output; defaults to name.h. Not available in res mode.2None8h
output_formatBrc emits a header and inline RC; res emits only a binary resource.2"rc"J"rc"J"res"N
unicode:Read UTF-16 input. This is wmc -u, not wrc's UTF-8 option.2False"1
wine_message_file//wine:wine_message_file.bzl,
*
nameA unique name for this target. !

srcMessage definitions. =
;
out.Output RC or RES file, matching output_format. 8[
Y
headerERC mode header output; defaults to name.h. Not available in res mode.2None8j
h
output_formatBrc emits a header and inline RC; res emits only a binary resource.2"rc"J"rc"J"res"P
N
unicode:Read UTF-16 input. This is wmc -u, not wrc's UTF-8 option.2False,Compile message definitions with native wmc.�
winewine_resource_file.bzl�wine_resource_file�Compile UTF-8 RC source to a binary RES file without a host SDK.

Declare every included header and resource asset in hdrs and data. Their parent
directories and the bundled Wine headers form the include search path. Generated
files work as ordinary output labels. No C/C++ compilation or linking is added.
Upstream __DATE__ and __TIME__ expand to wall-clock time; avoid them in cached builds."�
�
wine_resource_file�Compile UTF-8 RC source to a binary RES file without a host SDK.

Declare every included header and resource asset in hdrs and data. Their parent
directories and the bundled Wine headers form the include search path. Generated
files work as ordinary output labels. No C/C++ compilation or linking is added.
Upstream __DATE__ and __TIME__ expand to wall-clock time; avoid them in cached builds.*
nameA unique name for this target. !
srcUTF-8 resource script. K
hdrs=Declared included headers; each parent directory is searched.2[]J
data<Declared resource assets; each parent directory is searched.2[]>
defines-Preprocessor definitions, NAME or NAME=VALUE.2[]�
includes�Additional package-relative include directories, searched in both source and generated output roots. Inputs must still be declared in hdrs/data.2[] 
outBinary .res output. 8"3
wine_resource_file//wine:wine_resource_file.bzl,
*
nameA unique name for this target. #
!
srcUTF-8 resource script. M
K
hdrs=Declared included headers; each parent directory is searched.2[]L
J
data<Declared resource assets; each parent directory is searched.2[]@
>
defines-Preprocessor definitions, NAME or NAME=VALUE.2[]�
�
includes�Additional package-relative include directories, searched in both source and generated output roots. Inputs must still be declared in hdrs/data.2[]"
 
outBinary .res output. 8*Compile Windows resources with native wrc. 