�
+
ryandraves_nlbbzl/constraintsdefs.bzl�compatible_with_config.Expresses compatibility with a config_setting.*�
�
compatible_with_config
config_label (.Expresses compatibility with a config_setting.2D
compatible_with_config*@@ryandraves_nlb//bzl/constraints:defs.bzl
�incompatible_with_config0Expresses incompatibility with a config_setting.*�
�
incompatible_with_config
config_label (0Expresses incompatibility with a config_setting.2F
incompatible_with_config*@@ryandraves_nlb//bzl/constraints:defs.bzl
�
)
ryandraves_nlb
bzl/macrosbuffham.bzl*�ModuleInfo request error: invalid argument: Traceback (most recent call last):
	File "external/ryandraves_nlb/bzl/macros/buffham.bzl", line 133, column 18, in <toplevel>
		buffham_template = macro(
Error in macro: in call to macro(), parameter 'inherit_attrs' got value of type 'build.stack.devtools.build.constellate.fakebuildapi.FakeStarlarkNativeModuleApi$2', want 'rule, macro, string, or NoneType'�
$
ryandraves_nlb
bzl/macroscc.bzl*�ModuleInfo request error: invalid argument: Traceback (most recent call last):
	File "external/ryandraves_nlb/bzl/macros/cc.bzl", line 1, column 49, in <toplevel>
		load("@aspect_bazel_lib//lib:transitions.bzl", "platform_transition_test")
Error: file '@aspect_bazel_lib//lib:transitions.bzl' does not contain symbol 'platform_transition_test'��
%
ryandraves_nlb
bzl/macrosemb.bzl��flashFlash a binary to a device"��
�N
flashFlash a binary to a device*
nameA unique name for this target. �	
config_settings�	
Config settings to change for this target.

The keys are labels for settings, and the values are strings for the new value
to use. Pass `Label` objects or canonical label strings for the keys to ensure
they resolve as expected (canonical labels start with `@@` and can be
obtained by calling `str(Label(...))`).

Most `@rules_python//python/config_setting` settings can be used here, which
allows, for example, making only a certain `py_binary` use
{obj}`--boostrap_impl=script`.

Additional or custom config settings can be registered using the
{obj}`add_transition_setting` API. This allows, for example, forcing a
particular CPU, or defining a custom setting that `select()` uses elsewhere
to pick between `pip.parse` hubs. See the [How to guide on multiple
versions of a library] for a more concrete example.

:::{note}
These values are transitioned on, so will affect the analysis graph and the
associated memory overhead. The more unique configurations in your overall
build, the more memory and (often unnecessary) re-analysis and re-building
can occur. See
https://bazel.build/extending/config#memory-performance-considerations for
more information about risks and considerations.
:::

:::{versionadded} 1.7.0
:::
	2{}�
data�
The list of files need by this library at runtime. See comments about
the [`data` attribute typically defined by rules](https://bazel.build/reference/be/common-definitions#typical-attributes).

There is no `py_embed_data` like there is `cc_embed_data` and `go_embed_data`.
This is because Python has a concept of runtime resources.
2[]�
deps�
List of additional libraries to be linked in to the target.
See comments about
the [`deps` attribute typically defined by
rules](https://bazel.build/reference/be/common-definitions#typical-attributes).
These are typically `py_library` rules.

Targets that only provide data files used at runtime belong in the `data`
attribute.

:::{note}
The order of this list can matter because it affects the order that information
from dependencies is merged in, which can be relevant depending on the ordering
mode of depsets that are merged.

* {obj}`PyInfo.venv_symlinks` uses default ordering.

See {obj}`PyInfo` for more information about the ordering of its depsets and
how its fields are merged.
:::
*
PyInfo*
CcInfo*
BuiltinPyInfo2[]
distribs2[]�
env�Dictionary of strings; optional; values are subject to `$(location)` and "Make
variable" substitution.

Specifies additional environment variables to set when the target is executed by
`test` or `run`.

2{}�
imports�
List of import directories to be added to the PYTHONPATH.

Subject to "Make variable" substitution. These import directories will be added
for this rule and all rules that depend on it (note: not the rules this rule
depends on. Each directory will be added to `PYTHONPATH` by `py_binary` rules
that depend on this rule. The strings are repo-runfiles-root relative,

Absolute paths (paths that start with `/`) and paths that references a path
above the execution root are not allowed and will result in an error.
2[]�
interpreter_args�
Arguments that are only applicable to the interpreter.

The args an interpreter supports are specific to the interpreter. For
CPython, see https://docs.python.org/3/using/cmdline.html.

:::{note}
Only supported for {obj}`--bootstrap_impl=script`. Ignored otherwise.
:::

:::{seealso}
The {any}`RULES_PYTHON_ADDITIONAL_INTERPRETER_ARGS` environment variable
:::

:::{versionadded} 1.3.0
:::
2[]�
legacy_create_init�Whether to implicitly create empty `__init__.py` files in the runfiles tree.
These are created in every directory containing Python source code or shared
libraries, and every parent directory of those directories, excluding the repo
root directory. The default, `-1` (auto), means true unless
`--incompatible_default_to_explicit_init_py` is used. If false, the user is
responsible for creating (possibly empty) `__init__.py` files and adding them to
the `srcs` of Python targets as required.
2-1
licenses2[]�
main�Optional; the name of the source file that is the main entry point of the
application. This file must also be listed in `srcs`. If left unspecified,
`name`, with `.py` appended, is used instead. If `name` does not match any
filename in `srcs`, `main` must be specified.

This is mutually exclusive with {obj}`main_module`.
2None�
main_module�
Module name to execute as the main program.

When set, `srcs` is not required, and it is assumed the module is
provided by a dependency.

See https://docs.python.org/3/using/cmdline.html#cmdoption-m for more
information about running modules as the main program.

This is mutually exclusive with {obj}`main`.

:::{versionadded} 1.3.0
:::
:::{versionchanged} 1.7.0
Support added for {obj}`--bootstrap_impl=system_python`.
:::
2""�

precompile�
Whether py source files **for this target** should be precompiled.

Values:

* `inherit`: Allow the downstream binary decide if precompiled files are used.
* `enabled`: Compile Python source files at build time.
* `disabled`: Don't compile Python source files at build time.

:::{seealso}

* The {flag}`--precompile` flag, which can override this attribute in some cases
  and will affect all targets when building.
* The {obj}`pyc_collection` attribute for transitively enabling precompiling on
  a per-target basis.
* The [Precompiling](precompiling) docs for a guide about using precompiling.
:::
2	"inherit"�
precompile_invalidation_mode�
How precompiled files should be verified to be up-to-date with their associated
source files. Possible values are:
* `auto`: The effective value will be automatically determined by other build
  settings.
* `checked_hash`: Use the pyc file if the hash of the source file matches the hash
  recorded in the pyc file. This is most useful when working with code that
  you may modify.
* `unchecked_hash`: Always use the pyc file; don't check the pyc's hash against
  the source file. This is most useful when the code won't be modified.

For more information on pyc invalidation modes, see
https://docs.python.org/3/library/py_compile.html#py_compile.PycInvalidationMode
2"auto"�
precompile_optimize_level�
The optimization level for precompiled files.

For more information about optimization levels, see the `compile()` function's
`optimize` arg docs at https://docs.python.org/3/library/functions.html#compile

NOTE: The value `-1` means "current interpreter", which will be the interpreter
used _at build time when pycs are generated_, not the interpreter used at
runtime when the code actually runs.
20�
precompile_source_retention�
Determines, when a source file is compiled, if the source file is kept
in the resulting output or not. Valid values are:

* `inherit`: Inherit the value from the {flag}`--precompile_source_retention` flag.
* `keep_source`: Include the original Python source.
* `omit_source`: Don't include the original py source.
2	"inherit"�
pyc_collection�
Determines whether pyc files from dependencies should be manually included.

Valid values are:
* `inherit`: Inherit the value from {flag}`--precompile`.
* `include_pyc`: Add implicitly generated pyc files from dependencies. i.e.
  pyc files for targets that specify {attr}`precompile="inherit"`.
* `disabled`: Don't add implicitly generated pyc files. Note that
  pyc files may still come from dependencies that enable precompiling at the
  target level.
2	"inherit"�
pyi_deps�
Dependencies providing type definitions the library needs.

These are dependencies that satisfy imports guarded by `typing.TYPE_CHECKING`.
These are build-time only dependencies and not included as part of a runnable
program (packaging rules may include them, however).

:::{versionadded} 1.1.0
:::
*
PyInfo*
CcInfo*
BuiltinPyInfo2[]�
pyi_srcs�
Type definition files for the library.

These are typically `.pyi` files, but other file types for type-checker specific
formats are allowed. These files are build-time only dependencies and not included
as part of a runnable program (packaging rules may include them, however).

:::{versionadded} 1.1.0
:::
2[]�
python_version�
The Python version this target should use.

The value should be in `X.Y` or `X.Y.Z` (or compatible) format. If empty or
unspecified, the incoming configuration's {obj}`--python_version` flag is
inherited. For backwards compatibility, the values `PY2` and `PY3` are
accepted, but treated as an empty/unspecified value.

:::{note}
In order for the requested version to be used, there must be a
toolchain configured to match the Python version. If there isn't, then it
may be silently ignored, or an error may occur, depending on the toolchain
configuration.
:::

:::{versionchanged} 1.1.0

This attribute was changed from only accepting `PY2` and `PY3` values to
accepting arbitrary Python versions.
:::
2""�
srcs�
The list of Python source files that are processed to create the target. This
includes all your checked-in code and may include generated source files.  The
`.py` files belong in `srcs` and library targets belong in `deps`. Other binary
files that may be needed at run time belong in `data`.
2[]4
srcs_versionDefunct, unused, does nothing.2""�
stamp�
Whether to encode build information into the binary. Possible values:

* `stamp = 1`: Always stamp the build information into the binary, even in
  `--nostamp` builds. **This setting should be avoided**, since it potentially kills
  remote caching for the binary and any downstream actions that depend on it.
* `stamp = 0`: Always replace build information by constant values. This gives
  good build result caching.
* `stamp = -1`: Embedding of build information is controlled by the
  `--[no]stamp` flag.

Stamped binaries are not rebuilt unless their dependencies change.

WARNING: Stamping can harm build performance by reducing cache hits and should
be avoided if possible.
2-1
,
*
nameA unique name for this target. �	
�	
config_settings�	
Config settings to change for this target.

The keys are labels for settings, and the values are strings for the new value
to use. Pass `Label` objects or canonical label strings for the keys to ensure
they resolve as expected (canonical labels start with `@@` and can be
obtained by calling `str(Label(...))`).

Most `@rules_python//python/config_setting` settings can be used here, which
allows, for example, making only a certain `py_binary` use
{obj}`--boostrap_impl=script`.

Additional or custom config settings can be registered using the
{obj}`add_transition_setting` API. This allows, for example, forcing a
particular CPU, or defining a custom setting that `select()` uses elsewhere
to pick between `pip.parse` hubs. See the [How to guide on multiple
versions of a library] for a more concrete example.

:::{note}
These values are transitioned on, so will affect the analysis graph and the
associated memory overhead. The more unique configurations in your overall
build, the more memory and (often unnecessary) re-analysis and re-building
can occur. See
https://bazel.build/extending/config#memory-performance-considerations for
more information about risks and considerations.
:::

:::{versionadded} 1.7.0
:::
	2{}�
�
data�
The list of files need by this library at runtime. See comments about
the [`data` attribute typically defined by rules](https://bazel.build/reference/be/common-definitions#typical-attributes).

There is no `py_embed_data` like there is `cc_embed_data` and `go_embed_data`.
This is because Python has a concept of runtime resources.
2[]�
�
deps�
List of additional libraries to be linked in to the target.
See comments about
the [`deps` attribute typically defined by
rules](https://bazel.build/reference/be/common-definitions#typical-attributes).
These are typically `py_library` rules.

Targets that only provide data files used at runtime belong in the `data`
attribute.

:::{note}
The order of this list can matter because it affects the order that information
from dependencies is merged in, which can be relevant depending on the ordering
mode of depsets that are merged.

* {obj}`PyInfo.venv_symlinks` uses default ordering.

See {obj}`PyInfo` for more information about the ordering of its depsets and
how its fields are merged.
:::
*
PyInfo*
CcInfo*
BuiltinPyInfo2[]

distribs2[]�
�
env�Dictionary of strings; optional; values are subject to `$(location)` and "Make
variable" substitution.

Specifies additional environment variables to set when the target is executed by
`test` or `run`.

2{}�
�
imports�
List of import directories to be added to the PYTHONPATH.

Subject to "Make variable" substitution. These import directories will be added
for this rule and all rules that depend on it (note: not the rules this rule
depends on. Each directory will be added to `PYTHONPATH` by `py_binary` rules
that depend on this rule. The strings are repo-runfiles-root relative,

Absolute paths (paths that start with `/`) and paths that references a path
above the execution root are not allowed and will result in an error.
2[]�
�
interpreter_args�
Arguments that are only applicable to the interpreter.

The args an interpreter supports are specific to the interpreter. For
CPython, see https://docs.python.org/3/using/cmdline.html.

:::{note}
Only supported for {obj}`--bootstrap_impl=script`. Ignored otherwise.
:::

:::{seealso}
The {any}`RULES_PYTHON_ADDITIONAL_INTERPRETER_ARGS` environment variable
:::

:::{versionadded} 1.3.0
:::
2[]�
�
legacy_create_init�Whether to implicitly create empty `__init__.py` files in the runfiles tree.
These are created in every directory containing Python source code or shared
libraries, and every parent directory of those directories, excluding the repo
root directory. The default, `-1` (auto), means true unless
`--incompatible_default_to_explicit_init_py` is used. If false, the user is
responsible for creating (possibly empty) `__init__.py` files and adding them to
the `srcs` of Python targets as required.
2-1

licenses2[]�
�
main�Optional; the name of the source file that is the main entry point of the
application. This file must also be listed in `srcs`. If left unspecified,
`name`, with `.py` appended, is used instead. If `name` does not match any
filename in `srcs`, `main` must be specified.

This is mutually exclusive with {obj}`main_module`.
2None�
�
main_module�
Module name to execute as the main program.

When set, `srcs` is not required, and it is assumed the module is
provided by a dependency.

See https://docs.python.org/3/using/cmdline.html#cmdoption-m for more
information about running modules as the main program.

This is mutually exclusive with {obj}`main`.

:::{versionadded} 1.3.0
:::
:::{versionchanged} 1.7.0
Support added for {obj}`--bootstrap_impl=system_python`.
:::
2""�
�

precompile�
Whether py source files **for this target** should be precompiled.

Values:

* `inherit`: Allow the downstream binary decide if precompiled files are used.
* `enabled`: Compile Python source files at build time.
* `disabled`: Don't compile Python source files at build time.

:::{seealso}

* The {flag}`--precompile` flag, which can override this attribute in some cases
  and will affect all targets when building.
* The {obj}`pyc_collection` attribute for transitively enabling precompiling on
  a per-target basis.
* The [Precompiling](precompiling) docs for a guide about using precompiling.
:::
2	"inherit"�
�
precompile_invalidation_mode�
How precompiled files should be verified to be up-to-date with their associated
source files. Possible values are:
* `auto`: The effective value will be automatically determined by other build
  settings.
* `checked_hash`: Use the pyc file if the hash of the source file matches the hash
  recorded in the pyc file. This is most useful when working with code that
  you may modify.
* `unchecked_hash`: Always use the pyc file; don't check the pyc's hash against
  the source file. This is most useful when the code won't be modified.

For more information on pyc invalidation modes, see
https://docs.python.org/3/library/py_compile.html#py_compile.PycInvalidationMode
2"auto"�
�
precompile_optimize_level�
The optimization level for precompiled files.

For more information about optimization levels, see the `compile()` function's
`optimize` arg docs at https://docs.python.org/3/library/functions.html#compile

NOTE: The value `-1` means "current interpreter", which will be the interpreter
used _at build time when pycs are generated_, not the interpreter used at
runtime when the code actually runs.
20�
�
precompile_source_retention�
Determines, when a source file is compiled, if the source file is kept
in the resulting output or not. Valid values are:

* `inherit`: Inherit the value from the {flag}`--precompile_source_retention` flag.
* `keep_source`: Include the original Python source.
* `omit_source`: Don't include the original py source.
2	"inherit"�
�
pyc_collection�
Determines whether pyc files from dependencies should be manually included.

Valid values are:
* `inherit`: Inherit the value from {flag}`--precompile`.
* `include_pyc`: Add implicitly generated pyc files from dependencies. i.e.
  pyc files for targets that specify {attr}`precompile="inherit"`.
* `disabled`: Don't add implicitly generated pyc files. Note that
  pyc files may still come from dependencies that enable precompiling at the
  target level.
2	"inherit"�
�
pyi_deps�
Dependencies providing type definitions the library needs.

These are dependencies that satisfy imports guarded by `typing.TYPE_CHECKING`.
These are build-time only dependencies and not included as part of a runnable
program (packaging rules may include them, however).

:::{versionadded} 1.1.0
:::
*
PyInfo*
CcInfo*
BuiltinPyInfo2[]�
�
pyi_srcs�
Type definition files for the library.

These are typically `.pyi` files, but other file types for type-checker specific
formats are allowed. These files are build-time only dependencies and not included
as part of a runnable program (packaging rules may include them, however).

:::{versionadded} 1.1.0
:::
2[]�
�
python_version�
The Python version this target should use.

The value should be in `X.Y` or `X.Y.Z` (or compatible) format. If empty or
unspecified, the incoming configuration's {obj}`--python_version` flag is
inherited. For backwards compatibility, the values `PY2` and `PY3` are
accepted, but treated as an empty/unspecified value.

:::{note}
In order for the requested version to be used, there must be a
toolchain configured to match the Python version. If there isn't, then it
may be silently ignored, or an error may occur, depending on the toolchain
configuration.
:::

:::{versionchanged} 1.1.0

This attribute was changed from only accepting `PY2` and `PY3` values to
accepting arbitrary Python versions.
:::
2""�
�
srcs�
The list of Python source files that are processed to create the target. This
includes all your checked-in code and may include generated source files.  The
`.py` files belong in `srcs` and library targets belong in `deps`. Other binary
files that may be needed at run time belong in `data`.
2[]6
4
srcs_versionDefunct, unused, does nothing.2""�
�
stamp�
Whether to encode build information into the binary. Possible values:

* `stamp = 1`: Always stamp the build information into the binary, even in
  `--nostamp` builds. **This setting should be avoided**, since it potentially kills
  remote caching for the binary and any downstream actions that depend on it.
* `stamp = 0`: Always replace build information by constant values. This gives
  good build result caching.
* `stamp = -1`: Embedding of build information is controlled by the
  `--[no]stamp` flag.

Stamped binaries are not rebuilt unless their dependencies change.

WARNING: Stamping can harm build performance by reducing cache hits and should
be avoided if possible.
2-1�	host_testRun a host test*�
�
	host_test"
nameThe name of the binary ()
srcsThe source files for the test (
binaryThe binary to run ()
depsThe dependencies for the test (7
kwargs+Additional arguments to pass to `py_binary`(Run a host test21
	host_test$@@ryandraves_nlb//bzl/macros:emb.bzl
*py_test2py_testh
//py:defs.bzlrU

aspect_rules_pypydefs.bzl$
	py_binary	py_binary
(1
3w
//bzl/macros:python.bzlrZ
(
ryandraves_nlb
bzl/macros
python.bzl 
py_testpy_test
18
:%Common rules for embedded development�+
&
ryandraves_nlb
bzl/macrosnext.bzl�(next�Generates Next.js targets build, dev & start targets.

`{name}`       - a js_run_binary build target that runs `next build`
`{name}_dev`   - a js_run_devserver binary target that runs `next dev`
`{name}_start` - a js_run_devserver binary target that runs `next start`

Use this macro in the BUILD file at the root of a next app where the `next.config.js` file is
located.

For example, a target such as

```
next(
    name = "next",
    srcs = [
        "//blog/pages",
        "//blog/public",
        "//blog/styles",
    ],
    data = [
        "//blog:node_modules/next",
        "//blog:node_modules/react-dom",
        "//blog:node_modules/react",
        "//blog:node_modules/typescript",
        "next.config.js",
        "package.json",
    ],
    next_bin = "../../node_modules/.bin/next",
    next_js_binary = "//:next_js_binary",
)
```

in an `next.js/BUILD.bazel` file where the root `BUILD.bazel` file has
next linked to `node_modules` and the `next_js_binary`:

```
load("@npm//:defs.bzl", "npm_link_all_packages")
load("@npm//:next/package_json.bzl", next_bin = "bin")

npm_link_all_packages(name = "node_modules")

next_bin.next_binary(
    name = "next_js_binary",
    visibility = ["//visibility:public"],
)
```

will create the targets:

```
//next.js:next
//next.js:next_dev
//next.js:next_start
```

To build the above next app, equivalent to running
`next build` outside Bazel, run,

```
bazel build //next.js:next
```

To run the development server in watch mode with
[ibazel](https://github.com/bazelbuild/bazel-watcher), equivalent to running
`next dev` outside Bazel, run

```
ibazel run //next.js:next_dev
```

To run the production server in watch mode with
[ibazel](https://github.com/bazelbuild/bazel-watcher), equivalent to running
`next start` outside Bazel,

```
ibazel run //next.js:next_start
```
*�
�
next)
nameThe name of the build target. (�
srcs�Source files to include in build & dev targets.
Typically these are source files or transpiled source files in Next.js source folders
such as `pages`, `public` & `styles`. (�
data�Data files to include in all targets.
These are typically npm packages required for the build & configuration files such as
package.json and next.config.js. (�
next_js_binary�The next js_binary. Used for the `build `target.

Typically this is a js_binary target created using `bin` loaded from the `package_json.bzl`
file of the npm package.

See main docstring above for example usage. (�
next_bin�The next bin command. Used for the `dev` and `start` targets.

Typically the path to the next entry point from the current package. For example `./node_modules/.bin/next`,
if next is linked to the current package, or a relative path such as `../node_modules/.bin/next`, if next is
linked in the parent package.

See main docstring above for example usage. (�
next_build_out}The `next build` output directory. Defaults to `.next` which is the Next.js default output directory for the `build` command.".next"(�
next_export_out}The `next export` output directory. Defaults to `out` which is the Next.js default output directory for the `export` command."out"(B
kwargs6Other attributes passed to all targets such as `tags`.(�Generates Next.js targets build, dev & start targets.

`{name}`       - a js_run_binary build target that runs `next build`
`{name}_dev`   - a js_run_devserver binary target that runs `next dev`
`{name}_start` - a js_run_devserver binary target that runs `next start`

Use this macro in the BUILD file at the root of a next app where the `next.config.js` file is
located.

For example, a target such as

```
next(
    name = "next",
    srcs = [
        "//blog/pages",
        "//blog/public",
        "//blog/styles",
    ],
    data = [
        "//blog:node_modules/next",
        "//blog:node_modules/react-dom",
        "//blog:node_modules/react",
        "//blog:node_modules/typescript",
        "next.config.js",
        "package.json",
    ],
    next_bin = "../../node_modules/.bin/next",
    next_js_binary = "//:next_js_binary",
)
```

in an `next.js/BUILD.bazel` file where the root `BUILD.bazel` file has
next linked to `node_modules` and the `next_js_binary`:

```
load("@npm//:defs.bzl", "npm_link_all_packages")
load("@npm//:next/package_json.bzl", next_bin = "bin")

npm_link_all_packages(name = "node_modules")

next_bin.next_binary(
    name = "next_js_binary",
    visibility = ["//visibility:public"],
)
```

will create the targets:

```
//next.js:next
//next.js:next_dev
//next.js:next_start
```

To build the above next app, equivalent to running
`next build` outside Bazel, run,

```
bazel build //next.js:next
```

To run the development server in watch mode with
[ibazel](https://github.com/bazelbuild/bazel-watcher), equivalent to running
`next dev` outside Bazel, run

```
ibazel run //next.js:next_dev
```

To run the production server in watch mode with
[ibazel](https://github.com/bazelbuild/bazel-watcher), equivalent to running
`next start` outside Bazel,

```
ibazel run //next.js:next_start
```
2-
next%@@ryandraves_nlb//bzl/macros:next.bzl
*js_run_binary*js_run_devserver*js_run_devserver2js_run_binary�
//js:defs.bzlr�

aspect_rules_jsjsdefs.bzl,
js_run_binaryjs_run_binary
(52
js_run_devserverjs_run_devserver
9I
K�Wrapper macro to make the next.js rules more ergonomic.

From https://github.com/bazelbuild/examples/blob/b51e3bdd468ce8c4a516d7dca993909dcc84af32/frontend/next.js/defs.bzl
�
'
ryandraves_nlb
bzl/macros	patch.bzl*�ModuleInfo request error: invalid argument: Traceback (most recent call last):
	File "external/ryandraves_nlb/bzl/macros/patch.bzl", line 13, column 7, in <toplevel>
		patch = macro(
Error in macro: in call to macro(), parameter 'inherit_attrs' got value of type 'build.stack.devtools.build.constellate.fakebuildapi.FakeStarlarkNativeModuleApi$2', want 'rule, macro, string, or NoneType'�
&
ryandraves_nlb
bzl/macrospico.bzl�pico_project�Compile a Pico project

Produces a host binary, an ELF file, a UF2 file, and a bin file.

The UF2 file can be flashed to a Pico device in BOOTSEL mode with:
```
bazel run //tools:picotool -- load bazel-bin/path/to/name.uf2
```
b�

�
�
pico_project=
names0The names of the project (one name per platform) (
srcsThe source files (
depsThe dependencies (I
	platformsThe Pico platform to build for["//bzl/platforms:rp2040"](a
linker_scriptThe linker script to use4"//emb/project/bootloader:application_linker_script"(:
kwargs.Additional arguments to pass to binary targets(�Compile a Pico project

Produces a host binary, an ELF file, a UF2 file, and a bin file.

The UF2 file can be flashed to a Pico device in BOOTSEL mode with:
```
bazel run //tools:picotool -- load bazel-bin/path/to/name.uf2
```
25
pico_project%@@ryandraves_nlb//bzl/macros:pico.bzl
''"_pico_elf_and_bin*	cc_binary*_pico_elf_and_bin*_pico_elf_and_bin�
�
_pico_elf_and_bin�Macro for the ELF and bin files for a Pico project

Transitions the srcs to use the provided platform. The filegroup will contain artifacts for the target platform.*
nameA unique name for this target. B
srcs4The input to be transitioned to the target platform.2[]B
target_platform+The target platform to transition the srcs. ,
*
nameA unique name for this target. D
B
srcs4The input to be transitioned to the target platform.2[]D
B
target_platform+The target platform to transition the srcs. �pio_cc_libraryCompile a PIO C++ library*�
�
pio_cc_library#
nameThe name of the library ( 
pioThe PIO assembly file (+
hdrsAdditional headers to include[](8
kwargs,Additional arguments to pass to `cc_library`(Compile a PIO C++ library27
pio_cc_library%@@ryandraves_nlb//bzl/macros:pico.bzl
__*
cc_library2native.genrule2
cc_library�
//lib:transitions.bzlr�
(
aspect_bazel_liblibtransitions.bzlL
platform_transition_filegroupplatform_transition_filegroup
1N
P�
//bazel/toolchain:objcopy.bzlrh
(
pico-sdkbazel/toolchainobjcopy.bzl.
objcopy_to_binobjcopy_to_bin
1?
A�
//cc:defs.bzlrv

rules_ccccdefs.bzl$
	cc_binary	cc_binary
!*&

cc_library
cc_library
.8
:m
//bzl/macros:emb.bzlrS
%
ryandraves_nlb
bzl/macrosemb.bzl
flashflash
.3
5y
//bzl/rules:pico.bzlr_
%
ryandraves_nlb	bzl/rulespico.bzl(
pico_binarypico_binary
.9
;�
(
ryandraves_nlb
bzl/macros
python.bzl�py_test�py_test wrapper to invoke pytest

The default behavior is to require the test file to make its
own `__main__` or it'll silently pass.

Setup via https://stackoverflow.com/a/67389568*�
�
py_test

name (

srcs (
deps[](
args[](

kwargs(�py_test wrapper to invoke pytest

The default behavior is to require the test file to make its
own `__main__` or it'll silently pass.

Setup via https://stackoverflow.com/a/6738956822
py_test'@@ryandraves_nlb//bzl/macros:python.bzl
*_py_test2_py_teste
//py:defs.bzlrR

aspect_rules_pypydefs.bzl!
py_test_py_test
'/
<h
:requirements.bzlrQ

piprequirements.bzl(
requirementrequirement
"-
/�
0
ryandraves_nlbbzl/queriesoutput_groups.bzl�output_group_query_aspect:�
�
output_group_query_aspect"*
nameA unique name for this target. *L
output_group_query_aspect/@@ryandraves_nlb//bzl/queries:output_groups.bzl
	#	#,
*
nameA unique name for this target. �
(
ryandraves_nlb	bzl/rulesfeature.bzl�flag_header_file"�
�
flag_header_file*
nameA unique name for this target. G
build_setting2Build setting (flag) to construct the header from. ";
flag_header_file'@@ryandraves_nlb//bzl/rules:feature.bzl
**,
*
nameA unique name for this target. I
G
build_setting2Build setting (flag) to construct the header from. �feature_cc_library*�
t
feature_cc_library

name (
build_setting (2=
feature_cc_library'@@ryandraves_nlb//bzl/rules:feature.bzl
		"flag_header_file"native.cc_library2native.cc_library�
//rules:common_settings.bzlrn
*
bazel_skylibrulescommon_settings.bzl2
BuildSettingInfoBuildSettingInfo
3C
E�Rules for feature flags.

Graciously copied from
https://pigweed.dev/docs/blog/02-bazel-feature-flags.html#more-power-with-no-code-changes-platform-based-skylib-flags
�
%
ryandraves_nlb	bzl/rulespico.bzl�pico_binary"�
�
pico_binary*
nameA unique name for this target. "
binaryBinary to transition 3
linker_scriptLinker script to transition to 7
target_platform Target platform to transition to "3
pico_binary$@@ryandraves_nlb//bzl/rules:pico.bzl
,
*
nameA unique name for this target. $
"
binaryBinary to transition 5
3
linker_scriptLinker script to transition to 9
7
target_platform Target platform to transition to �Perform a platform & linker script transition for a Pico binary.

Since we want to pick different values for the linker script within the same
platform, we need a custom rule that does both. I think. Please prove me wrong,
I hate writing these.
�
4
ryandraves_nlb	bzl/rulesplatform_transition.bzl�platform_transition"�
�
platform_transition*
nameA unique name for this target. 	
dep 
target_platform "J
platform_transition3@@ryandraves_nlb//bzl/rules:platform_transition.bzl
"",
*
nameA unique name for this target. 
	
dep 

target_platform �Bazel rule to transition a non-executable target to a different platform.

This rule also exposes `CCInfo` for CC target transitions.

Example:
platform_transition(
    name = "my_library",
    dep = [":my_library_that_needs_a_custom_toolchain"],
    platform = "//my_platform:my_platform",
)
Inspired by https://stackoverflow.com/a/77020123 and
https://stackoverflow.com/a/71179440
�
,
ryandraves_nlbbzl/test_module	patch.bzl*�ModuleInfo request error: invalid argument: Traceback (most recent call last):
	File "external/ryandraves_nlb/bzl/test_module/patch.bzl", line 13, column 7, in <toplevel>
		patch = macro(
Error in macro: in call to macro(), parameter 'inherit_attrs' got value of type 'build.stack.devtools.build.constellate.fakebuildapi.FakeStarlarkNativeModuleApi$2', want 'rule, macro, string, or NoneType'�
+
ryandraves_nlbtoolsworkspace_tool.bzl�workspace_tool*�
f
workspace_tool

name (

tool (2<
workspace_tool*@@ryandraves_nlb//tools:workspace_tool.bzl
"native.sh_binary2
write_file2native.sh_binaryy
//rules:write_file.bzlr]
%
bazel_skylibruleswrite_file.bzl&

write_file
write_file
.8
:�Macro for creating a target that runs a tool from the workspace.

Adapted from https://dev.to/bazel/bazel-can-write-to-the-source-folder-b9b
 