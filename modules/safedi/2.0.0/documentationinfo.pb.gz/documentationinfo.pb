�

safedibazel
safedi.bzl�safedi_compile�Run SafeDITool against a module and emit both the
combined dependency-tree / mock Swift source and the `.safedi`
module-info artifact in a single action."�
�
safedi_compile�Run SafeDITool against a module and emit both the
combined dependency-tree / mock Swift source and the `.safedi`
module-info artifact in a single action.*
nameA unique name for this target. �
deps�Other `safedi_compile` labels whose `.safedi`
module-info artifacts this rule consumes for cross-module
`@Instantiable` type resolution.*

SafeDIInfo2[])
srcsSwift sources in this module. ",
safedi_compile@@safedi//bazel:safedi.bzl
cc,
*
nameA unique name for this target. �
�
deps�Other `safedi_compile` labels whose `.safedi`
module-info artifacts this rule consumes for cross-module
`@Instantiable` type resolution.*

SafeDIInfo2[]+
)
srcsSwift sources in this module. �
SafeDIInfo=Module info artifact (`.safedi`) emitted by `safedi_compile`.2�
�

SafeDIInfo=Module info artifact (`.safedi`) emitted by `safedi_compile`.Q
module_infoBThe `.safedi` file describing this module's @Instantiable surface."(

SafeDIInfo@@safedi//bazel:safedi.bzl
&&S
Q
module_infoBThe `.safedi` file describing this module's @Instantiable surface.�Custom Starlark rule for integrating SafeDI into a Bazel build.

`safedi_compile(srcs, deps)` runs `SafeDITool generate
--combined-output --module-info-output` once per module and produces
two artifacts:

  - `<rule>.swift` â every dependency-tree, mock, and mock
    configuration body SafeDITool would emit, concatenated into a
    single declared output. Bazel requires rule outputs to be known
    at analysis time, and the combined-output mode lets SafeDITool's
    output set (which depends on source contents) resolve to a
    single statically-known file. Add `[":<rule>"]` to a downstream
    `swift_library.srcs` to compile the generated code.

  - `<rule>.safedi` â the module-info artifact. Cross-module
    consumers list this rule's label in their own `safedi_compile`'s
    `deps` to reach `@Instantiable` types declared in this module
    without re-parsing the sources.

The rule shells out to `@safedi//Sources/SafeDITool:SafeDITool` (built
from source by Bazel, cached across runs).

This rule mirrors the Tuist plugin's `SafeDI.preCompileScript`
helper, which writes the same two artifacts in one invocation. Doing
both in one action is more efficient than splitting them across two
rules â every leaf-with-mocks or producer-with-mocks would otherwise
invoke SafeDITool twice on the same sources.

## Unsupported SafeDI features

- `#SafeDIConfiguration(additionalDirectoriesToInclude:)` is **not
  supported**. SafeDITool reads those paths at runtime to scan for
  additional source files, but Bazel's hermetic sandbox only exposes
  files declared as action inputs. List every Swift source you want
  SafeDITool to see directly in `srcs`.
 