��

safedibazel
safedi.bzl�safedi_compile�Run SafeDITool against a module and emit both the
combined dependency-tree / mock Swift source and the `.safedi`
module-info artifact in a single action.

Prefer `safedi_swift_library`, which declares this target and the
`swift_library` that compiles its output from one set of attributes."�
�
safedi_compile�Run SafeDITool against a module and emit both the
combined dependency-tree / mock Swift source and the `.safedi`
module-info artifact in a single action.

Prefer `safedi_swift_library`, which declares this target and the
`swift_library` that compiles its output from one set of attributes.*
nameA unique name for this target. �
copts�Swift compiler options matching the wrapped
`swift_library.copts`. Each `-D` flag among them reports a compilation
condition; other options are ignored.2[]�
defines�Compilation conditions active for this module,
matching the wrapped `swift_library.defines`. `DEBUG` is added
automatically in the `dbg` and `fastbuild` compilation modes, and
`NDEBUG` in the `opt` compilation mode.2[]�
deps�Other `safedi_compile` labels whose `.safedi`
module-info artifacts this rule consumes for cross-module
`@Instantiable` type resolution.*

SafeDIInfo2[])
srcsSwift sources in this module. ",
safedi_compile@@safedi//bazel:safedi.bzl
��,
*
nameA unique name for this target. �
�
copts�Swift compiler options matching the wrapped
`swift_library.copts`. Each `-D` flag among them reports a compilation
condition; other options are ignored.2[]�
�
defines�Compilation conditions active for this module,
matching the wrapped `swift_library.defines`. `DEBUG` is added
automatically in the `dbg` and `fastbuild` compilation modes, and
`NDEBUG` in the `opt` compilation mode.2[]�
�
deps�Other `safedi_compile` labels whose `.safedi`
module-info artifacts this rule consumes for cross-module
`@Instantiable` type resolution.*

SafeDIInfo2[]+
)
srcsSwift sources in this module. �|safedi_swift_library�Declares a `swift_library` that compiles the code SafeDI generates for it.

Declares two targets:

  - `<name>_safedi`, a `safedi_compile` target that runs SafeDITool
    over `srcs`. Other modules list it in their `safedi_deps`.
  - `<name>`, a `swift_library` that compiles `srcs` together with
    `<name>_safedi`'s generated source.

Both targets receive the same `srcs`, `defines`, and `copts`, so
SafeDITool scans the `#if` clauses the compiler compiles.


Compiles and links Swift code into a static library and Swift module.
"�w
�=
safedi_swift_library�Declares a `swift_library` that compiles the code SafeDI generates for it.

Declares two targets:

  - `<name>_safedi`, a `safedi_compile` target that runs SafeDITool
    over `srcs`. Other modules list it in their `safedi_deps`.
  - `<name>`, a `swift_library` that compiles `srcs` together with
    `<name>_safedi`'s generated source.

Both targets receive the same `srcs`, `defines`, and `copts`, so
SafeDITool scans the `#if` clauses the compiler compiles.


Compiles and links Swift code into a static library and Swift module.
*
nameA unique name for this target. �
%always_include_developer_search_paths�If `True`, the developer framework search paths will be added to the compilation
command. This enables a Swift module to access `XCTest` without having to mark
the target as `testonly = True`.
2False�


alwayslink�
If `False`, any binary that depends (directly or indirectly) on this Swift module
will only link in all the object files for the files listed in `srcs` when there
is a direct symbol reference.

Swift protocol conformances don't create linker references. Likewise, if the
Swift code has Objective-C classes/methods, their usage does not always result in
linker references.

_"All the object files"_ for this module is also somewhat fuzzy. Unlike C, C++,
and Objective-C, where each source file results in a `.o` file; for Swift the
number of .o files depends on the compiler options
(`-wmo`/`-whole-module-optimization`, `-num-threads`). That makes relying on
linker reference more fragile, and any individual .swift file in `srcs` may/may
not get picked up based on the linker references to other files that happen to
get batched into a single `.o` by the compiler options used.

Swift Package Manager always passes the individual `.o` files to the linker
instead of using intermediate static libraries, so it effectively is the same
as `alwayslink = True`.

Note that by default, this value will default to True. But if the
swift.enable_embedded feature is on, this value will be automatically overridden
to False, as the swift features that cause -force_load to be required (such as
reflection) are not available in that mode.
2True�
copts�Additional compiler options that should be passed to `swiftc`. These strings are
subject to `$(location ...)` and ["Make" variable](https://docs.bazel.build/versions/master/be/make-variables.html) expansion.
2[]�
data�The list of files needed by this target at runtime.

Files and targets named in the `data` attribute will appear in the `*.runfiles`
area of this target, if it has one. This may include data files needed by a
binary or library, or other programs needed by it.
2[]�
defines�A list of defines to add to the compilation command line.

Note that unlike C-family languages, Swift defines do not have values; they are
simply identifiers that are either defined or undefined. So strings in this list
should be simple identifiers, **not** `name=value` pairs.

Each string is prepended with `-D` and added to the command line. Unlike
`copts`, these flags are added for the target and every target that depends on
it, so use this attribute with caution. It is preferred that you add defines
directly to `copts`, only using this feature in the rare case that a library
needs to propagate a symbol up to those that depend on it.
2[]�
deps�A list of targets that are dependencies of the target being built, which will be
linked into that target.

If the Swift toolchain supports implementation-only imports (`private_deps` on
`swift_library`), then targets in `deps` are treated as regular
(non-implementation-only) imports that are propagated both to their direct and
indirect (transitive) dependents.

Allowed kinds of dependencies are:

*   `swift_library` (or anything propagating `SwiftInfo`)

*   `cc_library` and `objc_library` (or anything propagating `CcInfo`)
*
CcInfo*
	SwiftInfo2[]�
generated_header_name�The name of the generated Objective-C interface header. This name must end with
a `.h` extension and cannot contain any path separators.

If this attribute is not specified, then the default behavior is to name the
header `${target_name}-Swift.h`.

This attribute is ignored if the toolchain does not support generating headers.
2""�
generates_header�If True, an Objective-C header will be generated for this target, in the same
build package where the target is defined. By default, the name of the header is
`${target_name}-Swift.h`; this can be changed using the `generated_header_name`
attribute.

Targets should only set this attribute to True if they export Objective-C APIs.
A header generated for a target that does not export Objective-C APIs will be
effectively empty (except for a large amount of prologue and epilogue code) and
this is generally wasteful because the extra file needs to be propagated in the
build graph and, when explicit modules are enabled, extra actions must be
executed to compile the Objective-C module for the generated header.
2False�
library_evolution�Indicates whether the Swift code should be compiled with library evolution mode
enabled.

This attribute should be used to compile a module that will be distributed as
part of a client-facing (non-implementation-only) module in a library or
framework that will be distributed for use outside of the Bazel build graph.
Setting this to true will compile the module with the `-library-evolution` flag
and emit a `.swiftinterface` file as one of the compilation outputs.
2False�
linkopts�Additional linker options that should be passed to the linker for the binary
that depends on this target. These strings are subject to `$(location ...)`
and ["Make" variable](https://docs.bazel.build/versions/master/be/make-variables.html) expansion.
2[]�

linkstatic�If True, the Swift module will be built for static linking.  This will make all
interfaces internal to the module that is being linked against and will inform
the consuming module that the objects will be locally available (which may
potentially avoid a PLT relocation).  Set to `False` to build a `.so` or `.dll`.
2True�
module_name�The name of the Swift module being built.

If left unspecified, the module name will be computed based on the target's
build label, by stripping the leading `//` and replacing `/`, `:`, and other
non-identifier characters with underscores.
2""�
package_name�The semantic package of the Swift target being built. Targets with the same
package_name can access APIs using the 'package' access control modifier in
Swift 5.9+.
2""�
plugins�A list of `swift_compiler_plugin` targets that should be loaded by the compiler
when compiling this module and any modules that directly depend on it.
*
SwiftCompilerPluginInfo2[]�
private_deps�A list of targets that are implementation-only dependencies of the target being
built. Libraries/linker flags from these dependencies will be propagated to
dependent for linking, but artifacts/flags required for compilation (such as
.swiftmodule files, C headers, and search paths) will not be propagated.

Allowed kinds of dependencies are:

*   `swift_library` (or anything propagating `SwiftInfo`)

*   `cc_library` and `objc_library` (or anything propagating `CcInfo`)
*
CcInfo*
	SwiftInfo2[]�
srcs�A list of `.swift` source files that will be compiled into the library.

Except in very rare circumstances, a Swift source file should only appear in a
single `swift_*` target. Adding the same source file to multiple `swift_*`
targets can lead to binary bloat and/or symbol collisions. If specific sources
need to be shared by multiple targets, consider factoring them out into their
own `swift_library` instead.
 �
swiftc_inputslAdditional files that are referenced using `$(location ...)` in attributes that
support location expansion.
2[]
��,
*
nameA unique name for this target. �
�
%always_include_developer_search_paths�If `True`, the developer framework search paths will be added to the compilation
command. This enables a Swift module to access `XCTest` without having to mark
the target as `testonly = True`.
2False�

�


alwayslink�
If `False`, any binary that depends (directly or indirectly) on this Swift module
will only link in all the object files for the files listed in `srcs` when there
is a direct symbol reference.

Swift protocol conformances don't create linker references. Likewise, if the
Swift code has Objective-C classes/methods, their usage does not always result in
linker references.

_"All the object files"_ for this module is also somewhat fuzzy. Unlike C, C++,
and Objective-C, where each source file results in a `.o` file; for Swift the
number of .o files depends on the compiler options
(`-wmo`/`-whole-module-optimization`, `-num-threads`). That makes relying on
linker reference more fragile, and any individual .swift file in `srcs` may/may
not get picked up based on the linker references to other files that happen to
get batched into a single `.o` by the compiler options used.

Swift Package Manager always passes the individual `.o` files to the linker
instead of using intermediate static libraries, so it effectively is the same
as `alwayslink = True`.

Note that by default, this value will default to True. But if the
swift.enable_embedded feature is on, this value will be automatically overridden
to False, as the swift features that cause -force_load to be required (such as
reflection) are not available in that mode.
2True�
�
copts�Additional compiler options that should be passed to `swiftc`. These strings are
subject to `$(location ...)` and ["Make" variable](https://docs.bazel.build/versions/master/be/make-variables.html) expansion.
2[]�
�
data�The list of files needed by this target at runtime.

Files and targets named in the `data` attribute will appear in the `*.runfiles`
area of this target, if it has one. This may include data files needed by a
binary or library, or other programs needed by it.
2[]�
�
defines�A list of defines to add to the compilation command line.

Note that unlike C-family languages, Swift defines do not have values; they are
simply identifiers that are either defined or undefined. So strings in this list
should be simple identifiers, **not** `name=value` pairs.

Each string is prepended with `-D` and added to the command line. Unlike
`copts`, these flags are added for the target and every target that depends on
it, so use this attribute with caution. It is preferred that you add defines
directly to `copts`, only using this feature in the rare case that a library
needs to propagate a symbol up to those that depend on it.
2[]�
�
deps�A list of targets that are dependencies of the target being built, which will be
linked into that target.

If the Swift toolchain supports implementation-only imports (`private_deps` on
`swift_library`), then targets in `deps` are treated as regular
(non-implementation-only) imports that are propagated both to their direct and
indirect (transitive) dependents.

Allowed kinds of dependencies are:

*   `swift_library` (or anything propagating `SwiftInfo`)

*   `cc_library` and `objc_library` (or anything propagating `CcInfo`)
*
CcInfo*
	SwiftInfo2[]�
�
generated_header_name�The name of the generated Objective-C interface header. This name must end with
a `.h` extension and cannot contain any path separators.

If this attribute is not specified, then the default behavior is to name the
header `${target_name}-Swift.h`.

This attribute is ignored if the toolchain does not support generating headers.
2""�
�
generates_header�If True, an Objective-C header will be generated for this target, in the same
build package where the target is defined. By default, the name of the header is
`${target_name}-Swift.h`; this can be changed using the `generated_header_name`
attribute.

Targets should only set this attribute to True if they export Objective-C APIs.
A header generated for a target that does not export Objective-C APIs will be
effectively empty (except for a large amount of prologue and epilogue code) and
this is generally wasteful because the extra file needs to be propagated in the
build graph and, when explicit modules are enabled, extra actions must be
executed to compile the Objective-C module for the generated header.
2False�
�
library_evolution�Indicates whether the Swift code should be compiled with library evolution mode
enabled.

This attribute should be used to compile a module that will be distributed as
part of a client-facing (non-implementation-only) module in a library or
framework that will be distributed for use outside of the Bazel build graph.
Setting this to true will compile the module with the `-library-evolution` flag
and emit a `.swiftinterface` file as one of the compilation outputs.
2False�
�
linkopts�Additional linker options that should be passed to the linker for the binary
that depends on this target. These strings are subject to `$(location ...)`
and ["Make" variable](https://docs.bazel.build/versions/master/be/make-variables.html) expansion.
2[]�
�

linkstatic�If True, the Swift module will be built for static linking.  This will make all
interfaces internal to the module that is being linked against and will inform
the consuming module that the objects will be locally available (which may
potentially avoid a PLT relocation).  Set to `False` to build a `.so` or `.dll`.
2True�
�
module_name�The name of the Swift module being built.

If left unspecified, the module name will be computed based on the target's
build label, by stripping the leading `//` and replacing `/`, `:`, and other
non-identifier characters with underscores.
2""�
�
package_name�The semantic package of the Swift target being built. Targets with the same
package_name can access APIs using the 'package' access control modifier in
Swift 5.9+.
2""�
�
plugins�A list of `swift_compiler_plugin` targets that should be loaded by the compiler
when compiling this module and any modules that directly depend on it.
*
SwiftCompilerPluginInfo2[]�
�
private_deps�A list of targets that are implementation-only dependencies of the target being
built. Libraries/linker flags from these dependencies will be propagated to
dependent for linking, but artifacts/flags required for compilation (such as
.swiftmodule files, C headers, and search paths) will not be propagated.

Allowed kinds of dependencies are:

*   `swift_library` (or anything propagating `SwiftInfo`)

*   `cc_library` and `objc_library` (or anything propagating `CcInfo`)
*
CcInfo*
	SwiftInfo2[]�
�
srcs�A list of `.swift` source files that will be compiled into the library.

Except in very rare circumstances, a Swift source file should only appear in a
single `swift_*` target. Adding the same source file to multiple `swift_*`
targets can lead to binary bloat and/or symbol collisions. If specific sources
need to be shared by multiple targets, consider factoring them out into their
own `swift_library` instead.
 �
�
swiftc_inputslAdditional files that are referenced using `$(location ...)` in attributes that
support location expansion.
2[]�
SafeDIInfo=Module info artifact (`.safedi`) emitted by `safedi_compile`.2�
�

SafeDIInfo=Module info artifact (`.safedi`) emitted by `safedi_compile`.Q
module_infoBThe `.safedi` file describing this module's @Instantiable surface."(

SafeDIInfo@@safedi//bazel:safedi.bzl
RRS
Q
module_infoBThe `.safedi` file describing this module's @Instantiable surface.�
//rules:common_settings.bzlrn
*
bazel_skylibrulescommon_settings.bzl2
BuildSettingInfoBuildSettingInfo
O3OC
OOEt
//swift:swift.bzlr]

rules_swiftswift	swift.bzl,
swift_libraryswift_library
P(P5
PP7�Starlark rule and macro for integrating SafeDI into a Bazel build.

Most modules declare a `safedi_swift_library`, which takes the
attributes of a `swift_library` and declares two targets from them:

  - `<name>_safedi`, a `safedi_compile` target that runs SafeDITool.
  - `<name>`, a `swift_library` that compiles `srcs` together with the
    code SafeDITool generated.

Both targets receive the same `srcs`, `defines`, and `copts`, so the
compilation conditions SafeDITool scans with always match the ones
the compiler uses. Modules that need something the macro does not
offer can declare `safedi_compile` and `swift_library` by hand.

`safedi_compile(srcs, deps)` runs `SafeDITool generate
--combined-output --module-info-output` once per module and produces
two artifacts:

  - `<rule>.swift` â every dependency-tree, mock, and mock
    configuration body SafeDITool would emit, concatenated into a
    single declared output. Bazel requires rule outputs to be known
    at analysis time, and the combined-output mode lets SafeDITool's
    output set (which depends on source contents) resolve to a
    single statically-known file. Add `[":<rule>"]` to a downstream
    `swift_library.srcs` to compile the generated code.

  - `<rule>.safedi` â the module-info artifact. Cross-module
    consumers list this rule's label in their own `safedi_compile`'s
    `deps` (or `safedi_swift_library`'s `safedi_deps`) to reach
    `@Instantiable` types declared in this module without re-parsing
    the sources.

The rule shells out to `@safedi//Sources/SafeDITool:SafeDITool` (built
from source by Bazel, cached across runs).

This rule mirrors the Tuist plugin's `SafeDI.preCompileScript`
helper, which writes the same two artifacts in one invocation. Doing
both in one action is more efficient than splitting them across two
rules â every leaf-with-mocks or producer-with-mocks would otherwise
invoke SafeDITool twice on the same sources.

## Conditional compilation

SafeDITool scans only the `#if` clauses that are active for the
build. `safedi_compile` reports these conditions:

  - `DEBUG`, whenever Bazel's compilation mode is `dbg` or
    `fastbuild`, matching the `-DDEBUG` rules_swift passes to swiftc
    in those modes.
  - `NDEBUG`, whenever Bazel's compilation mode is `opt`, matching
    the `-DNDEBUG` rules_swift passes to swiftc in that mode.
  - `defines`, and every `-D` flag in `copts`, which must match the
    wrapped `swift_library`'s attributes of the same names.
    `safedi_swift_library` passes both targets the same values. The
    library cannot be read here (its `srcs` include this rule's
    output, so depending on it would be a cycle), so a hand-wired
    `safedi_compile` has to repeat them.
  - Every `-D` flag passed to rules_swift's
    `--@rules_swift//swift:copt` command-line flag, which rules_swift
    passes to every Swift compilation in the target configuration
    (`--@rules_swift//swift:exec_copt` in the exec configuration).

A bare condition none of these sources reports is inactive. That
includes `defines` propagated from a dependency, rules_swift's
`--@rules_swift//swift:per_module_swiftcopt`, and copts set on a
custom Swift toolchain. The generated code asserts every decision a
condition made, so a condition the build defines but the rule does not
report fails the build with a message naming it.

## Unsupported SafeDI features

- `#SafeDIConfiguration(additionalDirectoriesToInclude:)` is **not
  supported**. SafeDITool reads those paths at runtime to scan for
  additional source files, but Bazel's hermetic sandbox only exposes
  files declared as action inputs. List every Swift source you want
  SafeDITool to see directly in `srcs`.
 