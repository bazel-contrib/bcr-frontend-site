�
0
safedibazel/privateprebuilt_safeditool.bzl6	SAFEDITOOL_RELEASE2.3.0-alpha-4j2.3.0-alpha-4�The prebuilt SafeDITool binaries of SafeDI 2.3.0-alpha-4.

Scripts/create-bazel-source-archive.sh wrote this file into the source archive
of the release. The repository keeps it empty.
�
1
safedibazel/privatesafeditool_toolchain.bzl�resolved_safeditool�An executable that runs the SafeDITool the
`safeditool_toolchain_type` toolchain resolves to, which is the one
`safedi_compile` runs in the same build: `bazel run @safedi//:SafeDITool --
<arguments>`, through the alias at the repository root. Under `bazel run`,
SafeDITool runs in the directory `bazel run` was run from, so relative paths
among the arguments resolve from there."�
�
resolved_safeditool�An executable that runs the SafeDITool the
`safeditool_toolchain_type` toolchain resolves to, which is the one
`safedi_compile` runs in the same build: `bazel run @safedi//:SafeDITool --
<arguments>`, through the alias at the repository root. Under `bazel run`,
SafeDITool runs in the directory `bazel run` was run from, so relative paths
among the arguments resolve from there.*
nameA unique name for this target. "G
resolved_safeditool0@@safedi//bazel/private:safeditool_toolchain.bzl
]],
*
nameA unique name for this target. �safeditool_toolchain�Declares the SafeDITool a `safeditool_toolchain_type` toolchain
hands `safedi_compile`. SafeDI declares every such toolchain itself:
`//bazel:safeditool_from_source` and, in a release's source archive, one
per prebuilt binary (`//bazel:extensions.bzl`)."�
�
safeditool_toolchain�Declares the SafeDITool a `safeditool_toolchain_type` toolchain
hands `safedi_compile`. SafeDI declares every such toolchain itself:
`//bazel:safeditool_from_source` and, in a release's source archive, one
per prebuilt binary (`//bazel:extensions.bzl`).*
nameA unique name for this target. ,

safeditoolThe SafeDITool executable. "H
safeditool_toolchain0@@safedi//bazel/private:safeditool_toolchain.bzl
,
*
nameA unique name for this target. .
,

safeditoolThe SafeDITool executable. YThe rules that declare and run a toolchain of `@safedi//bazel:safeditool_toolchain_type`.�

safedibazelextensions.bzl�
safeditoolDeclares a toolchain for each prebuilt SafeDITool `bazel/private/prebuilt_safeditool.bzl` names. See this file's documentation.J�
�

safeditoolDeclares a toolchain for each prebuilt SafeDITool `bazel/private/prebuilt_safeditool.bzl` names. See this file's documentation.",

safeditool@@safedi//bazel:extensions.bzl
ss�
 //tools/build_defs/repo:http.bzlrd
.
bazel_toolstools/build_defs/repohttp.bzl$
	http_file	http_file
)7)@
))B�
'//bazel/private:prebuilt_safeditool.bzlr�
0
safedibazel/privateprebuilt_safeditool.bzl6
SAFEDITOOL_RELEASESAFEDITOOL_RELEASE
*9*K4
SAFEDITOOL_SHA256SAFEDITOOL_SHA256
*O*`
**b�The `safeditool` module extension, which SafeDI's own `MODULE.bazel` uses.

It declares the toolchains that hand `safedi_compile` a prebuilt
SafeDITool: an `http_file` repository for each binary the SafeDI release
uploads, and the `safeditool_toolchains` repository, which declares a
`toolchain()` for each binary on the execution platform it runs on.
`MODULE.bazel` registers those toolchains ahead of
`//bazel:safeditool_from_source_toolchain`, which builds SafeDITool from
this source tree and runs on any execution platform. Bazel downloads a
binary only when its toolchain is selected.

## Which SafeDITool a build runs

`bazel/private/prebuilt_safeditool.bzl` names the binaries and their
sha256. The repository keeps that file empty on every commit, and the
`Bazel Source Archive Check` CI job fails when it is not. The publish
workflow fills it in only inside `SafeDI-<version>.tar.gz`, the source
archive the Bazel Central Registry entry for `<version>` points at
(`Scripts/create-bazel-source-archive.sh`).

Guarantee: the rule and the SafeDITool it runs come from the same
source. An empty file makes this extension declare no prebuilt
toolchain, so the only toolchain left is
`//bazel:safeditool_from_source_toolchain`, whatever
`--@safedi//bazel:prefer_prebuilt_safeditool` says. A build of any
checkout of the repository (a `local_path_override`, a `git_override`,
or an `archive_override` of a GitHub archive) therefore runs SafeDITool
built from that checkout, and never an older release's binary that may
not accept the options the checkout's rule passes. The sha256 values
exist only in a release's source archive, where the rule and the binaries
are the same release.

  - A build of a SafeDI release from the registry runs that release's
    binary for the execution platform (macOS arm64 or x86_64, Linux
    x86_64 or arm64). It builds SafeDITool from source when
    `--@safedi//bazel:prefer_prebuilt_safeditool=false` is set or no
    binary runs on the execution platform.
  - A build of a checkout builds SafeDITool from that checkout.
��

safedibazel
safedi.bzl� safedi_compile�Run SafeDITool against a module and emit both the
combined dependency-tree / mock Swift source and the `.safedi`
module-info artifact in a single action.

Prefer `safedi_swift_library`, which declares this target and the
`swift_library` that compiles its output from one set of attributes."�
�
safedi_compile�Run SafeDITool against a module and emit both the
combined dependency-tree / mock Swift source and the `.safedi`
module-info artifact in a single action.

Prefer `safedi_swift_library`, which declares this target and the
`swift_library` that compiles its output from one set of attributes.*
nameA unique name for this target. �
copts�Swift compiler options matching the wrapped
`swift_library.copts`. Each `-D` flag among them reports a compilation
condition; other options are ignored.2[]�
defines�Compilation conditions active for this module,
matching the wrapped `swift_library.defines`. `DEBUG` is added
automatically in the `dbg` and `fastbuild` compilation modes, and
`NDEBUG` in the `opt` compilation mode.2[]�
deps�The `safedi_compile` labels of the modules this
module depends on directly, whose `.safedi` module-info artifacts this
rule consumes for cross-module `@Instantiable` type resolution. A module
that declares a root or a seam also reads the modules beneath them
that its dependency trees need, which the rule collects. A module also
lists each deeper module whose types the mocks SafeDI generates for it
should build and no dependency tree of the module uses. Each
`.safedi` carries what a seam or public mock of a module it depends on
needs, so a module is never listed only for another module's seam or
public mock. The SafeDI manual's "Which modules to list" says more.*

SafeDIInfo2[]�
module_name�The name of the Swift module that compiles this
rule's output: the wrapped `swift_library`'s `module_name`, or the
name rules_swift derives from that library's label.
`safedi_swift_library` passes it. SafeDITool records it in the
`.safedi` artifact, which names the module that declares its
`@Instantiable` types and the modules it depends on. �
package_name�The `package_name` of the wrapped `swift_library`,
which the compiler receives as `-package-name`. Leave it empty when
the library has none.2"")
srcsSwift sources in this module. ",
safedi_compile@@safedi//bazel:safedi.bzl
��,
*
nameA unique name for this target. �
�
copts�Swift compiler options matching the wrapped
`swift_library.copts`. Each `-D` flag among them reports a compilation
condition; other options are ignored.2[]�
�
defines�Compilation conditions active for this module,
matching the wrapped `swift_library.defines`. `DEBUG` is added
automatically in the `dbg` and `fastbuild` compilation modes, and
`NDEBUG` in the `opt` compilation mode.2[]�
�
deps�The `safedi_compile` labels of the modules this
module depends on directly, whose `.safedi` module-info artifacts this
rule consumes for cross-module `@Instantiable` type resolution. A module
that declares a root or a seam also reads the modules beneath them
that its dependency trees need, which the rule collects. A module also
lists each deeper module whose types the mocks SafeDI generates for it
should build and no dependency tree of the module uses. Each
`.safedi` carries what a seam or public mock of a module it depends on
needs, so a module is never listed only for another module's seam or
public mock. The SafeDI manual's "Which modules to list" says more.*

SafeDIInfo2[]�
�
module_name�The name of the Swift module that compiles this
rule's output: the wrapped `swift_library`'s `module_name`, or the
name rules_swift derives from that library's label.
`safedi_swift_library` passes it. SafeDITool records it in the
`.safedi` artifact, which names the module that declares its
`@Instantiable` types and the modules it depends on. �
�
package_name�The `package_name` of the wrapped `swift_library`,
which the compiler receives as `-package-name`. Leave it empty when
the library has none.2""+
)
srcsSwift sources in this module. �|safedi_swift_library�Declares a `swift_library` that compiles the code SafeDI generates for it.

Declares two targets:

  - `<name>_safedi`, a `safedi_compile` target that runs SafeDITool
    over `srcs`. Other modules list it in their `safedi_deps`.
  - `<name>`, a `swift_library` that compiles `srcs` together with
    `<name>_safedi`'s generated source.

Both targets receive the same `srcs`, `defines`, and `copts`, so
SafeDITool scans the `#if` clauses the compiler compiles.


Compiles and links Swift code into a static library and Swift module.
"�w
�=
safedi_swift_library�Declares a `swift_library` that compiles the code SafeDI generates for it.

Declares two targets:

  - `<name>_safedi`, a `safedi_compile` target that runs SafeDITool
    over `srcs`. Other modules list it in their `safedi_deps`.
  - `<name>`, a `swift_library` that compiles `srcs` together with
    `<name>_safedi`'s generated source.

Both targets receive the same `srcs`, `defines`, and `copts`, so
SafeDITool scans the `#if` clauses the compiler compiles.


Compiles and links Swift code into a static library and Swift module.
*
nameA unique name for this target. �
%always_include_developer_search_paths�If `True`, the developer framework search paths will be added to the compilation
command. This enables a Swift module to access `XCTest` without having to mark
the target as `testonly = True`.
2False�


alwayslink�
If `False`, any binary that depends (directly or indirectly) on this Swift module
will only link in all the object files for the files listed in `srcs` when there
is a direct symbol reference.

Swift protocol conformances don't create linker references. Likewise, if the
Swift code has Objective-C classes/methods, their usage does not always result in
linker references.

_"All the object files"_ for this module is also somewhat fuzzy. Unlike C, C++,
and Objective-C, where each source file results in a `.o` file; for Swift the
number of .o files depends on the compiler options
(`-wmo`/`-whole-module-optimization`, `-num-threads`). That makes relying on
linker reference more fragile, and any individual .swift file in `srcs` may/may
not get picked up based on the linker references to other files that happen to
get batched into a single `.o` by the compiler options used.

Swift Package Manager always passes the individual `.o` files to the linker
instead of using intermediate static libraries, so it effectively is the same
as `alwayslink = True`.

Note that by default, this value will default to True. But if the
swift.enable_embedded feature is on, this value will be automatically overridden
to False, as the swift features that cause -force_load to be required (such as
reflection) are not available in that mode.
2True�
copts�Additional compiler options that should be passed to `swiftc`. These strings are
subject to `$(location ...)` and ["Make" variable](https://docs.bazel.build/versions/master/be/make-variables.html) expansion.
2[]�
data�The list of files needed by this target at runtime.

Files and targets named in the `data` attribute will appear in the `*.runfiles`
area of this target, if it has one. This may include data files needed by a
binary or library, or other programs needed by it.
2[]�
defines�A list of defines to add to the compilation command line.

Note that unlike C-family languages, Swift defines do not have values; they are
simply identifiers that are either defined or undefined. So strings in this list
should be simple identifiers, **not** `name=value` pairs.

Each string is prepended with `-D` and added to the command line. Unlike
`copts`, these flags are added for the target and every target that depends on
it, so use this attribute with caution. It is preferred that you add defines
directly to `copts`, only using this feature in the rare case that a library
needs to propagate a symbol up to those that depend on it.
2[]�
deps�A list of targets that are dependencies of the target being built, which will be
linked into that target.

If the Swift toolchain supports implementation-only imports (`private_deps` on
`swift_library`), then targets in `deps` are treated as regular
(non-implementation-only) imports that are propagated both to their direct and
indirect (transitive) dependents.

Allowed kinds of dependencies are:

*   `swift_library` (or anything propagating `SwiftInfo`)

*   `cc_library` and `objc_library` (or anything propagating `CcInfo`)
*
CcInfo*
	SwiftInfo2[]�
generated_header_name�The name of the generated Objective-C interface header. This name must end with
a `.h` extension and cannot contain any path separators.

If this attribute is not specified, then the default behavior is to name the
header `${target_name}-Swift.h`.

This attribute is ignored if the toolchain does not support generating headers.
2""�
generates_header�If True, an Objective-C header will be generated for this target, in the same
build package where the target is defined. By default, the name of the header is
`${target_name}-Swift.h`; this can be changed using the `generated_header_name`
attribute.

Targets should only set this attribute to True if they export Objective-C APIs.
A header generated for a target that does not export Objective-C APIs will be
effectively empty (except for a large amount of prologue and epilogue code) and
this is generally wasteful because the extra file needs to be propagated in the
build graph and, when explicit modules are enabled, extra actions must be
executed to compile the Objective-C module for the generated header.
2False�
library_evolution�Indicates whether the Swift code should be compiled with library evolution mode
enabled.

This attribute should be used to compile a module that will be distributed as
part of a client-facing (non-implementation-only) module in a library or
framework that will be distributed for use outside of the Bazel build graph.
Setting this to true will compile the module with the `-library-evolution` flag
and emit a `.swiftinterface` file as one of the compilation outputs.
2False�
linkopts�Additional linker options that should be passed to the linker for the binary
that depends on this target. These strings are subject to `$(location ...)`
and ["Make" variable](https://docs.bazel.build/versions/master/be/make-variables.html) expansion.
2[]�

linkstatic�If True, the Swift module will be built for static linking.  This will make all
interfaces internal to the module that is being linked against and will inform
the consuming module that the objects will be locally available (which may
potentially avoid a PLT relocation).  Set to `False` to build a `.so` or `.dll`.
2True�
module_name�The name of the Swift module being built.

If left unspecified, the module name will be computed based on the target's
build label, by stripping the leading `//` and replacing `/`, `:`, and other
non-identifier characters with underscores.
2""�
package_name�The semantic package of the Swift target being built. Targets with the same
package_name can access APIs using the 'package' access control modifier in
Swift 5.9+.
2""�
plugins�A list of `swift_compiler_plugin` targets that should be loaded by the compiler
when compiling this module and any modules that directly depend on it.
*
SwiftCompilerPluginInfo2[]�
private_deps�A list of targets that are implementation-only dependencies of the target being
built. Libraries/linker flags from these dependencies will be propagated to
dependent for linking, but artifacts/flags required for compilation (such as
.swiftmodule files, C headers, and search paths) will not be propagated.

Allowed kinds of dependencies are:

*   `swift_library` (or anything propagating `SwiftInfo`)

*   `cc_library` and `objc_library` (or anything propagating `CcInfo`)
*
CcInfo*
	SwiftInfo2[]�
srcs�A list of `.swift` source files that will be compiled into the library.

Except in very rare circumstances, a Swift source file should only appear in a
single `swift_*` target. Adding the same source file to multiple `swift_*`
targets can lead to binary bloat and/or symbol collisions. If specific sources
need to be shared by multiple targets, consider factoring them out into their
own `swift_library` instead.
 �
swiftc_inputslAdditional files that are referenced using `$(location ...)` in attributes that
support location expansion.
2[]
��,
*
nameA unique name for this target. �
�
%always_include_developer_search_paths�If `True`, the developer framework search paths will be added to the compilation
command. This enables a Swift module to access `XCTest` without having to mark
the target as `testonly = True`.
2False�

�


alwayslink�
If `False`, any binary that depends (directly or indirectly) on this Swift module
will only link in all the object files for the files listed in `srcs` when there
is a direct symbol reference.

Swift protocol conformances don't create linker references. Likewise, if the
Swift code has Objective-C classes/methods, their usage does not always result in
linker references.

_"All the object files"_ for this module is also somewhat fuzzy. Unlike C, C++,
and Objective-C, where each source file results in a `.o` file; for Swift the
number of .o files depends on the compiler options
(`-wmo`/`-whole-module-optimization`, `-num-threads`). That makes relying on
linker reference more fragile, and any individual .swift file in `srcs` may/may
not get picked up based on the linker references to other files that happen to
get batched into a single `.o` by the compiler options used.

Swift Package Manager always passes the individual `.o` files to the linker
instead of using intermediate static libraries, so it effectively is the same
as `alwayslink = True`.

Note that by default, this value will default to True. But if the
swift.enable_embedded feature is on, this value will be automatically overridden
to False, as the swift features that cause -force_load to be required (such as
reflection) are not available in that mode.
2True�
�
copts�Additional compiler options that should be passed to `swiftc`. These strings are
subject to `$(location ...)` and ["Make" variable](https://docs.bazel.build/versions/master/be/make-variables.html) expansion.
2[]�
�
data�The list of files needed by this target at runtime.

Files and targets named in the `data` attribute will appear in the `*.runfiles`
area of this target, if it has one. This may include data files needed by a
binary or library, or other programs needed by it.
2[]�
�
defines�A list of defines to add to the compilation command line.

Note that unlike C-family languages, Swift defines do not have values; they are
simply identifiers that are either defined or undefined. So strings in this list
should be simple identifiers, **not** `name=value` pairs.

Each string is prepended with `-D` and added to the command line. Unlike
`copts`, these flags are added for the target and every target that depends on
it, so use this attribute with caution. It is preferred that you add defines
directly to `copts`, only using this feature in the rare case that a library
needs to propagate a symbol up to those that depend on it.
2[]�
�
deps�A list of targets that are dependencies of the target being built, which will be
linked into that target.

If the Swift toolchain supports implementation-only imports (`private_deps` on
`swift_library`), then targets in `deps` are treated as regular
(non-implementation-only) imports that are propagated both to their direct and
indirect (transitive) dependents.

Allowed kinds of dependencies are:

*   `swift_library` (or anything propagating `SwiftInfo`)

*   `cc_library` and `objc_library` (or anything propagating `CcInfo`)
*
CcInfo*
	SwiftInfo2[]�
�
generated_header_name�The name of the generated Objective-C interface header. This name must end with
a `.h` extension and cannot contain any path separators.

If this attribute is not specified, then the default behavior is to name the
header `${target_name}-Swift.h`.

This attribute is ignored if the toolchain does not support generating headers.
2""�
�
generates_header�If True, an Objective-C header will be generated for this target, in the same
build package where the target is defined. By default, the name of the header is
`${target_name}-Swift.h`; this can be changed using the `generated_header_name`
attribute.

Targets should only set this attribute to True if they export Objective-C APIs.
A header generated for a target that does not export Objective-C APIs will be
effectively empty (except for a large amount of prologue and epilogue code) and
this is generally wasteful because the extra file needs to be propagated in the
build graph and, when explicit modules are enabled, extra actions must be
executed to compile the Objective-C module for the generated header.
2False�
�
library_evolution�Indicates whether the Swift code should be compiled with library evolution mode
enabled.

This attribute should be used to compile a module that will be distributed as
part of a client-facing (non-implementation-only) module in a library or
framework that will be distributed for use outside of the Bazel build graph.
Setting this to true will compile the module with the `-library-evolution` flag
and emit a `.swiftinterface` file as one of the compilation outputs.
2False�
�
linkopts�Additional linker options that should be passed to the linker for the binary
that depends on this target. These strings are subject to `$(location ...)`
and ["Make" variable](https://docs.bazel.build/versions/master/be/make-variables.html) expansion.
2[]�
�

linkstatic�If True, the Swift module will be built for static linking.  This will make all
interfaces internal to the module that is being linked against and will inform
the consuming module that the objects will be locally available (which may
potentially avoid a PLT relocation).  Set to `False` to build a `.so` or `.dll`.
2True�
�
module_name�The name of the Swift module being built.

If left unspecified, the module name will be computed based on the target's
build label, by stripping the leading `//` and replacing `/`, `:`, and other
non-identifier characters with underscores.
2""�
�
package_name�The semantic package of the Swift target being built. Targets with the same
package_name can access APIs using the 'package' access control modifier in
Swift 5.9+.
2""�
�
plugins�A list of `swift_compiler_plugin` targets that should be loaded by the compiler
when compiling this module and any modules that directly depend on it.
*
SwiftCompilerPluginInfo2[]�
�
private_deps�A list of targets that are implementation-only dependencies of the target being
built. Libraries/linker flags from these dependencies will be propagated to
dependent for linking, but artifacts/flags required for compilation (such as
.swiftmodule files, C headers, and search paths) will not be propagated.

Allowed kinds of dependencies are:

*   `swift_library` (or anything propagating `SwiftInfo`)

*   `cc_library` and `objc_library` (or anything propagating `CcInfo`)
*
CcInfo*
	SwiftInfo2[]�
�
srcs�A list of `.swift` source files that will be compiled into the library.

Except in very rare circumstances, a Swift source file should only appear in a
single `swift_*` target. Adding the same source file to multiple `swift_*`
targets can lead to binary bloat and/or symbol collisions. If specific sources
need to be shared by multiple targets, consider factoring them out into their
own `swift_library` instead.
 �
�
swiftc_inputslAdditional files that are referenced using `$(location ...)` in attributes that
support location expansion.
2[]�
SafeDIInfo=Module info artifact (`.safedi`) emitted by `safedi_compile`.2�
�

SafeDIInfo=Module info artifact (`.safedi`) emitted by `safedi_compile`.Q
module_infoBThe `.safedi` file describing this module's @Instantiable surface.�
transitive_module_infos�A depset of this module's `.safedi`
file and that of every module beneath it, collected through `deps` as
rules_swift collects `SwiftInfo.transitive_modules`."(

SafeDIInfo@@safedi//bazel:safedi.bzl
��S
Q
module_infoBThe `.safedi` file describing this module's @Instantiable surface.�
�
transitive_module_infos�A depset of this module's `.safedi`
file and that of every module beneath it, collected through `deps` as
rules_swift collects `SwiftInfo.transitive_modules`.�
//rules:common_settings.bzlrr
*
bazel_skylibrulescommon_settings.bzl4
BuildSettingInfoBuildSettingInfo
�3�C
��E�
//swift:module_name.bzlr}
%
rules_swiftswiftmodule_name.bzlD
derive_swift_module_namederive_swift_module_name
�.�F
��Hx
//swift:swift.bzlra

rules_swiftswift	swift.bzl.
swift_libraryswift_library
�(�5
��7�2Starlark rule and macro for integrating SafeDI into a Bazel build.

Most modules declare a `safedi_swift_library`, which takes the
attributes of a `swift_library` and declares two targets from them:

  - `<name>_safedi`, a `safedi_compile` target that runs SafeDITool.
  - `<name>`, a `swift_library` that compiles `srcs` together with the
    code SafeDITool generated.

Both targets receive the same `srcs`, `defines`, and `copts`, so the
compilation conditions SafeDITool scans with always match the ones
the compiler uses. Modules that need something the macro does not
offer can declare `safedi_compile` and `swift_library` by hand.

`safedi_compile(srcs, deps)` runs `SafeDITool generate
--combined-output --module-info-output` once per module and produces
two artifacts:

  - `<rule>.swift` â every dependency-tree, mock, and mock
    configuration body SafeDITool would emit, concatenated into a
    single declared output. Bazel requires rule outputs to be known
    at analysis time, and the combined-output mode lets SafeDITool's
    output set (which depends on source contents) resolve to a
    single statically-known file. Add `[":<rule>"]` to a downstream
    `swift_library.srcs` to compile the generated code.

  - `<rule>.safedi` â the module-info artifact. A module that depends
    on this one lists this rule's label in its own `safedi_compile`'s
    `deps` (or `safedi_swift_library`'s `safedi_deps`) to reach
    `@Instantiable` types declared in this module without re-parsing
    the sources. A module lists the modules it depends on directly.
    The rule collects the rest of the modules beneath them in
    `SafeDIInfo.transitive_module_infos`, as rules_swift collects
    `SwiftInfo.transitive_modules`. SafeDITool reads one of those only
    in a module that declares a root or a seam, and only when it
    declares a type the module's dependency trees need, so a mock
    builds a deeper type only if a tree of its module uses that module
    or the module is listed. The artifact also carries what a seam or
    public mock of a module this one depends on needs, so a module is
    never listed only for another module's seam or public mock. The
    SafeDI manual's "Which modules to list" says more.

This rule mirrors the Tuist plugin's `SafeDI.preCompileScript`
helper, which writes the same two artifacts in one invocation. Doing
both in one action is more efficient than splitting them across two
rules â every leaf-with-mocks or producer-with-mocks would otherwise
invoke SafeDITool twice on the same sources.

## Which SafeDITool the rule runs

The rule takes SafeDITool from the `@safedi//bazel:safeditool_toolchain_type`
toolchain. A SafeDI release from the Bazel Central Registry registers a
toolchain for each prebuilt SafeDITool binary the release uploads (macOS
arm64 and x86_64, Linux x86_64 and arm64), so a build runs the release's
binary for its execution platform: the binary the SwiftPM plugin and the
Tuist plugin run. Bazel downloads it from the release's GitHub assets the
first time a build needs it and checks it against the sha256 the
release's source archive records. The rule runs
`@safedi//Sources/SafeDITool:SafeDITool`, built from source, instead:

  - when `--@safedi//bazel:prefer_prebuilt_safeditool=false` is set, for
    example with `common --@safedi//bazel:prefer_prebuilt_safeditool=false`
    in `.bazelrc`;
  - on an execution platform no prebuilt binary runs on;
  - always, when SafeDI comes from a checkout of its repository rather
    than a release (`local_path_override`, `git_override`, or
    `archive_override` of a GitHub archive), so the rule never runs a
    binary older than itself. See `bazel/extensions.bzl`.

`bazel run @safedi//:SafeDITool -- <arguments>` runs the same
SafeDITool, for `query needs` or `dump` over this rule's `.safedi` files.
Registering another toolchain of this type is not supported.

## Conditional compilation

SafeDITool scans only the `#if` clauses that are active for the
build. `safedi_compile` reports these conditions:

  - `DEBUG`, whenever Bazel's compilation mode is `dbg` or
    `fastbuild`, matching the `-DDEBUG` rules_swift passes to swiftc
    in those modes.
  - `NDEBUG`, whenever Bazel's compilation mode is `opt`, matching
    the `-DNDEBUG` rules_swift passes to swiftc in that mode.
  - `defines`, and every `-D` flag in `copts`, which must match the
    wrapped `swift_library`'s attributes of the same names.
    `safedi_swift_library` passes both targets the same values. The
    library cannot be read here (its `srcs` include this rule's
    output, so depending on it would be a cycle), so a hand-wired
    `safedi_compile` has to repeat them.
  - Every `-D` flag passed to rules_swift's
    `--@rules_swift//swift:copt` command-line flag, which rules_swift
    passes to every Swift compilation in the target configuration
    (`--@rules_swift//swift:exec_copt` in the exec configuration).

A bare condition none of these sources reports is inactive. That
includes `defines` propagated from a dependency, rules_swift's
`--@rules_swift//swift:per_module_swiftcopt`, and copts set on a
custom Swift toolchain. The generated code asserts every decision a
condition made, so a condition the build defines but the rule does not
report fails the build with a message naming it.

## Modules and packages

`safedi_compile` tells SafeDITool the name of the Swift module that
compiles its output (`module_name`, which is required) and that
module's package (`package_name`, which the compiler receives as
`-package-name`). SafeDITool records them in the `.safedi` artifact,
so a consumer knows which module and package declare each
`@Instantiable` type, and records the module each `deps` entry's
`.safedi` names as one of the module's dependencies, along with the
modules beneath them that a module that declares a root or a seam
reads.
`safedi_swift_library` passes the module name its `swift_library`
compiles: the `module_name` attribute, or the name rules_swift derives
from the library's label. Give `safedi_swift_library` a `package_name`
to compile the library with `-package-name`, which `package`
declarations need.

## Unsupported SafeDI features

- `#SafeDIConfiguration(additionalDirectoriesToInclude:)` is **not
  supported**. SafeDITool reads those paths at runtime to scan for
  additional source files, but Bazel's hermetic sandbox only exposes
  files declared as action inputs. List every Swift source you want
  SafeDITool to see directly in `srcs`.
 