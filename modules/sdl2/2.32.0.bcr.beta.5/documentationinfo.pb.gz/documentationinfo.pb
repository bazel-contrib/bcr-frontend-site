Ҋ

sdl2sdl2_config_checks.bzlt
//autoconf:checks.bzlrY
)
rules_cc_autoconfautoconf
checks.bzl
checkschecks
28
:��	SDL2_CONFIG_CHECKS_COMMONj��2��
��{"code":"\n#include <stddef.h>\n\ntypedef int _sizeof_check_type[sizeof(void *) == {value} ? 1 : -1];\n\nint main(void) {\n    return 0;\n}\n","define":"SIZEOF_VOIDP","language":"c","name":"ac_cv_sizeof_void_p","type":"sizeof"}
��{"code":"","define":"HAVE_LIBC","define_value":"1","define_value_fail":"1","language":"c","name":"ac_cv_define_HAVE_LIBC","type":"define"}
��{"code":"","define":"STDC_HEADERS","define_value":"1","define_value_fail":"1","language":"c","name":"ac_cv_define_STDC_HEADERS","type":"define"}
��{"code":"","define":"HAVE_SETJMP","define_value":"1","define_value_fail":"1","language":"c","name":"ac_cv_define_HAVE_SETJMP","type":"define"}
zx{"code":"#include <alloca.h>\n","define":"HAVE_ALLOCA_H","language":"c","name":"ac_cv_header_alloca_h","type":"compile"}
wu{"code":"#include <ctype.h>\n","define":"HAVE_CTYPE_H","language":"c","name":"ac_cv_header_ctype_h","type":"compile"}
{y{"code":"#include <d3d11_1.h>\n","define":"HAVE_D3D11_H","language":"c","name":"ac_cv_header_d3d11_1_h","type":"compile"}
wu{"code":"#include <d3d12.h>\n","define":"HAVE_D3D12_H","language":"c","name":"ac_cv_header_d3d12_h","type":"compile"}
��{"code":"#include <d3d12sdklayers.h>\n","define":"HAVE_D3D12SDKLAYERS_H","language":"c","name":"ac_cv_header_d3d12sdklayers_h","type":"compile"}
sq{"code":"#include <d3d9.h>\n","define":"HAVE_D3D_H","language":"c","name":"ac_cv_header_d3d9_h","type":"compile"}
wu{"code":"#include <float.h>\n","define":"HAVE_FLOAT_H","language":"c","name":"ac_cv_header_float_h","type":"compile"}
wu{"code":"#include <iconv.h>\n","define":"HAVE_ICONV_H","language":"c","name":"ac_cv_header_iconv_h","type":"compile"}
�~{"code":"#include <inttypes.h>\n","define":"HAVE_INTTYPES_H","language":"c","name":"ac_cv_header_inttypes_h","type":"compile"}
zx{"code":"#include <limits.h>\n","define":"HAVE_LIMITS_H","language":"c","name":"ac_cv_header_limits_h","type":"compile"}
��{"code":"#include <linux/input.h>\n","define":"HAVE_LINUX_INPUT_H","language":"c","name":"ac_cv_header_linux_input_h","type":"compile"}
zx{"code":"#include <malloc.h>\n","define":"HAVE_MALLOC_H","language":"c","name":"ac_cv_header_malloc_h","type":"compile"}
zx{"code":"#include <memory.h>\n","define":"HAVE_MEMORY_H","language":"c","name":"ac_cv_header_memory_h","type":"compile"}
��{"code":"#include <pthread_np.h>\n","define":"HAVE_PTHREAD_NP_H","language":"c","name":"ac_cv_header_pthread_np_h","type":"compile"}
zx{"code":"#include <signal.h>\n","define":"HAVE_SIGNAL_H","language":"c","name":"ac_cv_header_signal_h","type":"compile"}
zx{"code":"#include <stdarg.h>\n","define":"HAVE_STDARG_H","language":"c","name":"ac_cv_header_stdarg_h","type":"compile"}
zx{"code":"#include <stddef.h>\n","define":"HAVE_STDDEF_H","language":"c","name":"ac_cv_header_stddef_h","type":"compile"}
zx{"code":"#include <stdint.h>\n","define":"HAVE_STDINT_H","language":"c","name":"ac_cv_header_stdint_h","type":"compile"}
wu{"code":"#include <stdio.h>\n","define":"HAVE_STDIO_H","language":"c","name":"ac_cv_header_stdio_h","type":"compile"}
zx{"code":"#include <stdlib.h>\n","define":"HAVE_STDLIB_H","language":"c","name":"ac_cv_header_stdlib_h","type":"compile"}
zx{"code":"#include <string.h>\n","define":"HAVE_STRING_H","language":"c","name":"ac_cv_header_string_h","type":"compile"}
}{{"code":"#include <strings.h>\n","define":"HAVE_STRINGS_H","language":"c","name":"ac_cv_header_strings_h","type":"compile"}
��{"code":"#include <sys/types.h>\n","define":"HAVE_SYS_TYPES_H","language":"c","name":"ac_cv_header_sys_types_h","type":"compile"}
wu{"code":"#include <wchar.h>\n","define":"HAVE_WCHAR_H","language":"c","name":"ac_cv_header_wchar_h","type":"compile"}
tr{"code":"#include <math.h>\n","define":"HAVE_MATH_H","language":"c","name":"ac_cv_header_math_h","type":"compile"}
wu{"code":"#include <ddraw.h>\n","define":"HAVE_DDRAW_H","language":"c","name":"ac_cv_header_ddraw_h","type":"compile"}
tr{"code":"#include <dxgi.h>\n","define":"HAVE_DXGI_H","language":"c","name":"ac_cv_header_dxgi_h","type":"compile"}
}{{"code":"#include <dxgi1_6.h>\n","define":"HAVE_DXGI1_6_H","language":"c","name":"ac_cv_header_dxgi1_6_h","type":"compile"}
��{"code":"#include <dxgidebug.h>\n","define":"HAVE_DXGIDEBUG_H","language":"c","name":"ac_cv_header_dxgidebug_h","type":"compile"}
}{{"code":"#include <tpcshrd.h>\n","define":"HAVE_TPCSHRD_H","language":"c","name":"ac_cv_header_tpcshrd_h","type":"compile"}
zx{"code":"#include <xinput.h>\n","define":"HAVE_XINPUT_H","language":"c","name":"ac_cv_header_xinput_h","type":"compile"}
��{"code":"#include <sensorsapi.h>\n","define":"HAVE_SENSORSAPI_H","language":"c","name":"ac_cv_header_sensorsapi_h","type":"compile"}
��{"code":"#include <immintrin.h>\n","define":"HAVE_IMMINTRIN_H","language":"c","name":"ac_cv_header_immintrin_h","type":"compile"}
��{"code":"#include <X11/Xcursor/Xcursor.h>\n","define":"HAVE_XCURSOR_H","language":"c","name":"ac_cv_header_x11_xcursor_xcursor_h","type":"compile"}
��{"code":"#include <X11/extensions/Xfixes.h>\n","define":"HAVE_XFIXES_H","language":"c","name":"ac_cv_header_x11_extensions_xfixes_h","type":"compile"}
��{"code":"#include <X11/extensions/XInput2.h>\n","define":"HAVE_XINPUT2_H","language":"c","name":"ac_cv_header_x11_extensions_xinput2_h","type":"compile"}
��{"code":"#include <X11/extensions/Xrandr.h>\n","define":"HAVE_XRANDR_H","language":"c","name":"ac_cv_header_x11_extensions_xrandr_h","type":"compile"}
��{"code":"#include <xkbcommon/xkbcommon.h>\n","define":"HAVE_XKBCOMMON_H","language":"c","name":"ac_cv_header_xkbcommon_xkbcommon_h","type":"compile"}
��{"code":"#ifdef __cplusplus\nextern \"C\"\n#endif\n#if defined _MSC_VER\n#pragma comment(lib, \"legacy_stdio_definitions.lib\")\nint abs ();\n#else\nchar abs ();\n#endif\n\nint main(void) {\n    return abs();\n}\n","define":"HAVE_ABS","language":"c","name":"ac_cv_func_abs","type":"function"}
��{"code":"#ifdef __cplusplus\nextern \"C\"\n#endif\n#if defined _MSC_VER\n#pragma comment(lib, \"legacy_stdio_definitions.lib\")\nint alloca ();\n#else\nchar alloca ();\n#endif\n\nint main(void) {\n    return alloca();\n}\n","define":"HAVE_ALLOCA","language":"c","name":"ac_cv_func_alloca","type":"function"}
��{"code":"#ifdef __cplusplus\nextern \"C\"\n#endif\n#if defined _MSC_VER\n#pragma comment(lib, \"legacy_stdio_definitions.lib\")\nint atof ();\n#else\nchar atof ();\n#endif\n\nint main(void) {\n    return atof();\n}\n","define":"HAVE_ATOF","language":"c","name":"ac_cv_func_atof","type":"function"}
��{"code":"#ifdef __cplusplus\nextern \"C\"\n#endif\n#if defined _MSC_VER\n#pragma comment(lib, \"legacy_stdio_definitions.lib\")\nint atoi ();\n#else\nchar atoi ();\n#endif\n\nint main(void) {\n    return atoi();\n}\n","define":"HAVE_ATOI","language":"c","name":"ac_cv_func_atoi","type":"function"}
��{"code":"#ifdef __cplusplus\nextern \"C\"\n#endif\n#if defined _MSC_VER\n#pragma comment(lib, \"legacy_stdio_definitions.lib\")\nint bsearch ();\n#else\nchar bsearch ();\n#endif\n\nint main(void) {\n    return bsearch();\n}\n","define":"HAVE_BSEARCH","language":"c","name":"ac_cv_func_bsearch","type":"function"}
��{"code":"#ifdef __cplusplus\nextern \"C\"\n#endif\n#if defined _MSC_VER\n#pragma comment(lib, \"legacy_stdio_definitions.lib\")\nint calloc ();\n#else\nchar calloc ();\n#endif\n\nint main(void) {\n    return calloc();\n}\n","define":"HAVE_CALLOC","language":"c","name":"ac_cv_func_calloc","type":"function"}
��{"code":"#ifdef __cplusplus\nextern \"C\"\n#endif\n#if defined _MSC_VER\n#pragma comment(lib, \"legacy_stdio_definitions.lib\")\nint clock_gettime ();\n#else\nchar clock_gettime ();\n#endif\n\nint main(void) {\n    return clock_gettime();\n}\n","define":"HAVE_CLOCK_GETTIME","language":"c","name":"ac_cv_func_clock_gettime","type":"function"}
��{"code":"#ifdef __cplusplus\nextern \"C\"\n#endif\n#if defined _MSC_VER\n#pragma comment(lib, \"legacy_stdio_definitions.lib\")\nint free ();\n#else\nchar free ();\n#endif\n\nint main(void) {\n    return free();\n}\n","define":"HAVE_FREE","language":"c","name":"ac_cv_func_free","type":"function"}
��{"code":"#ifdef __cplusplus\nextern \"C\"\n#endif\n#if defined _MSC_VER\n#pragma comment(lib, \"legacy_stdio_definitions.lib\")\nint getauxval ();\n#else\nchar getauxval ();\n#endif\n\nint main(void) {\n    return getauxval();\n}\n","define":"HAVE_GETAUXVAL","language":"c","name":"ac_cv_func_getauxval","type":"function"}
��{"code":"#ifdef __cplusplus\nextern \"C\"\n#endif\n#if defined _MSC_VER\n#pragma comment(lib, \"legacy_stdio_definitions.lib\")\nint getenv ();\n#else\nchar getenv ();\n#endif\n\nint main(void) {\n    return getenv();\n}\n","define":"HAVE_GETENV","language":"c","name":"ac_cv_func_getenv","type":"function"}
��{"code":"#ifdef __cplusplus\nextern \"C\"\n#endif\n#if defined _MSC_VER\n#pragma comment(lib, \"legacy_stdio_definitions.lib\")\nint malloc ();\n#else\nchar malloc ();\n#endif\n\nint main(void) {\n    return malloc();\n}\n","define":"HAVE_MALLOC","language":"c","name":"ac_cv_func_malloc","type":"function"}
��{"code":"#ifdef __cplusplus\nextern \"C\"\n#endif\n#if defined _MSC_VER\n#pragma comment(lib, \"legacy_stdio_definitions.lib\")\nint memcmp ();\n#else\nchar memcmp ();\n#endif\n\nint main(void) {\n    return memcmp();\n}\n","define":"HAVE_MEMCMP","language":"c","name":"ac_cv_func_memcmp","type":"function"}
��{"code":"#ifdef __cplusplus\nextern \"C\"\n#endif\n#if defined _MSC_VER\n#pragma comment(lib, \"legacy_stdio_definitions.lib\")\nint memcpy ();\n#else\nchar memcpy ();\n#endif\n\nint main(void) {\n    return memcpy();\n}\n","define":"HAVE_MEMCPY","language":"c","name":"ac_cv_func_memcpy","type":"function"}
��{"code":"#ifdef __cplusplus\nextern \"C\"\n#endif\n#if defined _MSC_VER\n#pragma comment(lib, \"legacy_stdio_definitions.lib\")\nint memmove ();\n#else\nchar memmove ();\n#endif\n\nint main(void) {\n    return memmove();\n}\n","define":"HAVE_MEMMOVE","language":"c","name":"ac_cv_func_memmove","type":"function"}
��{"code":"#ifdef __cplusplus\nextern \"C\"\n#endif\n#if defined _MSC_VER\n#pragma comment(lib, \"legacy_stdio_definitions.lib\")\nint memset ();\n#else\nchar memset ();\n#endif\n\nint main(void) {\n    return memset();\n}\n","define":"HAVE_MEMSET","language":"c","name":"ac_cv_func_memset","type":"function"}
��{"code":"#ifdef __cplusplus\nextern \"C\"\n#endif\n#if defined _MSC_VER\n#pragma comment(lib, \"legacy_stdio_definitions.lib\")\nint mprotect ();\n#else\nchar mprotect ();\n#endif\n\nint main(void) {\n    return mprotect();\n}\n","define":"HAVE_MPROTECT","language":"c","name":"ac_cv_func_mprotect","type":"function"}
��{"code":"#ifdef __cplusplus\nextern \"C\"\n#endif\n#if defined _MSC_VER\n#pragma comment(lib, \"legacy_stdio_definitions.lib\")\nint nanosleep ();\n#else\nchar nanosleep ();\n#endif\n\nint main(void) {\n    return nanosleep();\n}\n","define":"HAVE_NANOSLEEP","language":"c","name":"ac_cv_func_nanosleep","type":"function"}
��{"code":"#ifdef __cplusplus\nextern \"C\"\n#endif\n#if defined _MSC_VER\n#pragma comment(lib, \"legacy_stdio_definitions.lib\")\nint iconv ();\n#else\nchar iconv ();\n#endif\n\nint main(void) {\n    return iconv();\n}\n","define":"HAVE_ICONV","language":"c","name":"ac_cv_func_iconv","type":"function"}
��{"code":"#ifdef __cplusplus\nextern \"C\"\n#endif\n#if defined _MSC_VER\n#pragma comment(lib, \"legacy_stdio_definitions.lib\")\nint poll ();\n#else\nchar poll ();\n#endif\n\nint main(void) {\n    return poll();\n}\n","define":"HAVE_POLL","language":"c","name":"ac_cv_func_poll","type":"function"}
��{"code":"#ifdef __cplusplus\nextern \"C\"\n#endif\n#if defined _MSC_VER\n#pragma comment(lib, \"legacy_stdio_definitions.lib\")\nint qsort ();\n#else\nchar qsort ();\n#endif\n\nint main(void) {\n    return qsort();\n}\n","define":"HAVE_QSORT","language":"c","name":"ac_cv_func_qsort","type":"function"}
��{"code":"#ifdef __cplusplus\nextern \"C\"\n#endif\n#if defined _MSC_VER\n#pragma comment(lib, \"legacy_stdio_definitions.lib\")\nint realloc ();\n#else\nchar realloc ();\n#endif\n\nint main(void) {\n    return realloc();\n}\n","define":"HAVE_REALLOC","language":"c","name":"ac_cv_func_realloc","type":"function"}
��{"code":"#ifdef __cplusplus\nextern \"C\"\n#endif\n#if defined _MSC_VER\n#pragma comment(lib, \"legacy_stdio_definitions.lib\")\nint strchr ();\n#else\nchar strchr ();\n#endif\n\nint main(void) {\n    return strchr();\n}\n","define":"HAVE_STRCHR","language":"c","name":"ac_cv_func_strchr","type":"function"}
��{"code":"#ifdef __cplusplus\nextern \"C\"\n#endif\n#if defined _MSC_VER\n#pragma comment(lib, \"legacy_stdio_definitions.lib\")\nint strcmp ();\n#else\nchar strcmp ();\n#endif\n\nint main(void) {\n    return strcmp();\n}\n","define":"HAVE_STRCMP","language":"c","name":"ac_cv_func_strcmp","type":"function"}
��{"code":"#ifdef __cplusplus\nextern \"C\"\n#endif\n#if defined _MSC_VER\n#pragma comment(lib, \"legacy_stdio_definitions.lib\")\nint strncmp ();\n#else\nchar strncmp ();\n#endif\n\nint main(void) {\n    return strncmp();\n}\n","define":"HAVE_STRNCMP","language":"c","name":"ac_cv_func_strncmp","type":"function"}
��{"code":"#ifdef __cplusplus\nextern \"C\"\n#endif\n#if defined _MSC_VER\n#pragma comment(lib, \"legacy_stdio_definitions.lib\")\nint strrchr ();\n#else\nchar strrchr ();\n#endif\n\nint main(void) {\n    return strrchr();\n}\n","define":"HAVE_STRRCHR","language":"c","name":"ac_cv_func_strrchr","type":"function"}
��{"code":"#ifdef __cplusplus\nextern \"C\"\n#endif\n#if defined _MSC_VER\n#pragma comment(lib, \"legacy_stdio_definitions.lib\")\nint strstr ();\n#else\nchar strstr ();\n#endif\n\nint main(void) {\n    return strstr();\n}\n","define":"HAVE_STRSTR","language":"c","name":"ac_cv_func_strstr","type":"function"}
��{"code":"#ifdef __cplusplus\nextern \"C\"\n#endif\n#if defined _MSC_VER\n#pragma comment(lib, \"legacy_stdio_definitions.lib\")\nint strlen ();\n#else\nchar strlen ();\n#endif\n\nint main(void) {\n    return strlen();\n}\n","define":"HAVE_STRLEN","language":"c","name":"ac_cv_func_strlen","type":"function"}
��{"code":"#ifdef __cplusplus\nextern \"C\"\n#endif\n#if defined _MSC_VER\n#pragma comment(lib, \"legacy_stdio_definitions.lib\")\nint strtod ();\n#else\nchar strtod ();\n#endif\n\nint main(void) {\n    return strtod();\n}\n","define":"HAVE_STRTOD","language":"c","name":"ac_cv_func_strtod","type":"function"}
��{"code":"#ifdef __cplusplus\nextern \"C\"\n#endif\n#if defined _MSC_VER\n#pragma comment(lib, \"legacy_stdio_definitions.lib\")\nint strtol ();\n#else\nchar strtol ();\n#endif\n\nint main(void) {\n    return strtol();\n}\n","define":"HAVE_STRTOL","language":"c","name":"ac_cv_func_strtol","type":"function"}
��{"code":"#ifdef __cplusplus\nextern \"C\"\n#endif\n#if defined _MSC_VER\n#pragma comment(lib, \"legacy_stdio_definitions.lib\")\nint strtoll ();\n#else\nchar strtoll ();\n#endif\n\nint main(void) {\n    return strtoll();\n}\n","define":"HAVE_STRTOLL","language":"c","name":"ac_cv_func_strtoll","type":"function"}
��{"code":"#ifdef __cplusplus\nextern \"C\"\n#endif\n#if defined _MSC_VER\n#pragma comment(lib, \"legacy_stdio_definitions.lib\")\nint strtoul ();\n#else\nchar strtoul ();\n#endif\n\nint main(void) {\n    return strtoul();\n}\n","define":"HAVE_STRTOUL","language":"c","name":"ac_cv_func_strtoul","type":"function"}
��{"code":"#ifdef __cplusplus\nextern \"C\"\n#endif\n#if defined _MSC_VER\n#pragma comment(lib, \"legacy_stdio_definitions.lib\")\nint strtoull ();\n#else\nchar strtoull ();\n#endif\n\nint main(void) {\n    return strtoull();\n}\n","define":"HAVE_STRTOULL","language":"c","name":"ac_cv_func_strtoull","type":"function"}
��{"code":"#ifdef __cplusplus\nextern \"C\"\n#endif\n#if defined _MSC_VER\n#pragma comment(lib, \"legacy_stdio_definitions.lib\")\nint sysconf ();\n#else\nchar sysconf ();\n#endif\n\nint main(void) {\n    return sysconf();\n}\n","define":"HAVE_SYSCONF","language":"c","name":"ac_cv_func_sysconf","type":"function"}
��{"code":"#ifdef __cplusplus\nextern \"C\"\n#endif\n#if defined _MSC_VER\n#pragma comment(lib, \"legacy_stdio_definitions.lib\")\nint vsnprintf ();\n#else\nchar vsnprintf ();\n#endif\n\nint main(void) {\n    return vsnprintf();\n}\n","define":"HAVE_VSNPRINTF","language":"c","name":"ac_cv_func_vsnprintf","type":"function"}
��{"code":"#ifdef __cplusplus\nextern \"C\"\n#endif\n#if defined _MSC_VER\n#pragma comment(lib, \"legacy_stdio_definitions.lib\")\nint vsscanf ();\n#else\nchar vsscanf ();\n#endif\n\nint main(void) {\n    return vsscanf();\n}\n","define":"HAVE_VSSCANF","language":"c","name":"ac_cv_func_vsscanf","type":"function"}
��{"code":"#ifdef __cplusplus\nextern \"C\"\n#endif\n#if defined _MSC_VER\n#pragma comment(lib, \"legacy_stdio_definitions.lib\")\nint wcscmp ();\n#else\nchar wcscmp ();\n#endif\n\nint main(void) {\n    return wcscmp();\n}\n","define":"HAVE_WCSCMP","language":"c","name":"ac_cv_func_wcscmp","type":"function"}
��{"code":"#ifdef __cplusplus\nextern \"C\"\n#endif\n#if defined _MSC_VER\n#pragma comment(lib, \"legacy_stdio_definitions.lib\")\nint wcslen ();\n#else\nchar wcslen ();\n#endif\n\nint main(void) {\n    return wcslen();\n}\n","define":"HAVE_WCSLEN","language":"c","name":"ac_cv_func_wcslen","type":"function"}
��{"code":"#ifdef __cplusplus\nextern \"C\"\n#endif\n#if defined _MSC_VER\n#pragma comment(lib, \"legacy_stdio_definitions.lib\")\nint wcsncmp ();\n#else\nchar wcsncmp ();\n#endif\n\nint main(void) {\n    return wcsncmp();\n}\n","define":"HAVE_WCSNCMP","language":"c","name":"ac_cv_func_wcsncmp","type":"function"}
��{"code":"#ifdef __cplusplus\nextern \"C\"\n#endif\n#if defined _MSC_VER\n#pragma comment(lib, \"legacy_stdio_definitions.lib\")\nint wcsstr ();\n#else\nchar wcsstr ();\n#endif\n\nint main(void) {\n    return wcsstr();\n}\n","define":"HAVE_WCSSTR","language":"c","name":"ac_cv_func_wcsstr","type":"function"}�2	SDL2_CONFIG_CHECKS_LINUXj�12�1
��{"code":"","define":"HAVE_DLOPEN","define_value":"1","define_value_fail":"1","language":"c","name":"ac_cv_define_HAVE_DLOPEN","type":"define"}
��{"code":"","define":"HAVE_O_CLOEXEC","define_value":"1","define_value_fail":"1","language":"c","name":"ac_cv_define_HAVE_O_CLOEXEC","type":"define"}
��{"code":"","define":"SDL_JOYSTICK_HIDAPI","define_value":"1","define_value_fail":"1","language":"c","name":"ac_cv_define_SDL_JOYSTICK_HIDAPI","type":"define"}
��{"code":"","define":"SDL_AUDIO_DRIVER_ALSA","define_value":"1","define_value_fail":"1","language":"c","name":"ac_cv_define_SDL_AUDIO_DRIVER_ALSA","type":"define"}
��{"code":"","define":"SDL_AUDIO_DRIVER_ALSA_DYNAMIC","define_value":"\"libasound.so.2\"","define_value_fail":"\"libasound.so.2\"","language":"c","name":"ac_cv_define_SDL_AUDIO_DRIVER_ALSA_DYNAMIC","type":"define"}
��{"code":"","define":"SDL_AUDIO_DRIVER_DISK","define_value":"1","define_value_fail":"1","language":"c","name":"ac_cv_define_SDL_AUDIO_DRIVER_DISK","type":"define"}
��{"code":"","define":"SDL_AUDIO_DRIVER_DUMMY","define_value":"1","define_value_fail":"1","language":"c","name":"ac_cv_define_SDL_AUDIO_DRIVER_DUMMY","type":"define"}
��{"code":"","condition":"ac_cv_header_linux_input_h","define":"SDL_INPUT_LINUXEV","define_value":"1","define_value_fail":0,"language":"c","name":"ac_cv_define_SDL_INPUT_LINUXEV","type":"define"}
��{"code":"","condition":"ac_cv_header_linux_input_h","define":"SDL_INPUT_LINUXKD","define_value":"1","define_value_fail":0,"language":"c","name":"ac_cv_define_SDL_INPUT_LINUXKD","type":"define"}
��{"code":"","condition":"ac_cv_header_linux_input_h","define":"SDL_JOYSTICK_LINUX","define_value":"1","define_value_fail":0,"language":"c","name":"ac_cv_define_SDL_JOYSTICK_LINUX","type":"define"}
��{"code":"","define":"SDL_HAPTIC_LINUX","define_value":"1","define_value_fail":"1","language":"c","name":"ac_cv_define_SDL_HAPTIC_LINUX","type":"define"}
��{"code":"","define":"SDL_SENSOR_DUMMY","define_value":"1","define_value_fail":"1","language":"c","name":"ac_cv_define_SDL_SENSOR_DUMMY","type":"define"}
��{"code":"","define":"SDL_LOADSO_DLOPEN","define_value":"1","define_value_fail":"1","language":"c","name":"ac_cv_define_SDL_LOADSO_DLOPEN","type":"define"}
��{"code":"","define":"SDL_THREAD_PTHREAD","define_value":"1","define_value_fail":"1","language":"c","name":"ac_cv_define_SDL_THREAD_PTHREAD","type":"define"}
��{"code":"","define":"SDL_THREAD_PTHREAD_RECURSIVE_MUTEX","define_value":"1","define_value_fail":"1","language":"c","name":"ac_cv_define_SDL_THREAD_PTHREAD_RECURSIVE_MUTEX","type":"define"}
��{"code":"","define":"SDL_TIMER_UNIX","define_value":"1","define_value_fail":"1","language":"c","name":"ac_cv_define_SDL_TIMER_UNIX","type":"define"}
��{"code":"","define":"SDL_VIDEO_DRIVER_DUMMY","define_value":"1","define_value_fail":"1","language":"c","name":"ac_cv_define_SDL_VIDEO_DRIVER_DUMMY","type":"define"}
��{"code":"","define":"SDL_VIDEO_OPENGL_EGL","define_value":"1","define_value_fail":"1","language":"c","name":"ac_cv_define_SDL_VIDEO_OPENGL_EGL","type":"define"}
��{"code":"","define":"SDL_VIDEO_OPENGL_ES2","define_value":"1","define_value_fail":"1","language":"c","name":"ac_cv_define_SDL_VIDEO_OPENGL_ES2","type":"define"}
��{"code":"","define":"SDL_VIDEO_RENDER_OGL_ES2","define_value":"1","define_value_fail":"1","language":"c","name":"ac_cv_define_SDL_VIDEO_RENDER_OGL_ES2","type":"define"}
��{"code":"","define":"SDL_VIDEO_DRIVER_WAYLAND","define_value":"1","define_value_fail":"1","language":"c","name":"ac_cv_define_SDL_VIDEO_DRIVER_WAYLAND","type":"define"}
��{"code":"","define":"SDL_VIDEO_DRIVER_WAYLAND_DYNAMIC","define_value":"\"libwayland-client.so.0\"","define_value_fail":"\"libwayland-client.so.0\"","language":"c","name":"ac_cv_define_SDL_VIDEO_DRIVER_WAYLAND_DYNAMIC","type":"define"}
��{"code":"","define":"SDL_VIDEO_DRIVER_WAYLAND_DYNAMIC_EGL","define_value":"\"libwayland-egl.so.1\"","define_value_fail":"\"libwayland-egl.so.1\"","language":"c","name":"ac_cv_define_SDL_VIDEO_DRIVER_WAYLAND_DYNAMIC_EGL","type":"define"}
��{"code":"","define":"SDL_VIDEO_DRIVER_WAYLAND_DYNAMIC_CURSOR","define_value":"\"libwayland-cursor.so.0\"","define_value_fail":"\"libwayland-cursor.so.0\"","language":"c","name":"ac_cv_define_SDL_VIDEO_DRIVER_WAYLAND_DYNAMIC_CURSOR","type":"define"}
��{"code":"","define":"SDL_VIDEO_DRIVER_WAYLAND_DYNAMIC_XKBCOMMON","define_value":"\"libxkbcommon.so.0\"","define_value_fail":"\"libxkbcommon.so.0\"","language":"c","name":"ac_cv_define_SDL_VIDEO_DRIVER_WAYLAND_DYNAMIC_XKBCOMMON","type":"define"}
��{"code":"","define":"SDL_VIDEO_DRIVER_X11","define_value":"1","define_value_fail":"1","language":"c","name":"ac_cv_define_SDL_VIDEO_DRIVER_X11","type":"define"}
��{"code":"","define":"SDL_VIDEO_DRIVER_X11_SUPPORTS_GENERIC_EVENTS","define_value":"1","define_value_fail":"1","language":"c","name":"ac_cv_define_SDL_VIDEO_DRIVER_X11_SUPPORTS_GENERIC_EVENTS","type":"define"}
��{"code":"","condition":"ac_cv_header_x11_xcursor_xcursor_h","define":"SDL_VIDEO_DRIVER_X11_XCURSOR","define_value":"1","define_value_fail":0,"language":"c","name":"ac_cv_define_SDL_VIDEO_DRIVER_X11_XCURSOR","type":"define"}
��{"code":"","condition":"ac_cv_header_x11_extensions_xfixes_h","define":"SDL_VIDEO_DRIVER_X11_XFIXES","define_value":"1","define_value_fail":0,"language":"c","name":"ac_cv_define_SDL_VIDEO_DRIVER_X11_XFIXES","type":"define"}
��{"code":"","condition":"ac_cv_header_x11_extensions_xinput2_h","define":"SDL_VIDEO_DRIVER_X11_XINPUT2","define_value":"1","define_value_fail":0,"language":"c","name":"ac_cv_define_SDL_VIDEO_DRIVER_X11_XINPUT2","type":"define"}
��{"code":"","condition":"ac_cv_header_x11_extensions_xrandr_h","define":"SDL_VIDEO_DRIVER_X11_XRANDR","define_value":"1","define_value_fail":0,"language":"c","name":"ac_cv_define_SDL_VIDEO_DRIVER_X11_XRANDR","type":"define"}
��{"code":"","define":"SDL_POWER_LINUX","define_value":"1","define_value_fail":"1","language":"c","name":"ac_cv_define_SDL_POWER_LINUX","type":"define"}
��{"code":"","define":"SDL_FILESYSTEM_UNIX","define_value":"1","define_value_fail":"1","language":"c","name":"ac_cv_define_SDL_FILESYSTEM_UNIX","type":"define"}
��{"code":"","define":"DYNAPI_NEEDS_DLOPEN","define_value":"1","define_value_fail":"1","language":"c","name":"ac_cv_define_DYNAPI_NEEDS_DLOPEN","type":"define"}�	SDL2_CONFIG_CHECKS_MACOSj�2�
��{"code":"","define":"HAVE_DLOPEN","define_value":"1","define_value_fail":"1","language":"c","name":"ac_cv_define_HAVE_DLOPEN","type":"define"}
��{"code":"","define":"SDL_HIDAPI_DISABLED","define_value":"1","define_value_fail":"1","language":"c","name":"ac_cv_define_SDL_HIDAPI_DISABLED","type":"define"}
��{"code":"","define":"SDL_AUDIO_DRIVER_COREAUDIO","define_value":"1","define_value_fail":"1","language":"c","name":"ac_cv_define_SDL_AUDIO_DRIVER_COREAUDIO","type":"define"}
��{"code":"","define":"SDL_AUDIO_DRIVER_DISK","define_value":"1","define_value_fail":"1","language":"c","name":"ac_cv_define_SDL_AUDIO_DRIVER_DISK","type":"define"}
��{"code":"","define":"SDL_AUDIO_DRIVER_DUMMY","define_value":"1","define_value_fail":"1","language":"c","name":"ac_cv_define_SDL_AUDIO_DRIVER_DUMMY","type":"define"}
��{"code":"","define":"SDL_HAPTIC_IOKIT","define_value":"1","define_value_fail":"1","language":"c","name":"ac_cv_define_SDL_HAPTIC_IOKIT","type":"define"}
��{"code":"","define":"SDL_JOYSTICK_IOKIT","define_value":"1","define_value_fail":"1","language":"c","name":"ac_cv_define_SDL_JOYSTICK_IOKIT","type":"define"}
��{"code":"","define":"SDL_JOYSTICK_MFI","define_value":"1","define_value_fail":"1","language":"c","name":"ac_cv_define_SDL_JOYSTICK_MFI","type":"define"}
��{"code":"","define":"SDL_SENSOR_DUMMY","define_value":"1","define_value_fail":"1","language":"c","name":"ac_cv_define_SDL_SENSOR_DUMMY","type":"define"}
��{"code":"","define":"SDL_LOADSO_DLOPEN","define_value":"1","define_value_fail":"1","language":"c","name":"ac_cv_define_SDL_LOADSO_DLOPEN","type":"define"}
��{"code":"","define":"SDL_THREAD_PTHREAD","define_value":"1","define_value_fail":"1","language":"c","name":"ac_cv_define_SDL_THREAD_PTHREAD","type":"define"}
��{"code":"","define":"SDL_THREAD_PTHREAD_RECURSIVE_MUTEX","define_value":"1","define_value_fail":"1","language":"c","name":"ac_cv_define_SDL_THREAD_PTHREAD_RECURSIVE_MUTEX","type":"define"}
��{"code":"","define":"SDL_TIMER_UNIX","define_value":"1","define_value_fail":"1","language":"c","name":"ac_cv_define_SDL_TIMER_UNIX","type":"define"}
��{"code":"","define":"SDL_VIDEO_DRIVER_COCOA","define_value":"1","define_value_fail":"1","language":"c","name":"ac_cv_define_SDL_VIDEO_DRIVER_COCOA","type":"define"}
��{"code":"","define":"SDL_VIDEO_DRIVER_DUMMY","define_value":"1","define_value_fail":"1","language":"c","name":"ac_cv_define_SDL_VIDEO_DRIVER_DUMMY","type":"define"}
��{"code":"","define":"SDL_VIDEO_OPENGL","define_value":"1","define_value_fail":"1","language":"c","name":"ac_cv_define_SDL_VIDEO_OPENGL","type":"define"}
��{"code":"","define":"SDL_VIDEO_OPENGL_CGL","define_value":"1","define_value_fail":"1","language":"c","name":"ac_cv_define_SDL_VIDEO_OPENGL_CGL","type":"define"}
��{"code":"","define":"SDL_VIDEO_RENDER_OGL","define_value":"1","define_value_fail":"1","language":"c","name":"ac_cv_define_SDL_VIDEO_RENDER_OGL","type":"define"}
��{"code":"","define":"SDL_VIDEO_RENDER_METAL","define_value":"1","define_value_fail":"1","language":"c","name":"ac_cv_define_SDL_VIDEO_RENDER_METAL","type":"define"}
��{"code":"","define":"SDL_VIDEO_METAL","define_value":"1","define_value_fail":"1","language":"c","name":"ac_cv_define_SDL_VIDEO_METAL","type":"define"}
��{"code":"","define":"SDL_FILESYSTEM_COCOA","define_value":"1","define_value_fail":"1","language":"c","name":"ac_cv_define_SDL_FILESYSTEM_COCOA","type":"define"}
��{"code":"","define":"SDL_POWER_MACOSX","define_value":"1","define_value_fail":"1","language":"c","name":"ac_cv_define_SDL_POWER_MACOSX","type":"define"}
��{"code":"","define":"DYNAPI_NEEDS_DLOPEN","define_value":"1","define_value_fail":"1","language":"c","name":"ac_cv_define_DYNAPI_NEEDS_DLOPEN","type":"define"}�	SDL2_CONFIG_CHECKS_NON_WINDOWSj�2�
��{"code":"","define":"HAVE_GCC_ATOMICS","define_value":"1","define_value_fail":"1","language":"c","name":"ac_cv_define_HAVE_GCC_ATOMICS","type":"define"}�*	SDL2_CONFIG_CHECKS_WINDOWSj�*2�*
��{"code":"#include <audioclient.h>\n","define":"HAVE_AUDIOCLIENT_H","language":"c","name":"ac_cv_header_audioclient_h","type":"compile"}
zx{"code":"#include <dinput.h>\n","define":"HAVE_DINPUT_H","language":"c","name":"ac_cv_header_dinput_h","type":"compile"}
zx{"code":"#include <dsound.h>\n","define":"HAVE_DSOUND_H","language":"c","name":"ac_cv_header_dsound_h","type":"compile"}
��{"code":"#include <mmdeviceapi.h>\n","define":"HAVE_MMDEVICEAPI_H","language":"c","name":"ac_cv_header_mmdeviceapi_h","type":"compile"}
��{"code":"","define":"SDL_JOYSTICK_HIDAPI","define_value":"1","define_value_fail":"1","language":"c","name":"ac_cv_define_SDL_JOYSTICK_HIDAPI","type":"define"}
��{"code":"","define":"SDL_AUDIO_DRIVER_WINMM","define_value":"1","define_value_fail":"1","language":"c","name":"ac_cv_define_SDL_AUDIO_DRIVER_WINMM","type":"define"}
��{"code":"","define":"SDL_AUDIO_DRIVER_DSOUND","define_value":1,"define_value_fail":1,"language":"c","name":"ac_cv_define_SDL_AUDIO_DRIVER_DSOUND","requires":["ac_cv_header_dsound_h==1"],"type":"define"}
��{"code":"","define":"SDL_AUDIO_DRIVER_WASAPI","define_value":1,"define_value_fail":1,"language":"c","name":"ac_cv_define_SDL_AUDIO_DRIVER_WASAPI","requires":["ac_cv_header_audioclient_h==1","ac_cv_header_mmdeviceapi_h==1"],"type":"define"}
��{"code":"","define":"SDL_AUDIO_DRIVER_DISK","define_value":"1","define_value_fail":"1","language":"c","name":"ac_cv_define_SDL_AUDIO_DRIVER_DISK","type":"define"}
��{"code":"","define":"SDL_AUDIO_DRIVER_DUMMY","define_value":"1","define_value_fail":"1","language":"c","name":"ac_cv_define_SDL_AUDIO_DRIVER_DUMMY","type":"define"}
��{"code":"","condition":"ac_cv_header_dinput_h","define":"SDL_JOYSTICK_DINPUT","define_value":"1","define_value_fail":0,"language":"c","name":"ac_cv_define_SDL_JOYSTICK_DINPUT","type":"define"}
��{"code":"","define":"SDL_JOYSTICK_RAWINPUT","define_value":"1","define_value_fail":"1","language":"c","name":"ac_cv_define_SDL_JOYSTICK_RAWINPUT","type":"define"}
��{"code":"","condition":"ac_cv_header_xinput_h","define":"SDL_JOYSTICK_XINPUT","define_value":"1","define_value_fail":0,"language":"c","name":"ac_cv_define_SDL_JOYSTICK_XINPUT","type":"define"}
��{"code":"","define":"SDL_JOYSTICK_WINDOWS","define_value":"1","define_value_fail":"1","language":"c","name":"ac_cv_define_SDL_JOYSTICK_WINDOWS","type":"define"}
��{"code":"","condition":"ac_cv_header_dinput_h","define":"SDL_HAPTIC_DINPUT","define_value":"1","define_value_fail":0,"language":"c","name":"ac_cv_define_SDL_HAPTIC_DINPUT","type":"define"}
��{"code":"","condition":"ac_cv_header_xinput_h","define":"SDL_HAPTIC_XINPUT","define_value":"1","define_value_fail":0,"language":"c","name":"ac_cv_define_SDL_HAPTIC_XINPUT","type":"define"}
��{"code":"","condition":"ac_cv_header_sensorsapi_h","define":"SDL_SENSOR_WINDOWS","define_value":"1","define_value_fail":0,"language":"c","name":"ac_cv_define_SDL_SENSOR_WINDOWS","type":"define"}
��{"code":"","define":"SDL_LOADSO_WINDOWS","define_value":"1","define_value_fail":"1","language":"c","name":"ac_cv_define_SDL_LOADSO_WINDOWS","type":"define"}
��{"code":"","define":"SDL_THREAD_GENERIC_COND_SUFFIX","define_value":"1","define_value_fail":"1","language":"c","name":"ac_cv_define_SDL_THREAD_GENERIC_COND_SUFFIX","type":"define"}
��{"code":"","define":"SDL_THREAD_WINDOWS","define_value":"1","define_value_fail":"1","language":"c","name":"ac_cv_define_SDL_THREAD_WINDOWS","type":"define"}
��{"code":"","define":"SDL_TIMER_WINDOWS","define_value":"1","define_value_fail":"1","language":"c","name":"ac_cv_define_SDL_TIMER_WINDOWS","type":"define"}
��{"code":"","define":"SDL_VIDEO_DRIVER_DUMMY","define_value":"1","define_value_fail":"1","language":"c","name":"ac_cv_define_SDL_VIDEO_DRIVER_DUMMY","type":"define"}
��{"code":"","define":"SDL_VIDEO_DRIVER_WINDOWS","define_value":"1","define_value_fail":"1","language":"c","name":"ac_cv_define_SDL_VIDEO_DRIVER_WINDOWS","type":"define"}
��{"code":"","define":"SDL_VIDEO_OPENGL","define_value":"1","define_value_fail":"1","language":"c","name":"ac_cv_define_SDL_VIDEO_OPENGL","type":"define"}
��{"code":"","define":"SDL_VIDEO_OPENGL_WGL","define_value":"1","define_value_fail":"1","language":"c","name":"ac_cv_define_SDL_VIDEO_OPENGL_WGL","type":"define"}
��{"code":"","define":"SDL_VIDEO_RENDER_OGL","define_value":"1","define_value_fail":"1","language":"c","name":"ac_cv_define_SDL_VIDEO_RENDER_OGL","type":"define"}
��{"code":"","define":"SDL_VIDEO_RENDER_D3D","define_value":1,"define_value_fail":1,"language":"c","name":"ac_cv_define_SDL_VIDEO_RENDER_D3D","requires":["ac_cv_header_d3d9_h==1"],"type":"define"}
��{"code":"","define":"SDL_VIDEO_RENDER_D3D11","define_value":1,"define_value_fail":1,"language":"c","name":"ac_cv_define_SDL_VIDEO_RENDER_D3D11","requires":["ac_cv_header_d3d11_1_h==1"],"type":"define"}
��{"code":"","define":"SDL_VIDEO_RENDER_D3D12","define_value":1,"define_value_fail":1,"language":"c","name":"ac_cv_define_SDL_VIDEO_RENDER_D3D12","requires":["ac_cv_header_d3d12_h==1","ac_cv_header_d3d12sdklayers_h==1"],"type":"define"}
��{"code":"","define":"SDL_POWER_WINDOWS","define_value":"1","define_value_fail":"1","language":"c","name":"ac_cv_define_SDL_POWER_WINDOWS","type":"define"}
��{"code":"","define":"SDL_FILESYSTEM_WINDOWS","define_value":"1","define_value_fail":"1","language":"c","name":"ac_cv_define_SDL_FILESYSTEM_WINDOWS","type":"define"}NSDL2 autoconf checks used to generate SDL_config.h from the upstream template.�

sdl2wayland_protocols.bzl�declare_wayland_protocols*h
X
declare_wayland_protocols2;
declare_wayland_protocols@@sdl2//:wayland_protocols.bzl
�	WAYLAND_PROTOCOL_HDRSj�2�
?=generated/wayland-protocols/cursor-shape-v1-client-protocol.h
CAgenerated/wayland-protocols/fractional-scale-v1-client-protocol.h
HFgenerated/wayland-protocols/idle-inhibit-unstable-v1-client-protocol.h
VTgenerated/wayland-protocols/keyboard-shortcuts-inhibit-unstable-v1-client-protocol.h
OMgenerated/wayland-protocols/pointer-constraints-unstable-v1-client-protocol.h
MKgenerated/wayland-protocols/primary-selection-unstable-v1-client-protocol.h
LJgenerated/wayland-protocols/relative-pointer-unstable-v1-client-protocol.h
B@generated/wayland-protocols/tablet-unstable-v2-client-protocol.h
FDgenerated/wayland-protocols/text-input-unstable-v3-client-protocol.h
:8generated/wayland-protocols/viewporter-client-protocol.h
A?generated/wayland-protocols/xdg-activation-v1-client-protocol.h
JHgenerated/wayland-protocols/xdg-decoration-unstable-v1-client-protocol.h
FDgenerated/wayland-protocols/xdg-output-unstable-v1-client-protocol.h
97generated/wayland-protocols/xdg-shell-client-protocol.h
DBgenerated/wayland-protocols/xdg-toplevel-icon-v1-client-protocol.h�	WAYLAND_PROTOCOL_NAMESj�2�
cursor-shape-v1
fractional-scale-v1
idle-inhibit-unstable-v1
(&keyboard-shortcuts-inhibit-unstable-v1
!pointer-constraints-unstable-v1
primary-selection-unstable-v1
relative-pointer-unstable-v1
tablet-unstable-v2
text-input-unstable-v3

viewporter
xdg-activation-v1
xdg-decoration-unstable-v1
xdg-output-unstable-v1
	xdg-shell
xdg-toplevel-icon-v1�	WAYLAND_PROTOCOL_SRCSj�2�
86generated/wayland-protocols/cursor-shape-v1-protocol.c
<:generated/wayland-protocols/fractional-scale-v1-protocol.c
A?generated/wayland-protocols/idle-inhibit-unstable-v1-protocol.c
OMgenerated/wayland-protocols/keyboard-shortcuts-inhibit-unstable-v1-protocol.c
HFgenerated/wayland-protocols/pointer-constraints-unstable-v1-protocol.c
FDgenerated/wayland-protocols/primary-selection-unstable-v1-protocol.c
ECgenerated/wayland-protocols/relative-pointer-unstable-v1-protocol.c
;9generated/wayland-protocols/tablet-unstable-v2-protocol.c
?=generated/wayland-protocols/text-input-unstable-v3-protocol.c
31generated/wayland-protocols/viewporter-protocol.c
:8generated/wayland-protocols/xdg-activation-v1-protocol.c
CAgenerated/wayland-protocols/xdg-decoration-unstable-v1-protocol.c
?=generated/wayland-protocols/xdg-output-unstable-v1-protocol.c
20generated/wayland-protocols/xdg-shell-protocol.c
=;generated/wayland-protocols/xdg-toplevel-icon-v1-protocol.c 