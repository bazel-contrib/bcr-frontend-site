�

sdl3cc_headers_only.bzl�cc_headers_only�This rule gives the compilation context of `deps`, and nothing to link.

A cc_library dependency puts the archives of that dependency on every
downstream link line. SDL loads these libraries at runtime by soname, and
compiles only against their headers.

The rule forwards the context as it is. With the external_include_paths
feature, rules_cc moves each search path of another repository to
external_includes, and create_compilation_context takes that parameter only
from rules_cc itself. The paths keep their kind, so they still follow SDL's
own, and SDL's generated wayland-client-protocol.h still wins over the wayland
module's. See wayland_protocols.bzl.

The defines of `deps` come with the context. They are XCMSDIR and XLOCALELIBDIR
of libx11, which SDL does not read. A `HAVE_*` name from a dependency would
change the features that SDL compiles, and give no warning.
"�	
�
cc_headers_only�This rule gives the compilation context of `deps`, and nothing to link.

A cc_library dependency puts the archives of that dependency on every
downstream link line. SDL loads these libraries at runtime by soname, and
compiles only against their headers.

The rule forwards the context as it is. With the external_include_paths
feature, rules_cc moves each search path of another repository to
external_includes, and create_compilation_context takes that parameter only
from rules_cc itself. The paths keep their kind, so they still follow SDL's
own, and SDL's generated wayland-client-protocol.h still wins over the wayland
module's. See wayland_protocols.bzl.

The defines of `deps` come with the context. They are XCMSDIR and XLOCALELIBDIR
of libx11, which SDL does not read. A `HAVE_*` name from a dependency would
change the features that SDL compiles, and give no warning.
*
nameA unique name for this target. K
deps3Libraries whose compilation contexts are forwarded.*
CcInfo2[]"/
cc_headers_only@@sdl3//:cc_headers_only.bzl
,
*
nameA unique name for this target. M
K
deps3Libraries whose compilation contexts are forwarded.*
CcInfo2[]y
//cc/common:cc_common.bzlrZ
$
rules_cc	cc/commoncc_common.bzl$
	cc_common	cc_common
-6
8o
//cc/common:cc_info.bzlrR
"
rules_cc	cc/commoncc_info.bzl
CcInfoCcInfo
+1
3EThis file gives a rule that forwards headers without their libraries.�	

sdl3objc_wrappers.bzl�	objc_wrappers�This rule writes one C file for each source. Each C file includes its source
by the path from the repository root. A cc_library compiles those C files with
`-x objective-c`, so any C toolchain that targets macOS can build them.
objc_library accepts `.m` files directly, but works only with apple_support's
toolchain. `__FILE__` and the debug line table still name the `.m` file.
"�
�
objc_wrappers�This rule writes one C file for each source. Each C file includes its source
by the path from the repository root. A cc_library compiles those C files with
`-x objective-c`, so any C toolchain that targets macOS can build them.
objc_library accepts `.m` files directly, but works only with apple_support's
toolchain. `__FILE__` and the debug line table still name the `.m` file.
*
nameA unique name for this target. 8
prefix$Directory the generated files go in.2"objc"*
srcsObjective-C sources to wrap.2[]"+
objc_wrappers@@sdl3//:objc_wrappers.bzl
,
*
nameA unique name for this target. :
8
prefix$Directory the generated files go in.2"objc",
*
srcsObjective-C sources to wrap.2[]EThis file gives a rule that wraps Objective-C sources for cc_library.��

sdl3sdl3_config_checks.bzlt
//autoconf:checks.bzlrY
)
rules_cc_autoconfautoconf
checks.bzl
checkschecks
0208
00:�	SDL3_CONFIG_CHECKS_COMPILERj�2�
��{"code":"int main(int argc, char **argv) {\n    int a;\n    void *x, *y, *z;\n    __sync_lock_test_and_set(&a, 4);\n    __sync_lock_test_and_set(&x, y);\n    __sync_fetch_and_add(&a, 1);\n    __sync_bool_compare_and_swap(&a, 5, 10);\n    __sync_bool_compare_and_swap(&x, y, z);\n    return 0; }\n","copts":["-D_GNU_SOURCE=1","-D_REENTRANT"],"define":"HAVE_GCC_ATOMICS","if_true":1,"language":"c","name":"ac_cv_try_link_HAVE_GCC_ATOMICS","type":"link"}
��{"code":"int main(int argc, char **argv) {\n    int a;\n    __sync_lock_test_and_set(&a, 1);\n    __sync_lock_release(&a);\n    return 0; }\n","copts":["-D_GNU_SOURCE=1","-D_REENTRANT"],"define":"HAVE_GCC_SYNC_LOCK_TEST_AND_SET","if_true":1,"language":"c","name":"ac_cv_try_link_HAVE_GCC_SYNC_LOCK_TEST_AND_SET","requires":["!HAVE_GCC_ATOMICS"],"type":"link"}��	SDL3_CONFIG_CHECKS_LIBCj��2��
��{"code":"","define":"HAVE_LIBC","define_value":"1","define_value_fail":"1","language":"c","name":"ac_cv_define_HAVE_LIBC","type":"define"}
��{"code":"#include <float.h>\n","copts":["-D_GNU_SOURCE=1","-D_REENTRANT"],"define":"HAVE_FLOAT_H","language":"c","name":"ac_cv_header_float_h","type":"compile"}
��{"code":"#include <iconv.h>\n","copts":["-D_GNU_SOURCE=1","-D_REENTRANT"],"define":"HAVE_ICONV_H","language":"c","name":"ac_cv_header_iconv_h","type":"compile"}
��{"code":"#include <inttypes.h>\n","copts":["-D_GNU_SOURCE=1","-D_REENTRANT"],"define":"HAVE_INTTYPES_H","language":"c","name":"ac_cv_header_inttypes_h","type":"compile"}
��{"code":"#include <limits.h>\n","copts":["-D_GNU_SOURCE=1","-D_REENTRANT"],"define":"HAVE_LIMITS_H","language":"c","name":"ac_cv_header_limits_h","type":"compile"}
��{"code":"#include <malloc.h>\n","copts":["-D_GNU_SOURCE=1","-D_REENTRANT"],"define":"HAVE_MALLOC_H","language":"c","name":"ac_cv_header_malloc_h","type":"compile"}
��{"code":"#include <math.h>\n","copts":["-D_GNU_SOURCE=1","-D_REENTRANT"],"define":"HAVE_MATH_H","language":"c","name":"ac_cv_header_math_h","type":"compile"}
��{"code":"#include <memory.h>\n","copts":["-D_GNU_SOURCE=1","-D_REENTRANT"],"define":"HAVE_MEMORY_H","language":"c","name":"ac_cv_header_memory_h","type":"compile"}
��{"code":"#include <signal.h>\n","copts":["-D_GNU_SOURCE=1","-D_REENTRANT"],"define":"HAVE_SIGNAL_H","language":"c","name":"ac_cv_header_signal_h","type":"compile"}
��{"code":"#include <stdarg.h>\n","copts":["-D_GNU_SOURCE=1","-D_REENTRANT"],"define":"HAVE_STDARG_H","language":"c","name":"ac_cv_header_stdarg_h","type":"compile"}
��{"code":"#include <stdbool.h>\n","copts":["-D_GNU_SOURCE=1","-D_REENTRANT"],"define":"HAVE_STDBOOL_H","language":"c","name":"ac_cv_header_stdbool_h","type":"compile"}
��{"code":"#include <stddef.h>\n","copts":["-D_GNU_SOURCE=1","-D_REENTRANT"],"define":"HAVE_STDDEF_H","language":"c","name":"ac_cv_header_stddef_h","type":"compile"}
��{"code":"#include <stdint.h>\n","copts":["-D_GNU_SOURCE=1","-D_REENTRANT"],"define":"HAVE_STDINT_H","language":"c","name":"ac_cv_header_stdint_h","type":"compile"}
��{"code":"#include <stdio.h>\n","copts":["-D_GNU_SOURCE=1","-D_REENTRANT"],"define":"HAVE_STDIO_H","language":"c","name":"ac_cv_header_stdio_h","type":"compile"}
��{"code":"#include <stdlib.h>\n","copts":["-D_GNU_SOURCE=1","-D_REENTRANT"],"define":"HAVE_STDLIB_H","language":"c","name":"ac_cv_header_stdlib_h","type":"compile"}
��{"code":"#include <string.h>\n","copts":["-D_GNU_SOURCE=1","-D_REENTRANT"],"define":"HAVE_STRING_H","language":"c","name":"ac_cv_header_string_h","type":"compile"}
��{"code":"#include <strings.h>\n","copts":["-D_GNU_SOURCE=1","-D_REENTRANT"],"define":"HAVE_STRINGS_H","language":"c","name":"ac_cv_header_strings_h","type":"compile"}
��{"code":"#include <sys/types.h>\n","copts":["-D_GNU_SOURCE=1","-D_REENTRANT"],"define":"HAVE_SYS_TYPES_H","language":"c","name":"ac_cv_header_sys_types_h","type":"compile"}
��{"code":"#include <time.h>\n","copts":["-D_GNU_SOURCE=1","-D_REENTRANT"],"define":"HAVE_TIME_H","language":"c","name":"ac_cv_header_time_h","type":"compile"}
��{"code":"#include <wchar.h>\n","copts":["-D_GNU_SOURCE=1","-D_REENTRANT"],"define":"HAVE_WCHAR_H","language":"c","name":"ac_cv_header_wchar_h","type":"compile"}
��{"code":"#include <math.h>\nint main(void) {\n#ifndef acos\n    (void)acos;\n#endif\n    return 0;\n}\n","copts":["-D_GNU_SOURCE=1","-D_REENTRANT"],"define":"HAVE_ACOS","if_true":1,"language":"c","linkopts":["-lm"],"name":"ac_cv_try_link_HAVE_ACOS","type":"link"}
��{"code":"#include <math.h>\nint main(void) {\n#ifndef acosf\n    (void)acosf;\n#endif\n    return 0;\n}\n","copts":["-D_GNU_SOURCE=1","-D_REENTRANT"],"define":"HAVE_ACOSF","if_true":1,"language":"c","linkopts":["-lm"],"name":"ac_cv_try_link_HAVE_ACOSF","type":"link"}
��{"code":"#include <math.h>\nint main(void) {\n#ifndef asin\n    (void)asin;\n#endif\n    return 0;\n}\n","copts":["-D_GNU_SOURCE=1","-D_REENTRANT"],"define":"HAVE_ASIN","if_true":1,"language":"c","linkopts":["-lm"],"name":"ac_cv_try_link_HAVE_ASIN","type":"link"}
��{"code":"#include <math.h>\nint main(void) {\n#ifndef asinf\n    (void)asinf;\n#endif\n    return 0;\n}\n","copts":["-D_GNU_SOURCE=1","-D_REENTRANT"],"define":"HAVE_ASINF","if_true":1,"language":"c","linkopts":["-lm"],"name":"ac_cv_try_link_HAVE_ASINF","type":"link"}
��{"code":"#include <math.h>\nint main(void) {\n#ifndef atan\n    (void)atan;\n#endif\n    return 0;\n}\n","copts":["-D_GNU_SOURCE=1","-D_REENTRANT"],"define":"HAVE_ATAN","if_true":1,"language":"c","linkopts":["-lm"],"name":"ac_cv_try_link_HAVE_ATAN","type":"link"}
��{"code":"#include <math.h>\nint main(void) {\n#ifndef atan2\n    (void)atan2;\n#endif\n    return 0;\n}\n","copts":["-D_GNU_SOURCE=1","-D_REENTRANT"],"define":"HAVE_ATAN2","if_true":1,"language":"c","linkopts":["-lm"],"name":"ac_cv_try_link_HAVE_ATAN2","type":"link"}
��{"code":"#include <math.h>\nint main(void) {\n#ifndef atan2f\n    (void)atan2f;\n#endif\n    return 0;\n}\n","copts":["-D_GNU_SOURCE=1","-D_REENTRANT"],"define":"HAVE_ATAN2F","if_true":1,"language":"c","linkopts":["-lm"],"name":"ac_cv_try_link_HAVE_ATAN2F","type":"link"}
��{"code":"#include <math.h>\nint main(void) {\n#ifndef atanf\n    (void)atanf;\n#endif\n    return 0;\n}\n","copts":["-D_GNU_SOURCE=1","-D_REENTRANT"],"define":"HAVE_ATANF","if_true":1,"language":"c","linkopts":["-lm"],"name":"ac_cv_try_link_HAVE_ATANF","type":"link"}
��{"code":"#include <math.h>\nint main(void) {\n#ifndef ceil\n    (void)ceil;\n#endif\n    return 0;\n}\n","copts":["-D_GNU_SOURCE=1","-D_REENTRANT"],"define":"HAVE_CEIL","if_true":1,"language":"c","linkopts":["-lm"],"name":"ac_cv_try_link_HAVE_CEIL","type":"link"}
��{"code":"#include <math.h>\nint main(void) {\n#ifndef ceilf\n    (void)ceilf;\n#endif\n    return 0;\n}\n","copts":["-D_GNU_SOURCE=1","-D_REENTRANT"],"define":"HAVE_CEILF","if_true":1,"language":"c","linkopts":["-lm"],"name":"ac_cv_try_link_HAVE_CEILF","type":"link"}
��{"code":"#include <math.h>\nint main(void) {\n#ifndef copysign\n    (void)copysign;\n#endif\n    return 0;\n}\n","copts":["-D_GNU_SOURCE=1","-D_REENTRANT"],"define":"HAVE_COPYSIGN","if_true":1,"language":"c","linkopts":["-lm"],"name":"ac_cv_try_link_HAVE_COPYSIGN","type":"link"}
��{"code":"#include <math.h>\nint main(void) {\n#ifndef copysignf\n    (void)copysignf;\n#endif\n    return 0;\n}\n","copts":["-D_GNU_SOURCE=1","-D_REENTRANT"],"define":"HAVE_COPYSIGNF","if_true":1,"language":"c","linkopts":["-lm"],"name":"ac_cv_try_link_HAVE_COPYSIGNF","type":"link"}
��{"code":"#include <math.h>\nint main(void) {\n#ifndef cos\n    (void)cos;\n#endif\n    return 0;\n}\n","copts":["-D_GNU_SOURCE=1","-D_REENTRANT"],"define":"HAVE_COS","if_true":1,"language":"c","linkopts":["-lm"],"name":"ac_cv_try_link_HAVE_COS","type":"link"}
��{"code":"#include <math.h>\nint main(void) {\n#ifndef cosf\n    (void)cosf;\n#endif\n    return 0;\n}\n","copts":["-D_GNU_SOURCE=1","-D_REENTRANT"],"define":"HAVE_COSF","if_true":1,"language":"c","linkopts":["-lm"],"name":"ac_cv_try_link_HAVE_COSF","type":"link"}
��{"code":"#include <math.h>\nint main(void) {\n#ifndef exp\n    (void)exp;\n#endif\n    return 0;\n}\n","copts":["-D_GNU_SOURCE=1","-D_REENTRANT"],"define":"HAVE_EXP","if_true":1,"language":"c","linkopts":["-lm"],"name":"ac_cv_try_link_HAVE_EXP","type":"link"}
��{"code":"#include <math.h>\nint main(void) {\n#ifndef expf\n    (void)expf;\n#endif\n    return 0;\n}\n","copts":["-D_GNU_SOURCE=1","-D_REENTRANT"],"define":"HAVE_EXPF","if_true":1,"language":"c","linkopts":["-lm"],"name":"ac_cv_try_link_HAVE_EXPF","type":"link"}
��{"code":"#include <math.h>\nint main(void) {\n#ifndef fabs\n    (void)fabs;\n#endif\n    return 0;\n}\n","copts":["-D_GNU_SOURCE=1","-D_REENTRANT"],"define":"HAVE_FABS","if_true":1,"language":"c","linkopts":["-lm"],"name":"ac_cv_try_link_HAVE_FABS","type":"link"}
��{"code":"#include <math.h>\nint main(void) {\n#ifndef fabsf\n    (void)fabsf;\n#endif\n    return 0;\n}\n","copts":["-D_GNU_SOURCE=1","-D_REENTRANT"],"define":"HAVE_FABSF","if_true":1,"language":"c","linkopts":["-lm"],"name":"ac_cv_try_link_HAVE_FABSF","type":"link"}
��{"code":"#include <math.h>\nint main(void) {\n#ifndef floor\n    (void)floor;\n#endif\n    return 0;\n}\n","copts":["-D_GNU_SOURCE=1","-D_REENTRANT"],"define":"HAVE_FLOOR","if_true":1,"language":"c","linkopts":["-lm"],"name":"ac_cv_try_link_HAVE_FLOOR","type":"link"}
��{"code":"#include <math.h>\nint main(void) {\n#ifndef floorf\n    (void)floorf;\n#endif\n    return 0;\n}\n","copts":["-D_GNU_SOURCE=1","-D_REENTRANT"],"define":"HAVE_FLOORF","if_true":1,"language":"c","linkopts":["-lm"],"name":"ac_cv_try_link_HAVE_FLOORF","type":"link"}
��{"code":"#include <math.h>\nint main(void) {\n#ifndef fmod\n    (void)fmod;\n#endif\n    return 0;\n}\n","copts":["-D_GNU_SOURCE=1","-D_REENTRANT"],"define":"HAVE_FMOD","if_true":1,"language":"c","linkopts":["-lm"],"name":"ac_cv_try_link_HAVE_FMOD","type":"link"}
��{"code":"#include <math.h>\nint main(void) {\n#ifndef fmodf\n    (void)fmodf;\n#endif\n    return 0;\n}\n","copts":["-D_GNU_SOURCE=1","-D_REENTRANT"],"define":"HAVE_FMODF","if_true":1,"language":"c","linkopts":["-lm"],"name":"ac_cv_try_link_HAVE_FMODF","type":"link"}
��{"code":"#include <math.h>\nint main(void) {\n#ifndef log\n    (void)log;\n#endif\n    return 0;\n}\n","copts":["-D_GNU_SOURCE=1","-D_REENTRANT"],"define":"HAVE_LOG","if_true":1,"language":"c","linkopts":["-lm"],"name":"ac_cv_try_link_HAVE_LOG","type":"link"}
��{"code":"#include <math.h>\nint main(void) {\n#ifndef log10\n    (void)log10;\n#endif\n    return 0;\n}\n","copts":["-D_GNU_SOURCE=1","-D_REENTRANT"],"define":"HAVE_LOG10","if_true":1,"language":"c","linkopts":["-lm"],"name":"ac_cv_try_link_HAVE_LOG10","type":"link"}
��{"code":"#include <math.h>\nint main(void) {\n#ifndef log10f\n    (void)log10f;\n#endif\n    return 0;\n}\n","copts":["-D_GNU_SOURCE=1","-D_REENTRANT"],"define":"HAVE_LOG10F","if_true":1,"language":"c","linkopts":["-lm"],"name":"ac_cv_try_link_HAVE_LOG10F","type":"link"}
��{"code":"#include <math.h>\nint main(void) {\n#ifndef logf\n    (void)logf;\n#endif\n    return 0;\n}\n","copts":["-D_GNU_SOURCE=1","-D_REENTRANT"],"define":"HAVE_LOGF","if_true":1,"language":"c","linkopts":["-lm"],"name":"ac_cv_try_link_HAVE_LOGF","type":"link"}
��{"code":"#include <math.h>\nint main(void) {\n#ifndef lround\n    (void)lround;\n#endif\n    return 0;\n}\n","copts":["-D_GNU_SOURCE=1","-D_REENTRANT"],"define":"HAVE_LROUND","if_true":1,"language":"c","linkopts":["-lm"],"name":"ac_cv_try_link_HAVE_LROUND","type":"link"}
��{"code":"#include <math.h>\nint main(void) {\n#ifndef lroundf\n    (void)lroundf;\n#endif\n    return 0;\n}\n","copts":["-D_GNU_SOURCE=1","-D_REENTRANT"],"define":"HAVE_LROUNDF","if_true":1,"language":"c","linkopts":["-lm"],"name":"ac_cv_try_link_HAVE_LROUNDF","type":"link"}
��{"code":"#include <math.h>\nint main(void) {\n#ifndef modf\n    (void)modf;\n#endif\n    return 0;\n}\n","copts":["-D_GNU_SOURCE=1","-D_REENTRANT"],"define":"HAVE_MODF","if_true":1,"language":"c","linkopts":["-lm"],"name":"ac_cv_try_link_HAVE_MODF","type":"link"}
��{"code":"#include <math.h>\nint main(void) {\n#ifndef modff\n    (void)modff;\n#endif\n    return 0;\n}\n","copts":["-D_GNU_SOURCE=1","-D_REENTRANT"],"define":"HAVE_MODFF","if_true":1,"language":"c","linkopts":["-lm"],"name":"ac_cv_try_link_HAVE_MODFF","type":"link"}
��{"code":"#include <math.h>\nint main(void) {\n#ifndef pow\n    (void)pow;\n#endif\n    return 0;\n}\n","copts":["-D_GNU_SOURCE=1","-D_REENTRANT"],"define":"HAVE_POW","if_true":1,"language":"c","linkopts":["-lm"],"name":"ac_cv_try_link_HAVE_POW","type":"link"}
��{"code":"#include <math.h>\nint main(void) {\n#ifndef powf\n    (void)powf;\n#endif\n    return 0;\n}\n","copts":["-D_GNU_SOURCE=1","-D_REENTRANT"],"define":"HAVE_POWF","if_true":1,"language":"c","linkopts":["-lm"],"name":"ac_cv_try_link_HAVE_POWF","type":"link"}
��{"code":"#include <math.h>\nint main(void) {\n#ifndef round\n    (void)round;\n#endif\n    return 0;\n}\n","copts":["-D_GNU_SOURCE=1","-D_REENTRANT"],"define":"HAVE_ROUND","if_true":1,"language":"c","linkopts":["-lm"],"name":"ac_cv_try_link_HAVE_ROUND","type":"link"}
��{"code":"#include <math.h>\nint main(void) {\n#ifndef roundf\n    (void)roundf;\n#endif\n    return 0;\n}\n","copts":["-D_GNU_SOURCE=1","-D_REENTRANT"],"define":"HAVE_ROUNDF","if_true":1,"language":"c","linkopts":["-lm"],"name":"ac_cv_try_link_HAVE_ROUNDF","type":"link"}
��{"code":"#include <math.h>\nint main(void) {\n#ifndef scalbn\n    (void)scalbn;\n#endif\n    return 0;\n}\n","copts":["-D_GNU_SOURCE=1","-D_REENTRANT"],"define":"HAVE_SCALBN","if_true":1,"language":"c","linkopts":["-lm"],"name":"ac_cv_try_link_HAVE_SCALBN","type":"link"}
��{"code":"#include <math.h>\nint main(void) {\n#ifndef scalbnf\n    (void)scalbnf;\n#endif\n    return 0;\n}\n","copts":["-D_GNU_SOURCE=1","-D_REENTRANT"],"define":"HAVE_SCALBNF","if_true":1,"language":"c","linkopts":["-lm"],"name":"ac_cv_try_link_HAVE_SCALBNF","type":"link"}
��{"code":"#include <math.h>\nint main(void) {\n#ifndef sin\n    (void)sin;\n#endif\n    return 0;\n}\n","copts":["-D_GNU_SOURCE=1","-D_REENTRANT"],"define":"HAVE_SIN","if_true":1,"language":"c","linkopts":["-lm"],"name":"ac_cv_try_link_HAVE_SIN","type":"link"}
��{"code":"#include <math.h>\nint main(void) {\n#ifndef sinf\n    (void)sinf;\n#endif\n    return 0;\n}\n","copts":["-D_GNU_SOURCE=1","-D_REENTRANT"],"define":"HAVE_SINF","if_true":1,"language":"c","linkopts":["-lm"],"name":"ac_cv_try_link_HAVE_SINF","type":"link"}
��{"code":"#include <math.h>\nint main(void) {\n#ifndef sqr\n    (void)sqr;\n#endif\n    return 0;\n}\n","copts":["-D_GNU_SOURCE=1","-D_REENTRANT"],"define":"HAVE_SQR","if_true":1,"language":"c","linkopts":["-lm"],"name":"ac_cv_try_link_HAVE_SQR","type":"link"}
��{"code":"#include <math.h>\nint main(void) {\n#ifndef sqrt\n    (void)sqrt;\n#endif\n    return 0;\n}\n","copts":["-D_GNU_SOURCE=1","-D_REENTRANT"],"define":"HAVE_SQRT","if_true":1,"language":"c","linkopts":["-lm"],"name":"ac_cv_try_link_HAVE_SQRT","type":"link"}
��{"code":"#include <math.h>\nint main(void) {\n#ifndef sqrtf\n    (void)sqrtf;\n#endif\n    return 0;\n}\n","copts":["-D_GNU_SOURCE=1","-D_REENTRANT"],"define":"HAVE_SQRTF","if_true":1,"language":"c","linkopts":["-lm"],"name":"ac_cv_try_link_HAVE_SQRTF","type":"link"}
��{"code":"#include <math.h>\nint main(void) {\n#ifndef tan\n    (void)tan;\n#endif\n    return 0;\n}\n","copts":["-D_GNU_SOURCE=1","-D_REENTRANT"],"define":"HAVE_TAN","if_true":1,"language":"c","linkopts":["-lm"],"name":"ac_cv_try_link_HAVE_TAN","type":"link"}
��{"code":"#include <math.h>\nint main(void) {\n#ifndef tanf\n    (void)tanf;\n#endif\n    return 0;\n}\n","copts":["-D_GNU_SOURCE=1","-D_REENTRANT"],"define":"HAVE_TANF","if_true":1,"language":"c","linkopts":["-lm"],"name":"ac_cv_try_link_HAVE_TANF","type":"link"}
��{"code":"#include <math.h>\nint main(void) {\n#ifndef trunc\n    (void)trunc;\n#endif\n    return 0;\n}\n","copts":["-D_GNU_SOURCE=1","-D_REENTRANT"],"define":"HAVE_TRUNC","if_true":1,"language":"c","linkopts":["-lm"],"name":"ac_cv_try_link_HAVE_TRUNC","type":"link"}
��{"code":"#include <math.h>\nint main(void) {\n#ifndef truncf\n    (void)truncf;\n#endif\n    return 0;\n}\n","copts":["-D_GNU_SOURCE=1","-D_REENTRANT"],"define":"HAVE_TRUNCF","if_true":1,"language":"c","linkopts":["-lm"],"name":"ac_cv_try_link_HAVE_TRUNCF","type":"link"}
��{"code":"#include <stdio.h>\nint main(void) {\n#ifndef fopen64\n    (void)fopen64;\n#endif\n    return 0;\n}\n","copts":["-D_GNU_SOURCE=1","-D_REENTRANT"],"define":"HAVE_FOPEN64","if_true":1,"language":"c","linkopts":["-lm"],"name":"ac_cv_try_link_HAVE_FOPEN64","type":"link"}
��{"code":"#include <stdio.h>\nint main(void) {\n#ifndef fseeko\n    (void)fseeko;\n#endif\n    return 0;\n}\n","copts":["-D_GNU_SOURCE=1","-D_REENTRANT"],"define":"HAVE_FSEEKO","if_true":1,"language":"c","linkopts":["-lm"],"name":"ac_cv_try_link_HAVE_FSEEKO","type":"link"}
��{"code":"#include <stdio.h>\nint main(void) {\n#ifndef fseeko64\n    (void)fseeko64;\n#endif\n    return 0;\n}\n","copts":["-D_GNU_SOURCE=1","-D_REENTRANT"],"define":"HAVE_FSEEKO64","if_true":1,"language":"c","linkopts":["-lm"],"name":"ac_cv_try_link_HAVE_FSEEKO64","type":"link"}
��{"code":"#include <stdio.h>\nint main(void) {\n#ifndef sscanf\n    (void)sscanf;\n#endif\n    return 0;\n}\n","copts":["-D_GNU_SOURCE=1","-D_REENTRANT"],"define":"HAVE_SSCANF","if_true":1,"language":"c","linkopts":["-lm"],"name":"ac_cv_try_link_HAVE_SSCANF","type":"link"}
��{"code":"#include <stdio.h>\nint main(void) {\n#ifndef vsnprintf\n    (void)vsnprintf;\n#endif\n    return 0;\n}\n","copts":["-D_GNU_SOURCE=1","-D_REENTRANT"],"define":"HAVE_VSNPRINTF","if_true":1,"language":"c","linkopts":["-lm"],"name":"ac_cv_try_link_HAVE_VSNPRINTF","type":"link"}
��{"code":"#include <stdio.h>\nint main(void) {\n#ifndef vsscanf\n    (void)vsscanf;\n#endif\n    return 0;\n}\n","copts":["-D_GNU_SOURCE=1","-D_REENTRANT"],"define":"HAVE_VSSCANF","if_true":1,"language":"c","linkopts":["-lm"],"name":"ac_cv_try_link_HAVE_VSSCANF","type":"link"}
��{"code":"#include <stdlib.h>\nint main(void) {\n#ifndef _Exit\n    (void)_Exit;\n#endif\n    return 0;\n}\n","copts":["-D_GNU_SOURCE=1","-D_REENTRANT"],"define":"HAVE__EXIT","if_true":1,"language":"c","linkopts":["-lm"],"name":"ac_cv_try_link_HAVE__EXIT","type":"link"}
��{"code":"#include <stdlib.h>\nint main(void) {\n#ifndef _i64toa\n    (void)_i64toa;\n#endif\n    return 0;\n}\n","copts":["-D_GNU_SOURCE=1","-D_REENTRANT"],"define":"HAVE__I64TOA","if_true":1,"language":"c","linkopts":["-lm"],"name":"ac_cv_try_link_HAVE__I64TOA","type":"link"}
��{"code":"#include <stdlib.h>\nint main(void) {\n#ifndef _ltoa\n    (void)_ltoa;\n#endif\n    return 0;\n}\n","copts":["-D_GNU_SOURCE=1","-D_REENTRANT"],"define":"HAVE__LTOA","if_true":1,"language":"c","linkopts":["-lm"],"name":"ac_cv_try_link_HAVE__LTOA","type":"link"}
��{"code":"#include <stdlib.h>\nint main(void) {\n#ifndef abs\n    (void)abs;\n#endif\n    return 0;\n}\n","copts":["-D_GNU_SOURCE=1","-D_REENTRANT"],"define":"HAVE_ABS","if_true":1,"language":"c","linkopts":["-lm"],"name":"ac_cv_try_link_HAVE_ABS","type":"link"}
��{"code":"#include <stdlib.h>\nint main(void) {\n#ifndef atof\n    (void)atof;\n#endif\n    return 0;\n}\n","copts":["-D_GNU_SOURCE=1","-D_REENTRANT"],"define":"HAVE_ATOF","if_true":1,"language":"c","linkopts":["-lm"],"name":"ac_cv_try_link_HAVE_ATOF","type":"link"}
��{"code":"#include <stdlib.h>\nint main(void) {\n#ifndef atoi\n    (void)atoi;\n#endif\n    return 0;\n}\n","copts":["-D_GNU_SOURCE=1","-D_REENTRANT"],"define":"HAVE_ATOI","if_true":1,"language":"c","linkopts":["-lm"],"name":"ac_cv_try_link_HAVE_ATOI","type":"link"}
��{"code":"#include <stdlib.h>\nint main(void) {\n#ifndef getenv\n    (void)getenv;\n#endif\n    return 0;\n}\n","copts":["-D_GNU_SOURCE=1","-D_REENTRANT"],"define":"HAVE_GETENV","if_true":1,"language":"c","linkopts":["-lm"],"name":"ac_cv_try_link_HAVE_GETENV","type":"link"}
��{"code":"#include <stdlib.h>\nint main(void) {\n#ifndef itoa\n    (void)itoa;\n#endif\n    return 0;\n}\n","copts":["-D_GNU_SOURCE=1","-D_REENTRANT"],"define":"HAVE_ITOA","if_true":1,"language":"c","linkopts":["-lm"],"name":"ac_cv_try_link_HAVE_ITOA","type":"link"}
��{"code":"#include <stdlib.h>\nint main(void) {\n#ifndef malloc\n    (void)malloc;\n#endif\n    return 0;\n}\n","copts":["-D_GNU_SOURCE=1","-D_REENTRANT"],"define":"HAVE_MALLOC","if_true":1,"language":"c","linkopts":["-lm"],"name":"ac_cv_try_link_HAVE_MALLOC","type":"link"}
��{"code":"#include <stdlib.h>\nint main(void) {\n#ifndef putenv\n    (void)putenv;\n#endif\n    return 0;\n}\n","copts":["-D_GNU_SOURCE=1","-D_REENTRANT"],"define":"HAVE_PUTENV","if_true":1,"language":"c","linkopts":["-lm"],"name":"ac_cv_try_link_HAVE_PUTENV","type":"link"}
��{"code":"#include <stdlib.h>\nint main(void) {\n#ifndef setenv\n    (void)setenv;\n#endif\n    return 0;\n}\n","copts":["-D_GNU_SOURCE=1","-D_REENTRANT"],"define":"HAVE_SETENV","if_true":1,"language":"c","linkopts":["-lm"],"name":"ac_cv_try_link_HAVE_SETENV","type":"link"}
��{"code":"#include <stdlib.h>\nint main(void) {\n#ifndef strtod\n    (void)strtod;\n#endif\n    return 0;\n}\n","copts":["-D_GNU_SOURCE=1","-D_REENTRANT"],"define":"HAVE_STRTOD","if_true":1,"language":"c","linkopts":["-lm"],"name":"ac_cv_try_link_HAVE_STRTOD","type":"link"}
��{"code":"#include <stdlib.h>\nint main(void) {\n#ifndef strtol\n    (void)strtol;\n#endif\n    return 0;\n}\n","copts":["-D_GNU_SOURCE=1","-D_REENTRANT"],"define":"HAVE_STRTOL","if_true":1,"language":"c","linkopts":["-lm"],"name":"ac_cv_try_link_HAVE_STRTOL","type":"link"}
��{"code":"#include <stdlib.h>\nint main(void) {\n#ifndef strtoll\n    (void)strtoll;\n#endif\n    return 0;\n}\n","copts":["-D_GNU_SOURCE=1","-D_REENTRANT"],"define":"HAVE_STRTOLL","if_true":1,"language":"c","linkopts":["-lm"],"name":"ac_cv_try_link_HAVE_STRTOLL","type":"link"}
��{"code":"#include <stdlib.h>\nint main(void) {\n#ifndef strtoul\n    (void)strtoul;\n#endif\n    return 0;\n}\n","copts":["-D_GNU_SOURCE=1","-D_REENTRANT"],"define":"HAVE_STRTOUL","if_true":1,"language":"c","linkopts":["-lm"],"name":"ac_cv_try_link_HAVE_STRTOUL","type":"link"}
��{"code":"#include <stdlib.h>\nint main(void) {\n#ifndef strtoull\n    (void)strtoull;\n#endif\n    return 0;\n}\n","copts":["-D_GNU_SOURCE=1","-D_REENTRANT"],"define":"HAVE_STRTOULL","if_true":1,"language":"c","linkopts":["-lm"],"name":"ac_cv_try_link_HAVE_STRTOULL","type":"link"}
��{"code":"#include <stdlib.h>\nint main(void) {\n#ifndef unsetenv\n    (void)unsetenv;\n#endif\n    return 0;\n}\n","copts":["-D_GNU_SOURCE=1","-D_REENTRANT"],"define":"HAVE_UNSETENV","if_true":1,"language":"c","linkopts":["-lm"],"name":"ac_cv_try_link_HAVE_UNSETENV","type":"link"}
��{"code":"#include <string.h>\nint main(void) {\n#ifndef memcmp\n    (void)memcmp;\n#endif\n    return 0;\n}\n","copts":["-D_GNU_SOURCE=1","-D_REENTRANT"],"define":"HAVE_MEMCMP","if_true":1,"language":"c","linkopts":["-lm"],"name":"ac_cv_try_link_HAVE_MEMCMP","type":"link"}
��{"code":"#include <string.h>\nint main(void) {\n#ifndef memcpy\n    (void)memcpy;\n#endif\n    return 0;\n}\n","copts":["-D_GNU_SOURCE=1","-D_REENTRANT"],"define":"HAVE_MEMCPY","if_true":1,"language":"c","linkopts":["-lm"],"name":"ac_cv_try_link_HAVE_MEMCPY","type":"link"}
��{"code":"#include <string.h>\nint main(void) {\n#ifndef memmove\n    (void)memmove;\n#endif\n    return 0;\n}\n","copts":["-D_GNU_SOURCE=1","-D_REENTRANT"],"define":"HAVE_MEMMOVE","if_true":1,"language":"c","linkopts":["-lm"],"name":"ac_cv_try_link_HAVE_MEMMOVE","type":"link"}
��{"code":"#include <string.h>\nint main(void) {\n#ifndef memset\n    (void)memset;\n#endif\n    return 0;\n}\n","copts":["-D_GNU_SOURCE=1","-D_REENTRANT"],"define":"HAVE_MEMSET","if_true":1,"language":"c","linkopts":["-lm"],"name":"ac_cv_try_link_HAVE_MEMSET","type":"link"}
��{"code":"#include <string.h>\nint main(void) {\n#ifndef strcasestr\n    (void)strcasestr;\n#endif\n    return 0;\n}\n","copts":["-D_GNU_SOURCE=1","-D_REENTRANT"],"define":"HAVE_STRCASESTR","if_true":1,"language":"c","linkopts":["-lm"],"name":"ac_cv_try_link_HAVE_STRCASESTR","type":"link"}
��{"code":"#include <string.h>\nint main(void) {\n#ifndef strchr\n    (void)strchr;\n#endif\n    return 0;\n}\n","copts":["-D_GNU_SOURCE=1","-D_REENTRANT"],"define":"HAVE_STRCHR","if_true":1,"language":"c","linkopts":["-lm"],"name":"ac_cv_try_link_HAVE_STRCHR","type":"link"}
��{"code":"#include <string.h>\nint main(void) {\n#ifndef strcmp\n    (void)strcmp;\n#endif\n    return 0;\n}\n","copts":["-D_GNU_SOURCE=1","-D_REENTRANT"],"define":"HAVE_STRCMP","if_true":1,"language":"c","linkopts":["-lm"],"name":"ac_cv_try_link_HAVE_STRCMP","type":"link"}
��{"code":"#include <string.h>\nint main(void) {\n#ifndef strlcat\n    (void)strlcat;\n#endif\n    return 0;\n}\n","copts":["-D_GNU_SOURCE=1","-D_REENTRANT"],"define":"HAVE_STRLCAT","if_true":1,"language":"c","linkopts":["-lm"],"name":"ac_cv_try_link_HAVE_STRLCAT","type":"link"}
��{"code":"#include <string.h>\nint main(void) {\n#ifndef strlcpy\n    (void)strlcpy;\n#endif\n    return 0;\n}\n","copts":["-D_GNU_SOURCE=1","-D_REENTRANT"],"define":"HAVE_STRLCPY","if_true":1,"language":"c","linkopts":["-lm"],"name":"ac_cv_try_link_HAVE_STRLCPY","type":"link"}
��{"code":"#include <string.h>\nint main(void) {\n#ifndef strlen\n    (void)strlen;\n#endif\n    return 0;\n}\n","copts":["-D_GNU_SOURCE=1","-D_REENTRANT"],"define":"HAVE_STRLEN","if_true":1,"language":"c","linkopts":["-lm"],"name":"ac_cv_try_link_HAVE_STRLEN","type":"link"}
��{"code":"#include <string.h>\nint main(void) {\n#ifndef strncmp\n    (void)strncmp;\n#endif\n    return 0;\n}\n","copts":["-D_GNU_SOURCE=1","-D_REENTRANT"],"define":"HAVE_STRNCMP","if_true":1,"language":"c","linkopts":["-lm"],"name":"ac_cv_try_link_HAVE_STRNCMP","type":"link"}
��{"code":"#include <string.h>\nint main(void) {\n#ifndef strnlen\n    (void)strnlen;\n#endif\n    return 0;\n}\n","copts":["-D_GNU_SOURCE=1","-D_REENTRANT"],"define":"HAVE_STRNLEN","if_true":1,"language":"c","linkopts":["-lm"],"name":"ac_cv_try_link_HAVE_STRNLEN","type":"link"}
��{"code":"#include <string.h>\nint main(void) {\n#ifndef strnstr\n    (void)strnstr;\n#endif\n    return 0;\n}\n","copts":["-D_GNU_SOURCE=1","-D_REENTRANT"],"define":"HAVE_STRNSTR","if_true":1,"language":"c","linkopts":["-lm"],"name":"ac_cv_try_link_HAVE_STRNSTR","type":"link"}
��{"code":"#include <string.h>\nint main(void) {\n#ifndef strpbrk\n    (void)strpbrk;\n#endif\n    return 0;\n}\n","copts":["-D_GNU_SOURCE=1","-D_REENTRANT"],"define":"HAVE_STRPBRK","if_true":1,"language":"c","linkopts":["-lm"],"name":"ac_cv_try_link_HAVE_STRPBRK","type":"link"}
��{"code":"#include <string.h>\nint main(void) {\n#ifndef strrchr\n    (void)strrchr;\n#endif\n    return 0;\n}\n","copts":["-D_GNU_SOURCE=1","-D_REENTRANT"],"define":"HAVE_STRRCHR","if_true":1,"language":"c","linkopts":["-lm"],"name":"ac_cv_try_link_HAVE_STRRCHR","type":"link"}
��{"code":"#include <string.h>\nint main(void) {\n#ifndef strstr\n    (void)strstr;\n#endif\n    return 0;\n}\n","copts":["-D_GNU_SOURCE=1","-D_REENTRANT"],"define":"HAVE_STRSTR","if_true":1,"language":"c","linkopts":["-lm"],"name":"ac_cv_try_link_HAVE_STRSTR","type":"link"}
��{"code":"#include <string.h>\nint main(void) {\n#ifndef strtok_r\n    (void)strtok_r;\n#endif\n    return 0;\n}\n","copts":["-D_GNU_SOURCE=1","-D_REENTRANT"],"define":"HAVE_STRTOK_R","if_true":1,"language":"c","linkopts":["-lm"],"name":"ac_cv_try_link_HAVE_STRTOK_R","type":"link"}
��{"code":"#include <strings.h>\nint main(void) {\n#ifndef bcopy\n    (void)bcopy;\n#endif\n    return 0;\n}\n","copts":["-D_GNU_SOURCE=1","-D_REENTRANT"],"define":"HAVE_BCOPY","if_true":1,"language":"c","linkopts":["-lm"],"name":"ac_cv_try_link_HAVE_BCOPY","type":"link"}
��{"code":"#include <strings.h>\nint main(void) {\n#ifndef index\n    (void)index;\n#endif\n    return 0;\n}\n","copts":["-D_GNU_SOURCE=1","-D_REENTRANT"],"define":"HAVE_INDEX","if_true":1,"language":"c","linkopts":["-lm"],"name":"ac_cv_try_link_HAVE_INDEX","type":"link"}
��{"code":"#include <strings.h>\nint main(void) {\n#ifndef rindex\n    (void)rindex;\n#endif\n    return 0;\n}\n","copts":["-D_GNU_SOURCE=1","-D_REENTRANT"],"define":"HAVE_RINDEX","if_true":1,"language":"c","linkopts":["-lm"],"name":"ac_cv_try_link_HAVE_RINDEX","type":"link"}
��{"code":"#include <wchar.h>\nint main(void) {\n#ifndef wcscmp\n    (void)wcscmp;\n#endif\n    return 0;\n}\n","copts":["-D_GNU_SOURCE=1","-D_REENTRANT"],"define":"HAVE_WCSCMP","if_true":1,"language":"c","linkopts":["-lm"],"name":"ac_cv_try_link_HAVE_WCSCMP","type":"link"}
��{"code":"#include <wchar.h>\nint main(void) {\n#ifndef wcsdup\n    (void)wcsdup;\n#endif\n    return 0;\n}\n","copts":["-D_GNU_SOURCE=1","-D_REENTRANT"],"define":"HAVE_WCSDUP","if_true":1,"language":"c","linkopts":["-lm"],"name":"ac_cv_try_link_HAVE_WCSDUP","type":"link"}
��{"code":"#include <wchar.h>\nint main(void) {\n#ifndef wcslcat\n    (void)wcslcat;\n#endif\n    return 0;\n}\n","copts":["-D_GNU_SOURCE=1","-D_REENTRANT"],"define":"HAVE_WCSLCAT","if_true":1,"language":"c","linkopts":["-lm"],"name":"ac_cv_try_link_HAVE_WCSLCAT","type":"link"}
��{"code":"#include <wchar.h>\nint main(void) {\n#ifndef wcslcpy\n    (void)wcslcpy;\n#endif\n    return 0;\n}\n","copts":["-D_GNU_SOURCE=1","-D_REENTRANT"],"define":"HAVE_WCSLCPY","if_true":1,"language":"c","linkopts":["-lm"],"name":"ac_cv_try_link_HAVE_WCSLCPY","type":"link"}
��{"code":"#include <wchar.h>\nint main(void) {\n#ifndef wcslen\n    (void)wcslen;\n#endif\n    return 0;\n}\n","copts":["-D_GNU_SOURCE=1","-D_REENTRANT"],"define":"HAVE_WCSLEN","if_true":1,"language":"c","linkopts":["-lm"],"name":"ac_cv_try_link_HAVE_WCSLEN","type":"link"}
��{"code":"#include <wchar.h>\nint main(void) {\n#ifndef wcsncmp\n    (void)wcsncmp;\n#endif\n    return 0;\n}\n","copts":["-D_GNU_SOURCE=1","-D_REENTRANT"],"define":"HAVE_WCSNCMP","if_true":1,"language":"c","linkopts":["-lm"],"name":"ac_cv_try_link_HAVE_WCSNCMP","type":"link"}
��{"code":"#include <wchar.h>\nint main(void) {\n#ifndef wcsnlen\n    (void)wcsnlen;\n#endif\n    return 0;\n}\n","copts":["-D_GNU_SOURCE=1","-D_REENTRANT"],"define":"HAVE_WCSNLEN","if_true":1,"language":"c","linkopts":["-lm"],"name":"ac_cv_try_link_HAVE_WCSNLEN","type":"link"}
��{"code":"#include <wchar.h>\nint main(void) {\n#ifndef wcsstr\n    (void)wcsstr;\n#endif\n    return 0;\n}\n","copts":["-D_GNU_SOURCE=1","-D_REENTRANT"],"define":"HAVE_WCSSTR","if_true":1,"language":"c","linkopts":["-lm"],"name":"ac_cv_try_link_HAVE_WCSSTR","type":"link"}
��{"code":"#include <wchar.h>\nint main(void) {\n#ifndef wcstol\n    (void)wcstol;\n#endif\n    return 0;\n}\n","copts":["-D_GNU_SOURCE=1","-D_REENTRANT"],"define":"HAVE_WCSTOL","if_true":1,"language":"c","linkopts":["-lm"],"name":"ac_cv_try_link_HAVE_WCSTOL","type":"link"}
��{"code":"#include <math.h>\nint main(void) { double d = 3.14159; return isinf(d); }\n","copts":["-D_GNU_SOURCE=1","-D_REENTRANT","-Wfloat-conversion","-Werror"],"define":"HAVE_ISINF","if_true":1,"language":"c","name":"ac_cv_try_link_HAVE_ISINF","type":"link"}
��{"code":"#include <math.h>\nint main(void) { float f = 3.14159f; return isinf(f); }\n","copts":["-D_GNU_SOURCE=1","-D_REENTRANT","-Wfloat-conversion","-Werror"],"define":"HAVE_ISINF_FLOAT_MACRO","if_true":1,"language":"c","name":"ac_cv_try_link_HAVE_ISINF_FLOAT_MACRO","type":"link"}
��{"code":"#include <math.h>\nint main(void) { float f = 3.14159f; return isinff(f); }\n","copts":["-D_GNU_SOURCE=1","-D_REENTRANT","-Wfloat-conversion","-Werror"],"define":"HAVE_ISINFF","if_true":1,"language":"c","name":"ac_cv_try_link_HAVE_ISINFF","type":"link"}
��{"code":"#include <math.h>\nint main(void) { double d = 3.14159; return isnan(d); }\n","copts":["-D_GNU_SOURCE=1","-D_REENTRANT","-Wfloat-conversion","-Werror"],"define":"HAVE_ISNAN","if_true":1,"language":"c","name":"ac_cv_try_link_HAVE_ISNAN","type":"link"}
��{"code":"#include <math.h>\nint main(void) { float f = 3.14159f; return isnan(f); }\n","copts":["-D_GNU_SOURCE=1","-D_REENTRANT","-Wfloat-conversion","-Werror"],"define":"HAVE_ISNAN_FLOAT_MACRO","if_true":1,"language":"c","name":"ac_cv_try_link_HAVE_ISNAN_FLOAT_MACRO","type":"link"}
��{"code":"#include <math.h>\nint main(void) { float f = 3.14159f; return isnanf(f); }\n","copts":["-D_GNU_SOURCE=1","-D_REENTRANT","-Wfloat-conversion","-Werror"],"define":"HAVE_ISNANF","if_true":1,"language":"c","name":"ac_cv_try_link_HAVE_ISNANF","type":"link"}
��{"code":"#include <unistd.h>\nint main(void) {\n#ifndef fdatasync\n    (void)fdatasync;\n#endif\n    return 0;\n}\n","copts":["-D_GNU_SOURCE=1","-D_REENTRANT"],"define":"HAVE_FDATASYNC","if_true":1,"language":"c","linkopts":["-lm"],"name":"ac_cv_try_link_HAVE_FDATASYNC","type":"link"}
��{"code":"#include <unistd.h>\nint main(void) {\n#ifndef gethostname\n    (void)gethostname;\n#endif\n    return 0;\n}\n","copts":["-D_GNU_SOURCE=1","-D_REENTRANT"],"define":"HAVE_GETHOSTNAME","if_true":1,"language":"c","linkopts":["-lm"],"name":"ac_cv_try_link_HAVE_GETHOSTNAME","type":"link"}
��{"code":"#include <unistd.h>\nint main(void) {\n#ifndef getpagesize\n    (void)getpagesize;\n#endif\n    return 0;\n}\n","copts":["-D_GNU_SOURCE=1","-D_REENTRANT"],"define":"HAVE_GETPAGESIZE","if_true":1,"language":"c","linkopts":["-lm"],"name":"ac_cv_try_link_HAVE_GETPAGESIZE","type":"link"}
��{"code":"#include <unistd.h>\nint main(void) {\n#ifndef getresgid\n    (void)getresgid;\n#endif\n    return 0;\n}\n","copts":["-D_GNU_SOURCE=1","-D_REENTRANT"],"define":"HAVE_GETRESGID","if_true":1,"language":"c","linkopts":["-lm"],"name":"ac_cv_try_link_HAVE_GETRESGID","type":"link"}
��{"code":"#include <unistd.h>\nint main(void) {\n#ifndef getresuid\n    (void)getresuid;\n#endif\n    return 0;\n}\n","copts":["-D_GNU_SOURCE=1","-D_REENTRANT"],"define":"HAVE_GETRESUID","if_true":1,"language":"c","linkopts":["-lm"],"name":"ac_cv_try_link_HAVE_GETRESUID","type":"link"}
��{"code":"#include <signal.h>\nint main(void) {\n#ifndef sigaction\n    (void)sigaction;\n#endif\n    return 0;\n}\n","copts":["-D_GNU_SOURCE=1","-D_REENTRANT"],"define":"HAVE_SIGACTION","if_true":1,"language":"c","linkopts":["-lm"],"name":"ac_cv_try_link_HAVE_SIGACTION","type":"link"}
��{"code":"#include <signal.h>\nint main(void) {\n#ifndef sigtimedwait\n    (void)sigtimedwait;\n#endif\n    return 0;\n}\n","copts":["-D_GNU_SOURCE=1","-D_REENTRANT"],"define":"HAVE_SIGTIMEDWAIT","if_true":1,"language":"c","linkopts":["-lm"],"name":"ac_cv_try_link_HAVE_SIGTIMEDWAIT","type":"link"}
��{"code":"#include <setjmp.h>\nint main(void) {\n#ifndef setjmp\n    (void)setjmp;\n#endif\n    return 0;\n}\n","copts":["-D_GNU_SOURCE=1","-D_REENTRANT"],"define":"HAVE_SETJMP","if_true":1,"language":"c","linkopts":["-lm"],"name":"ac_cv_try_link_HAVE_SETJMP","type":"link"}
��{"code":"#include <time.h>\nint main(void) {\n#ifndef nanosleep\n    (void)nanosleep;\n#endif\n    return 0;\n}\n","copts":["-D_GNU_SOURCE=1","-D_REENTRANT"],"define":"HAVE_NANOSLEEP","if_true":1,"language":"c","linkopts":["-lm"],"name":"ac_cv_try_link_HAVE_NANOSLEEP","type":"link"}
��{"code":"#include <time.h>\nint main(void) {\n#ifndef gmtime_r\n    (void)gmtime_r;\n#endif\n    return 0;\n}\n","copts":["-D_GNU_SOURCE=1","-D_REENTRANT"],"define":"HAVE_GMTIME_R","if_true":1,"language":"c","linkopts":["-lm"],"name":"ac_cv_try_link_HAVE_GMTIME_R","type":"link"}
��{"code":"#include <time.h>\nint main(void) {\n#ifndef localtime_r\n    (void)localtime_r;\n#endif\n    return 0;\n}\n","copts":["-D_GNU_SOURCE=1","-D_REENTRANT"],"define":"HAVE_LOCALTIME_R","if_true":1,"language":"c","linkopts":["-lm"],"name":"ac_cv_try_link_HAVE_LOCALTIME_R","type":"link"}
��{"code":"#include <langinfo.h>\nint main(void) {\n#ifndef nl_langinfo\n    (void)nl_langinfo;\n#endif\n    return 0;\n}\n","copts":["-D_GNU_SOURCE=1","-D_REENTRANT"],"define":"HAVE_NL_LANGINFO","if_true":1,"language":"c","linkopts":["-lm"],"name":"ac_cv_try_link_HAVE_NL_LANGINFO","type":"link"}
��{"code":"#include <unistd.h>\nint main(void) {\n#ifndef sysconf\n    (void)sysconf;\n#endif\n    return 0;\n}\n","copts":["-D_GNU_SOURCE=1","-D_REENTRANT"],"define":"HAVE_SYSCONF","if_true":1,"language":"c","linkopts":["-lm"],"name":"ac_cv_try_link_HAVE_SYSCONF","type":"link"}
��{"code":"#include <sys/types.h>\n#include <sys/sysctl.h>\nint main(void) {\n#ifndef sysctlbyname\n    (void)sysctlbyname;\n#endif\n    return 0;\n}\n","copts":["-D_GNU_SOURCE=1","-D_REENTRANT"],"define":"HAVE_SYSCTLBYNAME","if_true":1,"language":"c","linkopts":["-lm"],"name":"ac_cv_try_link_HAVE_SYSCTLBYNAME","type":"link"}
��{"code":"#include <sys/auxv.h>\nint main(void) {\n#ifndef getauxval\n    (void)getauxval;\n#endif\n    return 0;\n}\n","copts":["-D_GNU_SOURCE=1","-D_REENTRANT"],"define":"HAVE_GETAUXVAL","if_true":1,"language":"c","linkopts":["-lm"],"name":"ac_cv_try_link_HAVE_GETAUXVAL","type":"link"}
��{"code":"#include <sys/auxv.h>\nint main(void) {\n#ifndef elf_aux_info\n    (void)elf_aux_info;\n#endif\n    return 0;\n}\n","copts":["-D_GNU_SOURCE=1","-D_REENTRANT"],"define":"HAVE_ELF_AUX_INFO","if_true":1,"language":"c","linkopts":["-lm"],"name":"ac_cv_try_link_HAVE_ELF_AUX_INFO","type":"link"}
��{"code":"#include <poll.h>\nint main(void) {\n#ifndef ppoll\n    (void)ppoll;\n#endif\n    return 0;\n}\n","copts":["-D_GNU_SOURCE=1","-D_REENTRANT"],"define":"HAVE_PPOLL","if_true":1,"language":"c","linkopts":["-lm"],"name":"ac_cv_try_link_HAVE_PPOLL","type":"link"}
��{"code":"#include <sys/mman.h>\nint main(void) {\n#ifndef memfd_create\n    (void)memfd_create;\n#endif\n    return 0;\n}\n","copts":["-D_GNU_SOURCE=1","-D_REENTRANT"],"define":"HAVE_MEMFD_CREATE","if_true":1,"language":"c","linkopts":["-lm"],"name":"ac_cv_try_link_HAVE_MEMFD_CREATE","type":"link"}
��{"code":"#include <fcntl.h>\nint main(void) {\n#ifndef posix_fallocate\n    (void)posix_fallocate;\n#endif\n    return 0;\n}\n","copts":["-D_GNU_SOURCE=1","-D_REENTRANT"],"define":"HAVE_POSIX_FALLOCATE","if_true":1,"language":"c","linkopts":["-lm"],"name":"ac_cv_try_link_HAVE_POSIX_FALLOCATE","type":"link"}
��{"code":"#include <spawn.h>\nint main(void) {\n#ifndef posix_spawn_file_actions_addchdir\n    (void)posix_spawn_file_actions_addchdir;\n#endif\n    return 0;\n}\n","copts":["-D_GNU_SOURCE=1","-D_REENTRANT"],"define":"HAVE_POSIX_SPAWN_FILE_ACTIONS_ADDCHDIR","if_true":1,"language":"c","linkopts":["-lm"],"name":"ac_cv_try_link_HAVE_POSIX_SPAWN_FILE_ACTIONS_ADDCHDIR","type":"link"}
��{"code":"#include <spawn.h>\nint main(void) {\n#ifndef posix_spawn_file_actions_addchdir_np\n    (void)posix_spawn_file_actions_addchdir_np;\n#endif\n    return 0;\n}\n","copts":["-D_GNU_SOURCE=1","-D_REENTRANT"],"define":"HAVE_POSIX_SPAWN_FILE_ACTIONS_ADDCHDIR_NP","if_true":1,"language":"c","linkopts":["-lm"],"name":"ac_cv_try_link_HAVE_POSIX_SPAWN_FILE_ACTIONS_ADDCHDIR_NP","type":"link"}
��{"code":"#define LIBICONV_PLUG 1\n#include <stddef.h>\n#include <iconv.h>\nint main(void) { return !iconv_open(NULL, NULL); }\n","copts":["-D_GNU_SOURCE=1","-D_REENTRANT"],"define":"HAVE_ICONV","if_false":0,"if_true":1,"language":"c","name":"ac_cv_try_link_HAVE_ICONV","type":"link"}
��{"code":"\n#include <signal.h>\n#include <stddef.h>\n\nint main(void) {\n    static struct sigaction s;\n    (void)s;\n    return offsetof(struct sigaction, sa_sigaction);\n}\n","copts":["-D_GNU_SOURCE=1","-D_REENTRANT"],"define":"HAVE_SA_SIGACTION","language":"c","name":"ac_cv_member_struct_sigaction_sa_sigaction","type":"member"}
��{"code":"\n#include <sys/stat.h>\n#include <stddef.h>\n\nint main(void) {\n    static struct stat s;\n    (void)s;\n    return offsetof(struct stat, st_mtim);\n}\n","copts":["-D_GNU_SOURCE=1","-D_REENTRANT"],"define":"HAVE_ST_MTIM","language":"c","name":"ac_cv_member_struct_stat_st_mtim","type":"member"}
��{"code":"#include <alloca.h>\n","copts":["-D_GNU_SOURCE=1","-D_REENTRANT"],"define":"HAVE_ALLOCA_H","language":"c","name":"ac_cv_header_alloca_h","type":"compile"}��	SDL3_CONFIG_CHECKS_LINUXj��2��
��{"code":"#include <pthread.h>\nint main(void) { pthread_attr_t type; pthread_attr_init(&type); return 0; }\n","copts":["-D_GNU_SOURCE=1","-D_REENTRANT","-pthread"],"define":"HAVE_PTHREADS","if_true":1,"language":"c","linkopts":["-pthread"],"name":"ac_cv_try_link_HAVE_PTHREADS","type":"link"}
��{"code":"","define":"SDL_THREAD_PTHREAD","define_value":"1","define_value_fail":"1","language":"c","name":"ac_cv_define_SDL_THREAD_PTHREAD","requires":["HAVE_PTHREADS"],"type":"define"}
��{"code":"#include <pthread.h>\nint main(void) { pthread_mutexattr_t attr; pthread_mutexattr_settype(&attr, PTHREAD_MUTEX_RECURSIVE); return 0; }\n","copts":["-D_GNU_SOURCE=1","-D_REENTRANT","-pthread"],"define":"SDL_THREAD_PTHREAD_RECURSIVE_MUTEX","if_true":1,"language":"c","linkopts":["-pthread"],"name":"ac_cv_try_link_SDL_THREAD_PTHREAD_RECURSIVE_MUTEX","requires":["HAVE_PTHREADS"],"type":"link"}
��{"code":"#include <pthread.h>\nint main(void) { pthread_mutexattr_t attr; pthread_mutexattr_settype(&attr, PTHREAD_MUTEX_RECURSIVE_NP); return 0; }\n","copts":["-D_GNU_SOURCE=1","-D_REENTRANT","-pthread"],"define":"SDL_THREAD_PTHREAD_RECURSIVE_MUTEX_NP","if_true":1,"language":"c","linkopts":["-pthread"],"name":"ac_cv_try_link_SDL_THREAD_PTHREAD_RECURSIVE_MUTEX_NP","requires":["HAVE_PTHREADS","!SDL_THREAD_PTHREAD_RECURSIVE_MUTEX"],"type":"link"}
��{"code":"#include <pthread.h>\n#include <semaphore.h>\nint main(void) { return 0; }\n","copts":["-D_GNU_SOURCE=1","-D_REENTRANT","-pthread"],"define":"HAVE_PTHREADS_SEM","if_true":1,"language":"c","linkopts":["-pthread"],"name":"ac_cv_try_link_HAVE_PTHREADS_SEM","requires":["HAVE_PTHREADS"],"type":"link"}
��{"code":"#include <pthread.h>\n#include <semaphore.h>\n#include <time.h>\nint main(void) { sem_clockwait(NULL, CLOCK_MONOTONIC, NULL); return 0; }\n","copts":["-D_GNU_SOURCE=1","-D_REENTRANT","-pthread"],"define":"HAVE_SEM_CLOCKWAIT","if_true":1,"language":"c","linkopts":["-pthread"],"name":"ac_cv_try_link_HAVE_SEM_CLOCKWAIT","requires":["HAVE_PTHREADS_SEM"],"type":"link"}
��{"code":"#include <pthread.h>\n#include <semaphore.h>\n#include <time.h>\nint main(void) { sem_clockwait_np(NULL, CLOCK_MONOTONIC, 0, NULL, NULL); return 0; }\n","copts":["-D_GNU_SOURCE=1","-D_REENTRANT","-pthread"],"define":"HAVE_SEM_CLOCKWAIT_NP","if_true":1,"language":"c","linkopts":["-pthread"],"name":"ac_cv_try_link_HAVE_SEM_CLOCKWAIT_NP","requires":["HAVE_PTHREADS_SEM","!HAVE_SEM_CLOCKWAIT"],"type":"link"}
��{"code":"#include <pthread.h>\n#include <semaphore.h>\nint main(void) { sem_timedwait(NULL, NULL); return 0; }\n","copts":["-D_GNU_SOURCE=1","-D_REENTRANT","-pthread"],"define":"HAVE_SEM_TIMEDWAIT","if_true":1,"language":"c","linkopts":["-pthread"],"name":"ac_cv_try_link_HAVE_SEM_TIMEDWAIT","requires":["HAVE_PTHREADS_SEM","!HAVE_SEM_CLOCKWAIT","!HAVE_SEM_CLOCKWAIT_NP"],"type":"link"}
��{"code":"#include <pthread.h>\n","copts":["-D_GNU_SOURCE=1","-D_REENTRANT"],"define":"HAVE_PTHREAD_H","language":"c","name":"ac_cv_header_pthread_h","type":"compile"}
��{"code":"#include <pthread_np.h>\n","copts":["-D_GNU_SOURCE=1","-D_REENTRANT"],"define":"HAVE_PTHREAD_NP_H","language":"c","name":"ac_cv_header_pthread_np_h","type":"compile"}
��{"code":"#include <pthread.h>\nint main(void) {\n#ifndef pthread_condattr_setclock\n    (void)pthread_condattr_setclock;\n#endif\n    return 0;\n}\n","copts":["-D_GNU_SOURCE=1","-D_REENTRANT","-pthread"],"define":"HAVE_PTHREAD_CONDATTR_SETCLOCK","if_true":1,"language":"c","linkopts":["-pthread"],"name":"ac_cv_try_link_HAVE_PTHREAD_CONDATTR_SETCLOCK","requires":["HAVE_PTHREAD_H"],"type":"link"}
��{"code":"#include <pthread.h>\nint main(void) {\n#ifdef __APPLE__\n    pthread_setname_np(\"\");\n#else\n    pthread_setname_np(pthread_self(), \"\");\n#endif\n    return 0; }\n","copts":["-D_GNU_SOURCE=1","-D_REENTRANT","-pthread"],"define":"HAVE_PTHREAD_SETNAME_NP","if_true":1,"language":"c","linkopts":["-pthread"],"name":"ac_cv_try_link_HAVE_PTHREAD_SETNAME_NP","requires":["HAVE_PTHREAD_H"],"type":"link"}
��{"code":"#include <pthread.h>\n#include <pthread_np.h>\n\nint main(void) {\n#ifndef pthread_set_name_np\n#ifdef __cplusplus\n  (void) pthread_set_name_np;\n#else\n  (void) pthread_set_name_np;\n#endif\n#endif\n\n  ;\n  return 0;\n}\n","copts":["-D_GNU_SOURCE=1","-D_REENTRANT"],"define":"HAVE_PTHREAD_SET_NAME_NP","define_value":1,"define_value_fail":0,"language":"c","name":"ac_cv_have_decl_pthread_set_name_np","requires":["HAVE_PTHREAD_NP_H"],"type":"decl"}
��{"code":"#include <linux/input.h>\n#ifndef EVIOCGNAME\n#error EVIOCGNAME() ioctl not available\n#endif\nint main(void) { return 0; }\n","copts":["-D_GNU_SOURCE=1","-D_REENTRANT"],"define":"HAVE_LINUX_INPUT_H","if_true":1,"language":"c","name":"ac_cv_try_link_HAVE_LINUX_INPUT_H","type":"link"}
��{"code":"#include <linux/kd.h>\n#include <linux/keyboard.h>\n#include <sys/ioctl.h>\nint main(void) {\n    struct kbentry kbe;\n    kbe.kb_table = KG_CTRL;\n    ioctl(0, KDGKBENT, &kbe);\n    return 0; }\n","copts":["-D_GNU_SOURCE=1","-D_REENTRANT"],"define":"HAVE_INPUT_KD","if_true":1,"language":"c","name":"ac_cv_try_link_HAVE_INPUT_KD","type":"link"}
��{"code":"#include <linux/videodev2.h>\nint main(void) { return 0; }\n","copts":["-D_GNU_SOURCE=1","-D_REENTRANT"],"define":"HAVE_LINUX_VIDEODEV2_H","if_true":1,"language":"c","name":"ac_cv_try_link_HAVE_LINUX_VIDEODEV2_H","type":"link"}
��{"code":"","define":"SDL_INPUT_LINUXEV","define_value":"1","define_value_fail":"1","language":"c","name":"ac_cv_define_SDL_INPUT_LINUXEV","requires":["HAVE_LINUX_INPUT_H"],"type":"define"}
��{"code":"","define":"SDL_INPUT_LINUXKD","define_value":"1","define_value_fail":"1","language":"c","name":"ac_cv_define_SDL_INPUT_LINUXKD","requires":["HAVE_INPUT_KD"],"type":"define"}
��{"code":"","define":"SDL_HAPTIC_LINUX","define_value":"1","define_value_fail":"1","language":"c","name":"ac_cv_define_SDL_HAPTIC_LINUX","requires":["HAVE_LINUX_INPUT_H"],"type":"define"}
��{"code":"","define":"SDL_JOYSTICK_LINUX","define_value":"1","define_value_fail":"1","language":"c","name":"ac_cv_define_SDL_JOYSTICK_LINUX","requires":["HAVE_LINUX_INPUT_H"],"type":"define"}
��{"code":"","define":"SDL_CAMERA_DRIVER_V4L2","define_value":"1","define_value_fail":"1","language":"c","name":"ac_cv_define_SDL_CAMERA_DRIVER_V4L2","requires":["HAVE_LINUX_VIDEODEV2_H"],"type":"define"}
��{"code":"#include <sys/inotify.h>\n","copts":["-D_GNU_SOURCE=1","-D_REENTRANT"],"define":"HAVE_SYS_INOTIFY_H","language":"c","name":"ac_cv_header_sys_inotify_h","type":"compile"}
��{"code":"#include <sys/inotify.h>\nint main(void) {\n#ifndef inotify_init\n    (void)inotify_init;\n#endif\n    return 0;\n}\n","copts":["-D_GNU_SOURCE=1","-D_REENTRANT"],"define":"HAVE_INOTIFY_INIT","if_true":1,"language":"c","linkopts":["-lm"],"name":"ac_cv_try_link_HAVE_INOTIFY_INIT","type":"link"}
��{"code":"#include <sys/inotify.h>\nint main(void) {\n#ifndef inotify_init1\n    (void)inotify_init1;\n#endif\n    return 0;\n}\n","copts":["-D_GNU_SOURCE=1","-D_REENTRANT"],"define":"HAVE_INOTIFY_INIT1","if_true":1,"language":"c","linkopts":["-lm"],"name":"ac_cv_try_link_HAVE_INOTIFY_INIT1","type":"link"}
��{"code":"","define":"HAVE_INOTIFY","define_value":"1","define_value_fail":"1","language":"c","name":"ac_cv_define_HAVE_INOTIFY","requires":["HAVE_SYS_INOTIFY_H","HAVE_INOTIFY_INIT"],"type":"define"}
��{"code":"#include <dlfcn.h>\nint main(void) {\n#ifndef dlopen\n    (void)dlopen;\n#endif\n    return 0;\n}\n","copts":["-D_GNU_SOURCE=1","-D_REENTRANT"],"define":"HAVE_DLOPEN","if_true":1,"language":"c","linkopts":["-lm"],"name":"ac_cv_try_link_HAVE_DLOPEN","type":"link"}
��{"code":"","define":"SDL_LOADSO_DLOPEN","define_value":"1","define_value_fail":"1","language":"c","name":"ac_cv_define_SDL_LOADSO_DLOPEN","requires":["HAVE_DLOPEN"],"type":"define"}
��{"code":"","define":"DYNAPI_NEEDS_DLOPEN","define_value":"1","define_value_fail":"1","language":"c","name":"ac_cv_define_DYNAPI_NEEDS_DLOPEN","type":"define"}
��{"code":"#include <fcntl.h>\nint flag = O_CLOEXEC;\nint main(void) { return 0; }\n","copts":["-D_GNU_SOURCE=1","-D_REENTRANT"],"define":"HAVE_O_CLOEXEC","if_true":1,"language":"c","name":"ac_cv_try_link_HAVE_O_CLOEXEC","type":"link"}
�
�
{"code":["#define clock_gettime innocuous_clock_gettime\n#include <limits.h>\n#undef clock_gettime\n#ifdef __cplusplus\nextern \"C\"\n#endif\n#if defined _MSC_VER\nint clock_gettime (void);\n#else\nchar clock_gettime (void);\n#endif\n#if defined __stub_clock_gettime || defined __stub___clock_gettime\nchoke me\n#endif\nint main(void) { return clock_gettime(); }\n","#if !defined _MSC_VER\n#error \"header-inline function probe: Microsoft CRT only\"\n#endif\n#include <stdio.h>\n#include <stdlib.h>\n#include <stddef.h>\n#include <string.h>\n#include <inttypes.h>\n#include <stdint.h>\n#if defined __has_include\n# if __has_include(<strings.h>)\n#  include <strings.h>\n# endif\n# if __has_include(<sys/types.h>)\n#  include <sys/types.h>\n# endif\n# if __has_include(<sys/stat.h>)\n#  include <sys/stat.h>\n# endif\n# if __has_include(<unistd.h>)\n#  include <unistd.h>\n# endif\n#else\n# include <strings.h>\n# include <sys/types.h>\n# include <sys/stat.h>\n# include <unistd.h>\n#endif\n\nstatic void (*volatile rules_cc_autoconf_func_addr)(void);\nint main(void) {\n    rules_cc_autoconf_func_addr = (void (*)(void)) &clock_gettime;\n    return 0;\n}\n"],"copts":["-D_GNU_SOURCE=1","-D_REENTRANT"],"define":"HAVE_CLOCK_GETTIME","language":"c","name":"ac_cv_func_clock_gettime","type":"function"}
��{"code":"#include <spawn.h>\n#include <unistd.h>\nint main(void) {\n    int pipes[2];\n    int pid;\n    const char *args[] = { \"/bin/false\", NULL };\n    const char *env[] = { NULL };\n    pipe(pipes);\n    posix_spawnattr_t attr;\n    posix_spawn_file_actions_t fa;\n    posix_spawnattr_init(&attr);\n    posix_spawn_file_actions_init(&fa);\n    posix_spawn_file_actions_addclose(&fa, pipes[0]);\n    posix_spawn_file_actions_adddup2(&fa, pipes[1], STDOUT_FILENO);\n    posix_spawn(&pid, args[0], &fa, &attr, (char *const *)args, (char *const *)env);\n    posix_spawnp(&pid, args[0], &fa, &attr, (char *const *)args, (char *const *)env);\n    posix_spawn_file_actions_destroy(&fa);\n    posix_spawnattr_destroy(&attr);\n    return 0; }\n","copts":["-D_GNU_SOURCE=1","-D_REENTRANT"],"define":"HAVE_POSIX_SPAWN","if_false":0,"if_true":1,"language":"c","name":"ac_cv_try_link_HAVE_POSIX_SPAWN","type":"link"}
��{"code":"#include <unistd.h>\nint main(void) {\n#ifndef vfork\n    (void)vfork;\n#endif\n    return 0;\n}\n","copts":["-D_GNU_SOURCE=1","-D_REENTRANT"],"define":"HAVE_VFORK","if_true":1,"language":"c","linkopts":["-lm"],"name":"ac_cv_try_link_HAVE_VFORK","type":"link"}
��{"code":"","define":"SDL_PROCESS_POSIX","define_value":"1","define_value_fail":"1","language":"c","name":"ac_cv_define_SDL_PROCESS_POSIX","requires":["HAVE_POSIX_SPAWN","HAVE_VFORK"],"type":"define"}
��{"code":"","define":"SDL_AUDIO_DRIVER_ALSA","define_value":"1","define_value_fail":"1","language":"c","name":"ac_cv_define_SDL_AUDIO_DRIVER_ALSA","type":"define"}
��{"code":"","define":"SDL_AUDIO_DRIVER_ALSA_DYNAMIC","define_value":"\"libasound.so.2\"","define_value_fail":"\"libasound.so.2\"","language":"c","name":"ac_cv_define_SDL_AUDIO_DRIVER_ALSA_DYNAMIC","type":"define"}
��{"code":"","define":"SDL_AUDIO_DRIVER_DISK","define_value":"1","define_value_fail":"1","language":"c","name":"ac_cv_define_SDL_AUDIO_DRIVER_DISK","type":"define"}
��{"code":"","define":"SDL_AUDIO_DRIVER_DUMMY","define_value":"1","define_value_fail":"1","language":"c","name":"ac_cv_define_SDL_AUDIO_DRIVER_DUMMY","type":"define"}
��{"code":"","define":"SDL_JOYSTICK_HIDAPI","define_value":"1","define_value_fail":"1","language":"c","name":"ac_cv_define_SDL_JOYSTICK_HIDAPI","type":"define"}
��{"code":"","define":"SDL_JOYSTICK_VIRTUAL","define_value":"1","define_value_fail":"1","language":"c","name":"ac_cv_define_SDL_JOYSTICK_VIRTUAL","type":"define"}
��{"code":"","define":"SDL_SENSOR_DUMMY","define_value":"1","define_value_fail":"1","language":"c","name":"ac_cv_define_SDL_SENSOR_DUMMY","type":"define"}
��{"code":"","define":"SDL_POWER_LINUX","define_value":"1","define_value_fail":"1","language":"c","name":"ac_cv_define_SDL_POWER_LINUX","type":"define"}
��{"code":"","define":"SDL_FILESYSTEM_UNIX","define_value":"1","define_value_fail":"1","language":"c","name":"ac_cv_define_SDL_FILESYSTEM_UNIX","type":"define"}
��{"code":"","define":"SDL_STORAGE_STEAM","define_value":"1","define_value_fail":"1","language":"c","name":"ac_cv_define_SDL_STORAGE_STEAM","type":"define"}
��{"code":"","define":"SDL_FSOPS_POSIX","define_value":"1","define_value_fail":"1","language":"c","name":"ac_cv_define_SDL_FSOPS_POSIX","type":"define"}
��{"code":"","define":"SDL_TIME_UNIX","define_value":"1","define_value_fail":"1","language":"c","name":"ac_cv_define_SDL_TIME_UNIX","type":"define"}
��{"code":"","define":"SDL_TIMER_UNIX","define_value":"1","define_value_fail":"1","language":"c","name":"ac_cv_define_SDL_TIMER_UNIX","type":"define"}
��{"code":"","define":"SDL_CAMERA_DRIVER_DUMMY","define_value":"1","define_value_fail":"1","language":"c","name":"ac_cv_define_SDL_CAMERA_DRIVER_DUMMY","type":"define"}
��{"code":"","define":"SDL_VIDEO_DRIVER_DUMMY","define_value":"1","define_value_fail":"1","language":"c","name":"ac_cv_define_SDL_VIDEO_DRIVER_DUMMY","type":"define"}
��{"code":"","define":"SDL_VIDEO_DRIVER_OFFSCREEN","define_value":"1","define_value_fail":"1","language":"c","name":"ac_cv_define_SDL_VIDEO_DRIVER_OFFSCREEN","type":"define"}
��{"code":"","define":"SDL_VIDEO_OPENGL","define_value":"1","define_value_fail":"1","language":"c","name":"ac_cv_define_SDL_VIDEO_OPENGL","type":"define"}
��{"code":"","define":"SDL_VIDEO_OPENGL_EGL","define_value":"1","define_value_fail":"1","language":"c","name":"ac_cv_define_SDL_VIDEO_OPENGL_EGL","type":"define"}
��{"code":"","define":"SDL_VIDEO_OPENGL_ES2","define_value":"1","define_value_fail":"1","language":"c","name":"ac_cv_define_SDL_VIDEO_OPENGL_ES2","type":"define"}
��{"code":"","define":"SDL_VIDEO_RENDER_OGL","define_value":"1","define_value_fail":"1","language":"c","name":"ac_cv_define_SDL_VIDEO_RENDER_OGL","type":"define"}
��{"code":"","define":"SDL_VIDEO_RENDER_OGL_ES2","define_value":"1","define_value_fail":"1","language":"c","name":"ac_cv_define_SDL_VIDEO_RENDER_OGL_ES2","type":"define"}
��{"code":"","define":"SDL_VIDEO_VULKAN","define_value":"1","define_value_fail":"1","language":"c","name":"ac_cv_define_SDL_VIDEO_VULKAN","type":"define"}
��{"code":"","define":"SDL_VIDEO_RENDER_VULKAN","define_value":"1","define_value_fail":"1","language":"c","name":"ac_cv_define_SDL_VIDEO_RENDER_VULKAN","type":"define"}
��{"code":"","define":"SDL_GPU_VULKAN","define_value":"1","define_value_fail":"1","language":"c","name":"ac_cv_define_SDL_GPU_VULKAN","type":"define"}
��{"code":"","define":"SDL_VIDEO_RENDER_GPU","define_value":"1","define_value_fail":"1","language":"c","name":"ac_cv_define_SDL_VIDEO_RENDER_GPU","type":"define"}
��{"code":"","define":"SDL_VIDEO_DRIVER_X11","define_value":"1","define_value_fail":"1","language":"c","name":"ac_cv_define_SDL_VIDEO_DRIVER_X11","type":"define"}
��{"code":"","define":"SDL_VIDEO_DRIVER_X11_DYNAMIC","define_value":"\"libX11.so.6\"","define_value_fail":"\"libX11.so.6\"","language":"c","name":"ac_cv_define_SDL_VIDEO_DRIVER_X11_DYNAMIC","type":"define"}
��{"code":"","define":"SDL_VIDEO_DRIVER_X11_DYNAMIC_XCURSOR","define_value":"\"libXcursor.so.1\"","define_value_fail":"\"libXcursor.so.1\"","language":"c","name":"ac_cv_define_SDL_VIDEO_DRIVER_X11_DYNAMIC_XCURSOR","type":"define"}
��{"code":"","define":"SDL_VIDEO_DRIVER_X11_DYNAMIC_XEXT","define_value":"\"libXext.so.6\"","define_value_fail":"\"libXext.so.6\"","language":"c","name":"ac_cv_define_SDL_VIDEO_DRIVER_X11_DYNAMIC_XEXT","type":"define"}
��{"code":"","define":"SDL_VIDEO_DRIVER_X11_DYNAMIC_XFIXES","define_value":"\"libXfixes.so.3\"","define_value_fail":"\"libXfixes.so.3\"","language":"c","name":"ac_cv_define_SDL_VIDEO_DRIVER_X11_DYNAMIC_XFIXES","type":"define"}
��{"code":"","define":"SDL_VIDEO_DRIVER_X11_DYNAMIC_XINPUT2","define_value":"\"libXi.so.6\"","define_value_fail":"\"libXi.so.6\"","language":"c","name":"ac_cv_define_SDL_VIDEO_DRIVER_X11_DYNAMIC_XINPUT2","type":"define"}
��{"code":"","define":"SDL_VIDEO_DRIVER_X11_DYNAMIC_XRANDR","define_value":"\"libXrandr.so.2\"","define_value_fail":"\"libXrandr.so.2\"","language":"c","name":"ac_cv_define_SDL_VIDEO_DRIVER_X11_DYNAMIC_XRANDR","type":"define"}
��{"code":"","define":"SDL_VIDEO_DRIVER_X11_HAS_XKBLIB","define_value":"1","define_value_fail":"1","language":"c","name":"ac_cv_define_SDL_VIDEO_DRIVER_X11_HAS_XKBLIB","type":"define"}
��{"code":"","define":"SDL_VIDEO_DRIVER_X11_SUPPORTS_GENERIC_EVENTS","define_value":"1","define_value_fail":"1","language":"c","name":"ac_cv_define_SDL_VIDEO_DRIVER_X11_SUPPORTS_GENERIC_EVENTS","type":"define"}
��{"code":"","define":"SDL_VIDEO_DRIVER_X11_XCURSOR","define_value":"1","define_value_fail":"1","language":"c","name":"ac_cv_define_SDL_VIDEO_DRIVER_X11_XCURSOR","type":"define"}
��{"code":"","define":"SDL_VIDEO_DRIVER_X11_XDBE","define_value":"1","define_value_fail":"1","language":"c","name":"ac_cv_define_SDL_VIDEO_DRIVER_X11_XDBE","type":"define"}
��{"code":"","define":"SDL_VIDEO_DRIVER_X11_XFIXES","define_value":"1","define_value_fail":"1","language":"c","name":"ac_cv_define_SDL_VIDEO_DRIVER_X11_XFIXES","type":"define"}
��{"code":"","define":"SDL_VIDEO_DRIVER_X11_XINPUT2","define_value":"1","define_value_fail":"1","language":"c","name":"ac_cv_define_SDL_VIDEO_DRIVER_X11_XINPUT2","type":"define"}
��{"code":"","define":"SDL_VIDEO_DRIVER_X11_XINPUT2_SUPPORTS_GESTURE","define_value":"1","define_value_fail":"1","language":"c","name":"ac_cv_define_SDL_VIDEO_DRIVER_X11_XINPUT2_SUPPORTS_GESTURE","type":"define"}
��{"code":"","define":"SDL_VIDEO_DRIVER_X11_XINPUT2_SUPPORTS_MULTITOUCH","define_value":"1","define_value_fail":"1","language":"c","name":"ac_cv_define_SDL_VIDEO_DRIVER_X11_XINPUT2_SUPPORTS_MULTITOUCH","type":"define"}
��{"code":"","define":"SDL_VIDEO_DRIVER_X11_XINPUT2_SUPPORTS_SCROLLINFO","define_value":"1","define_value_fail":"1","language":"c","name":"ac_cv_define_SDL_VIDEO_DRIVER_X11_XINPUT2_SUPPORTS_SCROLLINFO","type":"define"}
��{"code":"","define":"SDL_VIDEO_DRIVER_X11_XRANDR","define_value":"1","define_value_fail":"1","language":"c","name":"ac_cv_define_SDL_VIDEO_DRIVER_X11_XRANDR","type":"define"}
��{"code":"","define":"SDL_VIDEO_DRIVER_X11_XSHAPE","define_value":"1","define_value_fail":"1","language":"c","name":"ac_cv_define_SDL_VIDEO_DRIVER_X11_XSHAPE","type":"define"}
��{"code":"","define":"SDL_VIDEO_DRIVER_X11_XSYNC","define_value":"1","define_value_fail":"1","language":"c","name":"ac_cv_define_SDL_VIDEO_DRIVER_X11_XSYNC","type":"define"}
��{"code":"","define":"SDL_VIDEO_DRIVER_WAYLAND","define_value":"1","define_value_fail":"1","language":"c","name":"ac_cv_define_SDL_VIDEO_DRIVER_WAYLAND","type":"define"}
��{"code":"","define":"SDL_VIDEO_DRIVER_WAYLAND_DYNAMIC","define_value":"\"libwayland-client.so.0\"","define_value_fail":"\"libwayland-client.so.0\"","language":"c","name":"ac_cv_define_SDL_VIDEO_DRIVER_WAYLAND_DYNAMIC","type":"define"}
��{"code":"","define":"SDL_VIDEO_DRIVER_WAYLAND_DYNAMIC_CURSOR","define_value":"\"libwayland-cursor.so.0\"","define_value_fail":"\"libwayland-cursor.so.0\"","language":"c","name":"ac_cv_define_SDL_VIDEO_DRIVER_WAYLAND_DYNAMIC_CURSOR","type":"define"}
��{"code":"","define":"SDL_VIDEO_DRIVER_WAYLAND_DYNAMIC_EGL","define_value":"\"libwayland-egl.so.1\"","define_value_fail":"\"libwayland-egl.so.1\"","language":"c","name":"ac_cv_define_SDL_VIDEO_DRIVER_WAYLAND_DYNAMIC_EGL","type":"define"}
��{"code":"","define":"SDL_VIDEO_DRIVER_WAYLAND_DYNAMIC_XKBCOMMON","define_value":"\"libxkbcommon.so.0\"","define_value_fail":"\"libxkbcommon.so.0\"","language":"c","name":"ac_cv_define_SDL_VIDEO_DRIVER_WAYLAND_DYNAMIC_XKBCOMMON","type":"define"}�Feature checks for SDL's Linux build configuration header.

SDL supplies hand-written headers for Windows and Apple platforms, and
generates the Linux header with CMake. These checks do the same work with
rules_cc_autoconf, against the toolchain and the sysroot that Bazel uses.
Each group links to the CMake lines that it copies.

The file has two kinds of entry:

  * checks, wherever CMake examines the system. CMake's check_symbol_exists
    and check_c_source_compiles build and link an executable, and these
    checks do the same;
  * fixed AC_DEFINEs, where CMake's answer follows from a build option or
    from a dependency in MODULE.bazel. The checks cannot see the X11,
    Wayland, xkbcommon and ALSA modules, so this file sets those values.
    Where a macro decides which symbols SDL demands at runtime, use the
    oldest library version that SDL supports, not the minimum version in
    MODULE.bazel.

A template entry with no check becomes `/* #undef NAME */`, and autoconf_hdr
drops a check that has no template entry. Neither case gives a warning.

To compare the generated header with SDL's own configure step, use a Linux
machine that has the X11, Wayland, xkbcommon, ALSA, GL and EGL development
packages:

    cmake -S SDL3-<version> -B build -DCMAKE_BUILD_TYPE=Release       -DSDL_SHARED=OFF -DSDL_STATIC=ON -DSDL_TESTS=OFF -DSDL_EXAMPLES=OFF       -DSDL_TEST_LIBRARY=OFF -DSDL_INSTALL=OFF       -DSDL_ALSA=ON -DSDL_PULSEAUDIO=OFF -DSDL_PIPEWIRE=OFF -DSDL_JACK=OFF       -DSDL_SNDIO=OFF -DSDL_OSS=OFF -DSDL_X11=ON -DSDL_X11_XSCRNSAVER=OFF       -DSDL_X11_XTEST=OFF -DSDL_FRIBIDI=OFF -DSDL_LIBTHAI=OFF -DSDL_WAYLAND=ON       -DSDL_WAYLAND_LIBDECOR=OFF -DSDL_KMSDRM=OFF -DSDL_OPENVR=OFF -DSDL_RPI=OFF       -DSDL_ROCKCHIP=OFF -DSDL_VIVANTE=OFF -DSDL_OPENGL=ON -DSDL_OPENGLES=ON       -DSDL_VULKAN=ON -DSDL_DBUS=OFF -DSDL_IBUS=OFF -DSDL_LIBUDEV=OFF       -DSDL_LIBURING=OFF -DSDL_HIDAPI_LIBUSB=OFF
    diff <(grep '^#define' build/include-config-release/build_config/SDL_build_config.h | sort)          <(grep '^#define' "$(bazel cquery --output=files @sdl3//:config_h)" | sort)

Three differences are expected. CMake finds Mesa's `GL/glx.h` and sets
`SDL_VIDEO_OPENGL_GLX`; this module has no GLX. CMake sets the
`SDL_DISABLE_<intrinsics>` lines for the CPU of the machine that runs it;
this module leaves them to `SDL_intrin.h`. CMake reads the packages on the
machine for the xkbcommon and libdecor version macros; this file sets a
minimum runtime version.
�

sdl3wayland_protocols.bzl�wayland_protocol_sources�This function declares the wayland-scanner genrules for `xmls`.

Returns a struct with `srcs` (the generated *-protocol.c files) and `hdrs`
(the generated *-client-protocol.h files).*�
�
wayland_protocol_sources

xmls (�This function declares the wayland-scanner genrules for `xmls`.

Returns a struct with `srcs` (the generated *-protocol.c files) and `hdrs`
(the generated *-client-protocol.h files).2:
wayland_protocol_sources@@sdl3//:wayland_protocols.bzl
�Client code for the XML files of the Wayland protocols.

SDL supplies these files in wayland-protocols/ and loads libwayland-client at
runtime, so Bazel compiles the protocol tables into SDL itself, as SDL's CMake
build does.

The genrules write the headers at the package root. SDL includes them with
quotes, and Bazel searches the output directory of the package first, so SDL's
own wayland-client-protocol.h has priority over the header that the wayland
module exports.
 