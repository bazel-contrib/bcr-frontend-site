�J
,
sentry_nativebazelbreakpad_sources.bzl�	BREAKPAD_HEADERS_COMMONj�2�
<://:external/breakpad/src/client/minidump_file_writer-inl.h
86//:external/breakpad/src/client/minidump_file_writer.h
.,//:external/breakpad/src/common/basictypes.h
/-//:external/breakpad/src/common/convert_UTF.h
*(//:external/breakpad/src/common/macros.h
'%//:external/breakpad/src/common/md5.h
42//:external/breakpad/src/common/memory_allocator.h
0.//:external/breakpad/src/common/memory_range.h
86//:external/breakpad/src/common/minidump_type_helper.h
.,//:external/breakpad/src/common/scoped_ptr.h
53//:external/breakpad/src/common/string_conversion.h
42//:external/breakpad/src/common/using_std_string.h
B@//:external/breakpad/src/google_breakpad/common/breakpad_types.h
FD//:external/breakpad/src/google_breakpad/common/minidump_cpu_amd64.h
DB//:external/breakpad/src/google_breakpad/common/minidump_cpu_arm.h
FD//:external/breakpad/src/google_breakpad/common/minidump_cpu_arm64.h
EC//:external/breakpad/src/google_breakpad/common/minidump_cpu_mips.h
DB//:external/breakpad/src/google_breakpad/common/minidump_cpu_ppc.h
FD//:external/breakpad/src/google_breakpad/common/minidump_cpu_ppc64.h
FD//:external/breakpad/src/google_breakpad/common/minidump_cpu_riscv.h
FD//:external/breakpad/src/google_breakpad/common/minidump_cpu_sparc.h
DB//:external/breakpad/src/google_breakpad/common/minidump_cpu_x86.h
NL//:external/breakpad/src/google_breakpad/common/minidump_exception_fuchsia.h
LJ//:external/breakpad/src/google_breakpad/common/minidump_exception_linux.h
JH//:external/breakpad/src/google_breakpad/common/minidump_exception_mac.h
JH//:external/breakpad/src/google_breakpad/common/minidump_exception_ps3.h
NL//:external/breakpad/src/google_breakpad/common/minidump_exception_solaris.h
LJ//:external/breakpad/src/google_breakpad/common/minidump_exception_win32.h
CA//:external/breakpad/src/google_breakpad/common/minidump_format.h
A?//:external/breakpad/src/google_breakpad/common/minidump_size.h�	BREAKPAD_HEADERS_LINUXj�2�
FD//:external/breakpad/src/client/linux/crash_generation/client_info.h
RP//:external/breakpad/src/client/linux/crash_generation/crash_generation_client.h
RP//:external/breakpad/src/client/linux/crash_generation/crash_generation_server.h
IG//:external/breakpad/src/client/linux/dump_writer_common/mapping_info.h
LJ//:external/breakpad/src/client/linux/dump_writer_common/raw_context_cpu.h
HF//:external/breakpad/src/client/linux/dump_writer_common/thread_info.h
LJ//:external/breakpad/src/client/linux/dump_writer_common/ucontext_reader.h
CA//:external/breakpad/src/client/linux/handler/exception_handler.h
FD//:external/breakpad/src/client/linux/handler/microdump_extra_info.h
EC//:external/breakpad/src/client/linux/handler/minidump_descriptor.h
1///:external/breakpad/src/client/linux/log/log.h
KI//:external/breakpad/src/client/linux/microdump_writer/microdump_writer.h
A?//:external/breakpad/src/client/linux/minidump_writer/cpu_set.h
JH//:external/breakpad/src/client/linux/minidump_writer/directory_reader.h
EC//:external/breakpad/src/client/linux/minidump_writer/line_reader.h
KI//:external/breakpad/src/client/linux/minidump_writer/linux_core_dumper.h
FD//:external/breakpad/src/client/linux/minidump_writer/linux_dumper.h
MK//:external/breakpad/src/client/linux/minidump_writer/linux_ptrace_dumper.h
IG//:external/breakpad/src/client/linux/minidump_writer/minidump_writer.h
A?//:external/breakpad/src/client/linux/minidump_writer/pe_file.h
DB//:external/breakpad/src/client/linux/minidump_writer/pe_structs.h
MK//:external/breakpad/src/client/linux/minidump_writer/proc_cpuinfo_reader.h
=;//:external/breakpad/src/common/linux/breakpad_getcontext.h
75//:external/breakpad/src/common/linux/eintr_wrapper.h
75//:external/breakpad/src/common/linux/elf_core_dump.h
86//:external/breakpad/src/common/linux/elf_gnu_compat.h
64//:external/breakpad/src/common/linux/elfutils-inl.h
20//:external/breakpad/src/common/linux/elfutils.h
1///:external/breakpad/src/common/linux/file_id.h
64//:external/breakpad/src/common/linux/guid_creator.h
42//:external/breakpad/src/common/linux/ignore_ret.h
<://:external/breakpad/src/common/linux/linux_libc_support.h
<://:external/breakpad/src/common/linux/memory_mapped_file.h
75//:external/breakpad/src/common/linux/safe_readlink.h
53//:external/breakpad/src/common/linux/scoped_pipe.h
86//:external/breakpad/src/common/linux/scoped_tmpfile.h
<://:external/breakpad/src/common/linux/ucontext_constants.h�	BREAKPAD_HEADERS_MACOSj�2�
PN//:external/breakpad/src/client/mac/crash_generation/crash_generation_client.h
PN//:external/breakpad/src/client/mac/crash_generation/crash_generation_server.h
A?//:external/breakpad/src/client/mac/handler/breakpad_nlist_64.h
><//:external/breakpad/src/client/mac/handler/dynamic_images.h
A?//:external/breakpad/src/client/mac/handler/exception_handler.h
><//:external/breakpad/src/client/mac/handler/mach_vm_compat.h
B@//:external/breakpad/src/client/mac/handler/minidump_generator.h
?=//:external/breakpad/src/client/mac/handler/ucontext_compat.h
75//:external/breakpad/src/common/linux/eintr_wrapper.h
75//:external/breakpad/src/common/linux/elf_core_dump.h
86//:external/breakpad/src/common/linux/elf_gnu_compat.h
64//:external/breakpad/src/common/linux/elfutils-inl.h
20//:external/breakpad/src/common/linux/elfutils.h
1///:external/breakpad/src/common/linux/file_id.h
64//:external/breakpad/src/common/linux/guid_creator.h
<://:external/breakpad/src/common/linux/linux_libc_support.h
<://:external/breakpad/src/common/linux/memory_mapped_file.h
75//:external/breakpad/src/common/linux/safe_readlink.h
53//:external/breakpad/src/common/linux/scoped_pipe.h
86//:external/breakpad/src/common/linux/scoped_tmpfile.h
<://:external/breakpad/src/common/linux/ucontext_constants.h
/-//:external/breakpad/src/common/mac/MachIPC.h
64//:external/breakpad/src/common/mac/arch_utilities.h
86//:external/breakpad/src/common/mac/bootstrap_compat.h
0.//:external/breakpad/src/common/mac/byteswap.h
/-//:external/breakpad/src/common/mac/file_id.h
0.//:external/breakpad/src/common/mac/macho_id.h
75//:external/breakpad/src/common/mac/macho_utilities.h
42//:external/breakpad/src/common/mac/macho_walker.h
?=//:external/breakpad/src/common/mac/scoped_task_suspend-inl.h
86//:external/breakpad/src/common/mac/string_utilities.h�	BREAKPAD_SOURCES_CLIENT_MACj�2�
QO//:external/breakpad/src/client/mac/crash_generation/crash_generation_client.cc
B@//:external/breakpad/src/client/mac/handler/exception_handler.cc�	BREAKPAD_SOURCES_COMMONj�2�
0.//:external/breakpad/src/common/convert_UTF.cc
(&//:external/breakpad/src/common/md5.cc
64//:external/breakpad/src/common/string_conversion.cc�	BREAKPAD_SOURCES_COMMON_LINUXj�2�
86//:external/breakpad/src/common/linux/elf_core_dump.cc
31//:external/breakpad/src/common/linux/elfutils.cc
20//:external/breakpad/src/common/linux/file_id.cc
75//:external/breakpad/src/common/linux/guid_creator.cc
=;//:external/breakpad/src/common/linux/linux_libc_support.cc
=;//:external/breakpad/src/common/linux/memory_mapped_file.cc
86//:external/breakpad/src/common/linux/safe_readlink.cc
64//:external/breakpad/src/common/linux/scoped_pipe.cc
97//:external/breakpad/src/common/linux/scoped_tmpfile.cco	(BREAKPAD_SOURCES_COMMON_LINUX_GETCONTEXTjA2?
=;//:external/breakpad/src/common/linux/breakpad_getcontext.S�	BREAKPAD_SOURCES_CLIENT_APPLEj�2�
97//:external/breakpad/src/client/minidump_file_writer.cc
B@//:external/breakpad/src/client/mac/handler/breakpad_nlist_64.cc
?=//:external/breakpad/src/client/mac/handler/dynamic_images.cc
CA//:external/breakpad/src/client/mac/handler/minidump_generator.cc�	BREAKPAD_SOURCES_CLIENT_LINUXj�2�
97//:external/breakpad/src/client/minidump_file_writer.cc
SQ//:external/breakpad/src/client/linux/crash_generation/crash_generation_client.cc
SQ//:external/breakpad/src/client/linux/crash_generation/crash_generation_server.cc
IG//:external/breakpad/src/client/linux/dump_writer_common/thread_info.cc
MK//:external/breakpad/src/client/linux/dump_writer_common/ucontext_reader.cc
DB//:external/breakpad/src/client/linux/handler/exception_handler.cc
FD//:external/breakpad/src/client/linux/handler/minidump_descriptor.cc
20//:external/breakpad/src/client/linux/log/log.cc
LJ//:external/breakpad/src/client/linux/microdump_writer/microdump_writer.cc
LJ//:external/breakpad/src/client/linux/minidump_writer/linux_core_dumper.cc
GE//:external/breakpad/src/client/linux/minidump_writer/linux_dumper.cc
NL//:external/breakpad/src/client/linux/minidump_writer/linux_ptrace_dumper.cc
JH//:external/breakpad/src/client/linux/minidump_writer/minidump_writer.cc
B@//:external/breakpad/src/client/linux/minidump_writer/pe_file.cc�	BREAKPAD_SOURCES_COMMON_APPLEj�2�
75//:external/breakpad/src/common/mac/arch_utilities.cc
0.//:external/breakpad/src/common/mac/file_id.cc
1///:external/breakpad/src/common/mac/macho_id.cc
86//:external/breakpad/src/common/mac/macho_utilities.cc
53//:external/breakpad/src/common/mac/macho_walker.cc
97//:external/breakpad/src/common/mac/string_utilities.cc^	BREAKPAD_SOURCES_COMMON_MACj=2;
97//:external/breakpad/src/common/mac/bootstrap_compat.cc�Exact source manifests for the sentry-native Breakpad fork.

When updating the overlay, compare normalized path multisets with
external/CMakeLists.txt so platform selections remain explicit.
�h
4
sentry_nativebazelcrashpad_handler_sources.bzl�	CRASHPAD_HANDLER_LINUX_HDRSj�2�
42external/crashpad/handler/linux/capture_snapshot.h
B@external/crashpad/handler/linux/crash_report_exception_handler.h
GEexternal/crashpad/handler/linux/cros_crash_report_exception_handler.h
<:external/crashpad/handler/linux/exception_handler_server.h�	CRASHPAD_HANDLER_MACOS_HDRSj�2�
@>external/crashpad/handler/mac/crash_report_exception_handler.h
:8external/crashpad/handler/mac/exception_handler_server.h
75external/crashpad/handler/mac/file_limit_annotation.h�	CRASHPAD_HANDLER_MACOS_SRCSj�2�
A?external/crashpad/handler/mac/crash_report_exception_handler.cc
;9external/crashpad/handler/mac/exception_handler_server.cc
86external/crashpad/handler/mac/file_limit_annotation.cc�		CRASHPAD_SNAPSHOT_COMMON_SRCSj�2�
31external/crashpad/snapshot/annotation_snapshot.cc
.,external/crashpad/snapshot/capture_memory.cc
+)external/crashpad/snapshot/cpu_context.cc
<:external/crashpad/snapshot/crashpad_info_client_options.cc
/-external/crashpad/snapshot/handle_snapshot.cc
/-external/crashpad/snapshot/memory_snapshot.cc
DBexternal/crashpad/snapshot/minidump/exception_snapshot_minidump.cc
A?external/crashpad/snapshot/minidump/memory_snapshot_minidump.cc
CAexternal/crashpad/snapshot/minidump/minidump_annotation_reader.cc
CAexternal/crashpad/snapshot/minidump/minidump_context_converter.cc
QOexternal/crashpad/snapshot/minidump/minidump_simple_string_dictionary_reader.cc
DBexternal/crashpad/snapshot/minidump/minidump_string_list_reader.cc
?=external/crashpad/snapshot/minidump/minidump_string_reader.cc
A?external/crashpad/snapshot/minidump/module_snapshot_minidump.cc
B@external/crashpad/snapshot/minidump/process_snapshot_minidump.cc
A?external/crashpad/snapshot/minidump/system_snapshot_minidump.cc
A?external/crashpad/snapshot/minidump/thread_snapshot_minidump.cc
86external/crashpad/snapshot/unloaded_module_snapshot.ccS	CRASHPAD_SNAPSHOT_X86_HDRSj321
/-external/crashpad/snapshot/x86/cpuid_reader.h�	CRASHPAD_SNAPSHOT_MACOS_SRCSj�2�
31external/crashpad/snapshot/mac/cpu_context_mac.cc
:8external/crashpad/snapshot/mac/exception_snapshot_mac.cc
CAexternal/crashpad/snapshot/mac/mach_o_image_annotations_reader.cc
75external/crashpad/snapshot/mac/mach_o_image_reader.cc
?=external/crashpad/snapshot/mac/mach_o_image_segment_reader.cc
DBexternal/crashpad/snapshot/mac/mach_o_image_symbol_table_reader.cc
75external/crashpad/snapshot/mac/module_snapshot_mac.cc
64external/crashpad/snapshot/mac/process_reader_mac.cc
86external/crashpad/snapshot/mac/process_snapshot_mac.cc
1/external/crashpad/snapshot/mac/process_types.cc
86external/crashpad/snapshot/mac/process_types/custom.cc
75external/crashpad/snapshot/mac/system_snapshot_mac.cc
75external/crashpad/snapshot/mac/thread_snapshot_mac.cc
.,external/crashpad/snapshot/posix/timezone.cc�	CRASHPAD_HANDLER_COMMON_SRCSj�2�
=;external/crashpad/handler/crash_report_upload_rate_limit.cc
97external/crashpad/handler/crash_report_upload_thread.cc
+)external/crashpad/handler/handler_main.cc
<:external/crashpad/handler/minidump_to_upload_parameters.cc
97external/crashpad/handler/prune_crash_reports_thread.cc
64external/crashpad/handler/user_stream_data_source.cc�	CRASHPAD_HANDLER_LINUX_SRCSj�2�
53external/crashpad/handler/linux/capture_snapshot.cc
CAexternal/crashpad/handler/linux/crash_report_exception_handler.cc
HFexternal/crashpad/handler/linux/cros_crash_report_exception_handler.cc
=;external/crashpad/handler/linux/exception_handler_server.cc�	CRASHPAD_MINIDUMP_HDRSj�2�
97external/crashpad/minidump/minidump_annotation_writer.h
97external/crashpad/minidump/minidump_byte_array_writer.h
/-external/crashpad/minidump/minidump_context.h
64external/crashpad/minidump/minidump_context_writer.h
<:external/crashpad/minidump/minidump_crashpad_info_writer.h
86external/crashpad/minidump/minidump_exception_writer.h
20external/crashpad/minidump/minidump_extensions.h
31external/crashpad/minidump/minidump_file_writer.h
53external/crashpad/minidump/minidump_handle_writer.h
:8external/crashpad/minidump/minidump_memory_info_writer.h
53external/crashpad/minidump/minidump_memory_writer.h
86external/crashpad/minidump/minidump_misc_info_writer.h
CAexternal/crashpad/minidump/minidump_module_crashpad_info_writer.h
53external/crashpad/minidump/minidump_module_writer.h
75external/crashpad/minidump/minidump_rva_list_writer.h
GEexternal/crashpad/minidump/minidump_simple_string_dictionary_writer.h
53external/crashpad/minidump/minidump_stream_writer.h
53external/crashpad/minidump/minidump_string_writer.h
:8external/crashpad/minidump/minidump_system_info_writer.h
53external/crashpad/minidump/minidump_thread_id_map.h
?=external/crashpad/minidump/minidump_thread_name_list_writer.h
53external/crashpad/minidump/minidump_thread_writer.h
><external/crashpad/minidump/minidump_unloaded_module_writer.h
IGexternal/crashpad/minidump/minidump_user_extension_stream_data_source.h
:8external/crashpad/minidump/minidump_user_stream_writer.h
0.external/crashpad/minidump/minidump_writable.h
31external/crashpad/minidump/minidump_writer_util.h�	CRASHPAD_MINIDUMP_SRCSj�2�
:8external/crashpad/minidump/minidump_annotation_writer.cc
:8external/crashpad/minidump/minidump_byte_array_writer.cc
75external/crashpad/minidump/minidump_context_writer.cc
=;external/crashpad/minidump/minidump_crashpad_info_writer.cc
97external/crashpad/minidump/minidump_exception_writer.cc
31external/crashpad/minidump/minidump_extensions.cc
42external/crashpad/minidump/minidump_file_writer.cc
64external/crashpad/minidump/minidump_handle_writer.cc
;9external/crashpad/minidump/minidump_memory_info_writer.cc
64external/crashpad/minidump/minidump_memory_writer.cc
97external/crashpad/minidump/minidump_misc_info_writer.cc
DBexternal/crashpad/minidump/minidump_module_crashpad_info_writer.cc
64external/crashpad/minidump/minidump_module_writer.cc
86external/crashpad/minidump/minidump_rva_list_writer.cc
HFexternal/crashpad/minidump/minidump_simple_string_dictionary_writer.cc
64external/crashpad/minidump/minidump_stream_writer.cc
64external/crashpad/minidump/minidump_string_writer.cc
;9external/crashpad/minidump/minidump_system_info_writer.cc
64external/crashpad/minidump/minidump_thread_id_map.cc
@>external/crashpad/minidump/minidump_thread_name_list_writer.cc
64external/crashpad/minidump/minidump_thread_writer.cc
?=external/crashpad/minidump/minidump_unloaded_module_writer.cc
JHexternal/crashpad/minidump/minidump_user_extension_stream_data_source.cc
;9external/crashpad/minidump/minidump_user_stream_writer.cc
1/external/crashpad/minidump/minidump_writable.cc
42external/crashpad/minidump/minidump_writer_util.cc�
	CRASHPAD_SNAPSHOT_LINUX_SRCSj�	2�	
CAexternal/crashpad/snapshot/crashpad_types/crashpad_info_reader.cc
FDexternal/crashpad/snapshot/crashpad_types/image_annotation_reader.cc
<:external/crashpad/snapshot/elf/elf_dynamic_array_reader.cc
42external/crashpad/snapshot/elf/elf_image_reader.cc
;9external/crashpad/snapshot/elf/elf_symbol_table_reader.cc
75external/crashpad/snapshot/elf/module_snapshot_elf.cc
CAexternal/crashpad/snapshot/linux/capture_memory_delegate_linux.cc
75external/crashpad/snapshot/linux/cpu_context_linux.cc
64external/crashpad/snapshot/linux/debug_rendezvous.cc
><external/crashpad/snapshot/linux/exception_snapshot_linux.cc
:8external/crashpad/snapshot/linux/process_reader_linux.cc
<:external/crashpad/snapshot/linux/process_snapshot_linux.cc
;9external/crashpad/snapshot/linux/system_snapshot_linux.cc
;9external/crashpad/snapshot/linux/thread_snapshot_linux.cc
.,external/crashpad/snapshot/posix/timezone.cc
CAexternal/crashpad/snapshot/sanitized/memory_snapshot_sanitized.cc
CAexternal/crashpad/snapshot/sanitized/module_snapshot_sanitized.cc
DBexternal/crashpad/snapshot/sanitized/process_snapshot_sanitized.cc
B@external/crashpad/snapshot/sanitized/sanitization_information.cc
CAexternal/crashpad/snapshot/sanitized/thread_snapshot_sanitized.cc�	$CRASHPAD_SNAPSHOT_MACOS_TEXTUAL_HDRSj�2�
;9external/crashpad/snapshot/mac/process_types/all.proctype
B@external/crashpad/snapshot/mac/process_types/annotation.proctype
ECexternal/crashpad/snapshot/mac/process_types/crashpad_info.proctype
KIexternal/crashpad/snapshot/mac/process_types/crashreporterclient.proctype
CAexternal/crashpad/snapshot/mac/process_types/dyld_images.proctype
><external/crashpad/snapshot/mac/process_types/loader.proctype
=;external/crashpad/snapshot/mac/process_types/nlist.proctype�	CRASHPAD_SNAPSHOT_COMMON_HDRSj�2�
/-external/crashpad/minidump/minidump_context.h
20external/crashpad/minidump/minidump_extensions.h
20external/crashpad/snapshot/annotation_snapshot.h
-+external/crashpad/snapshot/capture_memory.h
/-external/crashpad/snapshot/cpu_architecture.h
*(external/crashpad/snapshot/cpu_context.h
;9external/crashpad/snapshot/crashpad_info_client_options.h
1/external/crashpad/snapshot/exception_snapshot.h
.,external/crashpad/snapshot/handle_snapshot.h
97external/crashpad/snapshot/memory_map_region_snapshot.h
.,external/crashpad/snapshot/memory_snapshot.h
64external/crashpad/snapshot/memory_snapshot_generic.h
CAexternal/crashpad/snapshot/minidump/exception_snapshot_minidump.h
@>external/crashpad/snapshot/minidump/memory_snapshot_minidump.h
B@external/crashpad/snapshot/minidump/minidump_annotation_reader.h
B@external/crashpad/snapshot/minidump/minidump_context_converter.h
PNexternal/crashpad/snapshot/minidump/minidump_simple_string_dictionary_reader.h
75external/crashpad/snapshot/minidump/minidump_stream.h
CAexternal/crashpad/snapshot/minidump/minidump_string_list_reader.h
><external/crashpad/snapshot/minidump/minidump_string_reader.h
@>external/crashpad/snapshot/minidump/module_snapshot_minidump.h
A?external/crashpad/snapshot/minidump/process_snapshot_minidump.h
@>external/crashpad/snapshot/minidump/system_snapshot_minidump.h
@>external/crashpad/snapshot/minidump/thread_snapshot_minidump.h
.,external/crashpad/snapshot/module_snapshot.h
/-external/crashpad/snapshot/process_snapshot.h
1/external/crashpad/snapshot/snapshot_constants.h
.,external/crashpad/snapshot/system_snapshot.h
.,external/crashpad/snapshot/thread_snapshot.h
75external/crashpad/snapshot/unloaded_module_snapshot.hT	CRASHPAD_SNAPSHOT_X86_SRCSj422
0.external/crashpad/snapshot/x86/cpuid_reader.cc�	CRASHPAD_HANDLER_COMMON_HDRSj�2�
<:external/crashpad/handler/crash_report_upload_rate_limit.h
86external/crashpad/handler/crash_report_upload_thread.h
*(external/crashpad/handler/handler_main.h
;9external/crashpad/handler/minidump_to_upload_parameters.h
86external/crashpad/handler/prune_crash_reports_thread.h
53external/crashpad/handler/user_stream_data_source.h�
	CRASHPAD_SNAPSHOT_LINUX_HDRSj�
2�

B@external/crashpad/snapshot/crashpad_types/crashpad_info_reader.h
ECexternal/crashpad/snapshot/crashpad_types/image_annotation_reader.h
;9external/crashpad/snapshot/elf/elf_dynamic_array_reader.h
31external/crashpad/snapshot/elf/elf_image_reader.h
:8external/crashpad/snapshot/elf/elf_symbol_table_reader.h
64external/crashpad/snapshot/elf/module_snapshot_elf.h
B@external/crashpad/snapshot/linux/capture_memory_delegate_linux.h
64external/crashpad/snapshot/linux/cpu_context_linux.h
53external/crashpad/snapshot/linux/debug_rendezvous.h
=;external/crashpad/snapshot/linux/exception_snapshot_linux.h
97external/crashpad/snapshot/linux/process_reader_linux.h
;9external/crashpad/snapshot/linux/process_snapshot_linux.h
31external/crashpad/snapshot/linux/signal_context.h
:8external/crashpad/snapshot/linux/system_snapshot_linux.h
:8external/crashpad/snapshot/linux/thread_snapshot_linux.h
-+external/crashpad/snapshot/posix/timezone.h
B@external/crashpad/snapshot/sanitized/memory_snapshot_sanitized.h
B@external/crashpad/snapshot/sanitized/module_snapshot_sanitized.h
CAexternal/crashpad/snapshot/sanitized/process_snapshot_sanitized.h
A?external/crashpad/snapshot/sanitized/sanitization_information.h
B@external/crashpad/snapshot/sanitized/thread_snapshot_sanitized.h�	CRASHPAD_SNAPSHOT_MACOS_HDRSj�2�
20external/crashpad/snapshot/mac/cpu_context_mac.h
97external/crashpad/snapshot/mac/exception_snapshot_mac.h
B@external/crashpad/snapshot/mac/mach_o_image_annotations_reader.h
64external/crashpad/snapshot/mac/mach_o_image_reader.h
><external/crashpad/snapshot/mac/mach_o_image_segment_reader.h
CAexternal/crashpad/snapshot/mac/mach_o_image_symbol_table_reader.h
64external/crashpad/snapshot/mac/module_snapshot_mac.h
53external/crashpad/snapshot/mac/process_reader_mac.h
75external/crashpad/snapshot/mac/process_snapshot_mac.h
0.external/crashpad/snapshot/mac/process_types.h
86external/crashpad/snapshot/mac/process_types/flavors.h
97external/crashpad/snapshot/mac/process_types/internal.h
75external/crashpad/snapshot/mac/process_types/traits.h
64external/crashpad/snapshot/mac/system_snapshot_mac.h
64external/crashpad/snapshot/mac/thread_snapshot_mac.h
-+external/crashpad/snapshot/posix/timezone.h�Exact snapshot, minidump, and handler manifests for Crashpad.

When updating the overlay, compare normalized path multisets with the upstream
Crashpad targets so snapshot, minidump, and handler boundaries remain explicit.
�

(
sentry_nativebazelcrashpad_mig.bzl�crashpad_mig"�
�
crashpad_mig*
nameA unique name for this target. 

arch 
child_port_defs 
child_port_types 
compat_headers2[]	
mig 

mig_driver 
migcom 

output_dir2"mig""7
crashpad_mig'@@sentry_native//bazel:crashpad_mig.bzl
��,
*
nameA unique name for this target. 


arch 

child_port_defs 

child_port_types 

compat_headers2[]
	
mig 


mig_driver 

migcom 


output_dir2"mig"�
//lib:apple_support.bzlre
'
apple_supportlibapple_support.bzl,
apple_supportapple_support
0=
?a
//lib:paths.bzlrL

bazel_skyliblib	paths.bzl
pathspaths
',
.�
//cc:action_names.bzlrn
 
rules_ccccaction_names.bzl<
C_COMPILE_ACTION_NAMEC_COMPILE_ACTION_NAME
)>
@�
//cc:find_cc_toolchain.bzlr�
%
rules_ccccfind_cc_toolchain.bzl6
CC_TOOLCHAIN_ATTRSCC_TOOLCHAIN_ATTRS
.@6
find_cpp_toolchainfind_cpp_toolchain
DV2
use_cc_toolchainuse_cc_toolchain
Zj
ly
//cc/common:cc_common.bzlrZ
$
rules_cc	cc/commoncc_common.bzl$
	cc_common	cc_common
-6
8.Cross-platform Crashpad MIG source generation.��
,
sentry_nativebazelcrashpad_sources.bzl�crashpad_compat_strip_prefixDReturns the compat header prefix for root and external-repo layouts.*�
�
crashpad_compat_strip_prefix
platform_dir (DReturns the compat header prefix for root and external-repo layouts.2K
crashpad_compat_strip_prefix+@@sentry_native//bazel:crashpad_sources.bzl
  �crashpad_copts8Returns the fork's global C++ and Apple compile options.*�
�
crashpad_copts8Returns the fork's global C++ and Apple compile options.2=
crashpad_copts+@@sentry_native//bazel:crashpad_sources.bzl
�crashpad_supported_platformsEReturns compatibility constraints for the currently supported matrix.*�
�
crashpad_supported_platformsEReturns compatibility constraints for the currently supported matrix.2K
crashpad_supported_platforms+@@sentry_native//bazel:crashpad_sources.bzl
�	CRASHPAD_COMPAT_COMMON_HDRSj�2�
,*external/crashpad/compat/non_win/dbghelp.h
/-external/crashpad/compat/non_win/minwinbase.h
0.external/crashpad/compat/non_win/timezoneapi.h
,*external/crashpad/compat/non_win/verrsrc.h
,*external/crashpad/compat/non_win/windows.h
*(external/crashpad/compat/non_win/winnt.h�	!CRASHPAD_COMPAT_LINUX_SHADOW_HDRSj�2�
)'external/crashpad/compat/linux/signal.h
+)external/crashpad/compat/linux/sys/mman.h
-+external/crashpad/compat/linux/sys/ptrace.h
+)external/crashpad/compat/linux/sys/user.h�	CRASHPAD_UTIL_COMMON_HDRSj�2�
53external/crashpad/util/file/delimited_file_reader.h
0.external/crashpad/util/file/directory_reader.h
+)external/crashpad/util/file/file_helper.h
'%external/crashpad/util/file/file_io.h
+)external/crashpad/util/file/file_reader.h
+)external/crashpad/util/file/file_seeker.h
+)external/crashpad/util/file/file_writer.h
*(external/crashpad/util/file/filesystem.h
97external/crashpad/util/file/output_stream_file_writer.h
20external/crashpad/util/file/scoped_remove_file.h
+)external/crashpad/util/file/string_file.h
1/external/crashpad/util/misc/address_sanitizer.h
-+external/crashpad/util/misc/address_types.h
)'external/crashpad/util/misc/arraysize.h
20external/crashpad/util/misc/as_underlying_type.h
/-external/crashpad/util/misc/capture_context.h
%#external/crashpad/util/misc/clock.h
.,external/crashpad/util/misc/elf_note_types.h
1/external/crashpad/util/misc/from_pointer_cast.h
-+external/crashpad/util/misc/implicit_cast.h
42external/crashpad/util/misc/initialization_state.h
;9external/crashpad/util/misc/initialization_state_dcheck.h
&$external/crashpad/util/misc/lexing.h
0.external/crashpad/util/misc/memory_sanitizer.h
'%external/crashpad/util/misc/metrics.h
,*external/crashpad/util/misc/no_cfi_icall.h
%#external/crashpad/util/misc/paths.h
.,external/crashpad/util/misc/pdb_structures.h
-+external/crashpad/util/misc/random_string.h
)'external/crashpad/util/misc/range_set.h
1/external/crashpad/util/misc/reinterpret_bytes.h
42external/crashpad/util/misc/scoped_forbid_return.h
97external/crashpad/util/misc/symbolic_constants_common.h
$"external/crashpad/util/misc/time.h
)'external/crashpad/util/misc/tri_state.h
$"external/crashpad/util/misc/uuid.h
$"external/crashpad/util/misc/zlib.h
(&external/crashpad/util/net/http_body.h
-+external/crashpad/util/net/http_body_gzip.h
+)external/crashpad/util/net/http_headers.h
53external/crashpad/util/net/http_multipart_builder.h
-+external/crashpad/util/net/http_transport.h
" external/crashpad/util/net/url.h
86external/crashpad/util/numeric/checked_address_range.h
0.external/crashpad/util/numeric/checked_range.h
;9external/crashpad/util/numeric/checked_vm_address_range.h
0.external/crashpad/util/numeric/in_range_cast.h
)'external/crashpad/util/numeric/int128.h
20external/crashpad/util/numeric/safe_assignment.h
-+external/crashpad/util/process/process_id.h
1/external/crashpad/util/process/process_memory.h
86external/crashpad/util/process/process_memory_native.h
75external/crashpad/util/process/process_memory_range.h
31external/crashpad/util/stdlib/aligned_allocator.h
,*external/crashpad/util/stdlib/map_insert.h
&$external/crashpad/util/stdlib/objc.h
:8external/crashpad/util/stdlib/string_number_conversion.h
)'external/crashpad/util/stdlib/strlcpy.h
)'external/crashpad/util/stdlib/strnlen.h
42external/crashpad/util/stdlib/thread_safe_vector.h
64external/crashpad/util/stream/base94_output_stream.h
.,external/crashpad/util/stream/file_encoder.h
42external/crashpad/util/stream/file_output_stream.h
31external/crashpad/util/stream/log_output_stream.h
97external/crashpad/util/stream/output_stream_interface.h
42external/crashpad/util/stream/zlib_output_stream.h
.,external/crashpad/util/string/split_string.h
<:external/crashpad/util/synchronization/scoped_spin_guard.h
42external/crashpad/util/synchronization/semaphore.h
+)external/crashpad/util/thread/stoppable.h
(&external/crashpad/util/thread/thread.h
53external/crashpad/util/thread/thread_log_messages.h
/-external/crashpad/util/thread/worker_thread.h�		CRASHPAD_UTIL_LINUX_SRCSj�	2�	
20external/crashpad/util/linux/auxiliary_vector.cc
:8external/crashpad/util/linux/direct_ptrace_connection.cc
:8external/crashpad/util/linux/exception_handler_client.cc
<:external/crashpad/util/linux/exception_handler_protocol.cc
,*external/crashpad/util/linux/memory_map.cc
,*external/crashpad/util/linux/pac_helper.cc
20external/crashpad/util/linux/proc_stat_reader.cc
20external/crashpad/util/linux/proc_task_reader.cc
/-external/crashpad/util/linux/ptrace_broker.cc
/-external/crashpad/util/linux/ptrace_client.cc
)'external/crashpad/util/linux/ptracer.cc
86external/crashpad/util/linux/scoped_pr_set_dumpable.cc
75external/crashpad/util/linux/scoped_pr_set_ptracer.cc
64external/crashpad/util/linux/scoped_ptrace_attach.cc
(&external/crashpad/util/linux/socket.cc
-+external/crashpad/util/linux/thread_info.cc
53external/crashpad/util/misc/capture_context_linux.S
,*external/crashpad/util/misc/paths_linux.cc
+)external/crashpad/util/misc/time_linux.cc
64external/crashpad/util/net/http_transport_libcurl.cc
42external/crashpad/util/posix/process_info_linux.cc
86external/crashpad/util/process/process_memory_linux.cc
<:external/crashpad/util/process/process_memory_sanitized.cc�	CRASHPAD_UTIL_MACOS_SRCSj�
2�

(&external/crashpad/util/mac/mac_util.cc
20external/crashpad/util/mac/service_management.cc
&$external/crashpad/util/mac/sysctl.cc
%#external/crashpad/util/mac/xattr.cc
*(external/crashpad/util/mach/bootstrap.cc
53external/crashpad/util/mach/child_port_handshake.cc
20external/crashpad/util/mach/child_port_server.cc
><external/crashpad/util/mach/composite_mach_message_server.cc
42external/crashpad/util/mach/exc_client_variants.cc
42external/crashpad/util/mach/exc_server_variants.cc
42external/crashpad/util/mach/exception_behaviors.cc
;9external/crashpad/util/mach/exception_handler_protocol.cc
0.external/crashpad/util/mach/exception_ports.cc
0.external/crashpad/util/mach/exception_types.cc
0.external/crashpad/util/mach/mach_extensions.cc
-+external/crashpad/util/mach/mach_message.cc
42external/crashpad/util/mach/mach_message_server.cc
.,external/crashpad/util/mach/notify_server.cc
42external/crashpad/util/mach/scoped_task_suspend.cc
86external/crashpad/util/mach/symbolic_constants_mach.cc
-+external/crashpad/util/mach/task_for_pid.cc
31external/crashpad/util/misc/capture_context_mac.S
*(external/crashpad/util/misc/clock_mac.cc
*(external/crashpad/util/misc/paths_mac.cc
20external/crashpad/util/posix/process_info_mac.cc
64external/crashpad/util/process/process_memory_mac.cc
97external/crashpad/util/synchronization/semaphore_mac.cc�	MINI_CHROMIUM_MACOS_HDRSj�2�
QOexternal/crashpad/third_party/mini_chromium/mini_chromium/base/apple/bridging.h
XVexternal/crashpad/third_party/mini_chromium/mini_chromium/base/apple/foundation_util.h
USexternal/crashpad/third_party/mini_chromium/mini_chromium/base/apple/mach_logging.h
YWexternal/crashpad/third_party/mini_chromium/mini_chromium/base/apple/scoped_cftyperef.h
YWexternal/crashpad/third_party/mini_chromium/mini_chromium/base/apple/scoped_mach_port.h
WUexternal/crashpad/third_party/mini_chromium/mini_chromium/base/apple/scoped_mach_vm.h
b`external/crashpad/third_party/mini_chromium/mini_chromium/base/apple/scoped_nsautorelease_pool.h
WUexternal/crashpad/third_party/mini_chromium/mini_chromium/base/apple/scoped_typeref.h
VTexternal/crashpad/third_party/mini_chromium/mini_chromium/base/mac/scoped_ioobject.h
YWexternal/crashpad/third_party/mini_chromium/mini_chromium/base/mac/scoped_launch_data.h�	CRASHPAD_CLIENT_LINUX_SRCSj�2�
20external/crashpad/client/client_argv_handling.cc
;9external/crashpad/client/crash_report_database_generic.cc
31external/crashpad/client/crashpad_client_linux.cc
/-external/crashpad/client/crashpad_info_note.S�	CRASHPAD_CLIENT_MACOS_SRCSjg2e
1/external/crashpad/client/crashpad_client_mac.cc
0.external/crashpad/client/simulate_crash_mac.cc�	CRASHPAD_COMPAT_MACOS_HDRSj�2�
-+external/crashpad/compat/mac/Availability.h
53external/crashpad/compat/mac/AvailabilityVersions.h
20external/crashpad/compat/mac/kern/exc_resource.h
.,external/crashpad/compat/mac/mach-o/loader.h
75external/crashpad/compat/mac/mach/i386/thread_state.h
*(external/crashpad/compat/mac/mach/mach.h
-+external/crashpad/compat/mac/sys/resource.h�
	CRASHPAD_UTIL_MACOS_HDRSj�	2�	
97external/crashpad/util/mac/checked_mach_address_range.h
&$external/crashpad/util/mac/launchd.h
'%external/crashpad/util/mac/mac_util.h
1/external/crashpad/util/mac/service_management.h
%#external/crashpad/util/mac/sysctl.h
$"external/crashpad/util/mac/xattr.h
)'external/crashpad/util/mach/bootstrap.h
42external/crashpad/util/mach/child_port_handshake.h
1/external/crashpad/util/mach/child_port_server.h
0.external/crashpad/util/mach/child_port_types.h
=;external/crashpad/util/mach/composite_mach_message_server.h
31external/crashpad/util/mach/exc_client_variants.h
31external/crashpad/util/mach/exc_server_variants.h
31external/crashpad/util/mach/exception_behaviors.h
:8external/crashpad/util/mach/exception_handler_protocol.h
/-external/crashpad/util/mach/exception_ports.h
/-external/crashpad/util/mach/exception_types.h
/-external/crashpad/util/mach/mach_extensions.h
,*external/crashpad/util/mach/mach_message.h
31external/crashpad/util/mach/mach_message_server.h
-+external/crashpad/util/mach/notify_server.h
31external/crashpad/util/mach/scoped_task_suspend.h
75external/crashpad/util/mach/symbolic_constants_mach.h
,*external/crashpad/util/mach/task_for_pid.h
53external/crashpad/util/process/process_memory_mac.h�	MINI_CHROMIUM_MACOS_OBJC_SRCSj�2�
YWexternal/crashpad/third_party/mini_chromium/mini_chromium/base/apple/foundation_util.mm
caexternal/crashpad/third_party/mini_chromium/mini_chromium/base/apple/scoped_nsautorelease_pool.mm
fdexternal/crashpad/third_party/mini_chromium/mini_chromium/base/strings/sys_string_conversions_mac.mm�	MINI_CHROMIUM_MACOS_SRCSj�2�
VTexternal/crashpad/third_party/mini_chromium/mini_chromium/base/apple/mach_logging.cc
ZXexternal/crashpad/third_party/mini_chromium/mini_chromium/base/apple/scoped_mach_port.cc
XVexternal/crashpad/third_party/mini_chromium/mini_chromium/base/apple/scoped_mach_vm.cc
VTexternal/crashpad/third_party/mini_chromium/mini_chromium/base/mac/close_nocancel.cc�	MINI_CHROMIUM_POSIX_HDRSj�2�
VTexternal/crashpad/third_party/mini_chromium/mini_chromium/base/posix/eintr_wrapper.h
VTexternal/crashpad/third_party/mini_chromium/mini_chromium/base/posix/safe_strerror.h
\Zexternal/crashpad/third_party/mini_chromium/mini_chromium/base/strings/string_util_posix.h�	CRASHPAD_CLIENT_LINUX_HDRSjh2f
1/external/crashpad/client/client_argv_handling.h
1/external/crashpad/client/simulate_crash_linux.h�/	MINI_CHROMIUM_COMMON_HDRSj�.2�.
IGexternal/crashpad/third_party/mini_chromium/build/chromeos_buildflags.h
LJexternal/crashpad/third_party/mini_chromium/mini_chromium/base/atomicops.h
hfexternal/crashpad/third_party/mini_chromium/mini_chromium/base/atomicops_internals_atomicword_compat.h
_]external/crashpad/third_party/mini_chromium/mini_chromium/base/atomicops_internals_portable.h
MKexternal/crashpad/third_party/mini_chromium/mini_chromium/base/auto_reset.h
KIexternal/crashpad/third_party/mini_chromium/mini_chromium/base/bit_cast.h
HFexternal/crashpad/third_party/mini_chromium/mini_chromium/base/check.h
KIexternal/crashpad/third_party/mini_chromium/mini_chromium/base/check_op.h
TRexternal/crashpad/third_party/mini_chromium/mini_chromium/base/compiler_specific.h
_]external/crashpad/third_party/mini_chromium/mini_chromium/base/containers/checked_iterators.h
\Zexternal/crashpad/third_party/mini_chromium/mini_chromium/base/containers/dynamic_extent.h
XVexternal/crashpad/third_party/mini_chromium/mini_chromium/base/containers/heap_array.h
RPexternal/crashpad/third_party/mini_chromium/mini_chromium/base/containers/span.h
RPexternal/crashpad/third_party/mini_chromium/mini_chromium/base/containers/util.h
RPexternal/crashpad/third_party/mini_chromium/mini_chromium/base/cxx17_backports.h
NLexternal/crashpad/third_party/mini_chromium/mini_chromium/base/debug/alias.h
RPexternal/crashpad/third_party/mini_chromium/mini_chromium/base/files/file_path.h
RPexternal/crashpad/third_party/mini_chromium/mini_chromium/base/files/file_util.h
TRexternal/crashpad/third_party/mini_chromium/mini_chromium/base/files/scoped_file.h
PNexternal/crashpad/third_party/mini_chromium/mini_chromium/base/format_macros.h
RPexternal/crashpad/third_party/mini_chromium/mini_chromium/base/immediate_crash.h
JHexternal/crashpad/third_party/mini_chromium/mini_chromium/base/logging.h
VTexternal/crashpad/third_party/mini_chromium/mini_chromium/base/memory/free_deleter.h
SQexternal/crashpad/third_party/mini_chromium/mini_chromium/base/memory/page_size.h
[Yexternal/crashpad/third_party/mini_chromium/mini_chromium/base/memory/raw_ptr_exclusion.h
WUexternal/crashpad/third_party/mini_chromium/mini_chromium/base/memory/scoped_policy.h
^\external/crashpad/third_party/mini_chromium/mini_chromium/base/metrics/histogram_functions.h
[Yexternal/crashpad/third_party/mini_chromium/mini_chromium/base/metrics/histogram_macros.h
igexternal/crashpad/third_party/mini_chromium/mini_chromium/base/metrics/persistent_histogram_allocator.h
MKexternal/crashpad/third_party/mini_chromium/mini_chromium/base/notreached.h
ZXexternal/crashpad/third_party/mini_chromium/mini_chromium/base/numerics/basic_ops_impl.h
\Zexternal/crashpad/third_party/mini_chromium/mini_chromium/base/numerics/byte_conversions.h
XVexternal/crashpad/third_party/mini_chromium/mini_chromium/base/numerics/checked_math.h
][external/crashpad/third_party/mini_chromium/mini_chromium/base/numerics/checked_math_impl.h
XVexternal/crashpad/third_party/mini_chromium/mini_chromium/base/numerics/clamped_math.h
][external/crashpad/third_party/mini_chromium/mini_chromium/base/numerics/clamped_math_impl.h
\Zexternal/crashpad/third_party/mini_chromium/mini_chromium/base/numerics/safe_conversions.h
ecexternal/crashpad/third_party/mini_chromium/mini_chromium/base/numerics/safe_conversions_arm_impl.h
a_external/crashpad/third_party/mini_chromium/mini_chromium/base/numerics/safe_conversions_impl.h
USexternal/crashpad/third_party/mini_chromium/mini_chromium/base/numerics/safe_math.h
^\external/crashpad/third_party/mini_chromium/mini_chromium/base/numerics/safe_math_arm_impl.h
dbexternal/crashpad/third_party/mini_chromium/mini_chromium/base/numerics/safe_math_clang_gcc_impl.h
a_external/crashpad/third_party/mini_chromium/mini_chromium/base/numerics/safe_math_shared_impl.h
QOexternal/crashpad/third_party/mini_chromium/mini_chromium/base/process/memory.h
LJexternal/crashpad/third_party/mini_chromium/mini_chromium/base/rand_util.h
ZXexternal/crashpad/third_party/mini_chromium/mini_chromium/base/scoped_clear_last_error.h
QOexternal/crashpad/third_party/mini_chromium/mini_chromium/base/scoped_generic.h
RPexternal/crashpad/third_party/mini_chromium/mini_chromium/base/strings/pattern.h
QOexternal/crashpad/third_party/mini_chromium/mini_chromium/base/strings/strcat.h
ZXexternal/crashpad/third_party/mini_chromium/mini_chromium/base/strings/strcat_internal.h
dbexternal/crashpad/third_party/mini_chromium/mini_chromium/base/strings/string_number_conversions.h
VTexternal/crashpad/third_party/mini_chromium/mini_chromium/base/strings/string_util.h
WUexternal/crashpad/third_party/mini_chromium/mini_chromium/base/strings/stringprintf.h
a_external/crashpad/third_party/mini_chromium/mini_chromium/base/strings/sys_string_conversions.h
fdexternal/crashpad/third_party/mini_chromium/mini_chromium/base/strings/utf_string_conversion_utils.h
a_external/crashpad/third_party/mini_chromium/mini_chromium/base/strings/utf_string_conversions.h
ecexternal/crashpad/third_party/mini_chromium/mini_chromium/base/synchronization/condition_variable.h
WUexternal/crashpad/third_party/mini_chromium/mini_chromium/base/synchronization/lock.h
\Zexternal/crashpad/third_party/mini_chromium/mini_chromium/base/synchronization/lock_impl.h
PNexternal/crashpad/third_party/mini_chromium/mini_chromium/base/sys_byteorder.h
PNexternal/crashpad/third_party/mini_chromium/mini_chromium/base/template_util.h
ZXexternal/crashpad/third_party/mini_chromium/mini_chromium/base/third_party/icu/icu_utf.h
a_external/crashpad/third_party/mini_chromium/mini_chromium/base/threading/thread_local_storage.h
\Zexternal/crashpad/third_party/mini_chromium/mini_chromium/base/types/cxx23_to_underlying.h
SQexternal/crashpad/third_party/mini_chromium/mini_chromium/base/types/to_address.h
PNexternal/crashpad/third_party/mini_chromium/mini_chromium/build/build_config.h
MKexternal/crashpad/third_party/mini_chromium/mini_chromium/build/buildflag.h�	MINI_CHROMIUM_COMMON_SRCSj�2�
OMexternal/crashpad/third_party/mini_chromium/mini_chromium/base/debug/alias.cc
SQexternal/crashpad/third_party/mini_chromium/mini_chromium/base/files/file_path.cc
SQexternal/crashpad/third_party/mini_chromium/mini_chromium/base/files/file_util.cc
USexternal/crashpad/third_party/mini_chromium/mini_chromium/base/files/scoped_file.cc
KIexternal/crashpad/third_party/mini_chromium/mini_chromium/base/logging.cc
RPexternal/crashpad/third_party/mini_chromium/mini_chromium/base/process/memory.cc
MKexternal/crashpad/third_party/mini_chromium/mini_chromium/base/rand_util.cc
SQexternal/crashpad/third_party/mini_chromium/mini_chromium/base/strings/pattern.cc
RPexternal/crashpad/third_party/mini_chromium/mini_chromium/base/strings/strcat.cc
ecexternal/crashpad/third_party/mini_chromium/mini_chromium/base/strings/string_number_conversions.cc
XVexternal/crashpad/third_party/mini_chromium/mini_chromium/base/strings/stringprintf.cc
geexternal/crashpad/third_party/mini_chromium/mini_chromium/base/strings/utf_string_conversion_utils.cc
b`external/crashpad/third_party/mini_chromium/mini_chromium/base/strings/utf_string_conversions.cc
XVexternal/crashpad/third_party/mini_chromium/mini_chromium/base/synchronization/lock.cc
[Yexternal/crashpad/third_party/mini_chromium/mini_chromium/base/third_party/icu/icu_utf.cc
b`external/crashpad/third_party/mini_chromium/mini_chromium/base/threading/thread_local_storage.cc�	MINI_CHROMIUM_POSIX_SRCSj�2�
YWexternal/crashpad/third_party/mini_chromium/mini_chromium/base/files/file_util_posix.cc
ZXexternal/crashpad/third_party/mini_chromium/mini_chromium/base/memory/page_size_posix.cc
WUexternal/crashpad/third_party/mini_chromium/mini_chromium/base/posix/safe_strerror.cc
ljexternal/crashpad/third_party/mini_chromium/mini_chromium/base/synchronization/condition_variable_posix.cc
caexternal/crashpad/third_party/mini_chromium/mini_chromium/base/synchronization/lock_impl_posix.cc
hfexternal/crashpad/third_party/mini_chromium/mini_chromium/base/threading/thread_local_storage_posix.cc�	CRASHPAD_CLIENT_COMMON_HDRSj�2�
'%external/crashpad/client/annotation.h
,*external/crashpad/client/annotation_list.h
20external/crashpad/client/crash_report_database.h
,*external/crashpad/client/crashpad_client.h
*(external/crashpad/client/crashpad_info.h
97external/crashpad/client/length_delimited_ring_buffer.h
0.external/crashpad/client/prune_crash_reports.h
31external/crashpad/client/ring_buffer_annotation.h
%#external/crashpad/client/settings.h
53external/crashpad/client/simple_address_range_bag.h
53external/crashpad/client/simple_string_dictionary.h
+)external/crashpad/client/simulate_crash.hS	CRASHPAD_CLIENT_MACOS_HDRSj321
/-external/crashpad/client/simulate_crash_mac.h�	CRASHPAD_UTIL_COMMON_SRCSj�2�
64external/crashpad/util/file/delimited_file_reader.cc
,*external/crashpad/util/file/file_helper.cc
(&external/crashpad/util/file/file_io.cc
,*external/crashpad/util/file/file_reader.cc
,*external/crashpad/util/file/file_seeker.cc
,*external/crashpad/util/file/file_writer.cc
:8external/crashpad/util/file/output_stream_file_writer.cc
31external/crashpad/util/file/scoped_remove_file.cc
,*external/crashpad/util/file/string_file.cc
<:external/crashpad/util/misc/initialization_state_dcheck.cc
'%external/crashpad/util/misc/lexing.cc
(&external/crashpad/util/misc/metrics.cc
/-external/crashpad/util/misc/pdb_structures.cc
.,external/crashpad/util/misc/random_string.cc
*(external/crashpad/util/misc/range_set.cc
20external/crashpad/util/misc/reinterpret_bytes.cc
53external/crashpad/util/misc/scoped_forbid_return.cc
%#external/crashpad/util/misc/time.cc
%#external/crashpad/util/misc/uuid.cc
%#external/crashpad/util/misc/zlib.cc
)'external/crashpad/util/net/http_body.cc
.,external/crashpad/util/net/http_body_gzip.cc
64external/crashpad/util/net/http_multipart_builder.cc
.,external/crashpad/util/net/http_transport.cc
#!external/crashpad/util/net/url.cc
97external/crashpad/util/numeric/checked_address_range.cc
20external/crashpad/util/process/process_memory.cc
86external/crashpad/util/process/process_memory_range.cc
42external/crashpad/util/stdlib/aligned_allocator.cc
;9external/crashpad/util/stdlib/string_number_conversion.cc
*(external/crashpad/util/stdlib/strlcpy.cc
*(external/crashpad/util/stdlib/strnlen.cc
75external/crashpad/util/stream/base94_output_stream.cc
/-external/crashpad/util/stream/file_encoder.cc
53external/crashpad/util/stream/file_output_stream.cc
42external/crashpad/util/stream/log_output_stream.cc
53external/crashpad/util/stream/zlib_output_stream.cc
/-external/crashpad/util/string/split_string.cc
)'external/crashpad/util/thread/thread.cc
64external/crashpad/util/thread/thread_log_messages.cc
0.external/crashpad/util/thread/worker_thread.cc�		CRASHPAD_UTIL_LINUX_HDRSj�	2�	
.,external/crashpad/util/linux/address_types.h
1/external/crashpad/util/linux/auxiliary_vector.h
<:external/crashpad/util/linux/checked_linux_address_range.h
97external/crashpad/util/linux/direct_ptrace_connection.h
97external/crashpad/util/linux/exception_handler_client.h
;9external/crashpad/util/linux/exception_handler_protocol.h
64external/crashpad/util/linux/exception_information.h
+)external/crashpad/util/linux/memory_map.h
+)external/crashpad/util/linux/pac_helper.h
1/external/crashpad/util/linux/proc_stat_reader.h
1/external/crashpad/util/linux/proc_task_reader.h
.,external/crashpad/util/linux/ptrace_broker.h
.,external/crashpad/util/linux/ptrace_client.h
20external/crashpad/util/linux/ptrace_connection.h
(&external/crashpad/util/linux/ptracer.h
75external/crashpad/util/linux/scoped_pr_set_dumpable.h
64external/crashpad/util/linux/scoped_pr_set_ptracer.h
53external/crashpad/util/linux/scoped_ptrace_attach.h
'%external/crashpad/util/linux/socket.h
,*external/crashpad/util/linux/thread_info.h
'%external/crashpad/util/linux/traits.h
75external/crashpad/util/process/process_memory_linux.h
;9external/crashpad/util/process/process_memory_sanitized.h�	CRASHPAD_UTIL_MACOS_OBJC_SRCSj_2]
'%external/crashpad/util/mac/launchd.mm
20external/crashpad/util/net/http_transport_mac.mm�	CRASHPAD_UTIL_POSIX_HDRSj�2�
/-external/crashpad/util/posix/close_multiple.h
,*external/crashpad/util/posix/close_stdio.h
0.external/crashpad/util/posix/drop_privileges.h
-+external/crashpad/util/posix/process_info.h
+)external/crashpad/util/posix/scoped_dir.h
,*external/crashpad/util/posix/scoped_mmap.h
(&external/crashpad/util/posix/signals.h
1/external/crashpad/util/posix/spawn_subprocess.h
97external/crashpad/util/posix/symbolic_constants_posix.h�	CRASHPAD_UTIL_POSIX_SRCSj�2�
75external/crashpad/util/file/directory_reader_posix.cc
.,external/crashpad/util/file/file_io_posix.cc
1/external/crashpad/util/file/filesystem_posix.cc
,*external/crashpad/util/misc/clock_posix.cc
0.external/crashpad/util/posix/close_multiple.cc
-+external/crashpad/util/posix/close_stdio.cc
1/external/crashpad/util/posix/drop_privileges.cc
,*external/crashpad/util/posix/scoped_dir.cc
-+external/crashpad/util/posix/scoped_mmap.cc
)'external/crashpad/util/posix/signals.cc
20external/crashpad/util/posix/spawn_subprocess.cc
:8external/crashpad/util/posix/symbolic_constants_posix.cc
;9external/crashpad/util/synchronization/semaphore_posix.cc
/-external/crashpad/util/thread/thread_posix.cc�	CRASHPAD_CLIENT_COMMON_SRCSj�2�
(&external/crashpad/client/annotation.cc
-+external/crashpad/client/annotation_list.cc
31external/crashpad/client/crash_report_database.cc
+)external/crashpad/client/crashpad_info.cc
1/external/crashpad/client/prune_crash_reports.cc
&$external/crashpad/client/settings.cc`	CRASHPAD_CLIENT_MACOS_OBJC_SRCSj;29
75external/crashpad/client/crash_report_database_mac.mm�Exact source manifests for the sentry-native Crashpad fork.

When updating the overlay, compare normalized path multisets with the upstream
Crashpad targets so platform selections remain explicit.
� 
*
sentry_nativebazelsentry_sources.bzl�	NATIVE_DAEMON_COMMON_SRCSj�2�
75src/backends/native/minidump/sentry_minidump_common.c
97src/backends/native/minidump/sentry_minidump_indirect.c
+)src/backends/native/sentry_crash_daemon.cX	NATIVE_DAEMON_MACOS_SRCSj:28
64src/backends/native/minidump/sentry_minidump_macos.c�	NATIVE_DAEMON_PRIVATE_HDRSj�2�
75src/backends/native/minidump/sentry_minidump_common.h
75src/backends/native/minidump/sentry_minidump_format.h
97src/backends/native/minidump/sentry_minidump_indirect.h
75src/backends/native/minidump/sentry_minidump_writer.h
+)src/backends/native/sentry_crash_daemon.h�
	COMMON_PRIVATE_HDRSj�	2�	
src/sentry_alloc.h
src/sentry_app_hang_latch.h
src/sentry_app_hang_monitor.h
src/sentry_attachment.h
src/sentry_backend.h
src/sentry_batcher.h
src/sentry_boot.h
src/sentry_client_report.h
src/sentry_core.h
src/sentry_cpu_relax.h
src/sentry_database.h
src/sentry_elf.h
src/sentry_envelope.h
src/sentry_hint.h
src/sentry_integration.h
src/sentry_json.h
src/sentry_logger.h
src/sentry_logs.h
src/sentry_metrics.h
src/sentry_options.h
src/sentry_os.h
src/sentry_path.h
src/sentry_process.h
src/sentry_random.h
src/sentry_ratelimiter.h
src/sentry_retry.h
src/sentry_ringbuffer.h
src/sentry_sampling_context.h
src/sentry_scope.h
src/sentry_screenshot.h
src/sentry_session.h
src/sentry_session_replay.h
src/sentry_slice.h
src/sentry_string.h
src/sentry_symbolizer.h
src/sentry_sync.h
src/sentry_telemetry.h
src/sentry_thread_stackwalk.h
src/sentry_tracing.h
src/sentry_transport.h
src/sentry_tsan.h
!src/sentry_unix_pageallocator.h
src/sentry_unix_spinlock.h
src/sentry_utils.h
src/sentry_uuid.h
src/sentry_value.h
src/sentry_writer.h
(&src/transports/sentry_http_transport.h
 src/unwinder/sentry_unwinder.h
vendor/jsmn.h�	COMMON_SRCSj�2�
src/path/sentry_path.c
$"src/screenshot/sentry_screenshot.c
src/sentry_alloc.c
src/sentry_app_hang_latch.c
src/sentry_app_hang_monitor.c
src/sentry_attachment.c
src/sentry_backend.c
src/sentry_batcher.c
src/sentry_client_report.c
src/sentry_core.c
src/sentry_database.c
src/sentry_envelope.c
src/sentry_hint.c
src/sentry_info.c
src/sentry_json.c
src/sentry_logger.c
src/sentry_logs.c
src/sentry_metrics.c
src/sentry_options.c
src/sentry_os.c
src/sentry_ratelimiter.c
src/sentry_retry.c
src/sentry_ringbuffer.c
src/sentry_scope.c
src/sentry_session.c
src/sentry_slice.c
src/sentry_string.c
src/sentry_sync.c
src/sentry_telemetry.c
src/sentry_tracing.c
src/sentry_transport.c
src/sentry_utils.c
src/sentry_uuid.c
src/sentry_value.c
src/sentry_writer.c
,*src/session_replay/sentry_session_replay.c
,*src/transports/sentry_function_transport.c
(&src/transports/sentry_http_transport.c
 src/unwinder/sentry_unwinder.c�	
LINUX_SRCSj�2�
.,src/modulefinder/sentry_modulefinder_linux.c
.,src/modulefinder/sentry_modulefinder_linux.h
%#src/sentry_thread_stackwalk_posix.c
*(src/unwinder/sentry_unwinder_libunwind.c
vendor/stb_sprintf.c
vendor/stb_sprintf.h�	
MACOS_SRCSj�2�
.,src/modulefinder/sentry_modulefinder_apple.c
$"src/sentry_thread_stackwalk_mach.c
.,src/unwinder/sentry_unwinder_libunwind_mac.c�	NATIVE_BACKEND_PRIVATE_HDRSj�2�
,*src/backends/native/sentry_crash_context.h
,*src/backends/native/sentry_crash_handler.h
(&src/backends/native/sentry_crash_ipc.h�	NATIVE_DAEMON_LINUX_SRCSjm2k
64src/backends/native/minidump/sentry_minidump_linux.c
1/src/unwinder/sentry_unwinder_libunwind_remote.c�		UNIX_SRCSj�2�
src/path/sentry_path_unix.c
#!src/process/sentry_process_unix.c
src/sentry_random.c
!src/sentry_unix_pageallocator.c
)'src/symbolizer/sentry_symbolizer_unix.cO	DEFAULT_FEATURE_SRCSj523
1/src/session_replay/sentry_session_replay_none.c�Explicit sentry-native source manifests derived from upstream CMake.

When updating the overlay, compare normalized path multisets with the upstream
CMake target lists so platform and feature selections remain explicit.
 