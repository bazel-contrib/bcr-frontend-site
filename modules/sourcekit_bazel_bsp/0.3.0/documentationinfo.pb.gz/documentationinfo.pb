�
.
sourcekit_bazel_bsprules/internalspm.bzl�spm_release_binary_Builds a Swift package using SPM with 'swift build -c release' and returns the compiled binary."�
�
spm_release_binary_Builds a Swift package using SPM with 'swift build -c release' and returns the compiled binary.*
nameA unique name for this target. B
package_swift-The Package.swift file at the workspace root. 

srcs "C
spm_release_binary-@@sourcekit_bazel_bsp//rules/internal:spm.bzl
11,
*
nameA unique name for this target. D
B
package_swift-The Package.swift file at the workspace root. 


srcs �	BASE_SCRIPT�#!/bin/bash
set -e
ORIG_PATH=$(pwd)
PKG_PATH="{}"
PKG_DIR=$(dirname $PKG_PATH)

cd $PKG_DIR
swift build -c release
BIN_PATH=$(realpath .build/release/{})
cd $ORIG_PATH
cp $BIN_PATH "{}"
j��#!/bin/bash
set -e
ORIG_PATH=$(pwd)
PKG_PATH="{}"
PKG_DIR=$(dirname $PKG_PATH)

cd $PKG_DIR
swift build -c release
BIN_PATH=$(realpath .build/release/{})
cd $ORIG_PATH
cp $BIN_PATH "{}"
�
5
sourcekit_bazel_bsprulessetup_sourcekit_bsp.bzl�setup_sourcekit_bspYConfigures sourcekit-bazel-bsp in the current workspace using the provided configuration."�
�
setup_sourcekit_bspYConfigures sourcekit-bazel-bsp in the current workspace using the provided configuration.*
nameA unique name for this target. R
bazel_wrapper6The name of the Bazel CLI to invoke (e.g. 'bazelisk').2"bazel"�
compile_top_level�Instead of attempting to build targets individually, build the top-level parent. If your project contains build_test targets for your individual libraries and you're passing them as the top-level targets for the BSP, you can use this flag to build those targets directly for better predictability and caching.2FalseB
files_to_watch*A list of file globs to watch for changes.2[]�
index_build_batch_size�The number of targets to prepare in parallel. If not specified, SourceKit-LSP will calculate an appropriate value based on the environment. Requires compile_top_level and using the pre-built SourceKit-LSP binary from the release archive.20y
index_flagsdFlags that should be passed to all indexing-related Bazel invocations. Do not include the -- prefix.2[]�
sourcekit_bazel_bspUThe path to the sourcekit-bazel-bsp binary. Will compile from source if not provided.2//Sources:sourcekit-bazel-bsp�
targets�The *top level* Bazel applications or test targets that this should serve a BSP for. It's best to keep this list small if possible for performance reasons. If not specified, the server will try to discover top-level targets automatically �
top_level_rules_to_discover�A list of top-level rule types to discover targets for (e.g. 'ios_application', 'ios_unit_test'). Only applicable when not specifying targets directly. If not specified, all supported top-level rule types will be used for target discovery.2[]"K
setup_sourcekit_bsp4@@sourcekit_bazel_bsp//rules:setup_sourcekit_bsp.bzl
88,
*
nameA unique name for this target. T
R
bazel_wrapper6The name of the Bazel CLI to invoke (e.g. 'bazelisk').2"bazel"�
�
compile_top_level�Instead of attempting to build targets individually, build the top-level parent. If your project contains build_test targets for your individual libraries and you're passing them as the top-level targets for the BSP, you can use this flag to build those targets directly for better predictability and caching.2FalseD
B
files_to_watch*A list of file globs to watch for changes.2[]�
�
index_build_batch_size�The number of targets to prepare in parallel. If not specified, SourceKit-LSP will calculate an appropriate value based on the environment. Requires compile_top_level and using the pre-built SourceKit-LSP binary from the release archive.20{
y
index_flagsdFlags that should be passed to all indexing-related Bazel invocations. Do not include the -- prefix.2[]�
�
sourcekit_bazel_bspUThe path to the sourcekit-bazel-bsp binary. Will compile from source if not provided.2//Sources:sourcekit-bazel-bsp�
�
targets�The *top level* Bazel applications or test targets that this should serve a BSP for. It's best to keep this list small if possible for performance reasons. If not specified, the server will try to discover top-level targets automatically �
�
top_level_rules_to_discover�A list of top-level rule types to discover targets for (e.g. 'ios_application', 'ios_unit_test'). Only applicable when not specifying targets directly. If not specified, all supported top-level rule types will be used for target discovery.2[] 