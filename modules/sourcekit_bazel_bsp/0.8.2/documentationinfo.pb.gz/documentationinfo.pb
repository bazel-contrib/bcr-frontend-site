�
.
sourcekit_bazel_bsprules/internalspm.bzl�spm_release_binary_Builds a Swift package using SPM with 'swift build -c release' and returns the compiled binary."�
�
spm_release_binary_Builds a Swift package using SPM with 'swift build -c release' and returns the compiled binary.*
nameA unique name for this target. B
package_swift-The Package.swift file at the workspace root. 

srcs "C
spm_release_binary-@@sourcekit_bazel_bsp//rules/internal:spm.bzl
11,
*
nameA unique name for this target. D
B
package_swift-The Package.swift file at the workspace root. 


srcs �	BASE_SCRIPT�#!/bin/bash
set -e
ORIG_PATH=$(pwd)
PKG_PATH="{}"
PKG_DIR=$(dirname $PKG_PATH)

cd $PKG_DIR
swift build -c release
BIN_PATH=$(realpath .build/release/{})
cd $ORIG_PATH
cp $BIN_PATH "{}"
j��#!/bin/bash
set -e
ORIG_PATH=$(pwd)
PKG_PATH="{}"
PKG_DIR=$(dirname $PKG_PATH)

cd $PKG_DIR
swift build -c release
BIN_PATH=$(realpath .build/release/{})
cd $ORIG_PATH
cp $BIN_PATH "{}"
�8
5
sourcekit_bazel_bsprulessetup_sourcekit_bsp.bzl�7setup_sourcekit_bspYConfigures sourcekit-bazel-bsp in the current workspace using the provided configuration."�7
�
setup_sourcekit_bspYConfigures sourcekit-bazel-bsp in the current workspace using the provided configuration.*
nameA unique name for this target. �
apple_support_repo_namekThe name of the apple_support external repository in your workspace. Change this if using a different name.2"apple_support"�
aquery_flagsvFlags that should be passed to the aquery invocations used to gather compiler arguments. Do not include the -- prefix.2[]R
bazel_wrapper6The name of the Bazel CLI to invoke (e.g. 'bazelisk').2"bazel"�
compile_top_level�When enabled, builds entire top-level targets instead of using the aspect-based approach for individual libraries. This is slower but may be needed for certain build configurations. If your project contains build_test targets for your individual libraries and you're passing them as the top-level targets for the BSP, you can use this flag to build those targets directly for better predictability and caching.2False�
dependency_rules_to_discover�A list of dependency rule types to discover targets for (e.g. 'swift_library', 'objc_library', 'cc_library'). If not specified, all supported dependency rule types will be used for target discovery.2[]�
dependency_targets_to_excludeuA list of target patterns to exclude from dependency targets in the cquery. Wildcards are supported (e.g. //foo/...).2[]�
!experimental_no_extra_output_base�(EXPERIMENTAL) If enabled, the BSP will not create a separate output base for its indexing actions. Can greatly reduce disk usage and improve cache hits at the cost of more pressure on the single Bazel server.2False�
experimental_shared_index_store�(EXPERIMENTAL) If enabled, the BSP will create a symlink so that the BSP's output base shares the index store with the main output base. This allows both regular builds and BSP builds to share the same index data. Has no effect if experimental_no_extra_output_base is enabled.2FalseB
files_to_watch*A list of file globs to watch for changes.2[]p
index_build_batch_sizeQThe number of targets to prepare in parallel. If not provided, will default to 1.20y
index_flagsdFlags that should be passed to all indexing-related Bazel invocations. Do not include the -- prefix.2[]o
lsp_timeout[A custom timeout value to provide to sourcekit-lsp when waiting for responses from the BSP.20�
merge_lsp_config�If set to true, the generated .sourcekit-lsp/config.json will merge with any existing contents instead of fully overriding the file.2True�
query_flagsoFlags that should be passed to the query invocations used to validate file paths. Do not include the -- prefix.2[]�
sourcekit_bazel_bspUThe path to the sourcekit-bazel-bsp binary. Will compile from source if not provided.2//Sources:sourcekit-bazel-bsp�
targets�The *top level* Bazel applications or test targets that this should serve a BSP for. Wildcards are supported (e.g. //foo/...). It's best to keep this list small if possible for performance reasons. If not specified, the server will try to discover top-level targets automatically �
top_level_rules_to_discover�A list of top-level rule types to discover targets for (e.g. 'ios_application', 'ios_unit_test'). If not specified, all supported top-level rule types will be used for target discovery.2[]�
top_level_targets_to_excludetA list of target patterns to exclude from top-level targets in the cquery. Wildcards are supported (e.g. //foo/...).2[]"K
setup_sourcekit_bsp4@@sourcekit_bazel_bsp//rules:setup_sourcekit_bsp.bzl
uu,
*
nameA unique name for this target. �
�
apple_support_repo_namekThe name of the apple_support external repository in your workspace. Change this if using a different name.2"apple_support"�
�
aquery_flagsvFlags that should be passed to the aquery invocations used to gather compiler arguments. Do not include the -- prefix.2[]T
R
bazel_wrapper6The name of the Bazel CLI to invoke (e.g. 'bazelisk').2"bazel"�
�
compile_top_level�When enabled, builds entire top-level targets instead of using the aspect-based approach for individual libraries. This is slower but may be needed for certain build configurations. If your project contains build_test targets for your individual libraries and you're passing them as the top-level targets for the BSP, you can use this flag to build those targets directly for better predictability and caching.2False�
�
dependency_rules_to_discover�A list of dependency rule types to discover targets for (e.g. 'swift_library', 'objc_library', 'cc_library'). If not specified, all supported dependency rule types will be used for target discovery.2[]�
�
dependency_targets_to_excludeuA list of target patterns to exclude from dependency targets in the cquery. Wildcards are supported (e.g. //foo/...).2[]�
�
!experimental_no_extra_output_base�(EXPERIMENTAL) If enabled, the BSP will not create a separate output base for its indexing actions. Can greatly reduce disk usage and improve cache hits at the cost of more pressure on the single Bazel server.2False�
�
experimental_shared_index_store�(EXPERIMENTAL) If enabled, the BSP will create a symlink so that the BSP's output base shares the index store with the main output base. This allows both regular builds and BSP builds to share the same index data. Has no effect if experimental_no_extra_output_base is enabled.2FalseD
B
files_to_watch*A list of file globs to watch for changes.2[]r
p
index_build_batch_sizeQThe number of targets to prepare in parallel. If not provided, will default to 1.20{
y
index_flagsdFlags that should be passed to all indexing-related Bazel invocations. Do not include the -- prefix.2[]q
o
lsp_timeout[A custom timeout value to provide to sourcekit-lsp when waiting for responses from the BSP.20�
�
merge_lsp_config�If set to true, the generated .sourcekit-lsp/config.json will merge with any existing contents instead of fully overriding the file.2True�
�
query_flagsoFlags that should be passed to the query invocations used to validate file paths. Do not include the -- prefix.2[]�
�
sourcekit_bazel_bspUThe path to the sourcekit-bazel-bsp binary. Will compile from source if not provided.2//Sources:sourcekit-bazel-bsp�
�
targets�The *top level* Bazel applications or test targets that this should serve a BSP for. Wildcards are supported (e.g. //foo/...). It's best to keep this list small if possible for performance reasons. If not specified, the server will try to discover top-level targets automatically �
�
top_level_rules_to_discover�A list of top-level rule types to discover targets for (e.g. 'ios_application', 'ios_unit_test'). If not specified, all supported top-level rule types will be used for target discovery.2[]�
�
top_level_targets_to_excludetA list of target patterns to exclude from top-level targets in the cquery. Wildcards are supported (e.g. //foo/...).2[] 