�
1

sphinxdocssphinxdocs/privatereadthedocs.bzl��readthedocs_install�Run a program to copy Sphinx doc files into readthedocs output directories.

This is intended to be run using `bazel run` during the readthedocs
build process when the build process is overridden. See
https://docs.readthedocs.io/en/stable/build-customization.html#override-the-build-process
for more information.
"��
�Q
readthedocs_install�Run a program to copy Sphinx doc files into readthedocs output directories.

This is intended to be run using `bazel run` during the readthedocs
build process when the build process is overridden. See
https://docs.readthedocs.io/en/stable/build-customization.html#override-the-build-process
for more information.
*
nameA unique name for this target. �	
config_settings�	
Config settings to change for this target.

The keys are labels for settings, and the values are strings for the new value
to use. Pass `Label` objects or canonical label strings for the keys to ensure
they resolve as expected (canonical labels start with `@@` and can be
obtained by calling `str(Label(...))`).

Most `@rules_python//python/config_setting` settings can be used here, which
allows, for example, making only a certain `py_binary` use
{obj}`--boostrap_impl=script`.

Additional or custom config settings can be registered using the
{obj}`add_transition_setting` API. This allows, for example, forcing a
particular CPU, or defining a custom setting that `select()` uses elsewhere
to pick between `pip.parse` hubs. See the [How to guide on multiple
versions of a library] for a more concrete example.

:::{note}
These values are transitioned on, so will affect the analysis graph and the
associated memory overhead. The more unique configurations in your overall
build, the more memory and (often unnecessary) re-analysis and re-building
can occur. See
https://bazel.build/extending/config#memory-performance-considerations for
more information about risks and considerations.
:::

:::{versionadded} 1.7.0
:::
	2{}�
data�
The list of files need by this library at runtime. See comments about
the [`data` attribute typically defined by rules](https://bazel.build/reference/be/common-definitions#typical-attributes).

There is no `py_embed_data` like there is `cc_embed_data` and `go_embed_data`.
This is because Python has a concept of runtime resources.
2[]�
deps�
List of additional libraries to be linked in to the target.
See comments about
the [`deps` attribute typically defined by
rules](https://bazel.build/reference/be/common-definitions#typical-attributes).
These are typically `py_library` rules.

Targets that only provide data files used at runtime belong in the `data`
attribute.

:::{note}
The order of this list can matter because it affects the order that information
from dependencies is merged in, which can be relevant depending on the ordering
mode of depsets that are merged.

* {obj}`PyInfo.venv_symlinks` uses default ordering.

See {obj}`PyInfo` for more information about the ordering of its depsets and
how its fields are merged.
:::
*
PyInfo*
CcInfo*
BuiltinPyInfo2[]
distribs2[]�
env�Dictionary of strings; optional; values are subject to `$(location)` and "Make
variable" substitution.

Specifies additional environment variables to set when the target is executed by
`test` or `run`.

2{}�
imports�
List of import directories to be added to the PYTHONPATH.

Subject to "Make variable" substitution. These import directories will be added
for this rule and all rules that depend on it (note: not the rules this rule
depends on. Each directory will be added to `PYTHONPATH` by `py_binary` rules
that depend on this rule. The strings are repo-runfiles-root relative,

Absolute paths (paths that start with `/`) and paths that references a path
above the execution root are not allowed and will result in an error.
2[]�
interpreter_args�
Arguments that are only applicable to the interpreter.

The args an interpreter supports are specific to the interpreter. For
CPython, see https://docs.python.org/3/using/cmdline.html.

:::{note}
Only supported for {obj}`--bootstrap_impl=script`. Ignored otherwise.
:::

:::{seealso}
The {any}`RULES_PYTHON_ADDITIONAL_INTERPRETER_ARGS` environment variable
:::

:::{versionadded} 1.3.0
:::
2[]�
legacy_create_init�Whether to implicitly create empty `__init__.py` files in the runfiles tree.
These are created in every directory containing Python source code or shared
libraries, and every parent directory of those directories, excluding the repo
root directory. The default, `-1` (auto), means true unless
`--incompatible_default_to_explicit_init_py` is used. If false, the user is
responsible for creating (possibly empty) `__init__.py` files and adding them to
the `srcs` of Python targets as required.
2-1
licenses2[]�
main�Optional; the name of the source file that is the main entry point of the
application. This file must also be listed in `srcs`. If left unspecified,
`name`, with `.py` appended, is used instead. If `name` does not match any
filename in `srcs`, `main` must be specified.

This is mutually exclusive with {obj}`main_module`.
2None�
main_module�
Module name to execute as the main program.

When set, `srcs` is not required, and it is assumed the module is
provided by a dependency.

See https://docs.python.org/3/using/cmdline.html#cmdoption-m for more
information about running modules as the main program.

This is mutually exclusive with {obj}`main`.

:::{versionadded} 1.3.0
:::
:::{versionchanged} 1.7.0
Support added for {obj}`--bootstrap_impl=system_python`.
:::
2""�

precompile�
Whether py source files **for this target** should be precompiled.

Values:

* `inherit`: Allow the downstream binary decide if precompiled files are used.
* `enabled`: Compile Python source files at build time.
* `disabled`: Don't compile Python source files at build time.

:::{seealso}

* The {flag}`--precompile` flag, which can override this attribute in some cases
  and will affect all targets when building.
* The {obj}`pyc_collection` attribute for transitively enabling precompiling on
  a per-target basis.
* The [Precompiling](precompiling) docs for a guide about using precompiling.
:::
2	"inherit"�
precompile_invalidation_mode�
How precompiled files should be verified to be up-to-date with their associated
source files. Possible values are:
* `auto`: The effective value will be automatically determined by other build
  settings.
* `checked_hash`: Use the pyc file if the hash of the source file matches the hash
  recorded in the pyc file. This is most useful when working with code that
  you may modify.
* `unchecked_hash`: Always use the pyc file; don't check the pyc's hash against
  the source file. This is most useful when the code won't be modified.

For more information on pyc invalidation modes, see
https://docs.python.org/3/library/py_compile.html#py_compile.PycInvalidationMode
2"auto"�
precompile_optimize_level�
The optimization level for precompiled files.

For more information about optimization levels, see the `compile()` function's
`optimize` arg docs at https://docs.python.org/3/library/functions.html#compile

NOTE: The value `-1` means "current interpreter", which will be the interpreter
used _at build time when pycs are generated_, not the interpreter used at
runtime when the code actually runs.
20�
precompile_source_retention�
Determines, when a source file is compiled, if the source file is kept
in the resulting output or not. Valid values are:

* `inherit`: Inherit the value from the {flag}`--precompile_source_retention` flag.
* `keep_source`: Include the original Python source.
* `omit_source`: Don't include the original py source.
2	"inherit"�
pyc_collection�
Determines whether pyc files from dependencies should be manually included.

Valid values are:
* `inherit`: Inherit the value from {flag}`--precompile`.
* `include_pyc`: Add implicitly generated pyc files from dependencies. i.e.
  pyc files for targets that specify {attr}`precompile="inherit"`.
* `disabled`: Don't add implicitly generated pyc files. Note that
  pyc files may still come from dependencies that enable precompiling at the
  target level.
2	"inherit"�
pyi_deps�
Dependencies providing type definitions the library needs.

These are dependencies that satisfy imports guarded by `typing.TYPE_CHECKING`.
These are build-time only dependencies and not included as part of a runnable
program (packaging rules may include them, however).

:::{versionadded} 1.1.0
:::
*
PyInfo*
CcInfo*
BuiltinPyInfo2[]�
pyi_srcs�
Type definition files for the library.

These are typically `.pyi` files, but other file types for type-checker specific
formats are allowed. These files are build-time only dependencies and not included
as part of a runnable program (packaging rules may include them, however).

:::{versionadded} 1.1.0
:::
2[]�
python_version�
The Python version this target should use.

The value should be in `X.Y` or `X.Y.Z` (or compatible) format. If empty or
unspecified, the incoming configuration's {obj}`--python_version` flag is
inherited. For backwards compatibility, the values `PY2` and `PY3` are
accepted, but treated as an empty/unspecified value.

:::{note}
In order for the requested version to be used, there must be a
toolchain configured to match the Python version. If there isn't, then it
may be silently ignored, or an error may occur, depending on the toolchain
configuration.
:::

:::{versionchanged} 1.1.0

This attribute was changed from only accepting `PY2` and `PY3` values to
accepting arbitrary Python versions.
:::
2""�
srcs�
The list of Python source files that are processed to create the target. This
includes all your checked-in code and may include generated source files.  The
`.py` files belong in `srcs` and library targets belong in `deps`. Other binary
files that may be needed at run time belong in `data`.
2[]4
srcs_versionDefunct, unused, does nothing.2""�
stamp�
Whether to encode build information into the binary. Possible values:

* `stamp = 1`: Always stamp the build information into the binary, even in
  `--nostamp` builds. **This setting should be avoided**, since it potentially kills
  remote caching for the binary and any downstream actions that depend on it.
* `stamp = 0`: Always replace build information by constant values. This gives
  good build result caching.
* `stamp = -1`: Embedding of build information is controlled by the
  `--[no]stamp` flag.

Stamped binaries are not rebuilt unless their dependencies change.

WARNING: Stamping can harm build performance by reducing cache hits and should
be avoided if possible.
2-1
,
*
nameA unique name for this target. �	
�	
config_settings�	
Config settings to change for this target.

The keys are labels for settings, and the values are strings for the new value
to use. Pass `Label` objects or canonical label strings for the keys to ensure
they resolve as expected (canonical labels start with `@@` and can be
obtained by calling `str(Label(...))`).

Most `@rules_python//python/config_setting` settings can be used here, which
allows, for example, making only a certain `py_binary` use
{obj}`--boostrap_impl=script`.

Additional or custom config settings can be registered using the
{obj}`add_transition_setting` API. This allows, for example, forcing a
particular CPU, or defining a custom setting that `select()` uses elsewhere
to pick between `pip.parse` hubs. See the [How to guide on multiple
versions of a library] for a more concrete example.

:::{note}
These values are transitioned on, so will affect the analysis graph and the
associated memory overhead. The more unique configurations in your overall
build, the more memory and (often unnecessary) re-analysis and re-building
can occur. See
https://bazel.build/extending/config#memory-performance-considerations for
more information about risks and considerations.
:::

:::{versionadded} 1.7.0
:::
	2{}�
�
data�
The list of files need by this library at runtime. See comments about
the [`data` attribute typically defined by rules](https://bazel.build/reference/be/common-definitions#typical-attributes).

There is no `py_embed_data` like there is `cc_embed_data` and `go_embed_data`.
This is because Python has a concept of runtime resources.
2[]�
�
deps�
List of additional libraries to be linked in to the target.
See comments about
the [`deps` attribute typically defined by
rules](https://bazel.build/reference/be/common-definitions#typical-attributes).
These are typically `py_library` rules.

Targets that only provide data files used at runtime belong in the `data`
attribute.

:::{note}
The order of this list can matter because it affects the order that information
from dependencies is merged in, which can be relevant depending on the ordering
mode of depsets that are merged.

* {obj}`PyInfo.venv_symlinks` uses default ordering.

See {obj}`PyInfo` for more information about the ordering of its depsets and
how its fields are merged.
:::
*
PyInfo*
CcInfo*
BuiltinPyInfo2[]

distribs2[]�
�
env�Dictionary of strings; optional; values are subject to `$(location)` and "Make
variable" substitution.

Specifies additional environment variables to set when the target is executed by
`test` or `run`.

2{}�
�
imports�
List of import directories to be added to the PYTHONPATH.

Subject to "Make variable" substitution. These import directories will be added
for this rule and all rules that depend on it (note: not the rules this rule
depends on. Each directory will be added to `PYTHONPATH` by `py_binary` rules
that depend on this rule. The strings are repo-runfiles-root relative,

Absolute paths (paths that start with `/`) and paths that references a path
above the execution root are not allowed and will result in an error.
2[]�
�
interpreter_args�
Arguments that are only applicable to the interpreter.

The args an interpreter supports are specific to the interpreter. For
CPython, see https://docs.python.org/3/using/cmdline.html.

:::{note}
Only supported for {obj}`--bootstrap_impl=script`. Ignored otherwise.
:::

:::{seealso}
The {any}`RULES_PYTHON_ADDITIONAL_INTERPRETER_ARGS` environment variable
:::

:::{versionadded} 1.3.0
:::
2[]�
�
legacy_create_init�Whether to implicitly create empty `__init__.py` files in the runfiles tree.
These are created in every directory containing Python source code or shared
libraries, and every parent directory of those directories, excluding the repo
root directory. The default, `-1` (auto), means true unless
`--incompatible_default_to_explicit_init_py` is used. If false, the user is
responsible for creating (possibly empty) `__init__.py` files and adding them to
the `srcs` of Python targets as required.
2-1

licenses2[]�
�
main�Optional; the name of the source file that is the main entry point of the
application. This file must also be listed in `srcs`. If left unspecified,
`name`, with `.py` appended, is used instead. If `name` does not match any
filename in `srcs`, `main` must be specified.

This is mutually exclusive with {obj}`main_module`.
2None�
�
main_module�
Module name to execute as the main program.

When set, `srcs` is not required, and it is assumed the module is
provided by a dependency.

See https://docs.python.org/3/using/cmdline.html#cmdoption-m for more
information about running modules as the main program.

This is mutually exclusive with {obj}`main`.

:::{versionadded} 1.3.0
:::
:::{versionchanged} 1.7.0
Support added for {obj}`--bootstrap_impl=system_python`.
:::
2""�
�

precompile�
Whether py source files **for this target** should be precompiled.

Values:

* `inherit`: Allow the downstream binary decide if precompiled files are used.
* `enabled`: Compile Python source files at build time.
* `disabled`: Don't compile Python source files at build time.

:::{seealso}

* The {flag}`--precompile` flag, which can override this attribute in some cases
  and will affect all targets when building.
* The {obj}`pyc_collection` attribute for transitively enabling precompiling on
  a per-target basis.
* The [Precompiling](precompiling) docs for a guide about using precompiling.
:::
2	"inherit"�
�
precompile_invalidation_mode�
How precompiled files should be verified to be up-to-date with their associated
source files. Possible values are:
* `auto`: The effective value will be automatically determined by other build
  settings.
* `checked_hash`: Use the pyc file if the hash of the source file matches the hash
  recorded in the pyc file. This is most useful when working with code that
  you may modify.
* `unchecked_hash`: Always use the pyc file; don't check the pyc's hash against
  the source file. This is most useful when the code won't be modified.

For more information on pyc invalidation modes, see
https://docs.python.org/3/library/py_compile.html#py_compile.PycInvalidationMode
2"auto"�
�
precompile_optimize_level�
The optimization level for precompiled files.

For more information about optimization levels, see the `compile()` function's
`optimize` arg docs at https://docs.python.org/3/library/functions.html#compile

NOTE: The value `-1` means "current interpreter", which will be the interpreter
used _at build time when pycs are generated_, not the interpreter used at
runtime when the code actually runs.
20�
�
precompile_source_retention�
Determines, when a source file is compiled, if the source file is kept
in the resulting output or not. Valid values are:

* `inherit`: Inherit the value from the {flag}`--precompile_source_retention` flag.
* `keep_source`: Include the original Python source.
* `omit_source`: Don't include the original py source.
2	"inherit"�
�
pyc_collection�
Determines whether pyc files from dependencies should be manually included.

Valid values are:
* `inherit`: Inherit the value from {flag}`--precompile`.
* `include_pyc`: Add implicitly generated pyc files from dependencies. i.e.
  pyc files for targets that specify {attr}`precompile="inherit"`.
* `disabled`: Don't add implicitly generated pyc files. Note that
  pyc files may still come from dependencies that enable precompiling at the
  target level.
2	"inherit"�
�
pyi_deps�
Dependencies providing type definitions the library needs.

These are dependencies that satisfy imports guarded by `typing.TYPE_CHECKING`.
These are build-time only dependencies and not included as part of a runnable
program (packaging rules may include them, however).

:::{versionadded} 1.1.0
:::
*
PyInfo*
CcInfo*
BuiltinPyInfo2[]�
�
pyi_srcs�
Type definition files for the library.

These are typically `.pyi` files, but other file types for type-checker specific
formats are allowed. These files are build-time only dependencies and not included
as part of a runnable program (packaging rules may include them, however).

:::{versionadded} 1.1.0
:::
2[]�
�
python_version�
The Python version this target should use.

The value should be in `X.Y` or `X.Y.Z` (or compatible) format. If empty or
unspecified, the incoming configuration's {obj}`--python_version` flag is
inherited. For backwards compatibility, the values `PY2` and `PY3` are
accepted, but treated as an empty/unspecified value.

:::{note}
In order for the requested version to be used, there must be a
toolchain configured to match the Python version. If there isn't, then it
may be silently ignored, or an error may occur, depending on the toolchain
configuration.
:::

:::{versionchanged} 1.1.0

This attribute was changed from only accepting `PY2` and `PY3` values to
accepting arbitrary Python versions.
:::
2""�
�
srcs�
The list of Python source files that are processed to create the target. This
includes all your checked-in code and may include generated source files.  The
`.py` files belong in `srcs` and library targets belong in `deps`. Other binary
files that may be needed at run time belong in `data`.
2[]6
4
srcs_versionDefunct, unused, does nothing.2""�
�
stamp�
Whether to encode build information into the binary. Possible values:

* `stamp = 1`: Always stamp the build information into the binary, even in
  `--nostamp` builds. **This setting should be avoided**, since it potentially kills
  remote caching for the binary and any downstream actions that depend on it.
* `stamp = 0`: Always replace build information by constant values. This gives
  good build result caching.
* `stamp = -1`: Embedding of build information is controlled by the
  `--[no]stamp` flag.

Stamped binaries are not rebuilt unless their dependencies change.

WARNING: Stamping can harm build performance by reducing cache hits and should
be avoided if possible.
2-1w
//python:py_binary.bzlr[
%
rules_pythonpythonpy_binary.bzl$
	py_binary	py_binary
.7
9
//sphinxdocs/private:util.bzlr\
*

sphinxdocssphinxdocs/privateutil.bzl 
add_tagadd_tag
3:
<6Starlark rules for integrating Sphinx and Readthedocs.�;
,

sphinxdocssphinxdocs/private
sphinx.bzl�repeated_string_list_flag"�
�
repeated_string_list_flag*
nameA unique name for this target. "H
repeated_string_list_flag+@@sphinxdocs//sphinxdocs/private:sphinx.bzl
�!�!,
*
nameA unique name for this target. �
sphinx_run�
Directly run the underlying Sphinx command `sphinx_docs` uses.

This is primarily a debugging tool. It's useful for directly running the
Sphinx command so that debuggers can be attached or output more directly
inspected without Bazel interference.
"�
�

sphinx_run�
Directly run the underlying Sphinx command `sphinx_docs` uses.

This is primarily a debugging tool. It's useful for directly running the
Sphinx command so that debuggers can be attached or output more directly
inspected without Bazel interference.
*
nameA unique name for this target. 8
builder#The output format to make runnable.2"html"Z
docs8The {obj}`sphinx_docs` target to make directly runnable.*
_SphinxRunInfo2None"9

sphinx_run+@@sphinxdocs//sphinxdocs/private:sphinx.bzl
��,
*
nameA unique name for this target. :
8
builder#The output format to make runnable.2"html"\
Z
docs8The {obj}`sphinx_docs` target to make directly runnable.*
_SphinxRunInfo2None�sphinx_docs�Generate docs using Sphinx.

Generates targets:
* `<name>`: The output of this target is a directory for each
  format Sphinx creates. This target also has a separate output
  group for each format. e.g. `--output_group=html` will only build
  the "html" format files.
* `<name>.serve`: A binary that locally serves the HTML output. This
  allows previewing docs during development.
* `<name>.run`: A binary that directly runs the underlying Sphinx command
  to build the docs. This is a debugging aid.
"�

�
sphinx_docs�Generate docs using Sphinx.

Generates targets:
* `<name>`: The output of this target is a directory for each
  format Sphinx creates. This target also has a separate output
  group for each format. e.g. `--output_group=html` will only build
  the "html" format files.
* `<name>.serve`: A binary that locally serves the HTML output. This
  allows previewing docs during development.
* `<name>.run`: A binary that directly runs the underlying Sphinx command
  to build the docs. This is a debugging aid.
*
nameA unique name for this target. $
configConfig file for Sphinx %
deps*
SphinxDocsLibraryInfo2[]�
renamed_srcs~Doc source files for Sphinx that are renamed. This is typically used for files elsewhere, such as top level files in the repo.	2{}*
srcsDoc source files for Sphinx.2[]=
strip_prefix'Prefix to remove from input file paths.2"""B
_sphinx_source_tree+@@sphinxdocs//sphinxdocs/private:sphinx.bzl
^^,
*
nameA unique name for this target. &
$
configConfig file for Sphinx '
%
deps*
SphinxDocsLibraryInfo2[]�
�
renamed_srcs~Doc source files for Sphinx that are renamed. This is typically used for files elsewhere, such as top level files in the repo.	2{},
*
srcsDoc source files for Sphinx.2[]?
=
strip_prefix'Prefix to remove from input file paths.2""�sphinx_inventory�	Creates a compressed inventory file from an uncompressed on.

The Sphinx inventory format isn't formally documented, but is understood
to be:

```
# Sphinx inventory version 2
# Project: <project name>
# Version: <version string>
# The remainder of this file is compressed using zlib
name domain:role 1 relative-url display name
```

Where:
  * `<project name>` is a string. e.g. `Rules Python`
  * `<version string>` is a string e.g. `1.5.3`

And there are one or more `name domain:role ...` lines
  * `name`: the name of the symbol. It can contain special characters,
    but not spaces.
  * `domain:role`: The `domain` is usually a language, e.g. `py` or `bzl`.
    The `role` is usually the type of object, e.g. `class` or `func`. There
    is no canonical meaning to the values, they are usually domain-specific.
  * `1` is a number. It affects search priority.
  * `relative-url` is a URL path relative to the base url in the
    confg.py intersphinx config.
  * `display name` is a string. It can contain spaces, or simply be
    the value `-` to indicate it is the same as `name`

:::{seealso}
{bzl:obj}`//inventories` for inventories of Bazel objects.
:::
"�

�

sphinx_inventory�	Creates a compressed inventory file from an uncompressed on.

The Sphinx inventory format isn't formally documented, but is understood
to be:

```
# Sphinx inventory version 2
# Project: <project name>
# Version: <version string>
# The remainder of this file is compressed using zlib
name domain:role 1 relative-url display name
```

Where:
  * `<project name>` is a string. e.g. `Rules Python`
  * `<version string>` is a string e.g. `1.5.3`

And there are one or more `name domain:role ...` lines
  * `name`: the name of the symbol. It can contain special characters,
    but not spaces.
  * `domain:role`: The `domain` is usually a language, e.g. `py` or `bzl`.
    The `role` is usually the type of object, e.g. `class` or `func`. There
    is no canonical meaning to the values, they are usually domain-specific.
  * `1` is a number. It affects search priority.
  * `relative-url` is a URL path relative to the base url in the
    confg.py intersphinx config.
  * `display name` is a string. It can contain spaces, or simply be
    the value `-` to indicate it is the same as `name`

:::{seealso}
{bzl:obj}`//inventories` for inventories of Bazel objects.
:::
*
nameA unique name for this target. 
src2None"@
_sphinx_inventory+@@sphinxdocs//sphinxdocs/private:sphinx.bzl
��,
*
nameA unique name for this target. 

src2None�sphinx_build_binary�Create an executable with the sphinx-build command line interface.

The `deps` must contain the sphinx library and any other extensions Sphinx
needs at runtime.
*�
�
sphinx_build_binary~
namer{type}`str` name of the target. The name "sphinx-build" is the
conventional name to match what Sphinx itself uses. (�
py_binary_rule�{type}`callable` A `py_binary` compatible callable
for creating the target. If not set, the regular `py_binary`
rule is used. This allows using the version-aware rules, or
other alternative implementations.><function py_binary from @@rules_python//python:py_binary.bzl>(|
kwargsp{type}`dict` Additional kwargs to pass onto `py_binary`. The `srcs` and
`main` attributes must not be specified.(�Create an executable with the sphinx-build command line interface.

The `deps` must contain the sphinx library and any other extensions Sphinx
needs at runtime.
2B
sphinx_build_binary+@@sphinxdocs//sphinxdocs/private:sphinx.bzl
FF*py_binary_rule2py_binary_rulea
//lib:paths.bzlrL

bazel_skyliblib	paths.bzl
pathspaths
',
.�
//rules:common_settings.bzlrn
*
bazel_skylibrulescommon_settings.bzl2
BuildSettingInfoBuildSettingInfo
3C
Ew
//python:py_binary.bzlr[
%
rules_pythonpythonpy_binary.bzl$
	py_binary	py_binary
.7
9�
1//sphinxdocs/private:sphinx_docs_library_info.bzlr�
>

sphinxdocssphinxdocs/privatesphinx_docs_library_info.bzl<
SphinxDocsLibraryInfoSphinxDocsLibraryInfo
G\
^�
//sphinxdocs/private:util.bzlr�
*

sphinxdocssphinxdocs/privateutil.bzl 
add_tagadd_tag
3:@
copy_propagating_kwargscopy_propagating_kwargs
>U
WImplementation of sphinx rules.�

9

sphinxdocssphinxdocs/privatesphinx_docs_library.bzl�sphinx_docs_library"�
�
sphinx_docs_library*
nameA unique name for this target. �
deps�
Additional `sphinx_docs_library` targets to include. They do not have the
`prefix` and `strip_prefix` attributes applied to them.*
SphinxDocsLibraryInfo2[]W
prefixGPrefix to prepend to file paths. Added after `strip_prefix` is removed.2""1
srcs#Files that are part of the library.2[]]
strip_prefixGPrefix to remove from file paths. Removed before `prefix` is prepended.2"""O
sphinx_docs_library8@@sphinxdocs//sphinxdocs/private:sphinx_docs_library.bzl
,
*
nameA unique name for this target. �
�
deps�
Additional `sphinx_docs_library` targets to include. They do not have the
`prefix` and `strip_prefix` attributes applied to them.*
SphinxDocsLibraryInfo2[]Y
W
prefixGPrefix to prepend to file paths. Added after `strip_prefix` is removed.2""3
1
srcs#Files that are part of the library.2[]_
]
strip_prefixGPrefix to remove from file paths. Removed before `prefix` is prepended.2""�
1//sphinxdocs/private:sphinx_docs_library_info.bzlr�
>

sphinxdocssphinxdocs/privatesphinx_docs_library_info.bzl<
SphinxDocsLibraryInfoSphinxDocsLibraryInfo
G\
^&Implementation of sphinx_docs_library.�

>

sphinxdocssphinxdocs/privatesphinx_docs_library_info.bzl�	SphinxDocsLibraryInfo,Information about a collection of doc files.2�
�
SphinxDocsLibraryInfo,Information about a collection of doc files.H
files?
:type: depset[File]

The documentation files for the library.
p
prefixf
:type: str

Prefix to prepend to file paths in `files`. It is added after `strip_prefix`
is removed.
v
strip_prefixf
:type: str

Prefix to remove from file paths in `files`. It is removed before `prefix`
is prepended.
�

transitive�
:type: depset[struct]

Depset of transitive library information. Each entry in the depset is a struct
with fields matching the fields of this provider.
"V
SphinxDocsLibraryInfo=@@sphinxdocs//sphinxdocs/private:sphinx_docs_library_info.bzl
!!J
H
files?
:type: depset[File]

The documentation files for the library.
r
p
prefixf
:type: str

Prefix to prepend to file paths in `files`. It is added after `strip_prefix`
is removed.
x
v
strip_prefixf
:type: str

Prefix to remove from file paths in `files`. It is removed before `prefix`
is prepended.
�
�

transitive�
:type: depset[struct]

Depset of transitive library information. Each entry in the depset is a struct
with fields matching the fields of this provider.
/Provider for collecting doc files as libraries.�
?

sphinxdocssphinxdocs/privatesphinx_docs_library_macro.bzl�sphinx_docs_library1Collection of doc files for use by `sphinx_docs`.*�
�
sphinx_docs_libraryL
kwargs@Args passed onto underlying {bzl:rule}`sphinx_docs_library` rule(1Collection of doc files for use by `sphinx_docs`.2U
sphinx_docs_library>@@sphinxdocs//sphinxdocs/private:sphinx_docs_library_macro.bzl
*_sphinx_docs_library�
,//sphinxdocs/private:sphinx_docs_library.bzlr�
9

sphinxdocssphinxdocs/privatesphinx_docs_library.bzl9
sphinx_docs_library_sphinx_docs_library
AU
n
//sphinxdocs/private:util.bzlr\
*

sphinxdocssphinxdocs/privateutil.bzl 
add_tagadd_tag
3:
<,Implementation of sphinx_docs_library macro.�
4

sphinxdocssphinxdocs/privatesphinx_stardoc.bzl�sphinx_stardoc8Generate Sphinx-friendly Markdown for a single bzl file."�
�
sphinx_stardoc8Generate Sphinx-friendly Markdown for a single bzl file.*
nameA unique name for this target. 
target2None"L
_stardoc_input_helper3@@sphinxdocs//sphinxdocs/private:sphinx_stardoc.bzl
��,
*
nameA unique name for this target. 

target2None�
sphinx_stardocs�Generate Sphinx-friendly Markdown docs using Stardoc for bzl libraries.

A `build_test` for the docs is also generated to ensure Stardoc is able
to process the files.

NOTE: This generates MyST-flavored Markdown.
"�	
�
sphinx_stardocs�Generate Sphinx-friendly Markdown docs using Stardoc for bzl libraries.

A `build_test` for the docs is also generated to ensure Stardoc is able
to process the files.

NOTE: This generates MyST-flavored Markdown.
*
nameA unique name for this target. �
deps�
Additional `sphinx_docs_library` targets to include. They do not have the
`prefix` and `strip_prefix` attributes applied to them.*
SphinxDocsLibraryInfo2[]W
prefixGPrefix to prepend to file paths. Added after `strip_prefix` is removed.2""1
srcs#Files that are part of the library.2[]]
strip_prefixGPrefix to remove from file paths. Removed before `prefix` is prepended.2""
$$,
*
nameA unique name for this target. �
�
deps�
Additional `sphinx_docs_library` targets to include. They do not have the
`prefix` and `strip_prefix` attributes applied to them.*
SphinxDocsLibraryInfo2[]Y
W
prefixGPrefix to prepend to file paths. Added after `strip_prefix` is removed.2""3
1
srcs#Files that are part of the library.2[]_
]
strip_prefixGPrefix to remove from file paths. Removed before `prefix` is prepended.2""
:bzl_library.bzlri

bazel_skylibbzl_library.bzl8
StarlarkLibraryInfoStarlarkLibraryInfo
*=
?a
//lib:paths.bzlrL

bazel_skyliblib	paths.bzl
pathspaths
',
.a
//lib:types.bzlrL

bazel_skyliblib	types.bzl
typestypes
',
.y
//rules:build_test.bzlr]
%
bazel_skylibrulesbuild_test.bzl&

build_test
build_test
.8
:�
2//sphinxdocs/private:sphinx_docs_library_macro.bzlr�
?

sphinxdocssphinxdocs/privatesphinx_docs_library_macro.bzl8
sphinx_docs_librarysphinx_docs_library
H[
]�
//sphinxdocs/private:util.bzlr�
*

sphinxdocssphinxdocs/privateutil.bzl 
add_tagadd_tag
3:@
copy_propagating_kwargscopy_propagating_kwargs
>U
Wl
//stardoc:stardoc.bzlrQ

stardocstardocstardoc.bzl 
stardocstardoc
(/
1@Rules to generate Sphinx-compatible documentation for bzl files.�
*

sphinxdocssphinxdocs/privateutil.bzl�add_tagAdds `tag` to `attrs["tags"]`.*�
�
add_tag;
attrs.dict of keyword args. It is modified in place. (
tagstr, the tag to add. (Adds `tag` to `attrs["tags"]`.24
add_tag)@@sphinxdocs//sphinxdocs/private:util.bzl
''�copy_propagating_kwargs�Copies args that must be compatible between two targets with a dependency relationship.

This is intended for when one target depends on another, so they must have
compatible settings such as `testonly` and `compatible_with`. This usually
happens when a macro generates multiple targets, some of which depend
on one another, so their settings must be compatible.
*�
�
copy_propagating_kwargsG
from_kwargs4keyword args dict whose common kwarg will be copied. (�
into_kwargs�optional keyword args dict that the values from `from_kwargs`
will be copied into. The values in this dict will take precedence
over the ones in `from_kwargs` (i.e., if this has `testonly` already
set, then it won't be overwritten).
NOTE: THIS WILL BE MODIFIED IN-PLACE.None(�Copies args that must be compatible between two targets with a dependency relationship.

This is intended for when one target depends on another, so they must have
compatible settings such as `testonly` and `compatible_with`. This usually
happens when a macro generates multiple targets, some of which depend
on one another, so their settings must be compatible.
"�
�Keyword args to use for the depender target derived from the dependency
target. If `into_kwargs` was passed in, then that same object is
returned; this is to facilitate easy `**` expansion.2D
copy_propagating_kwargs)@@sphinxdocs//sphinxdocs/private:util.bzl
		a
//lib:types.bzlrL

bazel_skyliblib	types.bzl
typestypes
',
.	BZLMOD_ENABLEDj %Utility functions used by sphinxdocs.�
0

sphinxdocssphinxdocs/privatevisibility.bzl2	NOT_ACTUALLY_PUBLICj2
//visibility:public*Shared code for use with visibility specs.��
)

sphinxdocs
sphinxdocsreadthedocs.bzl��readthedocs_install�Run a program to copy Sphinx doc files into readthedocs output directories.

This is intended to be run using `bazel run` during the readthedocs
build process when the build process is overridden. See
https://docs.readthedocs.io/en/stable/build-customization.html#override-the-build-process
for more information.
"��
�Q
readthedocs_install�Run a program to copy Sphinx doc files into readthedocs output directories.

This is intended to be run using `bazel run` during the readthedocs
build process when the build process is overridden. See
https://docs.readthedocs.io/en/stable/build-customization.html#override-the-build-process
for more information.
*
nameA unique name for this target. �	
config_settings�	
Config settings to change for this target.

The keys are labels for settings, and the values are strings for the new value
to use. Pass `Label` objects or canonical label strings for the keys to ensure
they resolve as expected (canonical labels start with `@@` and can be
obtained by calling `str(Label(...))`).

Most `@rules_python//python/config_setting` settings can be used here, which
allows, for example, making only a certain `py_binary` use
{obj}`--boostrap_impl=script`.

Additional or custom config settings can be registered using the
{obj}`add_transition_setting` API. This allows, for example, forcing a
particular CPU, or defining a custom setting that `select()` uses elsewhere
to pick between `pip.parse` hubs. See the [How to guide on multiple
versions of a library] for a more concrete example.

:::{note}
These values are transitioned on, so will affect the analysis graph and the
associated memory overhead. The more unique configurations in your overall
build, the more memory and (often unnecessary) re-analysis and re-building
can occur. See
https://bazel.build/extending/config#memory-performance-considerations for
more information about risks and considerations.
:::

:::{versionadded} 1.7.0
:::
	2{}�
data�
The list of files need by this library at runtime. See comments about
the [`data` attribute typically defined by rules](https://bazel.build/reference/be/common-definitions#typical-attributes).

There is no `py_embed_data` like there is `cc_embed_data` and `go_embed_data`.
This is because Python has a concept of runtime resources.
2[]�
deps�
List of additional libraries to be linked in to the target.
See comments about
the [`deps` attribute typically defined by
rules](https://bazel.build/reference/be/common-definitions#typical-attributes).
These are typically `py_library` rules.

Targets that only provide data files used at runtime belong in the `data`
attribute.

:::{note}
The order of this list can matter because it affects the order that information
from dependencies is merged in, which can be relevant depending on the ordering
mode of depsets that are merged.

* {obj}`PyInfo.venv_symlinks` uses default ordering.

See {obj}`PyInfo` for more information about the ordering of its depsets and
how its fields are merged.
:::
*
PyInfo*
CcInfo*
BuiltinPyInfo2[]
distribs2[]�
env�Dictionary of strings; optional; values are subject to `$(location)` and "Make
variable" substitution.

Specifies additional environment variables to set when the target is executed by
`test` or `run`.

2{}�
imports�
List of import directories to be added to the PYTHONPATH.

Subject to "Make variable" substitution. These import directories will be added
for this rule and all rules that depend on it (note: not the rules this rule
depends on. Each directory will be added to `PYTHONPATH` by `py_binary` rules
that depend on this rule. The strings are repo-runfiles-root relative,

Absolute paths (paths that start with `/`) and paths that references a path
above the execution root are not allowed and will result in an error.
2[]�
interpreter_args�
Arguments that are only applicable to the interpreter.

The args an interpreter supports are specific to the interpreter. For
CPython, see https://docs.python.org/3/using/cmdline.html.

:::{note}
Only supported for {obj}`--bootstrap_impl=script`. Ignored otherwise.
:::

:::{seealso}
The {any}`RULES_PYTHON_ADDITIONAL_INTERPRETER_ARGS` environment variable
:::

:::{versionadded} 1.3.0
:::
2[]�
legacy_create_init�Whether to implicitly create empty `__init__.py` files in the runfiles tree.
These are created in every directory containing Python source code or shared
libraries, and every parent directory of those directories, excluding the repo
root directory. The default, `-1` (auto), means true unless
`--incompatible_default_to_explicit_init_py` is used. If false, the user is
responsible for creating (possibly empty) `__init__.py` files and adding them to
the `srcs` of Python targets as required.
2-1
licenses2[]�
main�Optional; the name of the source file that is the main entry point of the
application. This file must also be listed in `srcs`. If left unspecified,
`name`, with `.py` appended, is used instead. If `name` does not match any
filename in `srcs`, `main` must be specified.

This is mutually exclusive with {obj}`main_module`.
2None�
main_module�
Module name to execute as the main program.

When set, `srcs` is not required, and it is assumed the module is
provided by a dependency.

See https://docs.python.org/3/using/cmdline.html#cmdoption-m for more
information about running modules as the main program.

This is mutually exclusive with {obj}`main`.

:::{versionadded} 1.3.0
:::
:::{versionchanged} 1.7.0
Support added for {obj}`--bootstrap_impl=system_python`.
:::
2""�

precompile�
Whether py source files **for this target** should be precompiled.

Values:

* `inherit`: Allow the downstream binary decide if precompiled files are used.
* `enabled`: Compile Python source files at build time.
* `disabled`: Don't compile Python source files at build time.

:::{seealso}

* The {flag}`--precompile` flag, which can override this attribute in some cases
  and will affect all targets when building.
* The {obj}`pyc_collection` attribute for transitively enabling precompiling on
  a per-target basis.
* The [Precompiling](precompiling) docs for a guide about using precompiling.
:::
2	"inherit"�
precompile_invalidation_mode�
How precompiled files should be verified to be up-to-date with their associated
source files. Possible values are:
* `auto`: The effective value will be automatically determined by other build
  settings.
* `checked_hash`: Use the pyc file if the hash of the source file matches the hash
  recorded in the pyc file. This is most useful when working with code that
  you may modify.
* `unchecked_hash`: Always use the pyc file; don't check the pyc's hash against
  the source file. This is most useful when the code won't be modified.

For more information on pyc invalidation modes, see
https://docs.python.org/3/library/py_compile.html#py_compile.PycInvalidationMode
2"auto"�
precompile_optimize_level�
The optimization level for precompiled files.

For more information about optimization levels, see the `compile()` function's
`optimize` arg docs at https://docs.python.org/3/library/functions.html#compile

NOTE: The value `-1` means "current interpreter", which will be the interpreter
used _at build time when pycs are generated_, not the interpreter used at
runtime when the code actually runs.
20�
precompile_source_retention�
Determines, when a source file is compiled, if the source file is kept
in the resulting output or not. Valid values are:

* `inherit`: Inherit the value from the {flag}`--precompile_source_retention` flag.
* `keep_source`: Include the original Python source.
* `omit_source`: Don't include the original py source.
2	"inherit"�
pyc_collection�
Determines whether pyc files from dependencies should be manually included.

Valid values are:
* `inherit`: Inherit the value from {flag}`--precompile`.
* `include_pyc`: Add implicitly generated pyc files from dependencies. i.e.
  pyc files for targets that specify {attr}`precompile="inherit"`.
* `disabled`: Don't add implicitly generated pyc files. Note that
  pyc files may still come from dependencies that enable precompiling at the
  target level.
2	"inherit"�
pyi_deps�
Dependencies providing type definitions the library needs.

These are dependencies that satisfy imports guarded by `typing.TYPE_CHECKING`.
These are build-time only dependencies and not included as part of a runnable
program (packaging rules may include them, however).

:::{versionadded} 1.1.0
:::
*
PyInfo*
CcInfo*
BuiltinPyInfo2[]�
pyi_srcs�
Type definition files for the library.

These are typically `.pyi` files, but other file types for type-checker specific
formats are allowed. These files are build-time only dependencies and not included
as part of a runnable program (packaging rules may include them, however).

:::{versionadded} 1.1.0
:::
2[]�
python_version�
The Python version this target should use.

The value should be in `X.Y` or `X.Y.Z` (or compatible) format. If empty or
unspecified, the incoming configuration's {obj}`--python_version` flag is
inherited. For backwards compatibility, the values `PY2` and `PY3` are
accepted, but treated as an empty/unspecified value.

:::{note}
In order for the requested version to be used, there must be a
toolchain configured to match the Python version. If there isn't, then it
may be silently ignored, or an error may occur, depending on the toolchain
configuration.
:::

:::{versionchanged} 1.1.0

This attribute was changed from only accepting `PY2` and `PY3` values to
accepting arbitrary Python versions.
:::
2""�
srcs�
The list of Python source files that are processed to create the target. This
includes all your checked-in code and may include generated source files.  The
`.py` files belong in `srcs` and library targets belong in `deps`. Other binary
files that may be needed at run time belong in `data`.
2[]4
srcs_versionDefunct, unused, does nothing.2""�
stamp�
Whether to encode build information into the binary. Possible values:

* `stamp = 1`: Always stamp the build information into the binary, even in
  `--nostamp` builds. **This setting should be avoided**, since it potentially kills
  remote caching for the binary and any downstream actions that depend on it.
* `stamp = 0`: Always replace build information by constant values. This gives
  good build result caching.
* `stamp = -1`: Embedding of build information is controlled by the
  `--[no]stamp` flag.

Stamped binaries are not rebuilt unless their dependencies change.

WARNING: Stamping can harm build performance by reducing cache hits and should
be avoided if possible.
2-1
,
*
nameA unique name for this target. �	
�	
config_settings�	
Config settings to change for this target.

The keys are labels for settings, and the values are strings for the new value
to use. Pass `Label` objects or canonical label strings for the keys to ensure
they resolve as expected (canonical labels start with `@@` and can be
obtained by calling `str(Label(...))`).

Most `@rules_python//python/config_setting` settings can be used here, which
allows, for example, making only a certain `py_binary` use
{obj}`--boostrap_impl=script`.

Additional or custom config settings can be registered using the
{obj}`add_transition_setting` API. This allows, for example, forcing a
particular CPU, or defining a custom setting that `select()` uses elsewhere
to pick between `pip.parse` hubs. See the [How to guide on multiple
versions of a library] for a more concrete example.

:::{note}
These values are transitioned on, so will affect the analysis graph and the
associated memory overhead. The more unique configurations in your overall
build, the more memory and (often unnecessary) re-analysis and re-building
can occur. See
https://bazel.build/extending/config#memory-performance-considerations for
more information about risks and considerations.
:::

:::{versionadded} 1.7.0
:::
	2{}�
�
data�
The list of files need by this library at runtime. See comments about
the [`data` attribute typically defined by rules](https://bazel.build/reference/be/common-definitions#typical-attributes).

There is no `py_embed_data` like there is `cc_embed_data` and `go_embed_data`.
This is because Python has a concept of runtime resources.
2[]�
�
deps�
List of additional libraries to be linked in to the target.
See comments about
the [`deps` attribute typically defined by
rules](https://bazel.build/reference/be/common-definitions#typical-attributes).
These are typically `py_library` rules.

Targets that only provide data files used at runtime belong in the `data`
attribute.

:::{note}
The order of this list can matter because it affects the order that information
from dependencies is merged in, which can be relevant depending on the ordering
mode of depsets that are merged.

* {obj}`PyInfo.venv_symlinks` uses default ordering.

See {obj}`PyInfo` for more information about the ordering of its depsets and
how its fields are merged.
:::
*
PyInfo*
CcInfo*
BuiltinPyInfo2[]

distribs2[]�
�
env�Dictionary of strings; optional; values are subject to `$(location)` and "Make
variable" substitution.

Specifies additional environment variables to set when the target is executed by
`test` or `run`.

2{}�
�
imports�
List of import directories to be added to the PYTHONPATH.

Subject to "Make variable" substitution. These import directories will be added
for this rule and all rules that depend on it (note: not the rules this rule
depends on. Each directory will be added to `PYTHONPATH` by `py_binary` rules
that depend on this rule. The strings are repo-runfiles-root relative,

Absolute paths (paths that start with `/`) and paths that references a path
above the execution root are not allowed and will result in an error.
2[]�
�
interpreter_args�
Arguments that are only applicable to the interpreter.

The args an interpreter supports are specific to the interpreter. For
CPython, see https://docs.python.org/3/using/cmdline.html.

:::{note}
Only supported for {obj}`--bootstrap_impl=script`. Ignored otherwise.
:::

:::{seealso}
The {any}`RULES_PYTHON_ADDITIONAL_INTERPRETER_ARGS` environment variable
:::

:::{versionadded} 1.3.0
:::
2[]�
�
legacy_create_init�Whether to implicitly create empty `__init__.py` files in the runfiles tree.
These are created in every directory containing Python source code or shared
libraries, and every parent directory of those directories, excluding the repo
root directory. The default, `-1` (auto), means true unless
`--incompatible_default_to_explicit_init_py` is used. If false, the user is
responsible for creating (possibly empty) `__init__.py` files and adding them to
the `srcs` of Python targets as required.
2-1

licenses2[]�
�
main�Optional; the name of the source file that is the main entry point of the
application. This file must also be listed in `srcs`. If left unspecified,
`name`, with `.py` appended, is used instead. If `name` does not match any
filename in `srcs`, `main` must be specified.

This is mutually exclusive with {obj}`main_module`.
2None�
�
main_module�
Module name to execute as the main program.

When set, `srcs` is not required, and it is assumed the module is
provided by a dependency.

See https://docs.python.org/3/using/cmdline.html#cmdoption-m for more
information about running modules as the main program.

This is mutually exclusive with {obj}`main`.

:::{versionadded} 1.3.0
:::
:::{versionchanged} 1.7.0
Support added for {obj}`--bootstrap_impl=system_python`.
:::
2""�
�

precompile�
Whether py source files **for this target** should be precompiled.

Values:

* `inherit`: Allow the downstream binary decide if precompiled files are used.
* `enabled`: Compile Python source files at build time.
* `disabled`: Don't compile Python source files at build time.

:::{seealso}

* The {flag}`--precompile` flag, which can override this attribute in some cases
  and will affect all targets when building.
* The {obj}`pyc_collection` attribute for transitively enabling precompiling on
  a per-target basis.
* The [Precompiling](precompiling) docs for a guide about using precompiling.
:::
2	"inherit"�
�
precompile_invalidation_mode�
How precompiled files should be verified to be up-to-date with their associated
source files. Possible values are:
* `auto`: The effective value will be automatically determined by other build
  settings.
* `checked_hash`: Use the pyc file if the hash of the source file matches the hash
  recorded in the pyc file. This is most useful when working with code that
  you may modify.
* `unchecked_hash`: Always use the pyc file; don't check the pyc's hash against
  the source file. This is most useful when the code won't be modified.

For more information on pyc invalidation modes, see
https://docs.python.org/3/library/py_compile.html#py_compile.PycInvalidationMode
2"auto"�
�
precompile_optimize_level�
The optimization level for precompiled files.

For more information about optimization levels, see the `compile()` function's
`optimize` arg docs at https://docs.python.org/3/library/functions.html#compile

NOTE: The value `-1` means "current interpreter", which will be the interpreter
used _at build time when pycs are generated_, not the interpreter used at
runtime when the code actually runs.
20�
�
precompile_source_retention�
Determines, when a source file is compiled, if the source file is kept
in the resulting output or not. Valid values are:

* `inherit`: Inherit the value from the {flag}`--precompile_source_retention` flag.
* `keep_source`: Include the original Python source.
* `omit_source`: Don't include the original py source.
2	"inherit"�
�
pyc_collection�
Determines whether pyc files from dependencies should be manually included.

Valid values are:
* `inherit`: Inherit the value from {flag}`--precompile`.
* `include_pyc`: Add implicitly generated pyc files from dependencies. i.e.
  pyc files for targets that specify {attr}`precompile="inherit"`.
* `disabled`: Don't add implicitly generated pyc files. Note that
  pyc files may still come from dependencies that enable precompiling at the
  target level.
2	"inherit"�
�
pyi_deps�
Dependencies providing type definitions the library needs.

These are dependencies that satisfy imports guarded by `typing.TYPE_CHECKING`.
These are build-time only dependencies and not included as part of a runnable
program (packaging rules may include them, however).

:::{versionadded} 1.1.0
:::
*
PyInfo*
CcInfo*
BuiltinPyInfo2[]�
�
pyi_srcs�
Type definition files for the library.

These are typically `.pyi` files, but other file types for type-checker specific
formats are allowed. These files are build-time only dependencies and not included
as part of a runnable program (packaging rules may include them, however).

:::{versionadded} 1.1.0
:::
2[]�
�
python_version�
The Python version this target should use.

The value should be in `X.Y` or `X.Y.Z` (or compatible) format. If empty or
unspecified, the incoming configuration's {obj}`--python_version` flag is
inherited. For backwards compatibility, the values `PY2` and `PY3` are
accepted, but treated as an empty/unspecified value.

:::{note}
In order for the requested version to be used, there must be a
toolchain configured to match the Python version. If there isn't, then it
may be silently ignored, or an error may occur, depending on the toolchain
configuration.
:::

:::{versionchanged} 1.1.0

This attribute was changed from only accepting `PY2` and `PY3` values to
accepting arbitrary Python versions.
:::
2""�
�
srcs�
The list of Python source files that are processed to create the target. This
includes all your checked-in code and may include generated source files.  The
`.py` files belong in `srcs` and library targets belong in `deps`. Other binary
files that may be needed at run time belong in `data`.
2[]6
4
srcs_versionDefunct, unused, does nothing.2""�
�
stamp�
Whether to encode build information into the binary. Possible values:

* `stamp = 1`: Always stamp the build information into the binary, even in
  `--nostamp` builds. **This setting should be avoided**, since it potentially kills
  remote caching for the binary and any downstream actions that depend on it.
* `stamp = 0`: Always replace build information by constant values. This gives
  good build result caching.
* `stamp = -1`: Embedding of build information is controlled by the
  `--[no]stamp` flag.

Stamped binaries are not rebuilt unless their dependencies change.

WARNING: Stamping can harm build performance by reducing cache hits and should
be avoided if possible.
2-1�
$//sphinxdocs/private:readthedocs.bzlr|
1

sphinxdocssphinxdocs/privatereadthedocs.bzl9
readthedocs_install_readthedocs_install
9M
f6Starlark rules for integrating Sphinx and Readthedocs.�8
$

sphinxdocs
sphinxdocs
sphinx.bzl�
sphinx_run�
Directly run the underlying Sphinx command `sphinx_docs` uses.

This is primarily a debugging tool. It's useful for directly running the
Sphinx command so that debuggers can be attached or output more directly
inspected without Bazel interference.
"�
�

sphinx_run�
Directly run the underlying Sphinx command `sphinx_docs` uses.

This is primarily a debugging tool. It's useful for directly running the
Sphinx command so that debuggers can be attached or output more directly
inspected without Bazel interference.
*
nameA unique name for this target. 8
builder#The output format to make runnable.2"html"Z
docs8The {obj}`sphinx_docs` target to make directly runnable.*
_SphinxRunInfo2None"1

sphinx_run#@@sphinxdocs//sphinxdocs:sphinx.bzl
��,
*
nameA unique name for this target. :
8
builder#The output format to make runnable.2"html"\
Z
docs8The {obj}`sphinx_docs` target to make directly runnable.*
_SphinxRunInfo2None�sphinx_docs�Generate docs using Sphinx.

Generates targets:
* `<name>`: The output of this target is a directory for each
  format Sphinx creates. This target also has a separate output
  group for each format. e.g. `--output_group=html` will only build
  the "html" format files.
* `<name>.serve`: A binary that locally serves the HTML output. This
  allows previewing docs during development.
* `<name>.run`: A binary that directly runs the underlying Sphinx command
  to build the docs. This is a debugging aid.
"�

�
sphinx_docs�Generate docs using Sphinx.

Generates targets:
* `<name>`: The output of this target is a directory for each
  format Sphinx creates. This target also has a separate output
  group for each format. e.g. `--output_group=html` will only build
  the "html" format files.
* `<name>.serve`: A binary that locally serves the HTML output. This
  allows previewing docs during development.
* `<name>.run`: A binary that directly runs the underlying Sphinx command
  to build the docs. This is a debugging aid.
*
nameA unique name for this target. $
configConfig file for Sphinx %
deps*
SphinxDocsLibraryInfo2[]�
renamed_srcs~Doc source files for Sphinx that are renamed. This is typically used for files elsewhere, such as top level files in the repo.	2{}*
srcsDoc source files for Sphinx.2[]=
strip_prefix'Prefix to remove from input file paths.2""
^^,
*
nameA unique name for this target. &
$
configConfig file for Sphinx '
%
deps*
SphinxDocsLibraryInfo2[]�
�
renamed_srcs~Doc source files for Sphinx that are renamed. This is typically used for files elsewhere, such as top level files in the repo.	2{},
*
srcsDoc source files for Sphinx.2[]?
=
strip_prefix'Prefix to remove from input file paths.2""�sphinx_inventory�	Creates a compressed inventory file from an uncompressed on.

The Sphinx inventory format isn't formally documented, but is understood
to be:

```
# Sphinx inventory version 2
# Project: <project name>
# Version: <version string>
# The remainder of this file is compressed using zlib
name domain:role 1 relative-url display name
```

Where:
  * `<project name>` is a string. e.g. `Rules Python`
  * `<version string>` is a string e.g. `1.5.3`

And there are one or more `name domain:role ...` lines
  * `name`: the name of the symbol. It can contain special characters,
    but not spaces.
  * `domain:role`: The `domain` is usually a language, e.g. `py` or `bzl`.
    The `role` is usually the type of object, e.g. `class` or `func`. There
    is no canonical meaning to the values, they are usually domain-specific.
  * `1` is a number. It affects search priority.
  * `relative-url` is a URL path relative to the base url in the
    confg.py intersphinx config.
  * `display name` is a string. It can contain spaces, or simply be
    the value `-` to indicate it is the same as `name`

:::{seealso}
{bzl:obj}`//inventories` for inventories of Bazel objects.
:::
"�

�	
sphinx_inventory�	Creates a compressed inventory file from an uncompressed on.

The Sphinx inventory format isn't formally documented, but is understood
to be:

```
# Sphinx inventory version 2
# Project: <project name>
# Version: <version string>
# The remainder of this file is compressed using zlib
name domain:role 1 relative-url display name
```

Where:
  * `<project name>` is a string. e.g. `Rules Python`
  * `<version string>` is a string e.g. `1.5.3`

And there are one or more `name domain:role ...` lines
  * `name`: the name of the symbol. It can contain special characters,
    but not spaces.
  * `domain:role`: The `domain` is usually a language, e.g. `py` or `bzl`.
    The `role` is usually the type of object, e.g. `class` or `func`. There
    is no canonical meaning to the values, they are usually domain-specific.
  * `1` is a number. It affects search priority.
  * `relative-url` is a URL path relative to the base url in the
    confg.py intersphinx config.
  * `display name` is a string. It can contain spaces, or simply be
    the value `-` to indicate it is the same as `name`

:::{seealso}
{bzl:obj}`//inventories` for inventories of Bazel objects.
:::
*
nameA unique name for this target. 
src2None
��,
*
nameA unique name for this target. 

src2None�sphinx_build_binary�Create an executable with the sphinx-build command line interface.

The `deps` must contain the sphinx library and any other extensions Sphinx
needs at runtime.
*�
�
sphinx_build_binary~
namer{type}`str` name of the target. The name "sphinx-build" is the
conventional name to match what Sphinx itself uses. (�
py_binary_rule�{type}`callable` A `py_binary` compatible callable
for creating the target. If not set, the regular `py_binary`
rule is used. This allows using the version-aware rules, or
other alternative implementations.><function py_binary from @@rules_python//python:py_binary.bzl>(|
kwargsp{type}`dict` Additional kwargs to pass onto `py_binary`. The `srcs` and
`main` attributes must not be specified.(�Create an executable with the sphinx-build command line interface.

The `deps` must contain the sphinx library and any other extensions Sphinx
needs at runtime.
2B
sphinx_build_binary+@@sphinxdocs//sphinxdocs/private:sphinx.bzl
FF*py_binary_rule2py_binary_rule�
//sphinxdocs/private:sphinx.bzlr�
,

sphinxdocssphinxdocs/private
sphinx.bzl9
sphinx_build_binary_sphinx_build_binary
  )
sphinx_docs_sphinx_docs
!!3
sphinx_inventory_sphinx_inventory
""'

sphinx_run_sphinx_run
##
$�Rules to generate Sphinx documentation.

The general usage of the Sphinx rules requires two pieces:

1. Using `sphinx_docs` to define the docs to build and options for building.
2. Defining a `sphinx-build` binary to run Sphinx with the necessary
   dependencies to be used by (1); the `sphinx_build_binary` rule helps with
   this.

Defining your own `sphinx-build` binary is necessary because Sphinx uses
a plugin model to support extensibility.

The Sphinx integration is still experimental.
�
1

sphinxdocs
sphinxdocssphinx_docs_library.bzl�sphinx_docs_library1Collection of doc files for use by `sphinx_docs`.*�
�
sphinx_docs_libraryL
kwargs@Args passed onto underlying {bzl:rule}`sphinx_docs_library` rule(1Collection of doc files for use by `sphinx_docs`.2U
sphinx_docs_library>@@sphinxdocs//sphinxdocs/private:sphinx_docs_library_macro.bzl
*_sphinx_docs_library�
2//sphinxdocs/private:sphinx_docs_library_macro.bzlr�
?

sphinxdocssphinxdocs/privatesphinx_docs_library_macro.bzl9
sphinx_docs_library_sphinx_docs_library
G[
t"Library-like rule to collect docs.�
,

sphinxdocs
sphinxdocssphinx_stardoc.bzl�sphinx_stardoc8Generate Sphinx-friendly Markdown for a single bzl file."�
�
sphinx_stardoc8Generate Sphinx-friendly Markdown for a single bzl file.*
nameA unique name for this target. 
target2None
��,
*
nameA unique name for this target. 

target2None�
sphinx_stardocs�Generate Sphinx-friendly Markdown docs using Stardoc for bzl libraries.

A `build_test` for the docs is also generated to ensure Stardoc is able
to process the files.

NOTE: This generates MyST-flavored Markdown.
"�	
�
sphinx_stardocs�Generate Sphinx-friendly Markdown docs using Stardoc for bzl libraries.

A `build_test` for the docs is also generated to ensure Stardoc is able
to process the files.

NOTE: This generates MyST-flavored Markdown.
*
nameA unique name for this target. �
deps�
Additional `sphinx_docs_library` targets to include. They do not have the
`prefix` and `strip_prefix` attributes applied to them.*
SphinxDocsLibraryInfo2[]W
prefixGPrefix to prepend to file paths. Added after `strip_prefix` is removed.2""1
srcs#Files that are part of the library.2[]]
strip_prefixGPrefix to remove from file paths. Removed before `prefix` is prepended.2""
$$,
*
nameA unique name for this target. �
�
deps�
Additional `sphinx_docs_library` targets to include. They do not have the
`prefix` and `strip_prefix` attributes applied to them.*
SphinxDocsLibraryInfo2[]Y
W
prefixGPrefix to prepend to file paths. Added after `strip_prefix` is removed.2""3
1
srcs#Files that are part of the library.2[]_
]
strip_prefixGPrefix to remove from file paths. Removed before `prefix` is prepended.2""�
'//sphinxdocs/private:sphinx_stardoc.bzlr�
4

sphinxdocssphinxdocs/privatesphinx_stardoc.bzl/
sphinx_stardoc_sphinx_stardoc
<K1
sphinx_stardocs_sphinx_stardocs
`p
�@Rules to generate Sphinx-compatible documentation for bzl files. 