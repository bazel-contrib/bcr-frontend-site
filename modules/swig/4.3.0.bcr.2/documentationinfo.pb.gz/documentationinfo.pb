�6

swigswig.bzl�3swig_library�Generate SWIG wrapper code for language bindings.

This rule simplifies SWIG binding generation.

The rule automatically selects the appropriate SWIG library files based on the
'language' attribute. To add support for additional languages, ensure the
@swig repository has a corresponding 'lib_<language>' filegroup in its BUILD file,
then add the language mapping in the _LANGUAGE_TO_LIB_ATTR dictionary.

Attributes:
    srcs: SWIG interface files (.i) and headers
    language: Target language (python, java, tcl, etc.)
    module: Module name (optional, defaults to rule name)
    out: Wrapper output filename (optional, defaults to {name}_wrap.{c|cpp})
    outdir: Module file output directory (optional, defaults to rule directory)
    out_c_mode: Generate C wrapper instead of C++ (optional, default: False)
    defines: Preprocessor defines (optional)
    includes: Additional include paths (optional)
    opts: Additional SWIG options (optional)

Example (Python - basic):
    swig_library(
        name = "my_python_wrapper",
        srcs = ["interface.i", "header.h"],
        language = "python",
        module = "my_module",
        defines = ["SWIGPYTHON"],
    )
    # Generates: my_python_wrapper_wrap.cpp, my_module.py

Example (Python - custom output):
    swig_library(
        name = "nlopt_swig",
        srcs = ["nlopt.i", "nlopt.h"],
        language = "python",
        module = "nlopt",
        out = "nlopt_wrap.cpp",
        outdir = "generated",
        defines = ["SWIGPYTHON"],
    )
    # Generates: nlopt_wrap.cpp, generated/nlopt.py

Example (Java):
    swig_library(
        name = "my_java_wrapper",
        srcs = ["interface.i", "header.h"],
        language = "java",
        module = "MyModule",
        defines = ["SWIGJAVA"],
    )
    # Generates: my_java_wrapper_wrap.cpp, MyModule.java
"�$
�
swig_library�Generate SWIG wrapper code for language bindings.

This rule simplifies SWIG binding generation.

The rule automatically selects the appropriate SWIG library files based on the
'language' attribute. To add support for additional languages, ensure the
@swig repository has a corresponding 'lib_<language>' filegroup in its BUILD file,
then add the language mapping in the _LANGUAGE_TO_LIB_ATTR dictionary.

Attributes:
    srcs: SWIG interface files (.i) and headers
    language: Target language (python, java, tcl, etc.)
    module: Module name (optional, defaults to rule name)
    out: Wrapper output filename (optional, defaults to {name}_wrap.{c|cpp})
    outdir: Module file output directory (optional, defaults to rule directory)
    out_c_mode: Generate C wrapper instead of C++ (optional, default: False)
    defines: Preprocessor defines (optional)
    includes: Additional include paths (optional)
    opts: Additional SWIG options (optional)

Example (Python - basic):
    swig_library(
        name = "my_python_wrapper",
        srcs = ["interface.i", "header.h"],
        language = "python",
        module = "my_module",
        defines = ["SWIGPYTHON"],
    )
    # Generates: my_python_wrapper_wrap.cpp, my_module.py

Example (Python - custom output):
    swig_library(
        name = "nlopt_swig",
        srcs = ["nlopt.i", "nlopt.h"],
        language = "python",
        module = "nlopt",
        out = "nlopt_wrap.cpp",
        outdir = "generated",
        defines = ["SWIGPYTHON"],
    )
    # Generates: nlopt_wrap.cpp, generated/nlopt.py

Example (Java):
    swig_library(
        name = "my_java_wrapper",
        srcs = ["interface.i", "header.h"],
        language = "java",
        module = "MyModule",
        defines = ["SWIGJAVA"],
    )
    # Generates: my_java_wrapper_wrap.cpp, MyModule.java
*
nameA unique name for this target. E
defines4Preprocessor defines to pass to SWIG using -D flags.2[]~
includeslAdditional include paths to pass to SWIG using -I flags. Source file directories are automatically included.2[]7
language'Target language for binding generation. �
main�Main SWIG interface file (optional). If not specified, the first .i file in srcs is used. Only the main file is passed to SWIG; other files should be %include'd from the main file.2""M
module=SWIG module name. Defaults to the rule name if not specified.2""B
namespace_prefix(swig namespace prefix (for language=tcl)2""3
opts%Additional SWIG command-line options.2[]q
outdExplicit name for the wrapper output file. If not specified, defaults to '{rule_name}_wrap.{c|cpp}'.2""S

out_c_mode<If True, generate C wrapper instead of C++ (default: False).2False�
outdir�Output directory for language-specific module files (e.g., .py, .java). If specified, the module file will be placed in this subdirectory. If not specified, module files are placed in the rule's directory.2""=
runtime_header%Create a header with the swig binding2""�
srcs�SWIG interface files (.i) and headers. All files are available for %include directives. The main interface file is specified by 'main' attribute, or defaults to the first .i file. "!
swig_library@@swig//:swig.bzl
��,
*
nameA unique name for this target. G
E
defines4Preprocessor defines to pass to SWIG using -D flags.2[]�
~
includeslAdditional include paths to pass to SWIG using -I flags. Source file directories are automatically included.2[]9
7
language'Target language for binding generation. �
�
main�Main SWIG interface file (optional). If not specified, the first .i file in srcs is used. Only the main file is passed to SWIG; other files should be %include'd from the main file.2""O
M
module=SWIG module name. Defaults to the rule name if not specified.2""D
B
namespace_prefix(swig namespace prefix (for language=tcl)2""5
3
opts%Additional SWIG command-line options.2[]s
q
outdExplicit name for the wrapper output file. If not specified, defaults to '{rule_name}_wrap.{c|cpp}'.2""U
S

out_c_mode<If True, generate C wrapper instead of C++ (default: False).2False�
�
outdir�Output directory for language-specific module files (e.g., .py, .java). If specified, the module file will be placed in this subdirectory. If not specified, module files are placed in the rule's directory.2""?
=
runtime_header%Create a header with the swig binding2""�
�
srcs�SWIG interface files (.i) and headers. All files are available for %include directives. The main interface file is specified by 'main' attribute, or defaults to the first .i file. �Bazel rules for generating SWIG language bindings.

This module provides Bazel rules for generating language bindings
using SWIG.

Example usage:
    load("@swig//:swig.bzl", "swig_library")

    swig_library(
        name = "my_python_wrapper",
        srcs = [
            "my_interface.i",
            "additional.i",
            "header.h",
        ],
        main = "my_interface.i",
        language = "python",
        module = "my_module",
    )
 