�@
	tar.bzl�	
mtree_speclCreate an mtree specification to map a directory hierarchy. See https://man.freebsd.org/cgi/man.cgi?mtree(8)"�
�

mtree_speclCreate an mtree specification to map a directory hierarchy. See https://man.freebsd.org/cgi/man.cgi?mtree(8)*
nameA unique name for this target. 0
srcs"Files that are placed into the tar2[]6
out%Resulting specification file to write2None8�
include_runfiles�Include the runfiles tree in the resulting mtree for targets that are executable.

The runfiles are in the paths that Bazel uses. For example, for the
target `//my_prog:foo`, we would see files under paths like
`foo.runfiles/<repo name>/my_prog/<file>`2True"

mtree_spec//tar:mtree.bzl,
*
nameA unique name for this target. 2
0
srcs"Files that are placed into the tar2[]8
6
out%Resulting specification file to write2None8�
�
include_runfiles�Include the runfiles tree in the resulting mtree for targets that are executable.

The runfiles are in the paths that Bazel uses. For example, for the
target `//my_prog:foo`, we would see files under paths like
`foo.runfiles/<repo name>/my_prog/<file>`2True�mutateAFactory function to make a partially-applied `mtree_mutate` rule.*�
r
mutate

kwargs(AFactory function to make a partially-applied `mtree_mutate` rule.2
mutate//tar:mtree.bzl


kwargs(�mtree_mutate!Modify metadata in an mtree file.*�
�

mtree_mutate>
name2name of the target, output will be `[name].mtree`. (A
mtree4input mtree file, typically created by `mtree_spec`. (6
srcs&list of files to resolve symlinks for.None(�
preserve_symlinks�`EXPERIMENTAL!` We may remove or change it at any point without further notice. Flag to determine whether to preserve symlinks in the tar.False(|
strip_prefixdprefix to remove from all paths in the tar. Files and directories not under this prefix are dropped.None(G
package_dir0directory prefix to add to all paths in the tar.None(7
mtime&new modification time for all entries.None()
ownernew uid for all entries.None(/
	ownernamenew uname for all entries.None(�

awk_script�awk script for mtree mutation. Override to provide a custom script; use @include "default" to compose with the built-in pipeline."Label("//tar/private:default.awk")(m
script_argsXextra key=value variables passed via --assign. Available in awk_script and any includes.{}(�
includes�additional awk scripts appended after awk_script. A wrapper is generated that @include-s awk_script then each script here in order.None(2
kwargs&additional named parameters to genrule(!Modify metadata in an mtree file.2
mtree_mutate//tar:mtree.bzl@
>
name2name of the target, output will be `[name].mtree`. (C
A
mtree4input mtree file, typically created by `mtree_spec`. (8
6
srcs&list of files to resolve symlinks for.None(�
�
preserve_symlinks�`EXPERIMENTAL!` We may remove or change it at any point without further notice. Flag to determine whether to preserve symlinks in the tar.False(~
|
strip_prefixdprefix to remove from all paths in the tar. Files and directories not under this prefix are dropped.None(I
G
package_dir0directory prefix to add to all paths in the tar.None(9
7
mtime&new modification time for all entries.None(+
)
ownernew uid for all entries.None(1
/
	ownernamenew uname for all entries.None(�
�

awk_script�awk script for mtree mutation. Override to provide a custom script; use @include "default" to compose with the built-in pipeline."Label("//tar/private:default.awk")(o
m
script_argsXextra key=value variables passed via --assign. Available in awk_script and any includes.{}(�
�
includes�additional awk scripts appended after awk_script. A wrapper is generated that @include-s awk_script then each script here in order.None(4
2
kwargs&additional named parameters to genrule(� tar�	Wrapper macro around [`tar_rule`](#tar_rule).

### Options for mtree

mtree provides the "specification" or manifest of a tar file.
See https://man.freebsd.org/cgi/man.cgi?mtree(8)
Because BSD tar doesn't have a flag to set modification times to a constant,
we must always supply an mtree input to get reproducible builds.
See https://reproducible-builds.org/docs/archives/ for more explanation.

1. By default, mtree is "auto" which causes the macro to create an `mtree_spec` rule.

2. `mtree` may be supplied as an array literal of lines, e.g.

```
mtree =[
    "usr/bin uid=0 gid=0 mode=0755 type=dir",
    "usr/bin/ls uid=0 gid=0 mode=0755 time=0 type=file content={}/a".format(package_name()),
],
```

For the format of a line, see "There are four types of lines in a specification" on the man page for BSD mtree,
https://man.freebsd.org/cgi/man.cgi?mtree(8)

When you supply your own mtree lines, enable the `--@tar.bzl//tar:validate_reproducibility`
flag to add a validation action that checks every `type=file` entry sets `uid`, `gid`,
`time`, and `mode`, which are required for reproducible tar output.

3. `mtree` may be a label of a file containing the specification lines.
*�
�
tar(
namename of resulting `tar_rule` (�
mtree�"auto", or an array of specification lines, or a label of a file that contains the lines.
Subject to [$(location)](https://bazel.build/reference/be/make-variables#predefined_label_variables)
and ["Make variable"](https://bazel.build/reference/be/make-variables) substitution."auto"(9
mutate'a partially-applied `mtree_mutate` ruleNone(�
include_runfiles�When using "auto" mtree, this controls whether to include runfiles.

If mtree is supplied as an array literal of lines, you are already hardcoding list of included files.

When mtree is a label, you need to set [include_runfiles](https://github.com/bazel-contrib/tar.bzl/blob/main/docs/mtree.md#mtree_spec-include_runfiles) in mtree_specs.None(/
stamp!should mtree attribute be stamped0(=
kwargs1additional named parameters to pass to `tar_rule`(�	Wrapper macro around [`tar_rule`](#tar_rule).

### Options for mtree

mtree provides the "specification" or manifest of a tar file.
See https://man.freebsd.org/cgi/man.cgi?mtree(8)
Because BSD tar doesn't have a flag to set modification times to a constant,
we must always supply an mtree input to get reproducible builds.
See https://reproducible-builds.org/docs/archives/ for more explanation.

1. By default, mtree is "auto" which causes the macro to create an `mtree_spec` rule.

2. `mtree` may be supplied as an array literal of lines, e.g.

```
mtree =[
    "usr/bin uid=0 gid=0 mode=0755 type=dir",
    "usr/bin/ls uid=0 gid=0 mode=0755 time=0 type=file content={}/a".format(package_name()),
],
```

For the format of a line, see "There are four types of lines in a specification" on the man page for BSD mtree,
https://man.freebsd.org/cgi/man.cgi?mtree(8)

When you supply your own mtree lines, enable the `--@tar.bzl//tar:validate_reproducibility`
flag to add a validation action that checks every `type=file` entry sets `uid`, `gid`,
`time`, and `mode`, which are required for reproducible tar output.

3. `mtree` may be a label of a file containing the specification lines.
2
tar//tar:tar.bzl*
(
namename of resulting `tar_rule` (�
�
mtree�"auto", or an array of specification lines, or a label of a file that contains the lines.
Subject to [$(location)](https://bazel.build/reference/be/make-variables#predefined_label_variables)
and ["Make variable"](https://bazel.build/reference/be/make-variables) substitution."auto"(;
9
mutate'a partially-applied `mtree_mutate` ruleNone(�
�
include_runfiles�When using "auto" mtree, this controls whether to include runfiles.

If mtree is supplied as an array literal of lines, you are already hardcoding list of included files.

When mtree is a label, you need to set [include_runfiles](https://github.com/bazel-contrib/tar.bzl/blob/main/docs/mtree.md#mtree_spec-include_runfiles) in mtree_specs.None(1
/
stamp!should mtree attribute be stamped0(?
=
kwargs1additional named parameters to pass to `tar_rule`(8re-export to allow syntax sugar: load("@tar.bzl", "tar")�$
tar	mtree.bzl�	
mtree_speclCreate an mtree specification to map a directory hierarchy. See https://man.freebsd.org/cgi/man.cgi?mtree(8)"�
�

mtree_speclCreate an mtree specification to map a directory hierarchy. See https://man.freebsd.org/cgi/man.cgi?mtree(8)*
nameA unique name for this target. 0
srcs"Files that are placed into the tar2[]6
out%Resulting specification file to write2None8�
include_runfiles�Include the runfiles tree in the resulting mtree for targets that are executable.

The runfiles are in the paths that Bazel uses. For example, for the
target `//my_prog:foo`, we would see files under paths like
`foo.runfiles/<repo name>/my_prog/<file>`2True"

mtree_spec//tar:mtree.bzl,
*
nameA unique name for this target. 2
0
srcs"Files that are placed into the tar2[]8
6
out%Resulting specification file to write2None8�
�
include_runfiles�Include the runfiles tree in the resulting mtree for targets that are executable.

The runfiles are in the paths that Bazel uses. For example, for the
target `//my_prog:foo`, we would see files under paths like
`foo.runfiles/<repo name>/my_prog/<file>`2True�mtree_mutate!Modify metadata in an mtree file.*�
�

mtree_mutate>
name2name of the target, output will be `[name].mtree`. (A
mtree4input mtree file, typically created by `mtree_spec`. (6
srcs&list of files to resolve symlinks for.None(�
preserve_symlinks�`EXPERIMENTAL!` We may remove or change it at any point without further notice. Flag to determine whether to preserve symlinks in the tar.False(|
strip_prefixdprefix to remove from all paths in the tar. Files and directories not under this prefix are dropped.None(G
package_dir0directory prefix to add to all paths in the tar.None(7
mtime&new modification time for all entries.None()
ownernew uid for all entries.None(/
	ownernamenew uname for all entries.None(�

awk_script�awk script for mtree mutation. Override to provide a custom script; use @include "default" to compose with the built-in pipeline."Label("//tar/private:default.awk")(m
script_argsXextra key=value variables passed via --assign. Available in awk_script and any includes.{}(�
includes�additional awk scripts appended after awk_script. A wrapper is generated that @include-s awk_script then each script here in order.None(2
kwargs&additional named parameters to genrule(!Modify metadata in an mtree file.2
mtree_mutate//tar:mtree.bzl@
>
name2name of the target, output will be `[name].mtree`. (C
A
mtree4input mtree file, typically created by `mtree_spec`. (8
6
srcs&list of files to resolve symlinks for.None(�
�
preserve_symlinks�`EXPERIMENTAL!` We may remove or change it at any point without further notice. Flag to determine whether to preserve symlinks in the tar.False(~
|
strip_prefixdprefix to remove from all paths in the tar. Files and directories not under this prefix are dropped.None(I
G
package_dir0directory prefix to add to all paths in the tar.None(9
7
mtime&new modification time for all entries.None(+
)
ownernew uid for all entries.None(1
/
	ownernamenew uname for all entries.None(�
�

awk_script�awk script for mtree mutation. Override to provide a custom script; use @include "default" to compose with the built-in pipeline."Label("//tar/private:default.awk")(o
m
script_argsXextra key=value variables passed via --assign. Available in awk_script and any includes.{}(�
�
includes�additional awk scripts appended after awk_script. A wrapper is generated that @include-s awk_script then each script here in order.None(4
2
kwargs&additional named parameters to genrule(�mutateAFactory function to make a partially-applied `mtree_mutate` rule.*�
r
mutate

kwargs(AFactory function to make a partially-applied `mtree_mutate` rule.2
mutate//tar:mtree.bzl


kwargs(�Helpers for mtree(8), see https://man.freebsd.org/cgi/man.cgi?mtree(8)

### Mutating the tar contents

The `mtree_spec` rule can be used to create an mtree manifest for the tar file.
Then you can mutate that spec using `mtree_mutate` and feed the result
as the `mtree` attribute of the `tar` rule.

For example, to set the owner uid of files in the tar, you could:

```starlark
_TAR_SRCS = ["//some:files"]

mtree_spec(
    name = "mtree",
    srcs = _TAR_SRCS,
)

mtree_mutate(
    name = "change_owner",
    mtree = ":mtree",
    owner = "1000",
)

tar(
    name = "tar",
    srcs = _TAR_SRCS,
    mtree = "change_owner",
)
```�Y
tartar.bzl�*tar_rulelRule that executes BSD `tar`. Most users should use the [`tar`](#tar) macro, rather than load this directly."�)
�
tar_rulelRule that executes BSD `tar`. Most users should use the [`tar`](#tar) macro, rather than load this directly.*
nameA unique name for this target. F
args8Additional flags permitted by BSD tar; see the man page.2[]�
srcs�Files, directories, or other targets whose default outputs are placed into the tar.

If any of the srcs are binaries with runfiles, those are copied into the resulting tar as well.2[]�
mode�A mode indicator from the following list, copied from the tar manpage:

- create: Create a new archive containing the specified items.

Other modes may be added in the future.2"create"J"create"(
mtreeAn mtree specification file Q
out@Resulting tar file to write. If absent, `[name].tar` is written.2None8�
compressbCompress the archive file with a supported algorithm.

Default is `""` which means no compression.2""J""J"bzip2"J
"compress"J"gzip"J"lrzip"J"lz4"J"lzma"J"lzop"J"xz"J"zstd"C

compressor-External tool which can compress the archive.2None3
compressor_argsArg list for `compressor`.2""�
compute_unused_inputs�Whether to discover and prune input files that will not contribute to the archive.

Unused inputs are discovered by comparing the set of input files in `srcs` to the set
of files referenced by `mtree`. Files not used for content by the mtree specification
will not be read by the `tar` tool when creating the archive and can be pruned from the
input set using the `unused_inputs_list`
[mechanism](https://bazel.build/contribute/codebase#input-discovery).

Benefits: pruning unused input files can reduce the amount of work the build system must
perform. Pruned files are not included in the (local)action cache key; changes to them do
not invalidate the cache entry, which can lead to higher cache hit rates. Actions do not
need to block on the availability of pruned inputs, which can increase the available
parallelism of builds.

Risks: pruning an actually-used input file can lead to unexpected, incorrect results. The
comparison performed between `srcs` and `mtree` is currently inexact and may fail to
handle handwritten or externally-derived mtree specifications. However, it is safe to use
this feature when the lines found in `mtree` are derived from one or more `mtree_spec`
rules, filtered and/or merged on whole-line basis only.

Possible values:

    - `compute_unused_inputs = 1`: Always perform unused input discovery and pruning.
    - `compute_unused_inputs = 0`: Never discover or prune unused inputs.
    - `compute_unused_inputs = -1`: Discovery and pruning of unused inputs is controlled by the
        --[no]@tar.bzl//tar:tar_compute_unused_inputs flag.2-1J-1J0J1"
tar//tar/private:tar.bzl,
*
nameA unique name for this target. H
F
args8Additional flags permitted by BSD tar; see the man page.2[]�
�
srcs�Files, directories, or other targets whose default outputs are placed into the tar.

If any of the srcs are binaries with runfiles, those are copied into the resulting tar as well.2[]�
�
mode�A mode indicator from the following list, copied from the tar manpage:

- create: Create a new archive containing the specified items.

Other modes may be added in the future.2"create"J"create"*
(
mtreeAn mtree specification file S
Q
out@Resulting tar file to write. If absent, `[name].tar` is written.2None8�
�
compressbCompress the archive file with a supported algorithm.

Default is `""` which means no compression.2""J""J"bzip2"J
"compress"J"gzip"J"lrzip"J"lz4"J"lzma"J"lzop"J"xz"J"zstd"E
C

compressor-External tool which can compress the archive.2None5
3
compressor_argsArg list for `compressor`.2""�
�
compute_unused_inputs�Whether to discover and prune input files that will not contribute to the archive.

Unused inputs are discovered by comparing the set of input files in `srcs` to the set
of files referenced by `mtree`. Files not used for content by the mtree specification
will not be read by the `tar` tool when creating the archive and can be pruned from the
input set using the `unused_inputs_list`
[mechanism](https://bazel.build/contribute/codebase#input-discovery).

Benefits: pruning unused input files can reduce the amount of work the build system must
perform. Pruned files are not included in the (local)action cache key; changes to them do
not invalidate the cache entry, which can lead to higher cache hit rates. Actions do not
need to block on the availability of pruned inputs, which can increase the available
parallelism of builds.

Risks: pruning an actually-used input file can lead to unexpected, incorrect results. The
comparison performed between `srcs` and `mtree` is currently inexact and may fail to
handle handwritten or externally-derived mtree specifications. However, it is safe to use
this feature when the lines found in `mtree` are derived from one or more `mtree_spec`
rules, filtered and/or merged on whole-line basis only.

Possible values:

    - `compute_unused_inputs = 1`: Always perform unused input discovery and pruning.
    - `compute_unused_inputs = 0`: Never discover or prune unused inputs.
    - `compute_unused_inputs = -1`: Discovery and pruning of unused inputs is controlled by the
        --[no]@tar.bzl//tar:tar_compute_unused_inputs flag.2-1J-1J0J1�#tar_lib.common.add_compression_args*�
q
#tar_lib.common.add_compression_args
compress (

args (2.
_add_compression_args//tar/private:tar.bzl

compress (


args (rtar_lib.implementation*V
G
tar_lib.implementation	
ctx (2"
	_tar_impl//tar/private:tar.bzl
	
ctx (�tar_lib.mtree_implementation*^
O
tar_lib.mtree_implementation	
ctx (2$
_mtree_impl//tar/private:tar.bzl
	
ctx (� tar�	Wrapper macro around [`tar_rule`](#tar_rule).

### Options for mtree

mtree provides the "specification" or manifest of a tar file.
See https://man.freebsd.org/cgi/man.cgi?mtree(8)
Because BSD tar doesn't have a flag to set modification times to a constant,
we must always supply an mtree input to get reproducible builds.
See https://reproducible-builds.org/docs/archives/ for more explanation.

1. By default, mtree is "auto" which causes the macro to create an `mtree_spec` rule.

2. `mtree` may be supplied as an array literal of lines, e.g.

```
mtree =[
    "usr/bin uid=0 gid=0 mode=0755 type=dir",
    "usr/bin/ls uid=0 gid=0 mode=0755 time=0 type=file content={}/a".format(package_name()),
],
```

For the format of a line, see "There are four types of lines in a specification" on the man page for BSD mtree,
https://man.freebsd.org/cgi/man.cgi?mtree(8)

When you supply your own mtree lines, enable the `--@tar.bzl//tar:validate_reproducibility`
flag to add a validation action that checks every `type=file` entry sets `uid`, `gid`,
`time`, and `mode`, which are required for reproducible tar output.

3. `mtree` may be a label of a file containing the specification lines.
*�
�
tar(
namename of resulting `tar_rule` (�
mtree�"auto", or an array of specification lines, or a label of a file that contains the lines.
Subject to [$(location)](https://bazel.build/reference/be/make-variables#predefined_label_variables)
and ["Make variable"](https://bazel.build/reference/be/make-variables) substitution."auto"(9
mutate'a partially-applied `mtree_mutate` ruleNone(�
include_runfiles�When using "auto" mtree, this controls whether to include runfiles.

If mtree is supplied as an array literal of lines, you are already hardcoding list of included files.

When mtree is a label, you need to set [include_runfiles](https://github.com/bazel-contrib/tar.bzl/blob/main/docs/mtree.md#mtree_spec-include_runfiles) in mtree_specs.None(/
stamp!should mtree attribute be stamped0(=
kwargs1additional named parameters to pass to `tar_rule`(�	Wrapper macro around [`tar_rule`](#tar_rule).

### Options for mtree

mtree provides the "specification" or manifest of a tar file.
See https://man.freebsd.org/cgi/man.cgi?mtree(8)
Because BSD tar doesn't have a flag to set modification times to a constant,
we must always supply an mtree input to get reproducible builds.
See https://reproducible-builds.org/docs/archives/ for more explanation.

1. By default, mtree is "auto" which causes the macro to create an `mtree_spec` rule.

2. `mtree` may be supplied as an array literal of lines, e.g.

```
mtree =[
    "usr/bin uid=0 gid=0 mode=0755 type=dir",
    "usr/bin/ls uid=0 gid=0 mode=0755 time=0 type=file content={}/a".format(package_name()),
],
```

For the format of a line, see "There are four types of lines in a specification" on the man page for BSD mtree,
https://man.freebsd.org/cgi/man.cgi?mtree(8)

When you supply your own mtree lines, enable the `--@tar.bzl//tar:validate_reproducibility`
flag to add a validation action that checks every `type=file` entry sets `uid`, `gid`,
`time`, and `mode`, which are required for reproducible tar output.

3. `mtree` may be a label of a file containing the specification lines.
2
tar//tar:tar.bzl*
(
namename of resulting `tar_rule` (�
�
mtree�"auto", or an array of specification lines, or a label of a file that contains the lines.
Subject to [$(location)](https://bazel.build/reference/be/make-variables#predefined_label_variables)
and ["Make variable"](https://bazel.build/reference/be/make-variables) substitution."auto"(;
9
mutate'a partially-applied `mtree_mutate` ruleNone(�
�
include_runfiles�When using "auto" mtree, this controls whether to include runfiles.

If mtree is supplied as an array literal of lines, you are already hardcoding list of included files.

When mtree is a label, you need to set [include_runfiles](https://github.com/bazel-contrib/tar.bzl/blob/main/docs/mtree.md#mtree_spec-include_runfiles) in mtree_specs.None(1
/
stamp!should mtree attribute be stamped0(?
=
kwargs1additional named parameters to pass to `tar_rule`(�	API for calling tar, see https://man.freebsd.org/cgi/man.cgi?tar(1)

Load from:

```starlark
load("@tar.bzl", "tar")
```

Examples
--------

```starlark
# Build this target to produce archive.tar:
tar(
    name = "archive",
    srcs = ["my-file.txt"],
)
```

Mutations allow modification of the archive's structure. For example to strip the package name:

```starlark
load("@tar.bzl", "mutate", "tar")

tar(
    name = "new",
    srcs = ["my-file.txt"],
    # See arguments documented at
    # https://github.com/bazel-contrib/tar.bzl/blob/main/docs/mtree.md#mtree_mutate
    mutate = mutate(strip_prefix = package_name()),
)
```

Compression is supported. Of course it takes additional time and resources.

```starlark
# Build this target to produce archive.tar.gz:
tar(
    name = "my_archive",
    compress = "gzip",
    ...
)
```

Normally if your tar file is small, you can keep using the built-in gzip, but if your tar file is large, over 1GB, parallel `pigz` will greatly improve the performance.

1. Add `pigz` in `MODULE.bazel`; see https://registry.bazel.build/modules/pigz
2. Use the new tar compressor attribute in your BUILD file, eg:

```starlark
tar(
    name = "my_tar_file",
    compressor = "@pigz",
    compressor_args = "-n",
    ...
)
``` 