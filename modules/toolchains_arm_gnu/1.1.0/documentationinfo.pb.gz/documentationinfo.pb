�
.
toolchains_arm_gnu	toolchaintoolchain.bzl�aarch64_none_elf_toolchain0Create a toolchain with the given configuration.*�
�
aarch64_none_elf_toolchain&
nameThe name of the toolchain. (0
version!The version of the gcc toolchain. (&
kwargssame as toolchains_arm_gnu(0Create a toolchain with the given configuration.2K
aarch64_none_elf_toolchain-@@toolchains_arm_gnu//toolchain:toolchain.bzl
��*_arm_gnu_toolchain� aarch64_none_linux_gnu_toolchainHCreate an aarch64-none-linux-gnu toolchain with the given configuration.*�
�
 aarch64_none_linux_gnu_toolchain&
nameThe name of the toolchain. (8
version!The version of the gcc toolchain."13.2.1"(,
linkoptsAdditional linker options.[]()
kwargsAdditional keyword arguments.(HCreate an aarch64-none-linux-gnu toolchain with the given configuration.2Q
 aarch64_none_linux_gnu_toolchain-@@toolchains_arm_gnu//toolchain:toolchain.bzl
��*_arm_gnu_toolchain�arm_none_eabi_toolchain?Create an arm-none-eabi toolchain with the given configuration.*�
�
arm_none_eabi_toolchain&
nameThe name of the toolchain. (8
version!The version of the gcc toolchain."13.2.1"(&
kwargssame as toolchains_arm_gnu(?Create an arm-none-eabi toolchain with the given configuration.2H
arm_none_eabi_toolchain-@@toolchains_arm_gnu//toolchain:toolchain.bzl
��*_arm_gnu_toolchain�"arm_none_linux_gnueabihf_toolchainJCreate an arm-none-linux-gnueabihf toolchain with the given configuration.*�
�
"arm_none_linux_gnueabihf_toolchain&
nameThe name of the toolchain. (8
version!The version of the gcc toolchain."13.2.1"(,
linkoptsAdditional linker options.[]()
kwargsAdditional keyword arguments.(JCreate an arm-none-linux-gnueabihf toolchain with the given configuration.2S
"arm_none_linux_gnueabihf_toolchain-@@toolchains_arm_gnu//toolchain:toolchain.bzl
��*_arm_gnu_toolchaing
//cc:defs.bzlrT

rules_ccccdefs.bzl*
cc_toolchaincc_toolchain
!-
/�
//toolchain:config.bzlr�
+
toolchains_arm_gnu	toolchain
config.bzlH
cc_arm_gnu_toolchain_configcc_arm_gnu_toolchain_config
4O
Qz	toolsjo2m
as
ar
c++
cpp
g++
gcc
gdb
ld
nm
	objcopy
	objdump
	readelf
strip
sizeG
This module provides functions to register an arm-none-eabi toolchain
f
>
toolchains_arm_gnutoolchain/archivesaarch64_none_elf.bzl$aarch64_none_elf toolchiain archivesr
D
toolchains_arm_gnutoolchain/archivesaarch64_none_linux_gnu.bzl*aarch64-none-linux-gnu toolchiain archives`
;
toolchains_arm_gnutoolchain/archivesarm_none_eabi.bzl!arm-none-eabi toolchiain archivesv
F
toolchains_arm_gnutoolchain/archivesarm_none_linux_gnueabihf.bzl,arm-none=linux-gnueabihf toolchiain archives�

+
toolchains_arm_gnu	toolchain
config.bzl�cc_arm_gnu_toolchain_config"�
�
cc_arm_gnu_toolchain_config*
nameA unique name for this target. 
abi_version2""
copts2[]
gcc_repo2""
gcc_tool2"gcc"
gcc_version2""
host_system_name2""
include_path2[]
include_std2False
library_path2[]
linkopts2[]
toolchain_bins 
toolchain_identifier2""
toolchain_prefix2"""I
cc_arm_gnu_toolchain_config*@@toolchains_arm_gnu//toolchain:config.bzl
�#�#,
*
nameA unique name for this target. 

abi_version2""

copts2[]

gcc_repo2""

gcc_tool2"gcc"

gcc_version2""

host_system_name2""

include_path2[]

include_std2False

library_path2[]

linkopts2[]

toolchain_bins 

toolchain_identifier2""

toolchain_prefix2""�
&//tools/build_defs/cc:action_names.bzlrp
4
bazel_toolstools/build_defs/ccaction_names.bzl*
ACTION_NAMESACTION_NAMES
=I
K�
 //cc:cc_toolchain_config_lib.bzlr�
+
rules_cccccc_toolchain_config_lib.bzl,
action_configaction_config
4A 
featurefeature
EL&

flag_group
flag_group
PZ"
flag_setflag_set
^f
h��

toolchains_arm_gnudeps.bzl��aarch64_none_elf_deps0Workspace dependencies for the arm gcc toolchain*Ӕ
��
aarch64_none_elf_depsd
versionIThe version of the toolchain to use. If None, the latest version is used."13.2.1-1.1"(Ғ
archives2A dictionary of the version to archive attributes.��{"11.2.1-1.1": [{"name": "aarch64_none_elf_darwin_arm64", "url": "https://github.com/xpack-dev-tools/aarch64-none-elf-gcc-xpack/releases/download/v11.2.1-1.1/xpack-aarch64-none-elf-gcc-11.2.1-1.1-darwin-arm64.tar.gz", "sha256": "fdd941fa157fbd187a2168171a6222d53fbc02a1c21dc0454ce3b7315b3a3141", "strip_prefix": "xpack-aarch64-none-elf-gcc-11.2.1-1.1", "exec_compatible_with": ["@platforms//os:macos", "@platforms//cpu:arm64"]}, {"name": "aarch64_none_elf_darwin_x86_64", "url": "https://github.com/xpack-dev-tools/aarch64-none-elf-gcc-xpack/releases/download/v11.2.1-1.1/xpack-aarch64-none-elf-gcc-11.2.1-1.1-darwin-x64.tar.gz", "sha256": "285e232032b71bc76cac796d3553072ad23c5efb928b8128bdb7bcb6d726852c", "strip_prefix": "xpack-aarch64-none-elf-gcc-11.2.1-1.1", "exec_compatible_with": ["@platforms//os:macos", "@platforms//cpu:x86_64"]}, {"name": "aarch64_none_elf_linux_aarch64", "url": "https://github.com/xpack-dev-tools/aarch64-none-elf-gcc-xpack/releases/download/v11.2.1-1.1/xpack-aarch64-none-elf-gcc-11.2.1-1.1-linux-arm64.tar.gz", "sha256": "9e2753aea1d019f5c7853932b6b1afb623de11e4abe8ab367341a648d5b0e941", "strip_prefix": "xpack-aarch64-none-elf-gcc-11.2.1-1.1", "exec_compatible_with": ["@platforms//os:linux", "@platforms//cpu:arm64"]}, {"name": "aarch64_none_elf_linux_x86_64", "url": "https://github.com/xpack-dev-tools/aarch64-none-elf-gcc-xpack/releases/download/v11.2.1-1.1/xpack-aarch64-none-elf-gcc-11.2.1-1.1-linux-x64.tar.gz", "sha256": "f422b9a3a26c9801598233c9621d218c3c268547ed302d390061b2e9103bd188", "strip_prefix": "xpack-aarch64-none-elf-gcc-11.2.1-1.1", "exec_compatible_with": ["@platforms//os:linux", "@platforms//cpu:x86_64"]}, {"name": "aarch64_none_elf_windows_x86_64", "url": "https://github.com/xpack-dev-tools/aarch64-none-elf-gcc-xpack/releases/download/v11.2.1-1.1/xpack-aarch64-none-elf-gcc-11.2.1-1.1-win32-x64.zip", "sha256": "e5c5bb40fc8820a45ebd359e61e82a98b6d0c136e24628b2cba668261a9d8683", "strip_prefix": "xpack-aarch64-none-elf-gcc-11.2.1-1.1", "exec_compatible_with": ["@platforms//os:windows", "@platforms//cpu:x86_64"]}], "11.2.1-1.2": [{"name": "aarch64_none_elf_darwin_arm64", "url": "https://github.com/xpack-dev-tools/aarch64-none-elf-gcc-xpack/releases/download/v11.2.1-1.2/xpack-aarch64-none-elf-gcc-11.2.1-1.2-darwin-arm64.tar.gz", "sha256": "13790cf505cda92e12d5da01ac916fdecf4d724b8497828d446b7bc494d13a6b", "strip_prefix": "xpack-aarch64-none-elf-gcc-11.2.1-1.2", "exec_compatible_with": ["@platforms//os:macos", "@platforms//cpu:arm64"]}, {"name": "aarch64_none_elf_darwin_x86_64", "url": "https://github.com/xpack-dev-tools/aarch64-none-elf-gcc-xpack/releases/download/v11.2.1-1.2/xpack-aarch64-none-elf-gcc-11.2.1-1.2-darwin-x64.tar.gz", "sha256": "d32aa91694e5fea3e721fe9269a74f05887cf94c97636f9ccd4ae3ecfd034fa5", "strip_prefix": "xpack-aarch64-none-elf-gcc-11.2.1-1.2", "exec_compatible_with": ["@platforms//os:macos", "@platforms//cpu:x86_64"]}, {"name": "aarch64_none_elf_linux_aarch64", "url": "https://github.com/xpack-dev-tools/aarch64-none-elf-gcc-xpack/releases/download/v11.2.1-1.2/xpack-aarch64-none-elf-gcc-11.2.1-1.2-linux-arm64.tar.gz", "sha256": "9eb0b95e8267e7d86dc18cad44744f984ef8b1c50df030c854abd5e5e99a3c68", "strip_prefix": "xpack-aarch64-none-elf-gcc-11.2.1-1.2", "exec_compatible_with": ["@platforms//os:linux", "@platforms//cpu:arm64"]}, {"name": "aarch64_none_elf_linux_x86_64", "url": "https://github.com/xpack-dev-tools/aarch64-none-elf-gcc-xpack/releases/download/v11.2.1-1.2/xpack-aarch64-none-elf-gcc-11.2.1-1.2-linux-x64.tar.gz", "sha256": "e14ac6851317da56d192757e028460afc64b998c446d97b3761873a2b91058d8", "strip_prefix": "xpack-aarch64-none-elf-gcc-11.2.1-1.2", "exec_compatible_with": ["@platforms//os:linux", "@platforms//cpu:x86_64"]}, {"name": "aarch64_none_elf_windows_x86_64", "url": "https://github.com/xpack-dev-tools/aarch64-none-elf-gcc-xpack/releases/download/v11.2.1-1.2/xpack-aarch64-none-elf-gcc-11.2.1-1.2-win32-x64.zip", "sha256": "78deba2be085002cb31c80591792264e250aee9ae6d4d996871679781db16706", "strip_prefix": "xpack-aarch64-none-elf-gcc-11.2.1-1.2", "exec_compatible_with": ["@platforms//os:windows", "@platforms//cpu:x86_64"]}], "11.3.1-1.1": [{"name": "aarch64_none_elf_darwin_arm64", "url": "https://github.com/xpack-dev-tools/aarch64-none-elf-gcc-xpack/releases/download/v11.3.1-1.1/xpack-aarch64-none-elf-gcc-11.3.1-1.1-darwin-arm64.tar.gz", "sha256": "7ddb902469db43160db84c59f97ff60783b3e7b75ec1d98442e259b5e03c3201", "strip_prefix": "xpack-aarch64-none-elf-gcc-11.3.1-1.1", "exec_compatible_with": ["@platforms//os:macos", "@platforms//cpu:arm64"]}, {"name": "aarch64_none_elf_darwin_x86_64", "url": "https://github.com/xpack-dev-tools/aarch64-none-elf-gcc-xpack/releases/download/v11.3.1-1.1/xpack-aarch64-none-elf-gcc-11.3.1-1.1-darwin-x64.tar.gz", "sha256": "26a0a9d9098d58c758aceab30a6ac00d62d9c5d9a7b32b6494b99338c8457396", "strip_prefix": "xpack-aarch64-none-elf-gcc-11.3.1-1.1", "exec_compatible_with": ["@platforms//os:macos", "@platforms//cpu:x86_64"]}, {"name": "aarch64_none_elf_linux_aarch64", "url": "https://github.com/xpack-dev-tools/aarch64-none-elf-gcc-xpack/releases/download/v11.3.1-1.1/xpack-aarch64-none-elf-gcc-11.3.1-1.1-linux-arm64.tar.gz", "sha256": "81f610aa047f669cfcb9701737b2aed6a0956df822bdab813b1d1ca0182985c6", "strip_prefix": "xpack-aarch64-none-elf-gcc-11.3.1-1.1", "exec_compatible_with": ["@platforms//os:linux", "@platforms//cpu:arm64"]}, {"name": "aarch64_none_elf_linux_x86_64", "url": "https://github.com/xpack-dev-tools/aarch64-none-elf-gcc-xpack/releases/download/v11.3.1-1.1/xpack-aarch64-none-elf-gcc-11.3.1-1.1-linux-x64.tar.gz", "sha256": "60c9d00697981f7e721f81df69a830b4c9d3da52f3cb53f8ae86420faa808864", "strip_prefix": "xpack-aarch64-none-elf-gcc-11.3.1-1.1", "exec_compatible_with": ["@platforms//os:linux", "@platforms//cpu:x86_64"]}, {"name": "aarch64_none_elf_windows_x86_64", "url": "https://github.com/xpack-dev-tools/aarch64-none-elf-gcc-xpack/releases/download/v11.3.1-1.1/xpack-aarch64-none-elf-gcc-11.3.1-1.1-win32-x64.zip", "sha256": "c63dbea1fcd6a303fde1359e51d1819064a47ac2a3ed7cd353b554a22f3ab310", "strip_prefix": "xpack-aarch64-none-elf-gcc-11.3.1-1.1", "exec_compatible_with": ["@platforms//os:windows", "@platforms//cpu:x86_64"]}], "11.3.1-1.2": [{"name": "aarch64_none_elf_darwin_arm64", "url": "https://github.com/xpack-dev-tools/aarch64-none-elf-gcc-xpack/releases/download/v11.3.1-1.2/xpack-aarch64-none-elf-gcc-11.3.1-1.2-darwin-arm64.tar.gz", "sha256": "368d0d09f806db9c4e44671047502d0185a20534997bee617b2468586bcef6ec", "strip_prefix": "xpack-aarch64-none-elf-gcc-11.3.1-1.2", "exec_compatible_with": ["@platforms//os:macos", "@platforms//cpu:arm64"]}, {"name": "aarch64_none_elf_darwin_x86_64", "url": "https://github.com/xpack-dev-tools/aarch64-none-elf-gcc-xpack/releases/download/v11.3.1-1.2/xpack-aarch64-none-elf-gcc-11.3.1-1.2-darwin-x64.tar.gz", "sha256": "40b674e43ddca0cd98c41d22a7c59187c54d9e272fe4da57a9d91e6d0c99b0c1", "strip_prefix": "xpack-aarch64-none-elf-gcc-11.3.1-1.2", "exec_compatible_with": ["@platforms//os:macos", "@platforms//cpu:x86_64"]}, {"name": "aarch64_none_elf_linux_aarch64", "url": "https://github.com/xpack-dev-tools/aarch64-none-elf-gcc-xpack/releases/download/v11.3.1-1.2/xpack-aarch64-none-elf-gcc-11.3.1-1.2-linux-arm64.tar.gz", "sha256": "51c8142c51e34e3559687815b0dbdf65bd18db44674a21865fa9c688a7ccba1e", "strip_prefix": "xpack-aarch64-none-elf-gcc-11.3.1-1.2", "exec_compatible_with": ["@platforms//os:linux", "@platforms//cpu:arm64"]}, {"name": "aarch64_none_elf_linux_x86_64", "url": "https://github.com/xpack-dev-tools/aarch64-none-elf-gcc-xpack/releases/download/v11.3.1-1.2/xpack-aarch64-none-elf-gcc-11.3.1-1.2-linux-x64.tar.gz", "sha256": "1179481f8762ec1bbeda54eb1520a10187fca70d21aef37c3207ddf21e6cb8c9", "strip_prefix": "xpack-aarch64-none-elf-gcc-11.3.1-1.2", "exec_compatible_with": ["@platforms//os:linux", "@platforms//cpu:x86_64"]}, {"name": "aarch64_none_elf_windows_x86_64", "url": "https://github.com/xpack-dev-tools/aarch64-none-elf-gcc-xpack/releases/download/v11.3.1-1.2/xpack-aarch64-none-elf-gcc-11.3.1-1.2-win32-x64.zip", "sha256": "bc742a197f2e04ec0735bfad82ce9f742f7fa59ccee48b7058ad33c024013631", "strip_prefix": "xpack-aarch64-none-elf-gcc-11.3.1-1.2", "exec_compatible_with": ["@platforms//os:windows", "@platforms//cpu:x86_64"]}], "12.2.1-1.1": [{"name": "aarch64_none_elf_darwin_arm64", "url": "https://github.com/xpack-dev-tools/aarch64-none-elf-gcc-xpack/releases/download/v12.2.1-1.1/xpack-aarch64-none-elf-gcc-12.2.1-1.1-darwin-arm64.tar.gz", "sha256": "d96adb623baae7e8737418917c89a6da6d1f0cf157cfd0a190ad68b87700977e", "strip_prefix": "xpack-aarch64-none-elf-gcc-12.2.1-1.1", "exec_compatible_with": ["@platforms//os:macos", "@platforms//cpu:arm64"]}, {"name": "aarch64_none_elf_darwin_x86_64", "url": "https://github.com/xpack-dev-tools/aarch64-none-elf-gcc-xpack/releases/download/v12.2.1-1.1/xpack-aarch64-none-elf-gcc-12.2.1-1.1-darwin-x64.tar.gz", "sha256": "a9d3d28303b433155c632e8b950068142b54c3f6d3b6eb1a0e1dd8ef49edd6ea", "strip_prefix": "xpack-aarch64-none-elf-gcc-12.2.1-1.1", "exec_compatible_with": ["@platforms//os:macos", "@platforms//cpu:x86_64"]}, {"name": "aarch64_none_elf_linux_aarch64", "url": "https://github.com/xpack-dev-tools/aarch64-none-elf-gcc-xpack/releases/download/v12.2.1-1.1/xpack-aarch64-none-elf-gcc-12.2.1-1.1-linux-arm64.tar.gz", "sha256": "de41b7af6dd0abcb0d99c92357865db8c8fc2d73565ea9eae4581ceec1f25de4", "strip_prefix": "xpack-aarch64-none-elf-gcc-12.2.1-1.1", "exec_compatible_with": ["@platforms//os:linux", "@platforms//cpu:arm64"]}, {"name": "aarch64_none_elf_linux_x86_64", "url": "https://github.com/xpack-dev-tools/aarch64-none-elf-gcc-xpack/releases/download/v12.2.1-1.1/xpack-aarch64-none-elf-gcc-12.2.1-1.1-linux-x64.tar.gz", "sha256": "20c3255b0f9d35b4715351972470f2f3e09b77669c2c85627b4e81e16cc5a2e6", "strip_prefix": "xpack-aarch64-none-elf-gcc-12.2.1-1.1", "exec_compatible_with": ["@platforms//os:linux", "@platforms//cpu:x86_64"]}, {"name": "aarch64_none_elf_windows_x86_64", "url": "https://github.com/xpack-dev-tools/aarch64-none-elf-gcc-xpack/releases/download/v12.2.1-1.1/xpack-aarch64-none-elf-gcc-12.2.1-1.1-win32-x64.zip", "sha256": "179d7da383ed043930f6a03a24e56c9599565cb292063dba39b85db49c9d55a3", "strip_prefix": "xpack-aarch64-none-elf-gcc-12.2.1-1.1", "exec_compatible_with": ["@platforms//os:windows", "@platforms//cpu:x86_64"]}], "12.2.1-1.2": [{"name": "aarch64_none_elf_darwin_arm64", "url": "https://github.com/xpack-dev-tools/aarch64-none-elf-gcc-xpack/releases/download/v12.2.1-1.2/xpack-aarch64-none-elf-gcc-12.2.1-1.2-darwin-arm64.tar.gz", "sha256": "7f1a9f1092c87109016147e8faa0be373aeee050ccfa1ae4b57c22702253ae4d", "strip_prefix": "xpack-aarch64-none-elf-gcc-12.2.1-1.2", "exec_compatible_with": ["@platforms//os:macos", "@platforms//cpu:arm64"]}, {"name": "aarch64_none_elf_darwin_x86_64", "url": "https://github.com/xpack-dev-tools/aarch64-none-elf-gcc-xpack/releases/download/v12.2.1-1.2/xpack-aarch64-none-elf-gcc-12.2.1-1.2-darwin-x64.tar.gz", "sha256": "79de1b8b5833e78b28405bad0fa190178bc882e62743c86b789ff1333eb36893", "strip_prefix": "xpack-aarch64-none-elf-gcc-12.2.1-1.2", "exec_compatible_with": ["@platforms//os:macos", "@platforms//cpu:x86_64"]}, {"name": "aarch64_none_elf_linux_aarch64", "url": "https://github.com/xpack-dev-tools/aarch64-none-elf-gcc-xpack/releases/download/v12.2.1-1.2/xpack-aarch64-none-elf-gcc-12.2.1-1.2-linux-arm64.tar.gz", "sha256": "7f50183a26c409d6c15fc785144d665b2d070479796862c5f6cd2970c486e0ae", "strip_prefix": "xpack-aarch64-none-elf-gcc-12.2.1-1.2", "exec_compatible_with": ["@platforms//os:linux", "@platforms//cpu:arm64"]}, {"name": "aarch64_none_elf_linux_x86_64", "url": "https://github.com/xpack-dev-tools/aarch64-none-elf-gcc-xpack/releases/download/v12.2.1-1.2/xpack-aarch64-none-elf-gcc-12.2.1-1.2-linux-x64.tar.gz", "sha256": "a908ed7722469d15e0ccd453d13b8613809e434091690a794d1f4db6d386f111", "strip_prefix": "xpack-aarch64-none-elf-gcc-12.2.1-1.2", "exec_compatible_with": ["@platforms//os:linux", "@platforms//cpu:x86_64"]}, {"name": "aarch64_none_elf_windows_x86_64", "url": "https://github.com/xpack-dev-tools/aarch64-none-elf-gcc-xpack/releases/download/v12.2.1-1.2/xpack-aarch64-none-elf-gcc-12.2.1-1.2-win32-x64.zip", "sha256": "6a236ead2d161e9bc4dfb0294272d07f1e0473467033bb022be34c7ad4d45680", "strip_prefix": "xpack-aarch64-none-elf-gcc-12.2.1-1.2", "exec_compatible_with": ["@platforms//os:windows", "@platforms//cpu:x86_64"]}], "12.3.1-1.1": [{"name": "aarch64_none_elf_darwin_arm64", "url": "https://github.com/xpack-dev-tools/aarch64-none-elf-gcc-xpack/releases/download/v12.3.1-1.1/xpack-aarch64-none-elf-gcc-12.3.1-1.1-darwin-arm64.tar.gz", "sha256": "6cc55b6bd040e3eb1cd52528f8eb3f52a655647a3572f1be0bd67bf0f53063c9", "strip_prefix": "xpack-aarch64-none-elf-gcc-12.3.1-1.1", "exec_compatible_with": ["@platforms//os:macos", "@platforms//cpu:arm64"]}, {"name": "aarch64_none_elf_darwin_x86_64", "url": "https://github.com/xpack-dev-tools/aarch64-none-elf-gcc-xpack/releases/download/v12.3.1-1.1/xpack-aarch64-none-elf-gcc-12.3.1-1.1-darwin-x64.tar.gz", "sha256": "ba6947c1d8b55ec5ee80ad300aea18ac2025efb03df8002f780efed040cf3349", "strip_prefix": "xpack-aarch64-none-elf-gcc-12.3.1-1.1", "exec_compatible_with": ["@platforms//os:macos", "@platforms//cpu:x86_64"]}, {"name": "aarch64_none_elf_linux_aarch64", "url": "https://github.com/xpack-dev-tools/aarch64-none-elf-gcc-xpack/releases/download/v12.3.1-1.1/xpack-aarch64-none-elf-gcc-12.3.1-1.1-linux-arm64.tar.gz", "sha256": "0eaba21e98d0de28beecac0cbdb76fc46a99fb676075be2d64bf6b77d664bbc0", "strip_prefix": "xpack-aarch64-none-elf-gcc-12.3.1-1.1", "exec_compatible_with": ["@platforms//os:linux", "@platforms//cpu:arm64"]}, {"name": "aarch64_none_elf_linux_x86_64", "url": "https://github.com/xpack-dev-tools/aarch64-none-elf-gcc-xpack/releases/download/v12.3.1-1.1/xpack-aarch64-none-elf-gcc-12.3.1-1.1-linux-x64.tar.gz", "sha256": "b8567f486e9f5475494d8cb4177481024085c635be989a055cc4fdc89ef79e4f", "strip_prefix": "xpack-aarch64-none-elf-gcc-12.3.1-1.1", "exec_compatible_with": ["@platforms//os:linux", "@platforms//cpu:x86_64"]}, {"name": "aarch64_none_elf_windows_x86_64", "url": "https://github.com/xpack-dev-tools/aarch64-none-elf-gcc-xpack/releases/download/v12.3.1-1.1/xpack-aarch64-none-elf-gcc-12.3.1-1.1-win32-x64.zip", "sha256": "934d4ac5372198f281286d73467725bfdcbc61bac2ce3f91117dfc03a673e629", "strip_prefix": "xpack-aarch64-none-elf-gcc-12.3.1-1.1", "exec_compatible_with": ["@platforms//os:windows", "@platforms//cpu:x86_64"]}], "12.3.1-2.1": [{"name": "aarch64_none_elf_darwin_arm64", "url": "https://github.com/xpack-dev-tools/aarch64-none-elf-gcc-xpack/releases/download/v12.3.1-2.1/xpack-aarch64-none-elf-gcc-12.3.1-2.1-darwin-arm64.tar.gz", "sha256": "3bdae469f1479cf5535900aaf05c25b71f55cb17a0bbbea0eed41fc5e0371b31", "strip_prefix": "xpack-aarch64-none-elf-gcc-12.3.1-2.1", "exec_compatible_with": ["@platforms//os:macos", "@platforms//cpu:arm64"]}, {"name": "aarch64_none_elf_darwin_x86_64", "url": "https://github.com/xpack-dev-tools/aarch64-none-elf-gcc-xpack/releases/download/v12.3.1-2.1/xpack-aarch64-none-elf-gcc-12.3.1-2.1-darwin-x64.tar.gz", "sha256": "4764aff79bdde32f44e91f3ecb3527ba1fb040669c513a0e6a29a990be7c3e41", "strip_prefix": "xpack-aarch64-none-elf-gcc-12.3.1-2.1", "exec_compatible_with": ["@platforms//os:macos", "@platforms//cpu:x86_64"]}, {"name": "aarch64_none_elf_linux_aarch64", "url": "https://github.com/xpack-dev-tools/aarch64-none-elf-gcc-xpack/releases/download/v12.3.1-2.1/xpack-aarch64-none-elf-gcc-12.3.1-2.1-linux-arm64.tar.gz", "sha256": "e3ae04e8489e38edacd7d3ff062747559016143fc476dc4e328e7db5c65f071e", "strip_prefix": "xpack-aarch64-none-elf-gcc-12.3.1-2.1", "exec_compatible_with": ["@platforms//os:linux", "@platforms//cpu:arm64"]}, {"name": "aarch64_none_elf_linux_x86_64", "url": "https://github.com/xpack-dev-tools/aarch64-none-elf-gcc-xpack/releases/download/v12.3.1-2.1/xpack-aarch64-none-elf-gcc-12.3.1-2.1-linux-x64.tar.gz", "sha256": "6063a0fd5b4bd1445bf0db1521839e2bb43daa2d3b974a2d9a8b8a76a8b9bcf3", "strip_prefix": "xpack-aarch64-none-elf-gcc-12.3.1-2.1", "exec_compatible_with": ["@platforms//os:linux", "@platforms//cpu:x86_64"]}, {"name": "aarch64_none_elf_windows_x86_64", "url": "https://github.com/xpack-dev-tools/aarch64-none-elf-gcc-xpack/releases/download/v12.3.1-2.1/xpack-aarch64-none-elf-gcc-12.3.1-2.1-win32-x64.zip", "sha256": "41f87244a8c14a88d4926f20fee7e1087ba3ac7e128870a873e8bfa9e820ce92", "strip_prefix": "xpack-aarch64-none-elf-gcc-12.3.1-2.1", "exec_compatible_with": ["@platforms//os:windows", "@platforms//cpu:x86_64"]}], "13.2.1-1.1": [{"name": "aarch64_none_elf_darwin_arm64", "url": "https://github.com/xpack-dev-tools/aarch64-none-elf-gcc-xpack/releases/download/v13.2.1-1.1/xpack-aarch64-none-elf-gcc-13.2.1-1.1-darwin-arm64.tar.gz", "sha256": "13d1a5b53a847855210b0fc2d2758d0e5cec6e633a2aec920d7a886624082b64", "strip_prefix": "xpack-aarch64-none-elf-gcc-13.2.1-1.1", "exec_compatible_with": ["@platforms//os:macos", "@platforms//cpu:arm64"]}, {"name": "aarch64_none_elf_darwin_x86_64", "url": "https://github.com/xpack-dev-tools/aarch64-none-elf-gcc-xpack/releases/download/v13.2.1-1.1/xpack-aarch64-none-elf-gcc-13.2.1-1.1-darwin-x64.tar.gz", "sha256": "a35b37a9128ca8824bccb0d42da4d77bbbce464b4c5ac3700374f0b2560fdce1", "strip_prefix": "xpack-aarch64-none-elf-gcc-13.2.1-1.1", "exec_compatible_with": ["@platforms//os:macos", "@platforms//cpu:x86_64"]}, {"name": "aarch64_none_elf_linux_aarch64", "url": "https://github.com/xpack-dev-tools/aarch64-none-elf-gcc-xpack/releases/download/v13.2.1-1.1/xpack-aarch64-none-elf-gcc-13.2.1-1.1-linux-arm64.tar.gz", "sha256": "cec5f2820d6c91c612e0a653ee7ada1fb80d93d0e2f4d9ed1dc6f5b477ac349c", "strip_prefix": "xpack-aarch64-none-elf-gcc-13.2.1-1.1", "exec_compatible_with": ["@platforms//os:linux", "@platforms//cpu:arm64"]}, {"name": "aarch64_none_elf_linux_x86_64", "url": "https://github.com/xpack-dev-tools/aarch64-none-elf-gcc-xpack/releases/download/v13.2.1-1.1/xpack-aarch64-none-elf-gcc-13.2.1-1.1-linux-x64.tar.gz", "sha256": "bda035138579b596d7b0ca8815c06d11df24e063bd12c2a5c410f5ad61ec67a4", "strip_prefix": "xpack-aarch64-none-elf-gcc-13.2.1-1.1", "exec_compatible_with": ["@platforms//os:linux", "@platforms//cpu:x86_64"]}, {"name": "aarch64_none_elf_windows_x86_64", "url": "https://github.com/xpack-dev-tools/aarch64-none-elf-gcc-xpack/releases/download/v13.2.1-1.1/xpack-aarch64-none-elf-gcc-13.2.1-1.1-win32-x64.zip", "sha256": "6fb15fcccb4c038b8e0586a03484b58ce63f443cd9c5319b2377063bb665cf98", "strip_prefix": "xpack-aarch64-none-elf-gcc-13.2.1-1.1", "exec_compatible_with": ["@platforms//os:windows", "@platforms//cpu:x86_64"]}]}(0Workspace dependencies for the arm gcc toolchain28
aarch64_none_elf_deps@@toolchains_arm_gnu//:deps.bzl
���aarch64_none_linux_gnu_deps6Workspace dependencies for the arm linux gcc toolchain*�
�
aarch64_none_linux_gnu_deps`
versionIThe version of the toolchain to use. If None, the latest version is used."13.2.1"(�

archives2A dictionary of the version to archive attributes.�	{"13.2.1": [{"name": "aarch64_none_linux_gnu_linux_x86_64", "sha256": "12fcdf13a7430655229b20438a49e8566e26551ba08759922cdaf4695b0d4e23", "strip_prefix": "arm-gnu-toolchain-13.2.Rel1-x86_64-aarch64-none-linux-gnu", "url": "https://developer.arm.com/-/media/Files/downloads/gnu/13.2.rel1/binrel/arm-gnu-toolchain-13.2.rel1-x86_64-aarch64-none-linux-gnu.tar.xz?rev=22c39fc25e5541818967b4ff5a09ef3e&hash=B9FEDC2947EB21151985C2DC534ECCEC", "patches": ["@toolchains_arm_gnu//toolchain:patches/0001-Resolve-libc-relative-to-sysroot-aarch64_none_linux_gnu.patch"], "exec_compatible_with": ["@platforms//os:linux", "@platforms//cpu:x86_64"]}, {"name": "aarch64_none_linux_gnu_windows_x86_64", "sha256": "ccca7e520adbc5deb36d53a2b373e28a0c7e21107c487d4f5fd9cc8e0dbf6a11", "strip_prefix": "arm-gnu-toolchain-13.2.Rel1-mingw-w64-i686-aarch64-none-linux-gnu", "url": "https://developer.arm.com/-/media/Files/downloads/gnu/13.2.rel1/binrel/arm-gnu-toolchain-13.2.rel1-mingw-w64-i686-aarch64-none-linux-gnu.zip?rev=861fed530201460f8f58b10dca7bd431&hash=A040842727683903E8646B42A96A8B98", "patches": ["@toolchains_arm_gnu//toolchain:patches/0001-Resolve-libc-relative-to-sysroot-aarch64_none_linux_gnu.patch"], "exec_compatible_with": ["@platforms//os:windows", "@platforms//cpu:x86_64"]}]}(6Workspace dependencies for the arm linux gcc toolchain2>
aarch64_none_linux_gnu_deps@@toolchains_arm_gnu//:deps.bzl
���Warm_none_eabi_deps:Workspace dependencies for the arm none eabi gcc toolchain*�W
�V
arm_none_eabi_deps`
versionIThe version of the toolchain to use. If None, the latest version is used."13.2.1"(�U
archives.A dictionary of version to archive attributes.�T{"9.2.1": [{"name": "arm_none_eabi_darwin_x86_64", "sha256": "1249f860d4155d9c3ba8f30c19e7a88c5047923cea17e0d08e633f12408f01f0", "strip_prefix": "gcc-arm-none-eabi-9-2019-q4-major", "url": "https://developer.arm.com/-/media/Files/downloads/gnu-rm/9-2019q4/gcc-arm-none-eabi-9-2019-q4-major-mac.tar.bz2?revision=c2c4fe0e-c0b6-4162-97e6-7707e12f2b6e&la=en&hash=EC9D4B5F5B050267B924F876B306D72CDF3BDDC0", "exec_compatible_with": ["@platforms//os:macos", "@platforms//cpu:x86_64"]}, {"name": "arm_none_eabi_darwin_arm64", "sha256": "1249f860d4155d9c3ba8f30c19e7a88c5047923cea17e0d08e633f12408f01f0", "strip_prefix": "gcc-arm-none-eabi-9-2019-q4-major", "url": "https://developer.arm.com/-/media/Files/downloads/gnu-rm/9-2019q4/gcc-arm-none-eabi-9-2019-q4-major-mac.tar.bz2?revision=c2c4fe0e-c0b6-4162-97e6-7707e12f2b6e&la=en&hash=EC9D4B5F5B050267B924F876B306D72CDF3BDDC0", "exec_compatible_with": ["@platforms//os:macos", "@platforms//cpu:arm64"]}, {"name": "arm_none_eabi_linux_x86_64", "sha256": "bcd840f839d5bf49279638e9f67890b2ef3a7c9c7a9b25271e83ec4ff41d177a", "strip_prefix": "gcc-arm-none-eabi-9-2019-q4-major", "url": "https://developer.arm.com/-/media/Files/downloads/gnu-rm/9-2019q4/gcc-arm-none-eabi-9-2019-q4-major-x86_64-linux.tar.bz2?revision=108bd959-44bd-4619-9c19-26187abf5225&la=en&hash=E788CE92E5DFD64B2A8C246BBA91A249CB8E2D2D", "exec_compatible_with": ["@platforms//os:linux", "@platforms//cpu:x86_64"]}, {"name": "arm_none_eabi_linux_aarch64", "sha256": "1f5b9309006737950b2218250e6bb392e2d68d4f1a764fe66be96e2a78888d83", "strip_prefix": "gcc-arm-none-eabi-9-2019-q4-major", "url": "https://developer.arm.com/-/media/Files/downloads/gnu-rm/9-2019q4/gcc-arm-none-eabi-9-2019-q4-major-aarch64-linux.tar.bz2?revision=4583ce78-e7e7-459a-ad9f-bff8e94839f1&la=en&hash=550DB9C0184B7C70B6C020A5DCBB9D1E156264B7", "exec_compatible_with": ["@platforms//os:linux", "@platforms//cpu:aarch64"]}, {"name": "arm_none_eabi_windows_x86_64", "sha256": "e4c964add8d0fdcc6b14f323e277a0946456082a84a1cc560da265b357762b62", "url": "https://developer.arm.com/-/media/Files/downloads/gnu-rm/9-2019q4/gcc-arm-none-eabi-9-2019-q4-major-win32.zip?revision=20c5df9c-9870-47e2-b994-2a652fb99075&la=en&hash=347C07EEEB848CC8944F943D8E1EAAB55A6CA0BC", "exec_compatible_with": ["@platforms//os:windows", "@platforms//cpu:x86_64"]}], "13.2.1": [{"name": "arm_none_eabi_darwin_x86_64", "sha256": "075faa4f3e8eb45e59144858202351a28706f54a6ec17eedd88c9fb9412372cc", "strip_prefix": "arm-gnu-toolchain-13.2.Rel1-darwin-x86_64-arm-none-eabi", "url": "https://developer.arm.com/-/media/Files/downloads/gnu/13.2.rel1/binrel/arm-gnu-toolchain-13.2.rel1-darwin-x86_64-arm-none-eabi.tar.xz?rev=a3d8c87bb0af4c40b7d7e0e291f6541b&hash=10927356ACA904E1A0122794E036E8DDE7D8435D", "exec_compatible_with": ["@platforms//os:macos", "@platforms//cpu:x86_64"]}, {"name": "arm_none_eabi_darwin_arm64", "sha256": "39c44f8af42695b7b871df42e346c09fee670ea8dfc11f17083e296ea2b0d279", "strip_prefix": "arm-gnu-toolchain-13.2.Rel1-darwin-arm64-arm-none-eabi", "url": "https://developer.arm.com/-/media/Files/downloads/gnu/13.2.rel1/binrel/arm-gnu-toolchain-13.2.rel1-darwin-arm64-arm-none-eabi.tar.xz?rev=73e10891de3d41e29e95ac2878742b74&hash=6036196A3358CB5AD85FC01DFD0FEC02A", "exec_compatible_with": ["@platforms//os:macos", "@platforms//cpu:arm64"]}, {"name": "arm_none_eabi_linux_x86_64", "sha256": "6cd1bbc1d9ae57312bcd169ae283153a9572bd6a8e4eeae2fedfbc33b115fdbb", "strip_prefix": "arm-gnu-toolchain-13.2.Rel1-x86_64-arm-none-eabi", "url": "https://developer.arm.com/-/media/Files/downloads/gnu/13.2.rel1/binrel/arm-gnu-toolchain-13.2.rel1-x86_64-arm-none-eabi.tar.xz?rev=e434b9ea4afc4ed7998329566b764309&hash=688C370BF08399033CA9DE3C1CC8CF8E31D8C441", "exec_compatible_with": ["@platforms//os:linux", "@platforms//cpu:x86_64"]}, {"name": "arm_none_eabi_linux_aarch64", "sha256": "8fd8b4a0a8d44ab2e195ccfbeef42223dfb3ede29d80f14dcf2183c34b8d199a", "strip_prefix": "arm-gnu-toolchain-13.2.Rel1-aarch64-arm-none-eabi", "url": "https://developer.arm.com/-/media/Files/downloads/gnu/13.2.rel1/binrel/arm-gnu-toolchain-13.2.rel1-aarch64-arm-none-eabi.tar.xz?rev=17baf091942042768d55c9a304610954&hash=7F32B9E3ADFAFC4F8F74C30EBBBFECEB1AC96B60", "exec_compatible_with": ["@platforms//os:linux", "@platforms//cpu:aarch64"]}, {"name": "arm_none_eabi_windows_x86_64", "sha256": "51d933f00578aa28016c5e3c84f94403274ea7915539f8e56c13e2196437d18f", "strip_prefix": "arm-gnu-toolchain-13.2.Rel1-mingw-w64-i686-arm-none-eabi", "url": "https://developer.arm.com/-/media/Files/downloads/gnu/13.2.rel1/binrel/arm-gnu-toolchain-13.2.rel1-mingw-w64-i686-arm-none-eabi.zip?rev=93fda279901c4c0299e03e5c4899b51f&hash=A3C5FF788BE90810E121091C873E3532336C8D46", "exec_compatible_with": ["@platforms//os:windows", "@platforms//cpu:aarch64"]}], "12.3.1-1.1": [{"name": "arm_none_eabi_darwin_arm64", "url": "https://github.com/xpack-dev-tools/arm-none-eabi-gcc-xpack/releases/download/v12.3.1-1.1/xpack-arm-none-eabi-gcc-12.3.1-1.1-darwin-arm64.tar.gz", "sha256": "fc943971a9c52fe67992b9bcde618df96f08c2cf7ab75b1c487dcfa5e0ef34d1", "strip_prefix": "xpack-arm-none-eabi-gcc-12.3.1-1.1", "exec_compatible_with": ["@platforms//os:macos", "@platforms//cpu:arm64"]}, {"name": "arm_none_eabi_darwin_x86_64", "url": "https://github.com/xpack-dev-tools/arm-none-eabi-gcc-xpack/releases/download/v12.3.1-1.1/xpack-arm-none-eabi-gcc-12.3.1-1.1-darwin-x64.tar.gz", "sha256": "62e6146ec1bbd86ee92df97f74075c895ebf4ad36b0a05e3d38ae662c9e7a2ab", "strip_prefix": "xpack-arm-none-eabi-gcc-12.3.1-1.1", "exec_compatible_with": ["@platforms//os:macos", "@platforms//cpu:x86_64"]}, {"name": "arm_none_eabi_linux_aarch64", "url": "https://github.com/xpack-dev-tools/arm-none-eabi-gcc-xpack/releases/download/v12.3.1-1.1/xpack-arm-none-eabi-gcc-12.3.1-1.1-linux-arm64.tar.gz", "sha256": "f833298bda3545e9303198463839bc156b6aef3d340ca55c109666e3f6a1f3a0", "strip_prefix": "xpack-arm-none-eabi-gcc-12.3.1-1.1", "exec_compatible_with": ["@platforms//os:linux", "@platforms//cpu:arm64"]}, {"name": "arm_none_eabi_linux_x86_64", "url": "https://github.com/xpack-dev-tools/arm-none-eabi-gcc-xpack/releases/download/v12.3.1-1.1/xpack-arm-none-eabi-gcc-12.3.1-1.1-linux-x64.tar.gz", "sha256": "83b869765862bcf029966c82a258d9b330878e2570a277d82fc90af5e88077a4", "strip_prefix": "xpack-arm-none-eabi-gcc-12.3.1-1.1", "exec_compatible_with": ["@platforms//os:linux", "@platforms//cpu:x86_64"]}, {"name": "arm_none_eabi_windows_x86_64", "url": "https://github.com/xpack-dev-tools/arm-none-eabi-gcc-xpack/releases/download/v12.3.1-1.1/xpack-arm-none-eabi-gcc-12.3.1-1.1-win32-x64.zip", "sha256": "dcd941678c49b780869db94d5ad3f036b1f18003b968b8ab62af04648b265e92", "strip_prefix": "xpack-arm-none-eabi-gcc-12.3.1-1.1", "exec_compatible_with": ["@platforms//os:windows", "@platforms//cpu:x86_64"]}], "12.3.1-1.2": [{"name": "arm_none_eabi_darwin_arm64", "url": "https://github.com/xpack-dev-tools/arm-none-eabi-gcc-xpack/releases/download/v12.3.1-1.2/xpack-arm-none-eabi-gcc-12.3.1-1.2-darwin-arm64.tar.gz", "sha256": "507926ba1e37e6fcae2a7499559cffd6da015b93145ff7657aafca9ef097d683", "strip_prefix": "xpack-arm-none-eabi-gcc-12.3.1-1.2", "exec_compatible_with": ["@platforms//os:macos", "@platforms//cpu:arm64"]}, {"name": "arm_none_eabi_darwin_x86_64", "url": "https://github.com/xpack-dev-tools/arm-none-eabi-gcc-xpack/releases/download/v12.3.1-1.2/xpack-arm-none-eabi-gcc-12.3.1-1.2-darwin-x64.tar.gz", "sha256": "a90e6d0cb74c61e8d06e586f32bcd1983789da15808a8aa64658c1f5e892d2dc", "strip_prefix": "xpack-arm-none-eabi-gcc-12.3.1-1.2", "exec_compatible_with": ["@platforms//os:macos", "@platforms//cpu:x86_64"]}, {"name": "arm_none_eabi_linux_aarch64", "url": "https://github.com/xpack-dev-tools/arm-none-eabi-gcc-xpack/releases/download/v12.3.1-1.2/xpack-arm-none-eabi-gcc-12.3.1-1.2-linux-arm64.tar.gz", "sha256": "35fadc858f3551f789d87760eb40ad04f893a23936f5090a138e7de6cd04d939", "strip_prefix": "xpack-arm-none-eabi-gcc-12.3.1-1.2", "exec_compatible_with": ["@platforms//os:linux", "@platforms//cpu:arm64"]}, {"name": "arm_none_eabi_linux_x86_64", "url": "https://github.com/xpack-dev-tools/arm-none-eabi-gcc-xpack/releases/download/v12.3.1-1.2/xpack-arm-none-eabi-gcc-12.3.1-1.2-linux-x64.tar.gz", "sha256": "771dfb9d10e7339ac40f3a32be9cd287405c537ca0bf16e1dbf6fa6f1fc1dd2a", "strip_prefix": "xpack-arm-none-eabi-gcc-12.3.1-1.2", "exec_compatible_with": ["@platforms//os:linux", "@platforms//cpu:x86_64"]}, {"name": "arm_none_eabi_windows_x86_64", "url": "https://github.com/xpack-dev-tools/arm-none-eabi-gcc-xpack/releases/download/v12.3.1-1.2/xpack-arm-none-eabi-gcc-12.3.1-1.2-win32-x64.zip", "sha256": "cb5e2be31fcfc7c78390041efc5602f22266f21ed968443827898fa4c47c6f20", "strip_prefix": "xpack-arm-none-eabi-gcc-12.3.1-1.2", "exec_compatible_with": ["@platforms//os:windows", "@platforms//cpu:x86_64"]}], "13.2.1-1.1": [{"name": "arm_none_eabi_darwin_arm64", "url": "https://github.com/xpack-dev-tools/arm-none-eabi-gcc-xpack/releases/download/v13.2.1-1.1/xpack-arm-none-eabi-gcc-13.2.1-1.1-darwin-arm64.tar.gz", "sha256": "d4ce0de062420daab140161086ba017642365977e148d20f55a8807b1eacd703", "strip_prefix": "xpack-arm-none-eabi-gcc-13.2.1-1.1", "exec_compatible_with": ["@platforms//os:macos", "@platforms//cpu:arm64"]}, {"name": "arm_none_eabi_darwin_x86_64", "url": "https://github.com/xpack-dev-tools/arm-none-eabi-gcc-xpack/releases/download/v13.2.1-1.1/xpack-arm-none-eabi-gcc-13.2.1-1.1-darwin-x64.tar.gz", "sha256": "1ecc0fd6c31020aff702204f51459b4b00ff0d12b9cd95e832399881d819aa57", "strip_prefix": "xpack-arm-none-eabi-gcc-13.2.1-1.1", "exec_compatible_with": ["@platforms//os:macos", "@platforms//cpu:x86_64"]}, {"name": "arm_none_eabi_linux_aarch64", "url": "https://github.com/xpack-dev-tools/arm-none-eabi-gcc-xpack/releases/download/v13.2.1-1.1/xpack-arm-none-eabi-gcc-13.2.1-1.1-linux-arm64.tar.gz", "sha256": "ab7f75d95ead0b1efb7432e7f034f9575cc3d23dc1b03d41af1ec253486d19de", "strip_prefix": "xpack-arm-none-eabi-gcc-13.2.1-1.1", "exec_compatible_with": ["@platforms//os:linux", "@platforms//cpu:arm64"]}, {"name": "arm_none_eabi_linux_x86_64", "url": "https://github.com/xpack-dev-tools/arm-none-eabi-gcc-xpack/releases/download/v13.2.1-1.1/xpack-arm-none-eabi-gcc-13.2.1-1.1-linux-x64.tar.gz", "sha256": "1252a8cafe9237de27a765376697230368eec21db44dc3f1edeb8d838dabd530", "strip_prefix": "xpack-arm-none-eabi-gcc-13.2.1-1.1", "exec_compatible_with": ["@platforms//os:linux", "@platforms//cpu:x86_64"]}, {"name": "arm_none_eabi_windows_x86_64", "url": "https://github.com/xpack-dev-tools/arm-none-eabi-gcc-xpack/releases/download/v13.2.1-1.1/xpack-arm-none-eabi-gcc-13.2.1-1.1-win32-x64.zip", "sha256": "56b18ccb0a50f536332ec5de57799342ff0cd005ca2c54288c74759b51929e4f", "strip_prefix": "xpack-arm-none-eabi-gcc-13.2.1-1.1", "exec_compatible_with": ["@platforms//os:windows", "@platforms//cpu:x86_64"]}]}(:Workspace dependencies for the arm none eabi gcc toolchain25
arm_none_eabi_deps@@toolchains_arm_gnu//:deps.bzl
||�arm_none_linux_gnueabihf_deps6Workspace dependencies for the arm linux gcc toolchain*�
�
arm_none_linux_gnueabihf_deps`
versionIThe version of the toolchain to use. If None, the latest version is used."13.2.1"(�
archives2A dictionary of the version to archive attributes.�{"13.2.1": [{"name": "arm_none_linux_gnueabihf_linux_x86_64", "sha256": "df0f4927a67d1fd366ff81e40bd8c385a9324fbdde60437a512d106215f257b3", "strip_prefix": "arm-gnu-toolchain-13.2.Rel1-x86_64-arm-none-linux-gnueabihf", "url": "https://developer.arm.com/-/media/Files/downloads/gnu/13.2.rel1/binrel/arm-gnu-toolchain-13.2.rel1-x86_64-arm-none-linux-gnueabihf.tar.xz?rev=adb0c0238c934aeeaa12c09609c5e6fc&hash=68DA67DE12CBAD82A0FA4B75247E866155C93053", "patches": ["@toolchains_arm_gnu//toolchain:patches/0001-Resolve-libc-relative-to-sysroot.patch"], "exec_compatible_with": ["@platforms//os:linux", "@platforms//cpu:x86_64"]}, {"name": "arm_none_linux_gnueabihf_linux_aarch64", "sha256": "8ad384bb328bccc44396d85c8f8113b7b8c5e11bcfef322e77cda3ebe7baadb5", "strip_prefix": "arm-gnu-toolchain-13.2.Rel1-aarch64-arm-none-linux-gnueabihf", "url": "https://developer.arm.com/-/media/Files/downloads/gnu/13.2.rel1/binrel/arm-gnu-toolchain-13.2.rel1-aarch64-arm-none-linux-gnueabihf.tar.xz?rev=fbdb67e76c8349e5ad27a7c40fb270c9&hash=8CD3EBFFDC5E211275B705F6F9BCC0F6F5B4A53E", "patches": ["@toolchains_arm_gnu//toolchain:patches/0001-Resolve-libc-relative-to-sysroot.patch"], "exec_compatible_with": ["@platforms//os:linux", "@platforms//cpu:aarch64"]}, {"name": "arm_none_linux_gnueabihf_windows_x86_64", "sha256": "047e72bcef8f7767691f36929a8c74ef66f717cf6264a31f48dd31bfb067f4c8", "strip_prefix": "arm-gnu-toolchain-13.2.Rel1-mingw-w64-i686-arm-none-linux-gnueabihf", "url": "https://developer.arm.com/-/media/Files/downloads/gnu/13.2.rel1/binrel/arm-gnu-toolchain-13.2.rel1-mingw-w64-i686-arm-none-linux-gnueabihf.zip?rev=14b6dd20622a4beabb60a6ee41a4c141&hash=C1F9FA6DE8259B5ACA0211139F4304F2B942E489", "patches": ["@toolchains_arm_gnu//toolchain:patches/0001-Resolve-libc-relative-to-sysroot.patch"], "exec_compatible_with": ["@platforms//os:windows", "@platforms//cpu:x86_64"]}]}(6Workspace dependencies for the arm linux gcc toolchain2@
arm_none_linux_gnueabihf_deps@@toolchains_arm_gnu//:deps.bzl
���toolchains_arm_gnu_deps*�
�
toolchains_arm_gnu_deps
	toolchain (
toolchain_prefix (
version (
archives (2:
toolchains_arm_gnu_deps@@toolchains_arm_gnu//:deps.bzl
dd�+arm_gnu_cross_hosted_platform_specific_repoR�
�
+arm_gnu_cross_hosted_platform_specific_repo.
name"A unique name for this repository. 
exec_compatible_with2[]
patches2[]�
repo_mapping�A dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.<p>For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).
 
sha256 
strip_prefix2""
toolchain_prefix x
tools2m["as", "ar", "c++", "cpp", "g++", "gcc", "gdb", "ld", "nm", "objcopy", "objdump", "readelf", "strip", "size"]	
url 
version *N
+arm_gnu_cross_hosted_platform_specific_repo@@toolchains_arm_gnu//:deps.bzl
 > >0
.
name"A unique name for this repository. 

exec_compatible_with2[]

patches2[]�
�
repo_mapping�A dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.<p>For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).
 

sha256 

strip_prefix2""

toolchain_prefix z
x
tools2m["as", "ar", "c++", "cpp", "g++", "gcc", "gdb", "ld", "nm", "objcopy", "objdump", "readelf", "strip", "size"]
	
url 

version �toolchains_arm_gnu_repoR�
�
toolchains_arm_gnu_repo.
name"A unique name for this repository. 
hosts �
repo_mapping�A dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.<p>For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).
 
toolchain_name 
toolchain_prefix x
tools2m["as", "ar", "c++", "cpp", "g++", "gcc", "gdb", "ld", "nm", "objcopy", "objdump", "readelf", "strip", "size"]
version *:
toolchains_arm_gnu_repo@@toolchains_arm_gnu//:deps.bzl
Y*Y*0
.
name"A unique name for this repository. 

hosts �
�
repo_mapping�A dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.<p>For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).
 

toolchain_name 

toolchain_prefix z
x
tools2m["as", "ar", "c++", "cpp", "g++", "gcc", "gdb", "ld", "nm", "objcopy", "objdump", "readelf", "strip", "size"]

version s
:version.bzlra
!
toolchains_arm_gnuversion.bzl.
latest_versionlatest_version
,:
<{
//toolchain:toolchain.bzlr\
.
toolchains_arm_gnu	toolchaintoolchain.bzl
toolstools
7<
>�
)//toolchain/archives:aarch64_none_elf.bzlr�
>
toolchains_arm_gnutoolchain/archivesaarch64_none_elf.bzl2
AARCH64_NONE_ELFAARCH64_NONE_ELF
GW
Y�
///toolchain/archives:aarch64_none_linux_gnu.bzlr�
D
toolchains_arm_gnutoolchain/archivesaarch64_none_linux_gnu.bzl>
AARCH64_NONE_LINUX_GNUAARCH64_NONE_LINUX_GNU
Mc
e�
&//toolchain/archives:arm_none_eabi.bzlry
;
toolchains_arm_gnutoolchain/archivesarm_none_eabi.bzl,
ARM_NONE_EABIARM_NONE_EABI
DQ
S�
1//toolchain/archives:arm_none_linux_gnueabihf.bzlr�
F
toolchains_arm_gnutoolchain/archivesarm_none_linux_gnueabihf.bzlB
ARM_NONE_LINUX_GNUEABIHFARM_NONE_LINUX_GNUEABIHF
Og
ideps.bzl�	
$
toolchains_arm_gnuextensions.bzl�arm_toolchainJ�
�
arm_toolchain&
arm_none_eabi
version2"13.2.1"1
arm_none_linux_gnueabihf
version2"13.2.1"-
aarch64_none_elf
version2"13.2.1-1.1"/
aarch64_none_linux_gnu
version2"13.2.1""6
arm_toolchain%@@toolchains_arm_gnu//:extensions.bzl
/!/!A
&
arm_none_eabi
version2"13.2.1"

version2"13.2.1"L
1
arm_none_linux_gnueabihf
version2"13.2.1"

version2"13.2.1"L
-
aarch64_none_elf
version2"13.2.1-1.1"

version2"13.2.1-1.1"J
/
aarch64_none_linux_gnu
version2"13.2.1"

version2"13.2.1"�
	:deps.bzlr�

toolchains_arm_gnudeps.bzl<
aarch64_none_elf_depsaarch64_none_elf_deps
H
aarch64_none_linux_gnu_depsaarch64_none_linux_gnu_deps
!6
arm_none_eabi_depsarm_none_eabi_deps
L
arm_none_linux_gnueabihf_depsarm_none_linux_gnueabihf_deps
#
	�
:version.bzlr�
!
toolchains_arm_gnuversion.bzl.
latest_versionlatest_version

,
:(
min_versionmin_version

>
I


KModule extension for toolchains�
!
toolchains_arm_gnuversion.bzl�latest_version+Return the latest version of the toolchain.*�

latest_version

name (+Return the latest version of the toolchain.24
latest_version"@@toolchains_arm_gnu//:version.bzl
>>�max_version=Obtains the minimum version from the list of version strings.*�
�
max_version
versions (=Obtains the minimum version from the list of version strings.21
max_version"@@toolchains_arm_gnu//:version.bzl
**�min_version=Obtains the minimum version from the list of version strings.*�
�
min_version
versions (=Obtains the minimum version from the list of version strings.21
min_version"@@toolchains_arm_gnu//:version.bzl
44�
)//toolchain/archives:aarch64_none_elf.bzlr�
>
toolchains_arm_gnutoolchain/archivesaarch64_none_elf.bzl2
AARCH64_NONE_ELFAARCH64_NONE_ELF

�
///toolchain/archives:aarch64_none_linux_gnu.bzlr�
D
toolchains_arm_gnutoolchain/archivesaarch64_none_linux_gnu.bzl>
AARCH64_NONE_LINUX_GNUAARCH64_NONE_LINUX_GNU
		

�
&//toolchain/archives:arm_none_eabi.bzlry
;
toolchains_arm_gnutoolchain/archivesarm_none_eabi.bzl,
ARM_NONE_EABIARM_NONE_EABI

�
1//toolchain/archives:arm_none_linux_gnueabihf.bzlr�
F
toolchains_arm_gnutoolchain/archivesarm_none_linux_gnueabihf.bzlB
ARM_NONE_LINUX_GNUEABIHFARM_NONE_LINUX_GNUEABIHF

Version rules for toolchains 