�	
'
toolchains_filc
extensionsfilc.bzl�filc�Declares the pinned Fil-C compiler and matched Linux target distributions.

The consuming root must provide exactly one `prebuilt(version = "0.687")` tag,
import `filc_toolchains`, and register `@filc_toolchains//:all`. The compiler runs
on Linux AMD64 or ARM64; target toolchains support musl and Fil-C glibc 2.44.J�
�
filc�Declares the pinned Fil-C compiler and matched Linux target distributions.

The consuming root must provide exactly one `prebuilt(version = "0.687")` tag,
import `filc_toolchains`, and register `@filc_toolchains//:all`. The compiler runs
on Linux AMD64 or ARM64; target toolchains support musl and Fil-C glibc 2.44.�
prebuiltMSelects the pinned Fil-C distribution; required once across the module graph.K
version<Fil-C distribution version. This module supports only 0.687. "'%@toolchains_filc//extensions:filc.bzl�
�
prebuiltMSelects the pinned Fil-C distribution; required once across the module graph.K
version<Fil-C distribution version. This module supports only 0.687. M
K
version<Fil-C distribution version. This module supports only 0.687. <Explicit Fil-C registration for matched Linux target stacks.�

(
toolchains_filcruntimefilc_run.bzl�	filc_run�Packages a dynamic Fil-C executable with its target loader and libraries.

The output includes an executable launcher and a sibling `.bundle` directory.
Keep them together when deploying. Run on Linux with the target CPU; remote
compilation does not change where `bazel run` executes the resulting program."�
�
filc_run�Packages a dynamic Fil-C executable with its target loader and libraries.

The output includes an executable launcher and a sibling `.bundle` directory.
Keep them together when deploying. Run on Linux with the target CPU; remote
compilation does not change where `bazel run` executes the resulting program.*
nameA unique name for this target. _
binaryQDynamic Fil-C executable, typically a rules_cc cc_binary with linkstatic = False. Y
pluginsHAdditional shared libraries loaded at runtime, including their runfiles.2[]"2
filc_run&@toolchains_filc//runtime:filc_run.bzl8,
*
nameA unique name for this target. a
_
binaryQDynamic Fil-C executable, typically a rules_cc cc_binary with linkstatic = False. [
Y
pluginsHAdditional shared libraries loaded at runtime, including their runfiles.2[]HPackage a dynamic Fil-C executable with its target runtime and launcher.�
,
toolchains_filcruntimefilc_runtime.bzl�filc_runtime�Provides a target loader, runtime libraries, and redistribution notices.

Used by the registered Fil-C runtime toolchains. Custom runtime toolchains must
provide a loader and libraries matching the selected target CPU and libc."�
�
filc_runtime�Provides a target loader, runtime libraries, and redistribution notices.

Used by the registered Fil-C runtime toolchains. Custom runtime toolchains must
provide a loader and libraries matching the selected target CPU and libc.*
nameA unique name for this target. (
loaderTarget ELF dynamic loader. 1
	libraries Target runtime shared libraries. ?
licenses/Upstream notices to include in runtime bundles. ":
filc_runtime*@toolchains_filc//runtime:filc_runtime.bzl,
*
nameA unique name for this target. *
(
loaderTarget ELF dynamic loader. 3
1
	libraries Target runtime shared libraries. A
?
licenses/Upstream notices to include in runtime bundles. ITarget-side Fil-C dynamic runtime, independent of compiler execution CPU.�

)
toolchains_filcruntimefilc_test.bzl�		filc_test�Tests a dynamic Fil-C executable with its bundled target runtime.

Uses the registered Fil-C test toolchain to select a Linux test executor with
the target CPU. The wrapped binary must exit zero to pass. Both musl and glibc
targets run with the bundled loader and libraries rather than the host runtime."�
�
	filc_test�Tests a dynamic Fil-C executable with its bundled target runtime.

Uses the registered Fil-C test toolchain to select a Linux test executor with
the target CPU. The wrapped binary must exit zero to pass. Both musl and glibc
targets run with the bundled loader and libraries rather than the host runtime.*
nameA unique name for this target. _
binaryQDynamic Fil-C executable, typically a rules_cc cc_binary with linkstatic = False. Y
pluginsHAdditional shared libraries loaded at runtime, including their runfiles.2[]"4
	filc_test'@toolchains_filc//runtime:filc_test.bzl08,
*
nameA unique name for this target. a
_
binaryQDynamic Fil-C executable, typically a rules_cc cc_binary with linkstatic = False. [
Y
pluginsHAdditional shared libraries loaded at runtime, including their runfiles.2[]JRun a dynamic Fil-C executable with its bundled runtime on the target CPU. 