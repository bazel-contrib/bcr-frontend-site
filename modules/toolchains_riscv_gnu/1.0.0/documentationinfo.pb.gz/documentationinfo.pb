�
9
toolchains_riscv_gnutest/baremetal/startup	riscv.bzl-	ARCHj#2!
-march=rv32imc
-mabi=ilp32q	COPTSjf2d
-march=rv32imc
-mabi=ilp32
-c
-Wall
	-Wextra
-fmessage-length=0
-mcmodel=medlow>	LINKOPTSj02.
-march=rv32imc
-mabi=ilp32
	-nostdlib�
0
toolchains_riscv_gnu	toolchaintoolchain.bzl�riscv_none_elf_toolchain@Create an riscv-none-elf toolchain with the given configuration.*�
�
riscv_none_elf_toolchain&
nameThe name of the toolchain. (8
version!The version of the gcc toolchain."13.2.1"((
kwargssame as toolchains_riscv_gnu(@Create an riscv-none-elf toolchain with the given configuration.2K
riscv_none_elf_toolchain/@@toolchains_riscv_gnu//toolchain:toolchain.bzl
]]*_riscv_gnu_toolchaing
//cc:defs.bzlrT

rules_ccccdefs.bzl*
cc_toolchaincc_toolchain
!-
/�
//toolchain:config.bzlr�
-
toolchains_riscv_gnu	toolchain
config.bzlL
cc_riscv_gnu_toolchain_configcc_riscv_gnu_toolchain_config
6S
Uz	toolsjo2m
as
ar
c++
cpp
g++
gcc
gdb
ld
nm
	objcopy
	objdump
	readelf
strip
sizeH
This module provides functions to register an riscv-none-elf toolchain
d
>
toolchains_riscv_gnutoolchain/archivesriscv_none_elf.bzl"riscv-none-elf toolchiain archives�

-
toolchains_riscv_gnu	toolchain
config.bzl�cc_riscv_gnu_toolchain_config"�
�
cc_riscv_gnu_toolchain_config*
nameA unique name for this target. 
abi_version2""
copts2[]
gcc_repo2""
gcc_tool2"gcc"
gcc_version2""
host_system_name2""
include_path2[]
include_std2False
library_path2[]
linkopts2[]
toolchain_bins 
toolchain_identifier2""
toolchain_prefix2"""M
cc_riscv_gnu_toolchain_config,@@toolchains_riscv_gnu//toolchain:config.bzl
�%�%,
*
nameA unique name for this target. 

abi_version2""

copts2[]

gcc_repo2""

gcc_tool2"gcc"

gcc_version2""

host_system_name2""

include_path2[]

include_std2False

library_path2[]

linkopts2[]

toolchain_bins 

toolchain_identifier2""

toolchain_prefix2""�
&//tools/build_defs/cc:action_names.bzlrp
4
bazel_toolstools/build_defs/ccaction_names.bzl*
ACTION_NAMESACTION_NAMES
=I
K�
 //cc:cc_toolchain_config_lib.bzlr�
+
rules_cccccc_toolchain_config_lib.bzl,
action_configaction_config
4A 
featurefeature
EL&

flag_group
flag_group
PZ"
flag_setflag_set
^f
h��
 
toolchains_riscv_gnudeps.bzl��riscv_none_elf_deps:Workspace dependencies for the arm none eabi gcc toolchain*��
��
riscv_none_elf_depsb
versionIThe version of the toolchain to use. If None, the latest version is used.
"13.2.0-2"(��
archives.A dictionary of version to archive attributes.ܜ{"11.3.0-1": [{"name": "riscv_none_elf_darwin_arm64", "url": "https://github.com/xpack-dev-tools/riscv-none-elf-gcc-xpack/releases/download/v11.3.0-1/xpack-riscv-none-elf-gcc-11.3.0-1-darwin-arm64.tar.gz", "sha256": "e3fda6401ea1a055a90bfe3116f4d46fdc9201280df7c3991bb964f4bad18886", "strip_prefix": "xpack-riscv-none-elf-gcc-11.3.0-1", "exec_compatible_with": ["@platforms//os:macos", "@platforms//cpu:arm64"]}, {"name": "riscv_none_elf_darwin_x86_64", "url": "https://github.com/xpack-dev-tools/riscv-none-elf-gcc-xpack/releases/download/v11.3.0-1/xpack-riscv-none-elf-gcc-11.3.0-1-darwin-x64.tar.gz", "sha256": "67c2f2d9bb530948610400e2b43aeef8a1d4913fae275b1edf04968019fb19b9", "strip_prefix": "xpack-riscv-none-elf-gcc-11.3.0-1", "exec_compatible_with": ["@platforms//os:macos", "@platforms//cpu:x86_64"]}, {"name": "riscv_none_elf_linux_aarch64", "url": "https://github.com/xpack-dev-tools/riscv-none-elf-gcc-xpack/releases/download/v11.3.0-1/xpack-riscv-none-elf-gcc-11.3.0-1-linux-arm64.tar.gz", "sha256": "2cd91f4bcc0c7a0f5b5beead3be834f6708d7a196f94f7728ac68e1ad06cee24", "strip_prefix": "xpack-riscv-none-elf-gcc-11.3.0-1", "exec_compatible_with": ["@platforms//os:linux", "@platforms//cpu:arm64"]}, {"name": "riscv_none_elf_linux_x86_64", "url": "https://github.com/xpack-dev-tools/riscv-none-elf-gcc-xpack/releases/download/v11.3.0-1/xpack-riscv-none-elf-gcc-11.3.0-1-linux-x64.tar.gz", "sha256": "1c99fb1573ff2ed5deffce64cb96bb9272f351f054684c49dfd5ad41c6dd804d", "strip_prefix": "xpack-riscv-none-elf-gcc-11.3.0-1", "exec_compatible_with": ["@platforms//os:linux", "@platforms//cpu:x86_64"]}, {"name": "riscv_none_elf_windows_x86_64", "url": "https://github.com/xpack-dev-tools/riscv-none-elf-gcc-xpack/releases/download/v11.3.0-1/xpack-riscv-none-elf-gcc-11.3.0-1-win32-x64.zip", "sha256": "56cc2e340bdcaa718862b3526a7c550605e699847a8903e471336ba0a4535c68", "strip_prefix": "xpack-riscv-none-elf-gcc-11.3.0-1", "exec_compatible_with": ["@platforms//os:windows", "@platforms//cpu:x86_64"]}], "12.1.0-1": [{"name": "riscv_none_elf_darwin_arm64", "url": "https://github.com/xpack-dev-tools/riscv-none-elf-gcc-xpack/releases/download/v12.1.0-1/xpack-riscv-none-elf-gcc-12.1.0-1-darwin-arm64.tar.gz", "sha256": "a3eb788e1e5485e951ff1067ddf174c35f296540bfeb9e2a4dfd452a72b7c18e", "strip_prefix": "xpack-riscv-none-elf-gcc-12.1.0-1", "exec_compatible_with": ["@platforms//os:macos", "@platforms//cpu:arm64"]}, {"name": "riscv_none_elf_darwin_x86_64", "url": "https://github.com/xpack-dev-tools/riscv-none-elf-gcc-xpack/releases/download/v12.1.0-1/xpack-riscv-none-elf-gcc-12.1.0-1-darwin-x64.tar.gz", "sha256": "6ab43e586728af78ef2aede74cea976836a3bfec9e970b5cbbd7bdd30788e992", "strip_prefix": "xpack-riscv-none-elf-gcc-12.1.0-1", "exec_compatible_with": ["@platforms//os:macos", "@platforms//cpu:x86_64"]}, {"name": "riscv_none_elf_linux_aarch64", "url": "https://github.com/xpack-dev-tools/riscv-none-elf-gcc-xpack/releases/download/v12.1.0-1/xpack-riscv-none-elf-gcc-12.1.0-1-linux-arm64.tar.gz", "sha256": "78f9b63a97f378239cd447fdda54e7dd19d2823ee282b27f3e65aac398eedabb", "strip_prefix": "xpack-riscv-none-elf-gcc-12.1.0-1", "exec_compatible_with": ["@platforms//os:linux", "@platforms//cpu:arm64"]}, {"name": "riscv_none_elf_linux_x86_64", "url": "https://github.com/xpack-dev-tools/riscv-none-elf-gcc-xpack/releases/download/v12.1.0-1/xpack-riscv-none-elf-gcc-12.1.0-1-linux-x64.tar.gz", "sha256": "d6dc108ab53a41df3036f57cae4d0e538fb0d47c7b4d5fc8bb1b5499a64a2cdc", "strip_prefix": "xpack-riscv-none-elf-gcc-12.1.0-1", "exec_compatible_with": ["@platforms//os:linux", "@platforms//cpu:x86_64"]}, {"name": "riscv_none_elf_windows_x86_64", "url": "https://github.com/xpack-dev-tools/riscv-none-elf-gcc-xpack/releases/download/v12.1.0-1/xpack-riscv-none-elf-gcc-12.1.0-1-win32-x64.zip", "sha256": "7b79381242dbb3838e7f6a832dfd2628c7f6b36d9be793649ebaebad14cacbd9", "strip_prefix": "xpack-riscv-none-elf-gcc-12.1.0-1", "exec_compatible_with": ["@platforms//os:windows", "@platforms//cpu:x86_64"]}], "12.1.0-2": [{"name": "riscv_none_elf_darwin_arm64", "url": "https://github.com/xpack-dev-tools/riscv-none-elf-gcc-xpack/releases/download/v12.1.0-2/xpack-riscv-none-elf-gcc-12.1.0-2-darwin-arm64.tar.gz", "sha256": "e3532f8cc17969da85dd615108c5b2826eecacc7f003c0ba5914c03e3160af1c", "strip_prefix": "xpack-riscv-none-elf-gcc-12.1.0-2", "exec_compatible_with": ["@platforms//os:macos", "@platforms//cpu:arm64"]}, {"name": "riscv_none_elf_darwin_x86_64", "url": "https://github.com/xpack-dev-tools/riscv-none-elf-gcc-xpack/releases/download/v12.1.0-2/xpack-riscv-none-elf-gcc-12.1.0-2-darwin-x64.tar.gz", "sha256": "39bd9eb7df484309fb1c725ae806b16589b8d90f273419b2a41e4017886b2176", "strip_prefix": "xpack-riscv-none-elf-gcc-12.1.0-2", "exec_compatible_with": ["@platforms//os:macos", "@platforms//cpu:x86_64"]}, {"name": "riscv_none_elf_linux_aarch64", "url": "https://github.com/xpack-dev-tools/riscv-none-elf-gcc-xpack/releases/download/v12.1.0-2/xpack-riscv-none-elf-gcc-12.1.0-2-linux-arm64.tar.gz", "sha256": "66a81676aff6051d6e602f336f6c8ae9ca4dec483b45adbbf747dc022768653e", "strip_prefix": "xpack-riscv-none-elf-gcc-12.1.0-2", "exec_compatible_with": ["@platforms//os:linux", "@platforms//cpu:arm64"]}, {"name": "riscv_none_elf_linux_x86_64", "url": "https://github.com/xpack-dev-tools/riscv-none-elf-gcc-xpack/releases/download/v12.1.0-2/xpack-riscv-none-elf-gcc-12.1.0-2-linux-x64.tar.gz", "sha256": "0df95d28487b5e55eb48c487bfc8951a23ef97080a8621dd4109586f51dc177e", "strip_prefix": "xpack-riscv-none-elf-gcc-12.1.0-2", "exec_compatible_with": ["@platforms//os:linux", "@platforms//cpu:x86_64"]}, {"name": "riscv_none_elf_windows_x86_64", "url": "https://github.com/xpack-dev-tools/riscv-none-elf-gcc-xpack/releases/download/v12.1.0-2/xpack-riscv-none-elf-gcc-12.1.0-2-win32-x64.zip", "sha256": "ab2a596d00a4436192b80381b4b9bc1e6962de5699b4a494c4f476216963983d", "strip_prefix": "xpack-riscv-none-elf-gcc-12.1.0-2", "exec_compatible_with": ["@platforms//os:windows", "@platforms//cpu:x86_64"]}], "12.2.0-1": [{"name": "riscv_none_elf_darwin_arm64", "url": "https://github.com/xpack-dev-tools/riscv-none-elf-gcc-xpack/releases/download/v12.2.0-1/xpack-riscv-none-elf-gcc-12.2.0-1-darwin-arm64.tar.gz", "sha256": "4a0044c4c8e3115abe32030b80a136ab987fc2a0712b0ddf62d11d369a5ad521", "strip_prefix": "xpack-riscv-none-elf-gcc-12.2.0-1", "exec_compatible_with": ["@platforms//os:macos", "@platforms//cpu:arm64"]}, {"name": "riscv_none_elf_darwin_x86_64", "url": "https://github.com/xpack-dev-tools/riscv-none-elf-gcc-xpack/releases/download/v12.2.0-1/xpack-riscv-none-elf-gcc-12.2.0-1-darwin-x64.tar.gz", "sha256": "08508cc24201452a8f82bb12f9ee9474704d2d5db342205ae25567baca8de061", "strip_prefix": "xpack-riscv-none-elf-gcc-12.2.0-1", "exec_compatible_with": ["@platforms//os:macos", "@platforms//cpu:x86_64"]}, {"name": "riscv_none_elf_linux_aarch64", "url": "https://github.com/xpack-dev-tools/riscv-none-elf-gcc-xpack/releases/download/v12.2.0-1/xpack-riscv-none-elf-gcc-12.2.0-1-linux-arm64.tar.gz", "sha256": "68ff464c907c8160308a32babba49ccb0493e480520d5c8513373301e65e7ee2", "strip_prefix": "xpack-riscv-none-elf-gcc-12.2.0-1", "exec_compatible_with": ["@platforms//os:linux", "@platforms//cpu:arm64"]}, {"name": "riscv_none_elf_linux_x86_64", "url": "https://github.com/xpack-dev-tools/riscv-none-elf-gcc-xpack/releases/download/v12.2.0-1/xpack-riscv-none-elf-gcc-12.2.0-1-linux-x64.tar.gz", "sha256": "04b5f45d609b221505e9232b1b63ae6cdb17d0a23f13ce9c231fc4008753a58a", "strip_prefix": "xpack-riscv-none-elf-gcc-12.2.0-1", "exec_compatible_with": ["@platforms//os:linux", "@platforms//cpu:x86_64"]}, {"name": "riscv_none_elf_windows_x86_64", "url": "https://github.com/xpack-dev-tools/riscv-none-elf-gcc-xpack/releases/download/v12.2.0-1/xpack-riscv-none-elf-gcc-12.2.0-1-win32-x64.zip", "sha256": "1edf87d32975619076d3df558b8c1218daa54947f47b06c7ea9edb99e2290548", "strip_prefix": "xpack-riscv-none-elf-gcc-12.2.0-1", "exec_compatible_with": ["@platforms//os:windows", "@platforms//cpu:x86_64"]}], "12.2.0-2": [{"name": "riscv_none_elf_darwin_arm64", "url": "https://github.com/xpack-dev-tools/riscv-none-elf-gcc-xpack/releases/download/v12.2.0-2/xpack-riscv-none-elf-gcc-12.2.0-2-darwin-arm64.tar.gz", "sha256": "16480bd25ee7f9f94d2a5aa5ad3b81a5bce96841ee89ba9afa27220a58a55240", "strip_prefix": "xpack-riscv-none-elf-gcc-12.2.0-2", "exec_compatible_with": ["@platforms//os:macos", "@platforms//cpu:arm64"]}, {"name": "riscv_none_elf_darwin_x86_64", "url": "https://github.com/xpack-dev-tools/riscv-none-elf-gcc-xpack/releases/download/v12.2.0-2/xpack-riscv-none-elf-gcc-12.2.0-2-darwin-x64.tar.gz", "sha256": "85812c885e5e3359ce03a842222d1a738e664bc9fc14096680699c103020eceb", "strip_prefix": "xpack-riscv-none-elf-gcc-12.2.0-2", "exec_compatible_with": ["@platforms//os:macos", "@platforms//cpu:x86_64"]}, {"name": "riscv_none_elf_linux_aarch64", "url": "https://github.com/xpack-dev-tools/riscv-none-elf-gcc-xpack/releases/download/v12.2.0-2/xpack-riscv-none-elf-gcc-12.2.0-2-linux-arm64.tar.gz", "sha256": "207e96dfac200b2b119285a0c65a928a059963d2eeda37d8f979cfa9b7d7dcc8", "strip_prefix": "xpack-riscv-none-elf-gcc-12.2.0-2", "exec_compatible_with": ["@platforms//os:linux", "@platforms//cpu:arm64"]}, {"name": "riscv_none_elf_linux_x86_64", "url": "https://github.com/xpack-dev-tools/riscv-none-elf-gcc-xpack/releases/download/v12.2.0-2/xpack-riscv-none-elf-gcc-12.2.0-2-linux-x64.tar.gz", "sha256": "bc3bb92b7258bbc60aa763aef3f435a41917f1588e9c0da142815225fe3a43f4", "strip_prefix": "xpack-riscv-none-elf-gcc-12.2.0-2", "exec_compatible_with": ["@platforms//os:linux", "@platforms//cpu:x86_64"]}, {"name": "riscv_none_elf_windows_x86_64", "url": "https://github.com/xpack-dev-tools/riscv-none-elf-gcc-xpack/releases/download/v12.2.0-2/xpack-riscv-none-elf-gcc-12.2.0-2-win32-x64.zip", "sha256": "31d94eeb94829a8c3044a5b37436c08a9db8ea2dbdb38e1b3f62c93f5f94a60a", "strip_prefix": "xpack-riscv-none-elf-gcc-12.2.0-2", "exec_compatible_with": ["@platforms//os:windows", "@platforms//cpu:x86_64"]}], "12.2.0-3": [{"name": "riscv_none_elf_darwin_arm64", "url": "https://github.com/xpack-dev-tools/riscv-none-elf-gcc-xpack/releases/download/v12.2.0-3/xpack-riscv-none-elf-gcc-12.2.0-3-darwin-arm64.tar.gz", "sha256": "56967546a79f9f8034d755fd3df409f4c6ab64cb4a84ef0f6f881f8348e20f37", "strip_prefix": "xpack-riscv-none-elf-gcc-12.2.0-3", "exec_compatible_with": ["@platforms//os:macos", "@platforms//cpu:arm64"]}, {"name": "riscv_none_elf_darwin_x86_64", "url": "https://github.com/xpack-dev-tools/riscv-none-elf-gcc-xpack/releases/download/v12.2.0-3/xpack-riscv-none-elf-gcc-12.2.0-3-darwin-x64.tar.gz", "sha256": "f277d63d7540f50a57cc1df98911a5721e824f84ad22da37d81fa044bab18126", "strip_prefix": "xpack-riscv-none-elf-gcc-12.2.0-3", "exec_compatible_with": ["@platforms//os:macos", "@platforms//cpu:x86_64"]}, {"name": "riscv_none_elf_linux_aarch64", "url": "https://github.com/xpack-dev-tools/riscv-none-elf-gcc-xpack/releases/download/v12.2.0-3/xpack-riscv-none-elf-gcc-12.2.0-3-linux-arm64.tar.gz", "sha256": "64c70bb0b817bb9d9a700015bbb66450a7f238649346dd680bc897c783c68fb5", "strip_prefix": "xpack-riscv-none-elf-gcc-12.2.0-3", "exec_compatible_with": ["@platforms//os:linux", "@platforms//cpu:arm64"]}, {"name": "riscv_none_elf_linux_x86_64", "url": "https://github.com/xpack-dev-tools/riscv-none-elf-gcc-xpack/releases/download/v12.2.0-3/xpack-riscv-none-elf-gcc-12.2.0-3-linux-x64.tar.gz", "sha256": "0bb5f0c6a36f5197888fcd176e3734ec5b74167b5a631883f72ae3cbd47a97c3", "strip_prefix": "xpack-riscv-none-elf-gcc-12.2.0-3", "exec_compatible_with": ["@platforms//os:linux", "@platforms//cpu:x86_64"]}, {"name": "riscv_none_elf_windows_x86_64", "url": "https://github.com/xpack-dev-tools/riscv-none-elf-gcc-xpack/releases/download/v12.2.0-3/xpack-riscv-none-elf-gcc-12.2.0-3-win32-x64.zip", "sha256": "ced0ba39ed89048f176c9c93174b170443d2dbe669e9a6ddb92c3cfde689578e", "strip_prefix": "xpack-riscv-none-elf-gcc-12.2.0-3", "exec_compatible_with": ["@platforms//os:windows", "@platforms//cpu:x86_64"]}], "13.2.0-1": [{"name": "riscv_none_elf_darwin_arm64", "url": "https://github.com/xpack-dev-tools/riscv-none-elf-gcc-xpack/releases/download/v13.2.0-1/xpack-riscv-none-elf-gcc-13.2.0-1-darwin-arm64.tar.gz", "sha256": "a32037a72288f87b356aefde49e474ad9016f90bb7ad37546bb8f916e58c47e7", "strip_prefix": "xpack-riscv-none-elf-gcc-13.2.0-1", "exec_compatible_with": ["@platforms//os:macos", "@platforms//cpu:arm64"]}, {"name": "riscv_none_elf_darwin_x86_64", "url": "https://github.com/xpack-dev-tools/riscv-none-elf-gcc-xpack/releases/download/v13.2.0-1/xpack-riscv-none-elf-gcc-13.2.0-1-darwin-x64.tar.gz", "sha256": "5b3139c3c3b8a1b49c7791a022d8155c2a16e9d1a02469055027e40a41b288d0", "strip_prefix": "xpack-riscv-none-elf-gcc-13.2.0-1", "exec_compatible_with": ["@platforms//os:macos", "@platforms//cpu:x86_64"]}, {"name": "riscv_none_elf_linux_aarch64", "url": "https://github.com/xpack-dev-tools/riscv-none-elf-gcc-xpack/releases/download/v13.2.0-1/xpack-riscv-none-elf-gcc-13.2.0-1-linux-arm64.tar.gz", "sha256": "6df6ac0dfd2b56a7fe4a2fac74abf7c391a99a906e69aebea097757450683b50", "strip_prefix": "xpack-riscv-none-elf-gcc-13.2.0-1", "exec_compatible_with": ["@platforms//os:linux", "@platforms//cpu:arm64"]}, {"name": "riscv_none_elf_linux_x86_64", "url": "https://github.com/xpack-dev-tools/riscv-none-elf-gcc-xpack/releases/download/v13.2.0-1/xpack-riscv-none-elf-gcc-13.2.0-1-linux-x64.tar.gz", "sha256": "d7eff5c5d778873c3d486e5d2c805b82582e73081f93edb375a1ef5d84764b43", "strip_prefix": "xpack-riscv-none-elf-gcc-13.2.0-1", "exec_compatible_with": ["@platforms//os:linux", "@platforms//cpu:x86_64"]}, {"name": "riscv_none_elf_windows_x86_64", "url": "https://github.com/xpack-dev-tools/riscv-none-elf-gcc-xpack/releases/download/v13.2.0-1/xpack-riscv-none-elf-gcc-13.2.0-1-win32-x64.zip", "sha256": "9e952f2a6b4c423f3df208391c836c7ff67ffee8df7aae6ca8efc59110bd14b7", "strip_prefix": "xpack-riscv-none-elf-gcc-13.2.0-1", "exec_compatible_with": ["@platforms//os:windows", "@platforms//cpu:x86_64"]}], "12.3.0-1": [{"name": "riscv_none_elf_darwin_arm64", "url": "https://github.com/xpack-dev-tools/riscv-none-elf-gcc-xpack/releases/download/v12.3.0-1/xpack-riscv-none-elf-gcc-12.3.0-1-darwin-arm64.tar.gz", "sha256": "54150de972a3e28dee14fc341f5c46f3d25654ac66a23e8e295f68ec8171648a", "strip_prefix": "xpack-riscv-none-elf-gcc-12.3.0-1", "exec_compatible_with": ["@platforms//os:macos", "@platforms//cpu:arm64"]}, {"name": "riscv_none_elf_darwin_x86_64", "url": "https://github.com/xpack-dev-tools/riscv-none-elf-gcc-xpack/releases/download/v12.3.0-1/xpack-riscv-none-elf-gcc-12.3.0-1-darwin-x64.tar.gz", "sha256": "65d50dd2a87f4fd707d4859d4278a8eb01a6bfbba59ed07b5fbf7051a19ae4db", "strip_prefix": "xpack-riscv-none-elf-gcc-12.3.0-1", "exec_compatible_with": ["@platforms//os:macos", "@platforms//cpu:x86_64"]}, {"name": "riscv_none_elf_linux_aarch64", "url": "https://github.com/xpack-dev-tools/riscv-none-elf-gcc-xpack/releases/download/v12.3.0-1/xpack-riscv-none-elf-gcc-12.3.0-1-linux-arm64.tar.gz", "sha256": "6dfb0390838ea37beab031d426e56ca707f0e7b3ec7fea987e4c1ff748b6d3f1", "strip_prefix": "xpack-riscv-none-elf-gcc-12.3.0-1", "exec_compatible_with": ["@platforms//os:linux", "@platforms//cpu:arm64"]}, {"name": "riscv_none_elf_linux_x86_64", "url": "https://github.com/xpack-dev-tools/riscv-none-elf-gcc-xpack/releases/download/v12.3.0-1/xpack-riscv-none-elf-gcc-12.3.0-1-linux-x64.tar.gz", "sha256": "0a7f71150e7b284a01ef739a17a32bafce5db43c012d734d57be5a8c2e2b57b6", "strip_prefix": "xpack-riscv-none-elf-gcc-12.3.0-1", "exec_compatible_with": ["@platforms//os:linux", "@platforms//cpu:x86_64"]}, {"name": "riscv_none_elf_windows_x86_64", "url": "https://github.com/xpack-dev-tools/riscv-none-elf-gcc-xpack/releases/download/v12.3.0-1/xpack-riscv-none-elf-gcc-12.3.0-1-win32-x64.zip", "sha256": "58f3274a990815b87a29e64560dc57c192f9a45b1effc1106f607a50b7f6ccf0", "strip_prefix": "xpack-riscv-none-elf-gcc-12.3.0-1", "exec_compatible_with": ["@platforms//os:windows", "@platforms//cpu:x86_64"]}], "12.3.0-2": [{"name": "riscv_none_elf_darwin_arm64", "url": "https://github.com/xpack-dev-tools/riscv-none-elf-gcc-xpack/releases/download/v12.3.0-2/xpack-riscv-none-elf-gcc-12.3.0-2-darwin-arm64.tar.gz", "sha256": "211f85c5a577069032982dfba1244af513ae2d075e1ee43bddf03bcd8673c02f", "strip_prefix": "xpack-riscv-none-elf-gcc-12.3.0-2", "exec_compatible_with": ["@platforms//os:macos", "@platforms//cpu:arm64"]}, {"name": "riscv_none_elf_darwin_x86_64", "url": "https://github.com/xpack-dev-tools/riscv-none-elf-gcc-xpack/releases/download/v12.3.0-2/xpack-riscv-none-elf-gcc-12.3.0-2-darwin-x64.tar.gz", "sha256": "ef312ce2d7cfd7e667ca10f0ce7a3f0805c0c02e159cedeb9448bff7de236bcb", "strip_prefix": "xpack-riscv-none-elf-gcc-12.3.0-2", "exec_compatible_with": ["@platforms//os:macos", "@platforms//cpu:x86_64"]}, {"name": "riscv_none_elf_linux_aarch64", "url": "https://github.com/xpack-dev-tools/riscv-none-elf-gcc-xpack/releases/download/v12.3.0-2/xpack-riscv-none-elf-gcc-12.3.0-2-linux-arm64.tar.gz", "sha256": "09343a15feafa1b370436d806dc4efba5bce02586ef7f317a894c16615213c27", "strip_prefix": "xpack-riscv-none-elf-gcc-12.3.0-2", "exec_compatible_with": ["@platforms//os:linux", "@platforms//cpu:arm64"]}, {"name": "riscv_none_elf_linux_x86_64", "url": "https://github.com/xpack-dev-tools/riscv-none-elf-gcc-xpack/releases/download/v12.3.0-2/xpack-riscv-none-elf-gcc-12.3.0-2-linux-x64.tar.gz", "sha256": "9921d63c04611954af016b9ca74cd52c1ccb832800d321d67e4e651f16146d16", "strip_prefix": "xpack-riscv-none-elf-gcc-12.3.0-2", "exec_compatible_with": ["@platforms//os:linux", "@platforms//cpu:x86_64"]}, {"name": "riscv_none_elf_windows_x86_64", "url": "https://github.com/xpack-dev-tools/riscv-none-elf-gcc-xpack/releases/download/v12.3.0-2/xpack-riscv-none-elf-gcc-12.3.0-2-win32-x64.zip", "sha256": "87e851ebda6a179e988a33b58593c00e13f6edc55c3c73f913d28f10ab983653", "strip_prefix": "xpack-riscv-none-elf-gcc-12.3.0-2", "exec_compatible_with": ["@platforms//os:windows", "@platforms//cpu:x86_64"]}], "13.2.0-2": [{"name": "riscv_none_elf_darwin_arm64", "url": "https://github.com/xpack-dev-tools/riscv-none-elf-gcc-xpack/releases/download/v13.2.0-2/xpack-riscv-none-elf-gcc-13.2.0-2-darwin-arm64.tar.gz", "sha256": "dfe3123e5e5093b165eaaf18401b802cbb8697f5ec9b0f5cfd99c45e848fd8a7", "strip_prefix": "xpack-riscv-none-elf-gcc-13.2.0-2", "exec_compatible_with": ["@platforms//os:macos", "@platforms//cpu:arm64"]}, {"name": "riscv_none_elf_darwin_x86_64", "url": "https://github.com/xpack-dev-tools/riscv-none-elf-gcc-xpack/releases/download/v13.2.0-2/xpack-riscv-none-elf-gcc-13.2.0-2-darwin-x64.tar.gz", "sha256": "72e65bcad6360eb059096a0fb77f3e3e6c618b1281b89648056c95d1b2749466", "strip_prefix": "xpack-riscv-none-elf-gcc-13.2.0-2", "exec_compatible_with": ["@platforms//os:macos", "@platforms//cpu:x86_64"]}, {"name": "riscv_none_elf_linux_aarch64", "url": "https://github.com/xpack-dev-tools/riscv-none-elf-gcc-xpack/releases/download/v13.2.0-2/xpack-riscv-none-elf-gcc-13.2.0-2-linux-arm64.tar.gz", "sha256": "1c981c611a38dfe5af902089aed570d4dd501eb4ed88d801043e59ab9a62a86a", "strip_prefix": "xpack-riscv-none-elf-gcc-13.2.0-2", "exec_compatible_with": ["@platforms//os:linux", "@platforms//cpu:arm64"]}, {"name": "riscv_none_elf_linux_x86_64", "url": "https://github.com/xpack-dev-tools/riscv-none-elf-gcc-xpack/releases/download/v13.2.0-2/xpack-riscv-none-elf-gcc-13.2.0-2-linux-x64.tar.gz", "sha256": "52545afb900200fbf65fe05f7ce7090b8a42c64091f4f5d43cae6bb68ea2434a", "strip_prefix": "xpack-riscv-none-elf-gcc-13.2.0-2", "exec_compatible_with": ["@platforms//os:linux", "@platforms//cpu:x86_64"]}, {"name": "riscv_none_elf_windows_x86_64", "url": "https://github.com/xpack-dev-tools/riscv-none-elf-gcc-xpack/releases/download/v13.2.0-2/xpack-riscv-none-elf-gcc-13.2.0-2-win32-x64.zip", "sha256": "28ce9f0cfa09f8d4c638a59fb4e17e3f61c80c47e46f11b2ba505a2a3db602f8", "strip_prefix": "xpack-riscv-none-elf-gcc-13.2.0-2", "exec_compatible_with": ["@platforms//os:windows", "@platforms//cpu:x86_64"]}]}(:Workspace dependencies for the arm none eabi gcc toolchain28
riscv_none_elf_deps!@@toolchains_riscv_gnu//:deps.bzl
���toolchains_riscv_gnu_deps*Define dependencies for a riscv toolchain.*�
�
toolchains_riscv_gnu_deps+
	toolchainThe name of the toolchain. (4
toolchain_prefixThe prefix of the toolchain. (,
versionThe version of the toolchain. (>
archives.A dictionary of version to archive attributes. (*Define dependencies for a riscv toolchain.2>
toolchains_riscv_gnu_deps!@@toolchains_riscv_gnu//:deps.bzl
``�-riscv_gnu_cross_hosted_platform_specific_repoR�
�
-riscv_gnu_cross_hosted_platform_specific_repo.
name"A unique name for this repository. 
exec_compatible_with2[]
patches2[]�
repo_mapping�A dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.<p>For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).
 
sha256 
strip_prefix2""
toolchain_prefix x
tools2m["as", "ar", "c++", "cpp", "g++", "gcc", "gdb", "ld", "nm", "objcopy", "objdump", "readelf", "strip", "size"]	
url 
version *R
-riscv_gnu_cross_hosted_platform_specific_repo!@@toolchains_riscv_gnu//:deps.bzl
@@0
.
name"A unique name for this repository. 

exec_compatible_with2[]

patches2[]�
�
repo_mapping�A dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.<p>For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).
 

sha256 

strip_prefix2""

toolchain_prefix z
x
tools2m["as", "ar", "c++", "cpp", "g++", "gcc", "gdb", "ld", "nm", "objcopy", "objdump", "readelf", "strip", "size"]
	
url 

version �toolchains_riscv_gnu_repoR�
�
toolchains_riscv_gnu_repo.
name"A unique name for this repository. 
hosts �
repo_mapping�A dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.<p>For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).
 
toolchain_name 
toolchain_prefix x
tools2m["as", "ar", "c++", "cpp", "g++", "gcc", "gdb", "ld", "nm", "objcopy", "objdump", "readelf", "strip", "size"]
version *>
toolchains_riscv_gnu_repo!@@toolchains_riscv_gnu//:deps.bzl
U,U,0
.
name"A unique name for this repository. 

hosts �
�
repo_mapping�A dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.<p>For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).
 

toolchain_name 

toolchain_prefix z
x
tools2m["as", "ar", "c++", "cpp", "g++", "gcc", "gdb", "ld", "nm", "objcopy", "objdump", "readelf", "strip", "size"]

version }
//toolchain:toolchain.bzlr^
0
toolchains_riscv_gnu	toolchaintoolchain.bzl
toolstools
9>
@�
'//toolchain/archives:riscv_none_elf.bzlr~
>
toolchains_riscv_gnutoolchain/archivesriscv_none_elf.bzl.
riscv_none_elfriscv_none_elf
GU
Wdeps.bzl�
&
toolchains_riscv_gnuextensions.bzl�riscv_toolchainJ�
x
riscv_toolchain)
riscv_none_elf
version2
"13.2.0-1"":
riscv_toolchain'@@toolchains_riscv_gnu//:extensions.bzl
G#G#F
)
riscv_none_elf
version2
"13.2.0-1"

version2
"13.2.0-1"y
	:deps.bzlrj
 
toolchains_riscv_gnudeps.bzl8
riscv_none_elf_depsriscv_none_elf_deps
+>
@�
'//toolchain/archives:riscv_none_elf.bzlr~
>
toolchains_riscv_gnutoolchain/archivesriscv_none_elf.bzl.
riscv_none_elfriscv_none_elf
GU
WModule extension for toolchains 