�8
windowsextensions.bzl�msvc_runtimeMSVC runtime extension.J�
�	
msvc_runtimeMSVC runtime extension.�	
	configureg
architecturesBArchitectures to extract from the resolved MSVC runtime components2["x64", "arm64"]�
msvc_versionkRequired expected MSVC tools version. Only files under Contents/VC/Tools/MSVC/<msvc_version> are extracted.2""^
installer_manifest_url>URL of the resolved/specified Visual Studio installer manifest2""s
installer_manifest_integrityMOptional integrity of the resolved/specified Visual Studio installer manifest2""�
installer_manifest_sha256^Optional integrity (as sha256 hash) of the resolved/specified Visual Studio installer manifest2""�
visual_studio_channel_url�Visual Studio release channel URL used to resolve the installer manifest, use `visual_studio_installer_manifest_url` and `visual_studio_installer_manifest_integrity` for reproducibility instead2""https://aka.ms/vs/stable/channel"�
$visual_studio_installer_manifest_url�Override URL for the Visual Studio installer manifest, if set the installer manifest will not be resolved from a query to `visual_studio_channel_url`2""
*visual_studio_installer_manifest_integrityKOptional SRI integrity for the downloaded Visual Studio installer manifest.2"""/-//windows/private/extensions:msvc_runtime.bzl�
�	
	configureg
architecturesBArchitectures to extract from the resolved MSVC runtime components2["x64", "arm64"]�
msvc_versionkRequired expected MSVC tools version. Only files under Contents/VC/Tools/MSVC/<msvc_version> are extracted.2""^
installer_manifest_url>URL of the resolved/specified Visual Studio installer manifest2""s
installer_manifest_integrityMOptional integrity of the resolved/specified Visual Studio installer manifest2""�
installer_manifest_sha256^Optional integrity (as sha256 hash) of the resolved/specified Visual Studio installer manifest2""�
visual_studio_channel_url�Visual Studio release channel URL used to resolve the installer manifest, use `visual_studio_installer_manifest_url` and `visual_studio_installer_manifest_integrity` for reproducibility instead2""https://aka.ms/vs/stable/channel"�
$visual_studio_installer_manifest_url�Override URL for the Visual Studio installer manifest, if set the installer manifest will not be resolved from a query to `visual_studio_channel_url`2""
*visual_studio_installer_manifest_integrityKOptional SRI integrity for the downloaded Visual Studio installer manifest.2""i
g
architecturesBArchitectures to extract from the resolved MSVC runtime components2["x64", "arm64"]�
�
msvc_versionkRequired expected MSVC tools version. Only files under Contents/VC/Tools/MSVC/<msvc_version> are extracted.2""`
^
installer_manifest_url>URL of the resolved/specified Visual Studio installer manifest2""u
s
installer_manifest_integrityMOptional integrity of the resolved/specified Visual Studio installer manifest2""�
�
installer_manifest_sha256^Optional integrity (as sha256 hash) of the resolved/specified Visual Studio installer manifest2""�
�
visual_studio_channel_url�Visual Studio release channel URL used to resolve the installer manifest, use `visual_studio_installer_manifest_url` and `visual_studio_installer_manifest_integrity` for reproducibility instead2""https://aka.ms/vs/stable/channel"�
�
$visual_studio_installer_manifest_url�Override URL for the Visual Studio installer manifest, if set the installer manifest will not be resolved from a query to `visual_studio_channel_url`2""�

*visual_studio_installer_manifest_integrityKOptional SRI integrity for the downloaded Visual Studio installer manifest.2""�windows_sdk6Windows SDK extension backed by public NuGet packages.J�
�	
windows_sdk6Windows SDK extension backed by public NuGet packages.�
	configurej
architecturesEArchitectures of the Windows SDK to download additionally to the base2["x64", "arm64"]V
windows_sdk_version9Windows SDK NuGet package version, e.g. `10.0.26100.7705`2""d
windows_sdk_integrityE(optional) dict from Windows SDK NuGet package ID to integrity string
2{}�
transformations�Dict of source path patterns to transformations applied when run on case-sensitive filesystems.

Supports exact paths and `**/*.ext` patterns. Use value `lowercase` to create lowercase aliases.

Example:
```
transformations = {
    "base/c/Include/10.0.26100.0/shared/driverspecs.h": "base/c/Include/10.0.26100.0/shared/DriverSpecs.h",
    "base/c/Include/10.0.26100.0/shared/specstrings.h": "base/c/Include/10.0.26100.0/shared/SpecStrings.h",
    "base/c/Include/10.0.26100.0/um/ole2.h": "base/c/Include/10.0.26100.0/um/Ole2.h",
    "base/c/Include/10.0.26100.0/um/olectl.h": "base/c/Include/10.0.26100.0/um/OleCtl.h",
    "**/*.h": "lowercase",
    "**/*.lib": "lowercase",
    "**/*.Lib": "lowercase",
}
```
2{}".,//windows/private/extensions:windows_sdk.bzl�
�
	configurej
architecturesEArchitectures of the Windows SDK to download additionally to the base2["x64", "arm64"]V
windows_sdk_version9Windows SDK NuGet package version, e.g. `10.0.26100.7705`2""d
windows_sdk_integrityE(optional) dict from Windows SDK NuGet package ID to integrity string
2{}�
transformations�Dict of source path patterns to transformations applied when run on case-sensitive filesystems.

Supports exact paths and `**/*.ext` patterns. Use value `lowercase` to create lowercase aliases.

Example:
```
transformations = {
    "base/c/Include/10.0.26100.0/shared/driverspecs.h": "base/c/Include/10.0.26100.0/shared/DriverSpecs.h",
    "base/c/Include/10.0.26100.0/shared/specstrings.h": "base/c/Include/10.0.26100.0/shared/SpecStrings.h",
    "base/c/Include/10.0.26100.0/um/ole2.h": "base/c/Include/10.0.26100.0/um/Ole2.h",
    "base/c/Include/10.0.26100.0/um/olectl.h": "base/c/Include/10.0.26100.0/um/OleCtl.h",
    "**/*.h": "lowercase",
    "**/*.lib": "lowercase",
    "**/*.Lib": "lowercase",
}
```
2{}l
j
architecturesEArchitectures of the Windows SDK to download additionally to the base2["x64", "arm64"]X
V
windows_sdk_version9Windows SDK NuGet package version, e.g. `10.0.26100.7705`2""f
d
windows_sdk_integrityE(optional) dict from Windows SDK NuGet package ID to integrity string
2{}�
�
transformations�Dict of source path patterns to transformations applied when run on case-sensitive filesystems.

Supports exact paths and `**/*.ext` patterns. Use value `lowercase` to create lowercase aliases.

Example:
```
transformations = {
    "base/c/Include/10.0.26100.0/shared/driverspecs.h": "base/c/Include/10.0.26100.0/shared/DriverSpecs.h",
    "base/c/Include/10.0.26100.0/shared/specstrings.h": "base/c/Include/10.0.26100.0/shared/SpecStrings.h",
    "base/c/Include/10.0.26100.0/um/ole2.h": "base/c/Include/10.0.26100.0/um/Ole2.h",
    "base/c/Include/10.0.26100.0/um/olectl.h": "base/c/Include/10.0.26100.0/um/OleCtl.h",
    "**/*.h": "lowercase",
    "**/*.lib": "lowercase",
    "**/*.Lib": "lowercase",
}
```
2{}pExtensions for bzlmod.

Exposes in repositories a Microsoft Windows SDK or a MSVC runtime headers and libraries.�
windowsrepositories.bzl�http_archive*p
R
http_archive

name (

kwargs(2*
http_archive//windows:repositories.bzl


name (


kwargs(fwindows_dependencies*L
J
windows_dependencies22
windows_dependencies//windows:repositories.bzl�Declare runtime dependencies

These are needed for local dev, and users must install them as well.
See https://docs.bazel.build/versions/main/skylark/deploying.html#dependencies 