�%
(
	xkbcommonxkbcommon_config_checks.bzlt
//autoconf:checks.bzlrY
)
rules_cc_autoconfautoconf
checks.bzl
checkschecks
28
:�#	XKBCOMMON_CONFIG_CHECKSj�#2�#
��{"code":"","define":"_GNU_SOURCE","define_value":"1","define_value_fail":"1","language":"c","name":"ac_cv_define__GNU_SOURCE","type":"define"}
��{"code":"","define":"EXIT_INVALID_USAGE","define_value":"2","define_value_fail":"2","language":"c","name":"ac_cv_define_EXIT_INVALID_USAGE","type":"define"}
��{"code":"","define":"DFLT_XKB_CONFIG_ROOT","define_value":"\"/usr/share/X11/xkb\"","define_value_fail":"\"/usr/share/X11/xkb\"","language":"c","name":"ac_cv_define_DFLT_XKB_CONFIG_ROOT","type":"define"}
��{"code":"","define":"DFLT_XKB_CONFIG_EXTRA_PATH","define_value":"\"/etc/xkb\"","define_value_fail":"\"/etc/xkb\"","language":"c","name":"ac_cv_define_DFLT_XKB_CONFIG_EXTRA_PATH","type":"define"}
��{"code":"","define":"XLOCALEDIR","define_value":"\"/usr/share/X11/locale\"","define_value_fail":"\"/usr/share/X11/locale\"","language":"c","name":"ac_cv_define_XLOCALEDIR","type":"define"}
��{"code":"","define":"DEFAULT_XKB_RULES","define_value":"\"evdev\"","define_value_fail":"\"evdev\"","language":"c","name":"ac_cv_define_DEFAULT_XKB_RULES","type":"define"}
��{"code":"","define":"DEFAULT_XKB_MODEL","define_value":"\"pc105\"","define_value_fail":"\"pc105\"","language":"c","name":"ac_cv_define_DEFAULT_XKB_MODEL","type":"define"}
��{"code":"","define":"DEFAULT_XKB_LAYOUT","define_value":"\"us\"","define_value_fail":"\"us\"","language":"c","name":"ac_cv_define_DEFAULT_XKB_LAYOUT","type":"define"}
��{"code":"","define":"DEFAULT_XKB_VARIANT","define_value":"NULL","define_value_fail":"NULL","language":"c","name":"ac_cv_define_DEFAULT_XKB_VARIANT","type":"define"}
��{"code":"","define":"DEFAULT_XKB_OPTIONS","define_value":"NULL","define_value_fail":"NULL","language":"c","name":"ac_cv_define_DEFAULT_XKB_OPTIONS","type":"define"}
zx{"code":"#include <unistd.h>\n","define":"HAVE_UNISTD_H","language":"c","name":"ac_cv_header_unistd_h","type":"compile"}
��{"code":"#ifdef __cplusplus\nextern \"C\"\n#endif\n#if defined _MSC_VER\n#pragma comment(lib, \"legacy_stdio_definitions.lib\")\nint asprintf ();\n#else\nchar asprintf ();\n#endif\n\nint main(void) {\n    return asprintf();\n}\n","define":"HAVE_ASPRINTF","language":"c","name":"ac_cv_func_asprintf","type":"function"}
��{"code":"#ifdef __cplusplus\nextern \"C\"\n#endif\n#if defined _MSC_VER\n#pragma comment(lib, \"legacy_stdio_definitions.lib\")\nint eaccess ();\n#else\nchar eaccess ();\n#endif\n\nint main(void) {\n    return eaccess();\n}\n","define":"HAVE_EACCESS","language":"c","name":"ac_cv_func_eaccess","type":"function"}
��{"code":"#ifdef __cplusplus\nextern \"C\"\n#endif\n#if defined _MSC_VER\n#pragma comment(lib, \"legacy_stdio_definitions.lib\")\nint euidaccess ();\n#else\nchar euidaccess ();\n#endif\n\nint main(void) {\n    return euidaccess();\n}\n","define":"HAVE_EUIDACCESS","language":"c","name":"ac_cv_func_euidaccess","type":"function"}
��{"code":"#ifdef __cplusplus\nextern \"C\"\n#endif\n#if defined _MSC_VER\n#pragma comment(lib, \"legacy_stdio_definitions.lib\")\nint mmap ();\n#else\nchar mmap ();\n#endif\n\nint main(void) {\n    return mmap();\n}\n","define":"HAVE_MMAP","language":"c","name":"ac_cv_func_mmap","type":"function"}
��{"code":"#ifdef __cplusplus\nextern \"C\"\n#endif\n#if defined _MSC_VER\n#pragma comment(lib, \"legacy_stdio_definitions.lib\")\nint secure_getenv ();\n#else\nchar secure_getenv ();\n#endif\n\nint main(void) {\n    return secure_getenv();\n}\n","define":"HAVE_SECURE_GETENV","language":"c","name":"ac_cv_func_secure_getenv","type":"function"}
��{"code":"#ifdef __cplusplus\nextern \"C\"\n#endif\n#if defined _MSC_VER\n#pragma comment(lib, \"legacy_stdio_definitions.lib\")\nint strndup ();\n#else\nchar strndup ();\n#endif\n\nint main(void) {\n    return strndup();\n}\n","define":"HAVE_STRNDUP","language":"c","name":"ac_cv_func_strndup","type":"function"}
��{"code":"#ifdef __cplusplus\nextern \"C\"\n#endif\n#if defined _MSC_VER\n#pragma comment(lib, \"legacy_stdio_definitions.lib\")\nint vasprintf ();\n#else\nchar vasprintf ();\n#endif\n\nint main(void) {\n    return vasprintf();\n}\n","define":"HAVE_VASPRINTF","language":"c","name":"ac_cv_func_vasprintf","type":"function"}
��{"code":"#ifdef __cplusplus\nextern \"C\"\n#endif\n#if defined _MSC_VER\n#pragma comment(lib, \"legacy_stdio_definitions.lib\")\nint __secure_getenv ();\n#else\nchar __secure_getenv ();\n#endif\n\nint main(void) {\n    return __secure_getenv();\n}\n","define":"HAVE___SECURE_GETENV","language":"c","name":"ac_cv_func___secure_getenv","type":"function"}?Autoconf-style checks used to generate libxkbcommon's config.h. 