�
yqyq.bzl�yq�Invoke yq with an expression on a set of input files.

yq is capable of parsing and outputting to other formats. See their [docs](https://mikefarah.gitbook.io/yq) for more examples.
*�
�

yq
nameName of the rule (%
srcsList of input file labels (�

expression�yq expression (https://mikefarah.gitbook.io/yq/commands/evaluate).

Defaults to the identity
expression ".". Subject to stamp variable replacements, see [Stamping](./stamping.md).
When stamping is enabled, an environment variable named "STAMP" will be available in the expression.

Be careful to write the filter so that it handles unstamped builds, as in the example above."."(�
args�Additional args to pass to yq.

Note that you do not need to pass _eval_ or _eval-all_ as this
is handled automatically based on the number `srcs`. Passing the output format or the parse format
is optional as these can be guessed based on the file extensions in `srcs` and `outs`.[](�
outs�Name of the output files.

Defaults to a single output with the name plus a ".yaml" extension, or
the extension corresponding to a passed output argument (e.g., "-o=json"). For split operations you
must declare all outputs as the name of the output files depends on the expression.None(H
kwargs<Other common named parameters such as `tags` or `visibility`(�Invoke yq with an expression on a set of input files.

yq is capable of parsing and outputting to other formats. See their [docs](https://mikefarah.gitbook.io/yq) for more examples.
2
yq//yq:yq.bzl

nameName of the rule ('
%
srcsList of input file labels (�
�

expression�yq expression (https://mikefarah.gitbook.io/yq/commands/evaluate).

Defaults to the identity
expression ".". Subject to stamp variable replacements, see [Stamping](./stamping.md).
When stamping is enabled, an environment variable named "STAMP" will be available in the expression.

Be careful to write the filter so that it handles unstamped builds, as in the example above."."(�
�
args�Additional args to pass to yq.

Note that you do not need to pass _eval_ or _eval-all_ as this
is handled automatically based on the number `srcs`. Passing the output format or the parse format
is optional as these can be guessed based on the file extensions in `srcs` and `outs`.[](�
�
outs�Name of the output files.

Defaults to a single output with the name plus a ".yaml" extension, or
the extension corresponding to a passed output argument (e.g., "-o=json"). For split operations you
must declare all outputs as the name of the output files depends on the expression.None(J
H
kwargs<Other common named parameters such as `tags` or `visibility`(Public API for calling yq 