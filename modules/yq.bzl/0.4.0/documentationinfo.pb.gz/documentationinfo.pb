�/
yqyq.bzl�
yq_test�Assert that the given YAML files have the same semantic content.

Uses yq to filter each file, recursively sort mapping keys, and serialize
the results as compact JSON before comparing them. The default filter of
`"."` compares each whole file.
*�
�
yq_test3
name'Name of the resulting diff_test target. (J
file1=A YAML file, or `None` to evaluate `filter1` with null input. (P
file2CAnother YAML file, or `None` to evaluate `filter2` with null input. (4
filter1"A yq expression to apply to file1."."(4
filter2"A yq expression to apply to file2."."(C
kwargs7Additional named arguments for the resulting diff_test.(�Assert that the given YAML files have the same semantic content.

Uses yq to filter each file, recursively sort mapping keys, and serialize
the results as compact JSON before comparing them. The default filter of
`"."` compares each whole file.
2
yq_test//yq:yq.bzl5
3
name'Name of the resulting diff_test target. (L
J
file1=A YAML file, or `None` to evaluate `filter1` with null input. (R
P
file2CAnother YAML file, or `None` to evaluate `filter2` with null input. (6
4
filter1"A yq expression to apply to file1."."(6
4
filter2"A yq expression to apply to file2."."(E
C
kwargs7Additional named arguments for the resulting diff_test.(�yq�Invoke yq with an expression on a set of input files.

yq is capable of parsing and outputting to other formats. See their [docs](https://mikefarah.gitbook.io/yq) for more examples.
*�
�
yq
nameName of the rule (%
srcsList of input file labels (�

expression�yq expression (https://mikefarah.gitbook.io/yq/commands/evaluate). Cannot be used with `expression_file`.

Defaults to the identity expression ".".
Subject to stamp variable replacements, see [Stamping](./stamping.md).
When stamping is enabled, an environment variable named "STAMP" will be available in the expression.

Be careful to write the filter so that it handles unstamped builds, as in the example above.None(�
args�Additional args to pass to yq.

Note that you do not need to pass _eval_ or _eval-all_ as this is handled automatically based on the number `srcs`.
Passing the output format or the parse format is optional as these can be guessed based on the file extensions in `srcs` and `outs`.[](�
outs�Name of the output files.

Defaults to a single output with the name plus a ".yaml" extension, or the extension corresponding to a passed output argument such as `"-o=json"`.
For split operations you must declare all outputs, as the name of the output files depends on the expression.None(Y
expression_file>File containing a yq expression (alternative to `expression`).None(H
kwargs<Other common named parameters such as `tags` or `visibility`(�Invoke yq with an expression on a set of input files.

yq is capable of parsing and outputting to other formats. See their [docs](https://mikefarah.gitbook.io/yq) for more examples.
2
yq//yq:yq.bzl

nameName of the rule ('
%
srcsList of input file labels (�
�

expression�yq expression (https://mikefarah.gitbook.io/yq/commands/evaluate). Cannot be used with `expression_file`.

Defaults to the identity expression ".".
Subject to stamp variable replacements, see [Stamping](./stamping.md).
When stamping is enabled, an environment variable named "STAMP" will be available in the expression.

Be careful to write the filter so that it handles unstamped builds, as in the example above.None(�
�
args�Additional args to pass to yq.

Note that you do not need to pass _eval_ or _eval-all_ as this is handled automatically based on the number `srcs`.
Passing the output format or the parse format is optional as these can be guessed based on the file extensions in `srcs` and `outs`.[](�
�
outs�Name of the output files.

Defaults to a single output with the name plus a ".yaml" extension, or the extension corresponding to a passed output argument such as `"-o=json"`.
For split operations you must declare all outputs, as the name of the output files depends on the expression.None([
Y
expression_file>File containing a yq expression (alternative to `expression`).None(J
H
kwargs<Other common named parameters such as `tags` or `visibility`(�Load in your `BUILD` file:

```starlark
load("@yq.bzl", "yq")
```

Examples
--------

Remove fields:
```starlark
yq(
    name = "safe-config",
    srcs = ["config.yaml"],
    expression = "del(.credentials)",
)
```

Load an expression from a file:
```starlark
yq(
    name = "safe-config-from-file",
    srcs = ["config.yaml"],
    expression_file = "remove-credentials.yq",
)
```

Merge two yaml documents:
```starlark
yq(
    name = "ab",
    srcs = [
        "a.yaml",
        "b.yaml",
    ],
    expression = ". as $item ireduce ({}; . * $item )",
)
```

Split a yaml file into several files:
```starlark
yq(
    name = "split",
    srcs = ["multidoc.yaml"],
    outs = [
        "first.yml",
        "second.yml",
    ],
    args = [
        "-s '.a'",  # Split expression
        "--no-doc", # Exclude document separator --
    ],
)
```

Convert a yaml file to json:
```starlark
yq(
    name = "convert-to-json",
    srcs = ["foo.yaml"],
    args = ["-o=json"],
    outs = ["foo.json"],
)
```

Convert a json file to yaml:
```starlark
yq(
    name = "convert-to-yaml",
    srcs = ["bar.json"],
    args = ["-P"],
    outs = ["bar.yaml"],
)
```

Call yq in a genrule:
```starlark
genrule(
    name = "generate",
    srcs = ["farm.yaml"],
    outs = ["genrule_output.yaml"],
    cmd = "$(YQ_BIN) '.moo = "cow"' $(location farm.yaml) > $@",
    toolchains = ["@yq_toolchains//:resolved_toolchain"],
)
```

With --stamp, causes properties to be replaced by version control info.
```starlark
yq(
    name = "stamped",
    srcs = ["package.yaml"],
    expression = "|".join([
        "load(strenv(STAMP)) as $stamp",
        # Provide a default using the "alternative operator" in case $stamp is empty dict.
        ".version = ($stamp.BUILD_EMBED_LABEL // "<unstamped>")",
    ]),
)
``` 